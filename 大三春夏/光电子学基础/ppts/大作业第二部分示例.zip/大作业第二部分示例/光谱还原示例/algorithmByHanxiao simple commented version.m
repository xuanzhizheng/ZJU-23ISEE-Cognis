function outputData = algorithmByHanxiao( wavelength,gunits,c )
% INPUTS:
% the input variables wavelength,units,c should be imported from the
% dataset: measurement.mat, where:
%   wavelength: wavelengths within the spectral range, a vector
%   gunits:     Response curves, a matrix
%   c:          the measured signals, a vector
%
% OUTPUTS
%   ts:     (N*1 double)  wavelengths
%   fs:     (N*1 double)  spectrum
%   outputParams (struct)
%   coeff.alphaN - reconstructed Gaussian basis coefficients
%   coeff.varphiN - basis functioin for plotting, but not used in integration

method_id = 2;              % what kind of basis should be selected, 2 means Gaussian
parameter_choice_id = 3;    % method to determine the regularization factor, 3 for GCV method, 2 for Lcurve

%%%%%%%%%%%%Following is the settings for different regularization methods
%%%%%%%%%%%%and the reconstruction
if method_id ==2 % Gaussian Basis
    params.method = 'Expansion';
    params.basis.name = 'Guassian';
    params.basis.coeff = struct('fwhmN',0.01); % coefficient
    
    params.numOfti = 50; % number of Gaussian basis functions
    params.numOfts = 100; % the number of wavelengths in the plotted spectrum
    
    % settings
    params.regularisation.method = 'Tikhonov';
    params.regularisation.order = 0;
    params.regularisation.lambda = 1e-6; % the variance of c
    
    % parameter choice
    if parameter_choice_id == 1 % no automatic choice
        params.parameterChoice.flag = false;
    elseif parameter_choice_id == 2 % L-curve
        params.parameterChoice.flag = true;
        if params.parameterChoice.flag && ~isempty(params.regularisation.method)
            assert(strcmp(params.regularisation.method,'Tikhonov'));
            params.parameterChoice.method = 'L-curve';
        end
    elseif parameter_choice_id == 3 % GCV
        params.parameterChoice.flag = true;
        params.parameterChoice.method = 'GCV';
    else
        error('unknown method');
    end
        
    % optimisation 
    params.optimisation = optimoptions('lsqlin',...
        'Display','off'); 
end

    checkParams(params); % check the struct 'params' is complete or not
    
    %%%%%%%%%%%%%%%%%This function is the entry of the main reconstruction part
    outputData = calculateSpectrum(wavelength,gunits,c,params);
    %%%%%%%%%%%%%%%%%
    
    assert(isscalar(outputData));
end

%% functions
function outputData = calculateSpectrum(wavelength,gunits,c,params)
    
    %ts are the wavelengths, fs are the reconstructed spectrum
    %wavelength is the wavelengths of the response curves
    %const is a structure that contains the values of the max and min wavelengths and the
    %normalized max and min wavelengths
    [ts,fs,coeff,const] = computeSpecturm(wavelength,gunits,c,params);
    
    %plot recosntructed spectrum i.e. fs, wavelength is the wavelengths of the
    %response curves
    %the size of ts and wavelength can be different, but the max wavelength
    %and min wavelength are the same
    showSpectrum(ts,fs,wavelength,'off');
    
    outputData = struct('ts',ts,...
        'fs',fs,'coeff',coeff,'const',const);
end

%% Compute Spectrum from Measurements
function [ts,fs,coeff,const] = computeSpecturm(wavelength,gunits,c,params)
    % pre-procesing preparation, only normalizations here
    % data includes all the normalized input data
    % const is a structure that contains the values of the max and min wavelengths and the
    % normalized max and min wavelengths
    [data,const] = preProcessing(gunits,wavelength,c);
    
    
    % compute basis function varphi
    coeff = computeBasisFunctions(data,const,params);
        % check output coeff
        assert(all(isfield(coeff,{'varphiN','alphaN','tiN','tsN'})),...
            'The variable coeff does not have varphi or tiN');

    % ------------------------------------------------------------------------
    % obtain the normalised basis function f(x)
    fsN = getfsN(coeff,params);

    % denormalise data
    [ts,fs] = getDenomralisVariables(coeff.tsN,fsN,const);

end

%response interpolation
function k = getKernel(w,wavelengthN,gunitsN,unit_id)
% SPECIFICATION
%   get the value of response (of the unit_id sensor) at the wavelength of
%   "w"
%
% INPUTS:
%   w: the interpolated wavelength
%   wavelength: your measured wavelength
%   gunits: your measured unit responses (a matrix)
%   unit_id: the unit you want to interpolate
%
% OUTPUT:
%   k: the value of response of the unit with id = unit_id at the
%   wavelength of "w"

    k = interp1(wavelengthN,gunitsN(:,unit_id),w,'spline',0);
    % this function will assign any interpolation beyond the input range of
    % wavelength (490nm to 630nm) to zero.
end


% fs is the reconstructed spectrum, to plot spectrum with higher resolution
function fsN = getfsN(coeff,params)

    % check input 
    assert(length(coeff.tsN)==params.numOfts); 

    fsN = zeros(params.numOfts,1);
    
    if strcmpi(params.method,'Expansion')
        %coeff.alphaN is fitted coefficients for basis functions
        %coeff.alphaN is the alpha in eqn. (S7) in science paper
        fsN = coeff.varphiN*coeff.alphaN;
    else
        error('unknown method!');
    end

end

%% Compute Basis Function
function coeff = computeBasisFunctions(data,const,params)

if strcmpi(params.method,'Expansion')
    switch params.basis.name
        case 'Guassian'
            
            %coeff is a struct contains matrix A in equation S8 and
            %Laplacian matrix the regularization
            coeff = computeCoefficient_Gaussian(data,const,params);
            
            if params.parameterChoice.flag
                %params.regularisation.lambda is the regularization factor
                %gamma in equation S8 in the Science paper
                params.regularisation.lambda = ...
                    computeRegularisationParameter(data,coeff,params);
                disp(params.regularisation.lambda);
            end
            
            % compute the basis function varphiN
            % params.numOfti is the number of Gaussian basis functions
            coeff.alphaN = zeros(params.numOfti,1);
            
            %%%%%%%%%%%%%%%%%%%%%%here is the reconstruction part!!!!!
            if isempty(coeff.L) % no regularisation
                coeff.alphaN = lsqlin(coeff.A,data.cN,...
                    [],[],[],[],zeros(params.numOfti,1),[],[],params.optimisation);
            else % use the augmented matrix for regularization
            %            |A|          |c|
            %            | | * alpha= | |  here, A and c are defined in Eq. S8
            %    gamma^2*|L|          |0|   
                coeff.alphaN = lsqlin([coeff.A;params.regularisation.lambda*coeff.L],...
                    [data.cN';zeros(size(coeff.L,1),1)],...
                    [],[],[],[],zeros(params.numOfti,1),[],[],params.optimisation);
            end
            %%%%%%%%%%%%%%%%%%%%%%here is the reconstruction part!!!!!
        otherwise
            error('unknown basis');
    end
    
end
    
end

% L2-Gaussian
function coeff = computeCoefficient_Gaussian(data,const,params)
    % input check
    assert(all(isfield(data,{'cN','gunitsN','wavelengthN'})),...
        'the input variable: data, does have all required fields');
    
    % center wavelengths of the Gaussian basis, in normalized form
    % params.numOfti is the number of gaussian basis
    tiN = linspace(const.minWavelengthN,const.maxWavelengthN,...
        params.numOfti);
    
    %tsN(i) is the center wavelength of Gaussian basis for plotting purpose,normalzied
    tsN = linspace(const.minWavelengthN,const.maxWavelengthN,...
        params.numOfts);
    
    sigma = params.basis.coeff.fwhmN/(2*sqrt(2*log(2))); %fwhmN is the delta_d in Science paper
    fvarphi = @(x,x0) 1/(sigma*sqrt(2*pi))*exp(-0.5*((x - x0 )/sigma).^2); % this is the function calculate Gaussian curve
    
    % compute matrix A in equation S7 in Science paper 2019
    coeff.A = getA(fvarphi,tiN,data,const,params);
        %coeff.H = coeff.A'*coeff.A;
        %coeff.f = -coeff.A'*data.cN';
    
    % compute the regularization matrix
    % coeff.L is the Laplacian matrix, has a dimension of NumOfBasis*NumOfBasis
    coeff.L = getL(params);
    
    coeff.varphiN = zeros(params.numOfts,params.numOfti);
    coeff.tiN = tiN;
    coeff.tsN = tsN;
    
    %%%%tsN(i) is the center wavelengths of Gaussian basis
    %%%%tiN is a vector containing normalzied wavelengths
    %%%%params.numOfts is the number of Gaussian basis functions for
    %%%%plotting
    %%%%coeff.varphiN is the matrix containing all the Gaussian basis
    %%%%functions
    for i = 1:params.numOfts
        coeff.varphiN(i,:) = fvarphi(tiN,tsN(i));
    end
    
    % check output
    assert(isscalar(coeff)); % ensure that coeff is a scalar struct   
        
    %%%%generege matrix A in eqn. (S8)
    function A = getA(fPhi,tiN,data,const,params)
        % intialisation
        const.numOfUnits %number of detectors,params.numOfti is the number of Gaussian basis 
        A = zeros(const.numOfUnits,params.numOfti);

        for p = 1:const.numOfUnits
            for j = 1:params.numOfti
                A(p,j) = quadgk(@(s) ...
                getKernel(s,data.wavelengthN,data.gunitsN,p) ...
                .* fPhi(s,tiN(j)),...
                    const.minWavelengthN,const.maxWavelengthN);
            end
        end
    end

    % generate Laplacian matrix, there are a few types
    function L = getL(params)
        switch params.regularisation.order
            case -1 || params.regularisation.lambda==0
                L = [];
            case 0
                L = diag(ones(params.numOfti,1));
            case 1
                L = diag(ones(params.numOfti,1))+...
                    diag(-ones(params.numOfti-1,1),1);
            case 2
                L = 2*diag(ones(params.numOfti,1))+...
                    diag(-ones(params.numOfti-1,1),1)+...
                    diag(-ones(params.numOfti-1,1),-1);
            otherwise
                error('undefined');
        end
    end

end


%% Parameter Choice - L-curve method or GCV method, choose GCV here
function lambda = computeRegularisationParameter(data,coeff,params)

    % if use L-curve method to find the lambda
    if strcmp(params.parameterChoice.method,'L-curve')
        lambda = computeParameter_Lcurve(data,coeff,params);
    elseif strcmp(params.parameterChoice.method,'GCV')     
        lambda = computeParameter_GCV(data,coeff,params);
    end
end

% GCV method
% see: Discrete inverse problems insight and algorithms, pp96.
function lambda = computeParameter_GCV(data,coeff,params)
    [U,S,~] = svd(coeff.A);
    sigma = diag(S);
    
    m = size(coeff.A,1);
    
    options = optimset('Display','iter');

    lambda = fmincon(@(x) computeGCV(x,U,sigma,data.cN',m),...
        params.regularisation.lambda,[],[],[],[],0,[],[],options);
    
    assert(isscalar(lambda)); % check output
    
    %
    function G = computeGCV(lambda,U,sigma,b,m)
        
        numOfcol = length(sigma);
        % compute filter factor
        fi = sigma.^2./(sigma.^2+lambda^2);
        
        rho = 0;
        
        for i = 1:numOfcol 
            beta = U(:,i)'*b;
            
            % compute the residual norm
            rho = rho + ((1-fi(i))*beta).^2;
        end
        
        
        G = rho/(m-sum(fi))^2;
    end
end

%% Utility
% Pre-processing, only normalization is implemented here
function [data,const] = preProcessing(gunits,wavelength,c)

    [data.cN,const.Mc] = getNormalisedVariable(c); % normalise c
    [data.gunitsN,const.Mgunits] = getNormalisedVariable(gunits); % normalise gunits
    [data.wavelengthN,const.Mwavelength] = getNormalisedVariable(wavelength); % normalise wavelength

    const.numOfUnits = size(gunits,2); % total number of units
    const.maxWavelength = max(wavelength); % 
    const.minWavelength = min(wavelength); % 
    const.maxWavelengthN = max(data.wavelengthN);
    const.minWavelengthN = min(data.wavelengthN);

    % Check output data type
    assert(iscolumn(data.wavelengthN),'wavelength must be a column vector');
    assert(isrow(data.cN),'the response c must be a row vector');

    assert(size(data.gunitsN,1)==length(data.wavelengthN), ...
        'the number of rows in gunits must match the length of wavelength');
    assert(size(data.gunitsN,2)==length(data.cN), ...
        'the number of column in gunits must match the length of c');
end

% check input params
function checkParams(params)
    % check if the fields of the struct 'params' are complete
    assert(all(isfield(params,...
        {'method','numOfti','numOfts','regularisation','optimisation'})),...
        'params does not have all required fields');
    
    if strcmp(params.method,'Expansion')
        if isfield(params,'regularisation')
            assert(isfield(params.regularisation,'order'));
            assert(isfield(params.regularisation,'lambda'));
        end
    end
end

% normalisation, divide all the elements with the maximum element
function [yn,yM] = getNormalisedVariable(y)
    if isvector(y)
        yM = max(y);
        yn = y./yM;
    elseif ismatrix(y)
        yM = max(max(y));
        yn = y./yM;
    else
        error('unknown data type');
    end
end

% de-normalisation
function [ts,fs] = getDenomralisVariables(tsN,fsN,const)
    ts = tsN*const.Mwavelength; %convert to real wavelength
    fs = fsN*(const.Mc/const.Mwavelength/const.Mgunits);
end

% visualisation, plot the figure Zongyin sent in his email
function showSpectrum(ts,fs,wavelength,HoldOff)
    figure(1);
    if strcmpi(HoldOff,'off')
        hold on;
    elseif strcmpi(HoldOff,'on')
        hold on;
    end
    
    plot(ts,fs)
    grid on
    xlim([min(wavelength),max(wavelength)]);
    set(gcf,'color','w');
    xlabel('wavelength/nm');
    
end
