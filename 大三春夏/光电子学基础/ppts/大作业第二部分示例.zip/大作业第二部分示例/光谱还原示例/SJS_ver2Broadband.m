%version 2022/04/14, coded by Weiwei, Hoon, and Fedor
clear;clc;close all;

%**************parameter settings*************
NumWavelengths=19;          %Number of Wavelengths for reconstruction
NumWavelengthsPlot=NumWavelengths*10;   %number of wavelengths for plotting
NumGaussianBasis=19;        %Number of Gaussian Basis
MinLambda=400;              %smallest wavelength
MaxLambda=850;              %largest wavelength

%**************loading data*************
ResponseCurves=load('CalibrationData.txt');                     %Responsivity as function of wavelength at different Vg (Detectors)
ResponseCurves=ResponseCurves/max(max(ResponseCurves));         %normalize the input response curve

% % input monochromatic data 
% % TargetWavelength=580;
% % CSRefSpectrum=load(['ReferenceSpectrum' num2str(TargetWavelength) '.txt']);
% % CSRefSpectrum(:,2)=CSRefSpectrum(:,2)/max(CSRefSpectrum(:,2));
% % MeasuredSignals=load(['MeausuredSignals' num2str(TargetWavelength) '.txt']);    %Photocurrent as function of Vg (Detectors)

% %input broadband data
SignalFilename='MeausuredSignalsBroadSimple.txt';
CSFilename='ReferenceSpectrumBroadSimple.txt';
CSRefSpectrum=load(CSFilename);
CSRefSpectrum(:,2)=CSRefSpectrum(:,2)/max(CSRefSpectrum(:,2));
MeasuredSignals=load(SignalFilename);        %Photocurrent as function of Vg (Detectors)

NumCol=size(MeasuredSignals,2);                                 %Multiple data processing from matrix of MeasuredSignals
ReconstructedSpectrum=zeros(NumWavelengths,NumCol);             %Initialization of reconstructed spectrum for reconstruction
ReconstructedSpectrumPlot=zeros(NumWavelengthsPlot,NumCol);     %Initialization of reconstructed spectrum for plotting
    
VecOfLambdas=linspace(MinLambda,MaxLambda,NumWavelengths)'/MaxLambda;           %normalized wavelengths
VecOfLambdasPlot=linspace(MinLambda,MaxLambda,NumWavelengthsPlot)'/MaxLambda;   %normalized wavelengths

for i=1:NumCol

    MeasuredSignals(:,i)=MeasuredSignals(:,i)/max(max(MeasuredSignals(:,i)));  %normalized measured signals

    %**************generate Gaussian Basis here
    GaussianCenter=linspace(MinLambda,MaxLambda,NumGaussianBasis)'/MaxLambda;   %normalized wavelength centers
    GaussianBasis=zeros(NumWavelengths,NumGaussianBasis);                       %all the Gaussian basis for reconstruction
    GaussianBasisPlot=zeros(NumWavelengthsPlot,NumGaussianBasis);               %all the Gaussian basis for plotting
    
    %suggestions: complex spectra (0.075 < FWHM < 0.125), the spectral imaging (0.15 < FWHM < 0.2)
    MinFWHM=6;                                  %unit:0.001, so it is 0.001
    MaxFWHM=150;                                %unit:0.001, so it is 0.150
    FWHM=linspace(MinFWHM,MaxFWHM,MaxFWHM-MinFWHM+1)/1000;  %all the tested FWHM's
    ReguTerm=zeros(MaxFWHM-MinFWHM+1,1);        %record 2-norm of regularization term for all FWHMs's   
    MeasuResidual=zeros(MaxFWHM-MinFWHM+1,1);   %record 2-norm of signal residual for all FWHMs's
    
    for k=1:MaxFWHM-MinFWHM+1
    
        GaussianSigma=FWHM(k)/(2*sqrt(2*log(2)));      %standard deviation of the Gaussian basis, nomalized

        for j=1:NumGaussianBasis                                                    %generate all the Guassian basis
            GaussianBasis(:,j)=exp(-0.5*((VecOfLambdas-GaussianCenter(j))/GaussianSigma).^2);
            GaussianBasis(:,j)=1/GaussianSigma/sqrt(2*pi)*GaussianBasis(:,j);

            GaussianBasisPlot(:,j)=exp(-0.5*((VecOfLambdasPlot-GaussianCenter(j))/GaussianSigma).^2);
            GaussianBasisPlot(:,j)=1/GaussianSigma/sqrt(2*pi)*GaussianBasisPlot(:,j);
        end

        %**************reconstruction with matlab function 'lsqnonneg'
        LaplacianMatrix=eye(NumGaussianBasis);      %generate Laplacian matrix, which is an identity matrix
        WeightMatrix=ResponseCurves*GaussianBasis;  %this code is equivalent to Eq. (S6) in Science paper

        OptimalGamma=FindOptGamma_GCV(MeasuredSignals(:,i),WeightMatrix);   %find optimal gamma here with GCV method

        AugWeightMatrix=[WeightMatrix;OptimalGamma^2*LaplacianMatrix];      %generate augumented matrix
        AugMeasuredSignals=[MeasuredSignals(:,i);zeros(NumGaussianBasis,1)];%generated augumented vector

        [GaussianCoefficients,resnorm,residual,exitflag,output] = ...       %least square solution with non-negativity constraint
        lsqnonneg(AugWeightMatrix,AugMeasuredSignals);

        ReconstructedSpectrum(:,i)=GaussianBasis*GaussianCoefficients;      %reconstructed spectrum
        ReconstructedSpectrum(:,i)=ReconstructedSpectrum(:,i)/max(ReconstructedSpectrum(:,i));              %normalization

        ReconstructedSpectrumPlot(:,i)=GaussianBasisPlot*GaussianCoefficients;                              %reconstructed spectrum for plotting
        ReconstructedSpectrumPlot(:,i)=ReconstructedSpectrumPlot(:,i)/max(ReconstructedSpectrumPlot(:,i));  %normalization

        SimulatedSignals=ResponseCurves*GaussianBasis*GaussianCoefficients; %simulated signal with reconstructed spectrum

        ReguTerm(k)=norm(LaplacianMatrix*GaussianCoefficients)^2;           %2-norm of the regularization term
        MeasuResidual(k)=norm(SimulatedSignals-MeasuredSignals)^2;          %2-norm of the signal residual
    end 
       
    %data visualization
    figure('color','white','position',[0 0 1200 900]);
    subplot(2,2,1);hold on;
    plot(FWHM,MeasuResidual,'+');ylabel('||S^{m}-S^{s}||^2');xlabel('FWHM');title(SignalFilename); %plot 2-norm of signal residual vs. FWHM
    subplot(2,2,2);
    plot(FWHM,ReguTerm,'+');ylabel('||\alpha||^2');xlabel('FWHM') %plot 2-norm of regularization term vs. FWHM
    subplot(2,2,3);plot(MeasuredSignals(:,i));hold on;plot(SimulatedSignals,'*');
    legend('Measured Signals','Simulated Signals');xlabel('Detector index');ylabel('a.u.')
    title('Comparison between measured and simulated signals')
    subplot(2,2,4);
    plot(VecOfLambdasPlot*MaxLambda,ReconstructedSpectrumPlot,'-r');hold on;
    title(['Spectrum, FWHM=' num2str(FWHM(k))]);ylabel('a.u.');xlabel('\lambda (nm)')
    plot(CSRefSpectrum(:,1),CSRefSpectrum(:,2),'-b');legend('SJS','CS')

end

    %**************GCV method, see: Discrete inverse problems insight and algorithms, pp96.
    function lambda = FindOptGamma_GCV(c,A)
        [U,S,~] = svd(A);
        sigma = diag(S);
        options = optimset('Display','iter');
        InitialGuess=1e-6;  %initial value of Gamma
        lambda = fmincon(@(x) computeGCV(x,U,sigma,c,size(A,1)),...
           InitialGuess,[],[],[],[],0,[],[],options);
        assert(isscalar(lambda)); % check output
        function G = computeGCV(Gamma,U,sigma,b,m)
            numOfcol = length(sigma);
            fi = sigma.^2./(sigma.^2+Gamma^2); % compute filter factor
            rho = 0;
            for i = 1:numOfcol 
                beta = U(:,i)'*b;
                % compute the residual norm
                rho = rho + ((1-fi(i))*beta).^2;
            end
            G = rho/(m-sum(fi))^2;
        end
    end