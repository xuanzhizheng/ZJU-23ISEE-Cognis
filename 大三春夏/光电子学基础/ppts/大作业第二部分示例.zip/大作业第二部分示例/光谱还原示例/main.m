    close all
    clear
    load singlelight1.mat
    current = current;
    %load data1.mat
    %outputData = algorithmByHanxiao( wavelength,gunits,c )
    outputData = algorithmByHanxiao( wavelength,responses,current )
    hold on
