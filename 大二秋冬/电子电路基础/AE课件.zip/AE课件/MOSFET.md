![image-20241115143122146](../../../../AppData/Roaming/Typora/typora-user-images/image-20241115143122146.png)

![image-20241115145020000](../../../AppData/Roaming/Typora/typora-user-images/image-20241115145020000.png)

![image-20241115145030044](../../../AppData/Roaming/Typora/typora-user-images/image-20241115145030044.png)

![image-20241115145051586](../../../AppData/Roaming/Typora/typora-user-images/image-20241115145051586.png)

![image-20241115145103007](../../../AppData/Roaming/Typora/typora-user-images/image-20241115145103007.png)