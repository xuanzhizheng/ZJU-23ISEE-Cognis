#!/usr/bin/env python3
"""
2.1 工作集特征化实验
测试三个trace文件的指令和数据工作集大小
"""

import subprocess
import os
import re
import matplotlib.pyplot as plt
import matplotlib
from pathlib import Path

# 支持中文显示
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 配置参数
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
CODE_DIR = PROJECT_DIR / "code"
TRACES_DIR = PROJECT_DIR / "ext_traces"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "2.1_outputs"

# 三个样本trace文件
TRACE_FILES = ["cc.trace", "spice.trace", "tex.trace"]

# 固定参数
BLOCK_SIZE = 4          # 块大小固定为4字节

# 缓存大小范围：从4字节开始，每次翻倍，直到128KB
# 注意：更大的缓存可能导致模拟器问题（相联度过高）
CACHE_SIZES = [2**i for i in range(2, 18)]  # 4, 8, 16, ..., 131072

def run_simulation(trace_path, cache_size, cache_type):
    """
    运行缓存模拟器
    
    参数:
        trace_path: trace文件路径
        cache_size: 缓存大小（字节）
        cache_type: 'i' for instruction cache, 'd' for data cache
    
    返回:
        命中率 (0-1之间的浮点数)
    """
    sim_path = CODE_DIR / "sim"
    
    # 计算相联度（全相联 = 块数）
    associativity = cache_size // BLOCK_SIZE
    
    # 构建命令
    # 为了单独测试I-cache或D-cache，将另一个设置为足够大的值
    if cache_type == 'i':
        # 测试指令缓存，数据缓存设为128KB（足够大）
        cmd = [str(sim_path), "-is", str(cache_size), "-ds", "131072",
               "-bs", str(BLOCK_SIZE), "-a", str(associativity),
               "-wb", "-wa", str(trace_path)]
    else:
        # 测试数据缓存，指令缓存设为128KB（足够大）
        cmd = [str(sim_path), "-is", "131072", "-ds", str(cache_size),
               "-bs", str(BLOCK_SIZE), "-a", str(associativity),
               "-wb", "-wa", str(trace_path)]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=CODE_DIR)
        output = result.stdout
        
        # 解析命中率
        if cache_type == 'i':
            # 查找指令缓存命中率
            match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', output)
            if match:
                return float(match.group(2))
        else:
            # 查找数据缓存命中率 - 需要找到DATA部分的
            lines = output.split('\n')
            in_data_section = False
            for line in lines:
                if 'DATA' in line:
                    in_data_section = True
                elif in_data_section and 'miss rate:' in line:
                    match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', line)
                    if match:
                        return float(match.group(2))
        
        print(f"Warning: Could not parse hit rate for cache_size={cache_size}, type={cache_type}")
        return 0.0
            
    except subprocess.TimeoutExpired:
        print(f"Timeout for cache_size={cache_size}, type={cache_type}")
        return 0.0
    except Exception as e:
        print(f"Error: {e}")
        return 0.0

def find_working_set_size(sizes, rates, improvement_threshold=0.0001):
    """
    确定工作集大小（饱和点：命中率增长不再显著的最小缓存大小）
    
    参数:
        sizes: 缓存大小列表
        rates: 命中率列表
        improvement_threshold: 命中率改进阈值（默认0.01%），低于此值视为饱和
    
    返回:
        工作集大小（字节）
    """
    if len(rates) < 2:
        return sizes[-1] if sizes else 0
    
    # 从后往前找最后一个有任何增长的点
    # 饱和点 = 最后一个有增长点的缓存大小
    last_growth_idx = -1
    
    for i in range(len(rates) - 1, 0, -1):
        improvement = rates[i] - rates[i-1]
        if improvement > improvement_threshold:
            last_growth_idx = i
            break
    
    # 如果找到了增长点，返回该点的缓存大小
    if last_growth_idx > 0:
        return sizes[last_growth_idx]
    
    # 如果没有找到增长（所有点都不变），返回第一个非零点
    for i, rate in enumerate(rates):
        if rate > 0.0:
            return sizes[i]
    
    return sizes[-1]

def format_size(size_bytes):
    """格式化字节大小"""
    if size_bytes >= 1024:
        return f"{size_bytes // 1024}KB"
    else:
        return f"{size_bytes}B"

def plot_working_set(trace_name, cache_sizes, i_rates, d_rates, i_ws, d_ws, output_dir):
    """
    绘制工作集特征图
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 指令缓存图
    ax1.semilogx(cache_sizes, i_rates, 'b-o', linewidth=2, markersize=5, base=2)
    ax1.set_xlabel('Cache Size (bytes)', fontsize=12)
    ax1.set_ylabel('Hit Rate', fontsize=12)
    ax1.set_title(f'Instruction Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax1.grid(True, alpha=0.3, which='both')
    ax1.set_ylim([0, 1.05])
    
    # 标记工作集大小（饱和点）
    if i_ws in cache_sizes:
        ws_idx = cache_sizes.index(i_ws)
        ax1.axvline(x=i_ws, color='r', linestyle='--', alpha=0.7, linewidth=2, 
                    label=f'Working Set: {format_size(i_ws)}')
        ax1.plot(i_ws, i_rates[ws_idx], 'r*', markersize=15)
    ax1.legend()
    
    # 数据缓存图
    ax2.semilogx(cache_sizes, d_rates, 'g-s', linewidth=2, markersize=5, base=2)
    ax2.set_xlabel('Cache Size (bytes)', fontsize=12)
    ax2.set_ylabel('Hit Rate', fontsize=12)
    ax2.set_title(f'Data Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3, which='both')
    ax2.set_ylim([0, 1.05])
    
    # 标记工作集大小（饱和点）
    if d_ws in cache_sizes:
        ws_idx = cache_sizes.index(d_ws)
        ax2.axvline(x=d_ws, color='r', linestyle='--', alpha=0.7, linewidth=2,
                    label=f'Working Set: {format_size(d_ws)}')
        ax2.plot(d_ws, d_rates[ws_idx], 'r*', markersize=15)
    ax2.legend()
    
    plt.tight_layout()
    
    # 保存图像
    output_path = output_dir / f'working_set_{trace_name}.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"  Plot saved: {output_path}")
    plt.close()

def main():
    """主函数"""
    # 创建输出目录
    plots_dir = OUTPUT_DIR / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)
    
    # 检查模拟器
    sim_path = CODE_DIR / "sim"
    if not sim_path.exists():
        print(f"Error: Simulator not found at {sim_path}")
        print("Please compile the simulator first using 'make' in the code directory")
        return
    
    print("=" * 80)
    print("2.1 Working Set Characterization Experiment")
    print("=" * 80)
    print(f"Block Size: {BLOCK_SIZE} bytes")
    print(f"Associativity: Fully Associative (varies with cache size)")
    print(f"Write Policy: Write-Back with Write-Allocate")
    print(f"Cache Size Range: {CACHE_SIZES[0]} bytes to {CACHE_SIZES[-1]} bytes")
    print(f"Traces: {', '.join(TRACE_FILES)}")
    print("=" * 80)
    
    results = {}
    
    # 对每个trace文件进行实验
    for trace_file in TRACE_FILES:
        trace_path = TRACES_DIR / trace_file
        trace_name = trace_path.stem
        
        if not trace_path.exists():
            print(f"\nWarning: Trace file not found: {trace_path}")
            continue
        
        print(f"\n{'=' * 80}")
        print(f"Processing: {trace_file}")
        print(f"{'=' * 80}")
        
        i_rates = []
        d_rates = []
        
        # 对每个缓存大小运行模拟
        for cache_size in CACHE_SIZES:
            print(f"  Cache Size: {format_size(cache_size):>8} ", end='', flush=True)
            
            # 测试指令缓存
            i_rate = run_simulation(trace_path, cache_size, 'i')
            i_rates.append(i_rate)
            
            # 测试数据缓存
            d_rate = run_simulation(trace_path, cache_size, 'd')
            d_rates.append(d_rate)
            
            print(f"-> I-Hit: {i_rate:.4f}, D-Hit: {d_rate:.4f}")
        
        # 保存结果
        results[trace_name] = {
            'i_rates': i_rates,
            'd_rates': d_rates
        }
        
        # 确定工作集大小（饱和点）
        i_ws = find_working_set_size(CACHE_SIZES, i_rates)
        d_ws = find_working_set_size(CACHE_SIZES, d_rates)
        
        print(f"\n  Instruction Working Set Size (saturation point): {format_size(i_ws)} ({i_ws} bytes)")
        print(f"  Data Working Set Size (saturation point): {format_size(d_ws)} ({d_ws} bytes)")
        
        # 绘制图表
        plot_working_set(trace_name, CACHE_SIZES, i_rates, d_rates, i_ws, d_ws, plots_dir)
    
    # 生成综合报告
    print(f"\n{'=' * 80}")
    print("SUMMARY REPORT - Question 2")
    print(f"{'=' * 80}")
    print(f"{'Trace':<15} {'Instruction WS':<25} {'Data WS':<25}")
    print("-" * 80)
    
    report_lines = []
    report_lines.append("=" * 80)
    report_lines.append("2.1 Working Set Characterization - Experiment Report")
    report_lines.append("=" * 80)
    report_lines.append("")
    report_lines.append("QUESTION 1: Experiment Explanation")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("What this experiment does:")
    report_lines.append("This experiment characterizes the working set size by measuring cache hit rate")
    report_lines.append("as a function of cache size. We use a split cache to separately measure")
    report_lines.append("instruction and data cache behavior.")
    report_lines.append("")
    report_lines.append("How it works:")
    report_lines.append("- Start with a very small cache (4 bytes)")
    report_lines.append("- Double the cache size each iteration")
    report_lines.append("- Record the hit rate at each size")
    report_lines.append("- Continue until hit rate plateaus (becomes insensitive to cache size)")
    report_lines.append("")
    report_lines.append("Configuration:")
    report_lines.append(f"- Block Size: {BLOCK_SIZE} bytes (eliminates spatial locality effects)")
    report_lines.append("- Associativity: Fully Associative (number of blocks, eliminates conflict misses)")
    report_lines.append("- Write Policy: Write-Back with Write-Allocate")
    report_lines.append("- Cache Type: Split (separate I-cache and D-cache)")
    report_lines.append("")
    report_lines.append("Significance of plot features:")
    report_lines.append("")
    report_lines.append("1. Initial steep rise: As cache grows, more of the working set fits,")
    report_lines.append("   dramatically reducing capacity misses and increasing hit rate.")
    report_lines.append("")
    report_lines.append("2. Saturation point (working set size): Marks where hit rate improvement")
    report_lines.append("   becomes negligible (< 1% per doubling). This is where the cache becomes")
    report_lines.append("   large enough to hold most of the actively used data/instructions.")
    report_lines.append("")
    report_lines.append("3. Plateau: Hit rate stabilizes. Further increasing cache size provides")
    report_lines.append("   diminishing returns. The remaining misses are compulsory (first access)")
    report_lines.append("   and some capacity misses from non-repetitive accesses.")
    report_lines.append("")
    report_lines.append("4. Never reaches 100%: Due to compulsory misses (first-time accesses) and")
    report_lines.append("   some data/instructions that are accessed only once or very infrequently.")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 2: Working Set Sizes (at saturation point)")
    report_lines.append("-" * 80)
    report_lines.append(f"{'Trace':<15} {'Instruction WS':<25} {'Data WS':<25}")
    report_lines.append("-" * 80)
    
    for trace_name in sorted(results.keys()):
        i_ws = find_working_set_size(CACHE_SIZES, results[trace_name]['i_rates'])
        d_ws = find_working_set_size(CACHE_SIZES, results[trace_name]['d_rates'])
        
        line = f"{trace_name:<15} {format_size(i_ws):>10} ({i_ws:>8} bytes)  {format_size(d_ws):>10} ({d_ws:>8} bytes)"
        print(line)
        report_lines.append(line)
    
    report_lines.append("")
    report_lines.append("-" * 80)
    report_lines.append("Note: Working set size is defined as the saturation point - the minimum")
    report_lines.append("      cache size where hit rate improvement becomes negligible (< 1% per")
    report_lines.append("      doubling of cache size). This represents the actual working set of")
    report_lines.append("      the program, beyond which adding more cache provides diminishing returns.")
    report_lines.append("")
    
    # 保存报告
    report_path = OUTPUT_DIR / "experiment_report.txt"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report_lines))
    
    print(f"\n{'=' * 80}")
    print(f"Experiment completed!")
    print(f"Report saved: {report_path}")
    print(f"Plots saved in: {plots_dir}")
    print(f"{'=' * 80}")

if __name__ == "__main__":
    main()
