#!/usr/bin/env python3
"""
2.4 内存带宽分析
比较不同写策略对内存流量的影响
"""

import subprocess
import os
import re
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib

# 支持中文显示
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 配置参数
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
CODE_DIR = PROJECT_DIR / "code"
TRACES_DIR = PROJECT_DIR / "ext_traces"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "2.4_outputs"

# 三个样本trace文件
TRACE_FILES = ["cc.trace", "spice.trace", "tex.trace"]

# 实验1：比较WT vs WB（固定write-no-allocate）
# 实验配置
EXPERIMENT_1_CONFIGS = [
    {"size": 8192, "block": 64, "assoc": 2},
    {"size": 8192, "block": 128, "assoc": 2},
    {"size": 16384, "block": 64, "assoc": 2},
    {"size": 16384, "block": 128, "assoc": 4},
]

# 实验2：比较WA vs NWA（固定write-back）
EXPERIMENT_2_CONFIGS = [
    {"size": 8192, "block": 64, "assoc": 2},
    {"size": 8192, "block": 128, "assoc": 2},
    {"size": 16384, "block": 64, "assoc": 2},
    {"size": 16384, "block": 128, "assoc": 4},
]

def run_simulation(trace_path, cache_size, block_size, assoc, write_policy, alloc_policy):
    """
    运行缓存模拟器
    
    返回:
        dict: 包含所有统计信息的字典
    """
    sim_path = CODE_DIR / "sim"
    
    # 构建命令
    write_flag = "-wb" if write_policy == "WB" else "-wt"
    alloc_flag = "-wa" if alloc_policy == "WA" else "-nw"
    
    cmd = [str(sim_path), 
           "-is", str(cache_size), 
           "-ds", str(cache_size),
           "-bs", str(block_size), 
           "-a", str(assoc),
           write_flag, alloc_flag,
           str(trace_path)]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=CODE_DIR)
        output = result.stdout
        
        # 解析统计信息
        stats = {
            'i_accesses': 0,
            'i_misses': 0,
            'i_replacements': 0,
            'd_accesses': 0,
            'd_misses': 0,
            'd_replacements': 0,
            'demand_fetches': 0,
            'copies_back': 0,
        }
        
        lines = output.split('\n')
        section = None
        
        for line in lines:
            if 'INSTRUCTIONS' in line:
                section = 'inst'
            elif 'DATA' in line:
                section = 'data'
            elif 'TRAFFIC' in line:
                section = 'traffic'
            elif section == 'inst':
                if 'accesses:' in line:
                    match = re.search(r'accesses:\s+(\d+)', line)
                    if match: stats['i_accesses'] = int(match.group(1))
                elif 'misses:' in line:
                    match = re.search(r'misses:\s+(\d+)', line)
                    if match: stats['i_misses'] = int(match.group(1))
                elif 'replace:' in line:
                    match = re.search(r'replace:\s+(\d+)', line)
                    if match: stats['i_replacements'] = int(match.group(1))
            elif section == 'data':
                if 'accesses:' in line:
                    match = re.search(r'accesses:\s+(\d+)', line)
                    if match: stats['d_accesses'] = int(match.group(1))
                elif 'misses:' in line:
                    match = re.search(r'misses:\s+(\d+)', line)
                    if match: stats['d_misses'] = int(match.group(1))
                elif 'replace:' in line:
                    match = re.search(r'replace:\s+(\d+)', line)
                    if match: stats['d_replacements'] = int(match.group(1))
            elif section == 'traffic':
                if 'demand fetch:' in line:
                    match = re.search(r'demand fetch:\s+(\d+)', line)
                    if match: stats['demand_fetches'] = int(match.group(1))
                elif 'copies back:' in line:
                    match = re.search(r'copies back:\s+(\d+)', line)
                    if match: stats['copies_back'] = int(match.group(1))
        
        # 计算总内存流量
        stats['total_traffic'] = stats['demand_fetches'] + stats['copies_back']
        
        return stats
            
    except subprocess.TimeoutExpired:
        print(f"Timeout")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def format_config(config):
    """格式化配置为字符串"""
    size_kb = config['size'] // 1024
    return f"{size_kb}KB-{config['block']}B-{config['assoc']}way"

def run_experiment_1(trace_file):
    """实验1：比较WT vs WB（固定write-no-allocate）"""
    trace_path = TRACES_DIR / trace_file
    trace_name = trace_path.stem
    
    print(f"\n{'='*80}")
    print(f"Experiment 1: Write-Through vs Write-Back (Write-No-Allocate)")
    print(f"Trace: {trace_file}")
    print(f"{'='*80}")
    
    results = []
    
    for config in EXPERIMENT_1_CONFIGS:
        config_str = format_config(config)
        print(f"\nConfig: {config_str}")
        
        # Write-Through + No-Allocate
        print(f"  Testing WT+NWA...", end=' ', flush=True)
        wt_stats = run_simulation(trace_path, config['size'], config['block'], 
                                  config['assoc'], "WT", "NWA")
        if wt_stats:
            print(f"Traffic: {wt_stats['total_traffic']:,} words")
        
        # Write-Back + No-Allocate
        print(f"  Testing WB+NWA...", end=' ', flush=True)
        wb_stats = run_simulation(trace_path, config['size'], config['block'], 
                                  config['assoc'], "WB", "NWA")
        if wb_stats:
            print(f"Traffic: {wb_stats['total_traffic']:,} words")
        
        if wt_stats and wb_stats:
            results.append({
                'config': config_str,
                'wt_traffic': wt_stats['total_traffic'],
                'wb_traffic': wb_stats['total_traffic'],
                'wt_demand': wt_stats['demand_fetches'],
                'wt_copyback': wt_stats['copies_back'],
                'wb_demand': wb_stats['demand_fetches'],
                'wb_copyback': wb_stats['copies_back'],
                'reduction': (wt_stats['total_traffic'] - wb_stats['total_traffic']) / wt_stats['total_traffic'] * 100
            })
    
    return results

def run_experiment_2(trace_file):
    """实验2：比较WA vs NWA（固定write-back）"""
    trace_path = TRACES_DIR / trace_file
    trace_name = trace_path.stem
    
    print(f"\n{'='*80}")
    print(f"Experiment 2: Write-Allocate vs Write-No-Allocate (Write-Back)")
    print(f"Trace: {trace_file}")
    print(f"{'='*80}")
    
    results = []
    
    for config in EXPERIMENT_2_CONFIGS:
        config_str = format_config(config)
        print(f"\nConfig: {config_str}")
        
        # Write-Back + Write-Allocate
        print(f"  Testing WB+WA...", end=' ', flush=True)
        wa_stats = run_simulation(trace_path, config['size'], config['block'], 
                                  config['assoc'], "WB", "WA")
        if wa_stats:
            print(f"Traffic: {wa_stats['total_traffic']:,} words")
        
        # Write-Back + No-Allocate
        print(f"  Testing WB+NWA...", end=' ', flush=True)
        nwa_stats = run_simulation(trace_path, config['size'], config['block'], 
                                   config['assoc'], "WB", "NWA")
        if nwa_stats:
            print(f"Traffic: {nwa_stats['total_traffic']:,} words")
        
        if wa_stats and nwa_stats:
            results.append({
                'config': config_str,
                'wa_traffic': wa_stats['total_traffic'],
                'nwa_traffic': nwa_stats['total_traffic'],
                'wa_demand': wa_stats['demand_fetches'],
                'wa_copyback': wa_stats['copies_back'],
                'nwa_demand': nwa_stats['demand_fetches'],
                'nwa_copyback': nwa_stats['copies_back'],
                'reduction': (wa_stats['total_traffic'] - nwa_stats['total_traffic']) / wa_stats['total_traffic'] * 100
            })
    
    return results

def plot_results(all_results_exp1, all_results_exp2, output_dir):
    """绘制结果对比图"""
    
    for trace_name in all_results_exp1.keys():
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        
        # 实验1数据
        exp1_data = all_results_exp1[trace_name]
        configs = [r['config'] for r in exp1_data]
        wt_traffic = [r['wt_traffic'] for r in exp1_data]
        wb_traffic = [r['wb_traffic'] for r in exp1_data]
        
        # 图1: WT vs WB 总流量对比
        x = range(len(configs))
        width = 0.35
        ax1.bar([i - width/2 for i in x], wt_traffic, width, label='Write-Through', color='#ff9999')
        ax1.bar([i + width/2 for i in x], wb_traffic, width, label='Write-Back', color='#66b3ff')
        ax1.set_xlabel('Configuration', fontsize=11)
        ax1.set_ylabel('Memory Traffic (words)', fontsize=11)
        ax1.set_title(f'{trace_name}: Write-Through vs Write-Back (NWA)', fontsize=12, fontweight='bold')
        ax1.set_xticks(x)
        ax1.set_xticklabels(configs, rotation=45, ha='right', fontsize=9)
        ax1.legend()
        ax1.grid(axis='y', alpha=0.3)
        
        # 图2: WT vs WB 流量分解
        wt_demand = [r['wt_demand'] for r in exp1_data]
        wt_copyback = [r['wt_copyback'] for r in exp1_data]
        wb_demand = [r['wb_demand'] for r in exp1_data]
        wb_copyback = [r['wb_copyback'] for r in exp1_data]
        
        x_pos = range(len(configs) * 2)
        ax2.bar([i*2 for i in range(len(configs))], wt_demand, width, label='WT Demand Fetch', color='#ff9999')
        ax2.bar([i*2 for i in range(len(configs))], wt_copyback, width, bottom=wt_demand, label='WT Copy Back', color='#ffcccc')
        ax2.bar([i*2+1 for i in range(len(configs))], wb_demand, width, label='WB Demand Fetch', color='#66b3ff')
        ax2.bar([i*2+1 for i in range(len(configs))], wb_copyback, width, bottom=wb_demand, label='WB Copy Back', color='#b3d9ff')
        ax2.set_xlabel('Configuration', fontsize=11)
        ax2.set_ylabel('Memory Traffic (words)', fontsize=11)
        ax2.set_title(f'{trace_name}: Traffic Breakdown (WT vs WB)', fontsize=12, fontweight='bold')
        ax2.set_xticks([i*2+0.5 for i in range(len(configs))])
        ax2.set_xticklabels(configs, rotation=45, ha='right', fontsize=9)
        ax2.legend(fontsize=9)
        ax2.grid(axis='y', alpha=0.3)
        
        # 实验2数据
        exp2_data = all_results_exp2[trace_name]
        wa_traffic = [r['wa_traffic'] for r in exp2_data]
        nwa_traffic = [r['nwa_traffic'] for r in exp2_data]
        
        # 图3: WA vs NWA 总流量对比
        ax3.bar([i - width/2 for i in x], wa_traffic, width, label='Write-Allocate', color='#99ff99')
        ax3.bar([i + width/2 for i in x], nwa_traffic, width, label='No-Write-Allocate', color='#ffcc99')
        ax3.set_xlabel('Configuration', fontsize=11)
        ax3.set_ylabel('Memory Traffic (words)', fontsize=11)
        ax3.set_title(f'{trace_name}: Write-Allocate vs No-Write-Allocate (WB)', fontsize=12, fontweight='bold')
        ax3.set_xticks(x)
        ax3.set_xticklabels(configs, rotation=45, ha='right', fontsize=9)
        ax3.legend()
        ax3.grid(axis='y', alpha=0.3)
        
        # 图4: WA vs NWA 流量分解
        wa_demand = [r['wa_demand'] for r in exp2_data]
        wa_copyback = [r['wa_copyback'] for r in exp2_data]
        nwa_demand = [r['nwa_demand'] for r in exp2_data]
        nwa_copyback = [r['nwa_copyback'] for r in exp2_data]
        
        ax4.bar([i*2 for i in range(len(configs))], wa_demand, width, label='WA Demand Fetch', color='#99ff99')
        ax4.bar([i*2 for i in range(len(configs))], wa_copyback, width, bottom=wa_demand, label='WA Copy Back', color='#ccffcc')
        ax4.bar([i*2+1 for i in range(len(configs))], nwa_demand, width, label='NWA Demand Fetch', color='#ffcc99')
        ax4.bar([i*2+1 for i in range(len(configs))], nwa_copyback, width, bottom=nwa_demand, label='NWA Copy Back', color='#ffe6cc')
        ax4.set_xlabel('Configuration', fontsize=11)
        ax4.set_ylabel('Memory Traffic (words)', fontsize=11)
        ax4.set_title(f'{trace_name}: Traffic Breakdown (WA vs NWA)', fontsize=12, fontweight='bold')
        ax4.set_xticks([i*2+0.5 for i in range(len(configs))])
        ax4.set_xticklabels(configs, rotation=45, ha='right', fontsize=9)
        ax4.legend(fontsize=9)
        ax4.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        
        # 创建plots子目录
        plots_dir = output_dir / 'plots'
        plots_dir.mkdir(parents=True, exist_ok=True)
        
        output_path = plots_dir / f'memory_bandwidth_{trace_name}.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"\n  Plot saved: {output_path}")
        plt.close()

def main():
    """主函数"""
    # 创建输出目录
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 检查模拟器
    sim_path = CODE_DIR / "sim"
    if not sim_path.exists():
        print(f"Error: Simulator not found at {sim_path}")
        return
    
    print("=" * 80)
    print("2.4 Memory Bandwidth Analysis")
    print("=" * 80)
    
    all_results_exp1 = {}
    all_results_exp2 = {}
    
    # 对每个trace运行两个实验
    for trace_file in TRACE_FILES:
        trace_path = TRACES_DIR / trace_file
        if not trace_path.exists():
            print(f"\nWarning: Trace file not found: {trace_path}")
            continue
        
        trace_name = trace_path.stem
        
        # 实验1: WT vs WB
        exp1_results = run_experiment_1(trace_file)
        all_results_exp1[trace_name] = exp1_results
        
        # 实验2: WA vs NWA
        exp2_results = run_experiment_2(trace_file)
        all_results_exp2[trace_name] = exp2_results
    
    # 绘制图表
    print(f"\n{'='*80}")
    print("Generating plots...")
    print(f"{'='*80}")
    plot_results(all_results_exp1, all_results_exp2, OUTPUT_DIR)
    
    # 生成报告
    print(f"\n{'='*80}")
    print("Generating report...")
    print(f"{'='*80}")
    
    report_lines = []
    report_lines.append("=" * 80)
    report_lines.append("2.4 Memory Bandwidth Analysis - Experiment Report")
    report_lines.append("=" * 80)
    report_lines.append("")
    report_lines.append("EXPERIMENT OVERVIEW")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("This experiment analyzes the impact of different write policies on memory traffic.")
    report_lines.append("")
    report_lines.append("Experiment 1: Write-Through vs Write-Back (with Write-No-Allocate)")
    report_lines.append("  - Compares WT and WB cache with NWA policy")
    report_lines.append("  - Measures total memory traffic (demand fetches + copy backs)")
    report_lines.append("")
    report_lines.append("Experiment 2: Write-Allocate vs Write-No-Allocate (with Write-Back)")
    report_lines.append("  - Compares WA and NWA allocation policies with WB cache")
    report_lines.append("  - Measures impact of allocation policy on memory traffic")
    report_lines.append("")
    report_lines.append("")
    
    # 实验1结果
    report_lines.append("EXPERIMENT 1: WRITE-THROUGH vs WRITE-BACK (NWA)")
    report_lines.append("=" * 80)
    report_lines.append("")
    
    for trace_name in sorted(all_results_exp1.keys()):
        report_lines.append(f"\n{trace_name.upper()}")
        report_lines.append("-" * 80)
        report_lines.append(f"{'Config':<20} {'WT Traffic':>15} {'WB Traffic':>15} {'Reduction':>12}")
        report_lines.append("-" * 80)
        
        for result in all_results_exp1[trace_name]:
            line = f"{result['config']:<20} {result['wt_traffic']:>15,} {result['wb_traffic']:>15,} {result['reduction']:>11.2f}%"
            report_lines.append(line)
        
        # 平均减少
        avg_reduction = sum(r['reduction'] for r in all_results_exp1[trace_name]) / len(all_results_exp1[trace_name])
        report_lines.append("-" * 80)
        report_lines.append(f"Average traffic reduction with WB: {avg_reduction:.2f}%")
        report_lines.append("")
    
    report_lines.append("")
    report_lines.append("QUESTION 1: Which cache has smaller memory traffic - WT or WB? Why?")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("ANSWER: Write-Back (WB) cache generates LESS memory traffic than Write-Through (WT).")
    report_lines.append("")
    report_lines.append("REASONS:")
    report_lines.append("")
    report_lines.append("1. WRITE BEHAVIOR DIFFERENCE:")
    report_lines.append("   - Write-Through: EVERY write goes to memory immediately")
    report_lines.append("     * Write hit → write to cache AND memory (2 operations)")
    report_lines.append("     * Write miss → write to memory only")
    report_lines.append("     * Result: ALL writes generate memory traffic")
    report_lines.append("")
    report_lines.append("   - Write-Back: Writes go to memory ONLY on eviction")
    report_lines.append("     * Write hit → write to cache only, mark dirty")
    report_lines.append("     * Write miss → depends on allocation policy")
    report_lines.append("     * Result: Only DIRTY block evictions generate write traffic")
    report_lines.append("")
    report_lines.append("2. TEMPORAL LOCALITY EXPLOITATION:")
    report_lines.append("   - If a cache block is written multiple times before eviction:")
    report_lines.append("     * WT: Each write → 1 memory write (N writes → N memory writes)")
    report_lines.append("     * WB: Multiple writes → 1 memory write on eviction")
    report_lines.append("   - WB coalesces multiple writes to the same block")
    report_lines.append("")
    report_lines.append("3. READ VS WRITE TRAFFIC:")
    report_lines.append("   - Both policies have similar read traffic (demand fetches)")
    report_lines.append("   - Difference is in WRITE traffic:")
    report_lines.append("     * WT: demand_fetch + ALL_WRITES")
    report_lines.append("     * WB: demand_fetch + DIRTY_EVICTIONS")
    report_lines.append("     * Typically: DIRTY_EVICTIONS << ALL_WRITES")
    report_lines.append("")
    report_lines.append("")
    
    report_lines.append("QUESTION 2: Is there any scenario where WT would have less traffic?")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("ANSWER: Yes, but it's RARE. WT could have equal or less traffic in these scenarios:")
    report_lines.append("")
    report_lines.append("SCENARIO 1: No Writes at All")
    report_lines.append("  - If workload is read-only, both WT and WB have identical traffic")
    report_lines.append("  - No write-through operations, no dirty evictions")
    report_lines.append("  - Traffic = demand fetches only")
    report_lines.append("")
    report_lines.append("SCENARIO 2: Write-Once-Never-Read Pattern (Streaming Writes)")
    report_lines.append("  - Data is written once and never accessed again before eviction")
    report_lines.append("  - Example: Writing output to a buffer that's immediately flushed")
    report_lines.append("  - WT: 1 write to memory")
    report_lines.append("  - WB: 1 fetch (if write allocate) + 1 write on eviction = 2 operations")
    report_lines.append("  - BUT: This requires write-allocate policy; with NWA, both are similar")
    report_lines.append("")
    report_lines.append("SCENARIO 3: Very Low Cache Hit Rate")
    report_lines.append("  - If cache is thrashing (everything is immediately evicted):")
    report_lines.append("    * Every write becomes a dirty eviction in WB")
    report_lines.append("    * Traffic becomes similar to WT")
    report_lines.append("  - However, WT still has overhead of writing on EVERY operation")
    report_lines.append("")
    report_lines.append("SCENARIO 4: Small Block Size + Large Working Set")
    report_lines.append("  - If blocks are very small and working set is very large:")
    report_lines.append("    * WB must write back dirty blocks frequently")
    report_lines.append("    * Could approach WT traffic in extreme cases")
    report_lines.append("")
    report_lines.append("PRACTICAL REALITY:")
    report_lines.append("  - In almost all real workloads, WB generates significantly less traffic")
    report_lines.append("  - Programs exhibit temporal locality in writes")
    report_lines.append("  - Multiple writes to same location before eviction are common")
    report_lines.append("  - This is why modern processors use WB caches")
    report_lines.append("")
    report_lines.append("")
    
    # 实验2结果
    report_lines.append("EXPERIMENT 2: WRITE-ALLOCATE vs WRITE-NO-ALLOCATE (WB)")
    report_lines.append("=" * 80)
    report_lines.append("")
    
    for trace_name in sorted(all_results_exp2.keys()):
        report_lines.append(f"\n{trace_name.upper()}")
        report_lines.append("-" * 80)
        report_lines.append(f"{'Config':<20} {'WA Traffic':>15} {'NWA Traffic':>15} {'Difference':>12}")
        report_lines.append("-" * 80)
        
        for result in all_results_exp2[trace_name]:
            diff = result['reduction']
            line = f"{result['config']:<20} {result['wa_traffic']:>15,} {result['nwa_traffic']:>15,} {diff:>11.2f}%"
            report_lines.append(line)
        
        report_lines.append("")
    
    report_lines.append("")
    report_lines.append("QUESTION 3: Which has smaller memory traffic - WA or NWA? Why?")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("ANSWER: It DEPENDS on the write pattern, but generally Write-Allocate (WA)")
    report_lines.append("generates LESS traffic for most workloads.")
    report_lines.append("")
    report_lines.append("WRITE-ALLOCATE (WA) Behavior:")
    report_lines.append("  - Write miss → Allocate block in cache (fetch from memory)")
    report_lines.append("  - Write data to cache block")
    report_lines.append("  - Mark block as dirty")
    report_lines.append("  - On eviction → Write back to memory")
    report_lines.append("  - Traffic: 1 fetch + eventual 1 write-back")
    report_lines.append("")
    report_lines.append("NO-WRITE-ALLOCATE (NWA) Behavior:")
    report_lines.append("  - Write miss → Write directly to memory (no cache allocation)")
    report_lines.append("  - If block is later READ → Fetch from memory")
    report_lines.append("  - Traffic: 1 write + possible 1 fetch")
    report_lines.append("")
    report_lines.append("WHY WA IS USUALLY BETTER:")
    report_lines.append("")
    report_lines.append("1. SPATIAL LOCALITY:")
    report_lines.append("   - When you write to address X, you often read/write nearby addresses")
    report_lines.append("   - WA: Fetch block once, use for multiple accesses")
    report_lines.append("   - NWA: Write directly, then fetch again if needed")
    report_lines.append("")
    report_lines.append("2. TEMPORAL LOCALITY:")
    report_lines.append("   - Written data is often read back soon (write-then-read)")
    report_lines.append("   - WA: Data already in cache")
    report_lines.append("   - NWA: Must fetch from memory")
    report_lines.append("")
    report_lines.append("3. MULTIPLE WRITES TO SAME BLOCK:")
    report_lines.append("   - WA: Block in cache, subsequent writes are free")
    report_lines.append("   - NWA: Each write goes to memory")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 4: Scenarios where NWA could be better?")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("SCENARIO 1: Write-Only Streams (No Read-After-Write)")
    report_lines.append("  - Writing output that's never read back")
    report_lines.append("  - Example: Logging, video encoding output")
    report_lines.append("  - WA: Fetch (wasted) + Write = 2 operations")
    report_lines.append("  - NWA: Write = 1 operation")
    report_lines.append("  - NWA WINS")
    report_lines.append("")
    report_lines.append("SCENARIO 2: Cache Thrashing")
    report_lines.append("  - Working set much larger than cache")
    report_lines.append("  - Written blocks evicted before reuse")
    report_lines.append("  - WA: Fetch + Write-back = 2 operations (wasted)")
    report_lines.append("  - NWA: Write = 1 operation")
    report_lines.append("  - NWA WINS")
    report_lines.append("")
    report_lines.append("SCENARIO 3: Write-Once Initialization")
    report_lines.append("  - Initializing large arrays")
    report_lines.append("  - Writing values that won't be read until much later")
    report_lines.append("  - NWA avoids polluting cache")
    report_lines.append("")
    report_lines.append("PRACTICAL TRADEOFFS:")
    report_lines.append("  - Most systems use WA because of common read-after-write patterns")
    report_lines.append("  - Some systems use NWA for specific write-only operations")
    report_lines.append("  - Modern processors may have hybrid strategies")
    report_lines.append("  - Example: Non-temporal write instructions (bypass cache)")
    report_lines.append("")
    report_lines.append("")
    
    report_lines.append("SUMMARY OF KEY FINDINGS")
    report_lines.append("=" * 80)
    report_lines.append("")
    report_lines.append("1. Write-Back (WB) significantly reduces memory traffic vs Write-Through (WT)")
    report_lines.append("   - Typical reduction: 20-60% depending on write frequency")
    report_lines.append("   - Reason: Coalesces multiple writes to same block")
    report_lines.append("")
    report_lines.append("2. Write-Allocate (WA) generally reduces traffic vs No-Write-Allocate (NWA)")
    report_lines.append("   - Typical reduction: 5-30% depending on write patterns")
    report_lines.append("   - Reason: Exploits spatial and temporal locality")
    report_lines.append("")
    report_lines.append("3. Best configuration for minimum traffic:")
    report_lines.append("   - Write-Back + Write-Allocate (WB+WA)")
    report_lines.append("   - This is why modern processors use this combination")
    report_lines.append("")
    report_lines.append("4. Exceptions exist but are rare:")
    report_lines.append("   - Write-only streams favor NWA")
    report_lines.append("   - Cache thrashing can make policies equivalent")
    report_lines.append("   - Most real workloads favor WB+WA")
    report_lines.append("")
    report_lines.append("-" * 80)
    report_lines.append("End of Report")
    report_lines.append("=" * 80)
    
    # 保存报告
    report_path = OUTPUT_DIR / "experiment_report.txt"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report_lines))
    
    print(f"\n{'='*80}")
    print("Experiment completed!")
    print(f"Report saved: {report_path}")
    print(f"Plots saved in: {OUTPUT_DIR / 'plots'}")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()
