#!/usr/bin/env python3
"""
2.3 相联度影响分析
测试相联度对缓存命中率的影响
"""

import subprocess
import os
import re
import matplotlib.pyplot as plt
import matplotlib
from pathlib import Path

# 支持中文显示
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 配置参数
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
CODE_DIR = PROJECT_DIR / "code"
TRACES_DIR = PROJECT_DIR / "ext_traces"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "2.3_outputs"

# 三个样本trace文件
TRACE_FILES = ["cc.trace", "spice.trace", "tex.trace"]

# 固定参数
CACHE_SIZE = 8192       # 8 KB
BLOCK_SIZE = 128        # 128 bytes

# 相联度范围：1, 2, 4, 8, 16, 32, 64
ASSOCIATIVITIES = [2**i for i in range(0, 7)]  # 1, 2, 4, 8, 16, 32, 64

def run_simulation(trace_path, associativity):
    """
    运行缓存模拟器
    
    参数:
        trace_path: trace文件路径
        associativity: 相联度
    
    返回:
        (i_hit_rate, d_hit_rate): 指令和数据缓存的命中率
    """
    sim_path = CODE_DIR / "sim"
    
    # 构建命令 - split cache，各8KB
    cmd = [str(sim_path), 
           "-is", str(CACHE_SIZE), 
           "-ds", str(CACHE_SIZE),
           "-bs", str(BLOCK_SIZE), 
           "-a", str(associativity),
           "-wb", "-wa", 
           str(trace_path)]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=CODE_DIR)
        output = result.stdout
        
        i_rate = 0.0
        d_rate = 0.0
        
        # 解析命中率
        lines = output.split('\n')
        in_inst_section = False
        in_data_section = False
        
        for line in lines:
            if 'INSTRUCTIONS' in line:
                in_inst_section = True
                in_data_section = False
            elif 'DATA' in line:
                in_inst_section = False
                in_data_section = True
            elif in_inst_section and 'miss rate:' in line:
                match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', line)
                if match:
                    i_rate = float(match.group(2))
            elif in_data_section and 'miss rate:' in line:
                match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', line)
                if match:
                    d_rate = float(match.group(2))
        
        return i_rate, d_rate
            
    except subprocess.TimeoutExpired:
        print(f"Timeout for associativity={associativity}")
        return 0.0, 0.0
    except Exception as e:
        print(f"Error: {e}")
        return 0.0, 0.0

def find_optimal_associativity(assocs, rates):
    """
    找到最优相联度（命中率最高的）
    """
    if not rates:
        return None
    max_rate = max(rates)
    max_idx = rates.index(max_rate)
    return assocs[max_idx]

def plot_associativity_impact(trace_name, assocs, i_rates, d_rates, output_dir):
    """
    绘制相联度影响图
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 指令缓存图
    ax1.semilogx(assocs, i_rates, 'b-o', linewidth=2, markersize=6, base=2)
    ax1.set_xlabel('Associativity', fontsize=12)
    ax1.set_ylabel('Hit Rate', fontsize=12)
    ax1.set_title(f'Instruction Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax1.grid(True, alpha=0.3, which='both')
    ax1.set_ylim([0.93, 1.005])
    ax1.set_xticks(assocs)
    ax1.set_xticklabels([str(a) for a in assocs])
    
    # 标记最优点
    opt_assoc = find_optimal_associativity(assocs, i_rates)
    if opt_assoc:
        opt_rate = i_rates[assocs.index(opt_assoc)]
        ax1.plot(opt_assoc, opt_rate, 'r*', markersize=15, label=f'Optimal: {opt_assoc}-way')
        ax1.legend()
    
    # 数据缓存图
    ax2.semilogx(assocs, d_rates, 'g-s', linewidth=2, markersize=6, base=2)
    ax2.set_xlabel('Associativity', fontsize=12)
    ax2.set_ylabel('Hit Rate', fontsize=12)
    ax2.set_title(f'Data Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3, which='both')
    ax2.set_ylim([0.93, 1.005])
    ax2.set_xticks(assocs)
    ax2.set_xticklabels([str(a) for a in assocs])
    
    # 标记最优点
    opt_assoc = find_optimal_associativity(assocs, d_rates)
    if opt_assoc:
        opt_rate = d_rates[assocs.index(opt_assoc)]
        ax2.plot(opt_assoc, opt_rate, 'r*', markersize=15, label=f'Optimal: {opt_assoc}-way')
        ax2.legend()
    
    plt.tight_layout()
    
    # 保存图像
    output_path = output_dir / f'associativity_{trace_name}.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"  Plot saved: {output_path}")
    plt.close()

def main():
    """主函数"""
    # 创建输出目录
    plots_dir = OUTPUT_DIR / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)
    
    # 检查模拟器
    sim_path = CODE_DIR / "sim"
    if not sim_path.exists():
        print(f"Error: Simulator not found at {sim_path}")
        print("Please compile the simulator first using 'make' in the code directory")
        return
    
    print("=" * 80)
    print("2.3 Associativity Impact Analysis")
    print("=" * 80)
    print(f"Cache Size: {CACHE_SIZE} bytes (8 KB) per cache")
    print(f"Block Size: {BLOCK_SIZE} bytes")
    print(f"Cache Type: Split I-D cache")
    print(f"Write Policy: Write-Back with Write-Allocate")
    print(f"Associativity Range: {ASSOCIATIVITIES[0]} to {ASSOCIATIVITIES[-1]}")
    print(f"Traces: {', '.join(TRACE_FILES)}")
    print("=" * 80)
    
    results = {}
    
    # 对每个trace文件进行实验
    for trace_file in TRACE_FILES:
        trace_path = TRACES_DIR / trace_file
        trace_name = trace_path.stem
        
        if not trace_path.exists():
            print(f"\nWarning: Trace file not found: {trace_path}")
            continue
        
        print(f"\n{'=' * 80}")
        print(f"Processing: {trace_file}")
        print(f"{'=' * 80}")
        
        i_rates = []
        d_rates = []
        
        # 对每个相联度运行模拟
        for assoc in ASSOCIATIVITIES:
            print(f"  Associativity: {assoc:>2}-way ", end='', flush=True)
            
            i_rate, d_rate = run_simulation(trace_path, assoc)
            i_rates.append(i_rate)
            d_rates.append(d_rate)
            
            print(f"-> I-Hit: {i_rate:.4f}, D-Hit: {d_rate:.4f}")
        
        # 保存结果
        results[trace_name] = {
            'i_rates': i_rates,
            'd_rates': d_rates
        }
        
        # 找到最优相联度
        opt_i_assoc = find_optimal_associativity(ASSOCIATIVITIES, i_rates)
        opt_d_assoc = find_optimal_associativity(ASSOCIATIVITIES, d_rates)
        
        print(f"\n  Optimal Instruction Associativity: {opt_i_assoc}-way (Hit Rate: {i_rates[ASSOCIATIVITIES.index(opt_i_assoc)]:.4f})")
        print(f"  Optimal Data Associativity: {opt_d_assoc}-way (Hit Rate: {d_rates[ASSOCIATIVITIES.index(opt_d_assoc)]:.4f})")
        
        # 绘制图表
        plot_associativity_impact(trace_name, ASSOCIATIVITIES, i_rates, d_rates, plots_dir)
    
    # 生成综合报告
    print(f"\n{'=' * 80}")
    print("SUMMARY REPORT")
    print(f"{'=' * 80}")
    
    report_lines = []
    report_lines.append("=" * 80)
    report_lines.append("2.3 Impact of Associativity - Experiment Report")
    report_lines.append("=" * 80)
    report_lines.append("")
    report_lines.append("EXPERIMENT CONFIGURATION")
    report_lines.append("-" * 80)
    report_lines.append(f"Cache Size: {CACHE_SIZE} bytes (8 KB) per cache")
    report_lines.append(f"Block Size: {BLOCK_SIZE} bytes")
    report_lines.append("Cache Type: Split I-D cache")
    report_lines.append("Write Policy: Write-Back with Write-Allocate")
    report_lines.append(f"Associativity Range: {ASSOCIATIVITIES[0]} to {ASSOCIATIVITIES[-1]} (powers of 2)")
    report_lines.append(f"Test Traces: {', '.join([t.replace('.trace', '') for t in TRACE_FILES])}")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 1: Why the hit rate vs. associativity plot has the shape that it does")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("The hit rate vs. associativity curve typically shows the following characteristics:")
    report_lines.append("")
    report_lines.append("1. INITIAL STEEP RISE (Low associativity):")
    report_lines.append("   - Direct-mapped caches (1-way) suffer from many conflict misses")
    report_lines.append("   - When multiple memory blocks map to the same cache set, they evict each other")
    report_lines.append("   - Even a small increase in associativity (1→2, 2→4) dramatically reduces conflicts")
    report_lines.append("   - This is why we see a sharp improvement in hit rate at low associativities")
    report_lines.append("")
    report_lines.append("2. DIMINISHING RETURNS (Medium associativity):")
    report_lines.append("   - As associativity increases (8-way, 16-way), most conflict misses are eliminated")
    report_lines.append("   - The curve begins to flatten as gains become smaller")
    report_lines.append("   - Additional associativity helps only for the remaining edge cases")
    report_lines.append("")
    report_lines.append("3. PLATEAU (High associativity):")
    report_lines.append("   - Beyond a certain point (32-way, 64-way), hit rate stops improving")
    report_lines.append("   - Remaining misses are primarily capacity misses (cache too small) and")
    report_lines.append("     compulsory misses (first-time access)")
    report_lines.append("   - These cannot be eliminated by increasing associativity alone")
    report_lines.append("")
    report_lines.append("4. THE LAW OF DIMINISHING RETURNS:")
    report_lines.append("   - The benefit of doubling associativity decreases with each step")
    report_lines.append("   - Going from 1→2 way: large improvement (eliminates many conflicts)")
    report_lines.append("   - Going from 32→64 way: minimal improvement (few conflicts remain)")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 2: Differences between instruction and data reference plots")
    report_lines.append("-" * 80)
    report_lines.append("")
    
    # 分析每个trace的I/D差异
    print(f"\n{'Trace':<15} {'Optimal I-Assoc':<20} {'Optimal D-Assoc':<20}")
    print("-" * 80)
    
    report_lines.append("Optimal Associativities:")
    report_lines.append(f"{'Trace':<15} {'Instruction':<20} {'Data':<20}")
    report_lines.append("-" * 80)
    
    for trace_name in sorted(results.keys()):
        opt_i = find_optimal_associativity(ASSOCIATIVITIES, results[trace_name]['i_rates'])
        opt_d = find_optimal_associativity(ASSOCIATIVITIES, results[trace_name]['d_rates'])
        
        i_rate_at_opt = results[trace_name]['i_rates'][ASSOCIATIVITIES.index(opt_i)]
        d_rate_at_opt = results[trace_name]['d_rates'][ASSOCIATIVITIES.index(opt_d)]
        
        line = f"{trace_name:<15} {opt_i:>2}-way ({i_rate_at_opt:.4f})   {opt_d:>2}-way ({d_rate_at_opt:.4f})"
        print(line)
        report_lines.append(line)
    
    report_lines.append("")
    report_lines.append("")
    report_lines.append("KEY OBSERVATIONS:")
    report_lines.append("")
    report_lines.append("1. INSTRUCTION REFERENCES:")
    report_lines.append("   - Typically benefit more from higher associativity")
    report_lines.append("   - Instruction access patterns are more sequential and predictable")
    report_lines.append("   - Loops and function calls create temporal locality")
    report_lines.append("   - However, different code paths can map to the same cache sets")
    report_lines.append("   - Higher associativity helps accommodate multiple code paths")
    report_lines.append("")
    report_lines.append("2. DATA REFERENCES:")
    report_lines.append("   - Often show less sensitivity to associativity")
    report_lines.append("   - Data access patterns are more irregular and scattered")
    report_lines.append("   - Array accesses with large strides may have fewer conflicts")
    report_lines.append("   - Or conversely, may have conflicts that even high associativity cannot solve")
    report_lines.append("   - The impact depends heavily on the application's data structure usage")
    report_lines.append("")
    report_lines.append("3. WHAT THIS TELLS US:")
    report_lines.append("")
    report_lines.append("   a) PROGRAM BEHAVIOR DIFFERENCES:")
    report_lines.append("      - Instructions: More structured, benefit from exploiting spatial/temporal locality")
    report_lines.append("      - Data: More random, may need larger cache size rather than higher associativity")
    report_lines.append("")
    report_lines.append("   b) DESIGN IMPLICATIONS:")
    report_lines.append("      - I-cache might benefit from higher associativity (4-way or 8-way)")
    report_lines.append("      - D-cache might benefit more from larger size than higher associativity")
    report_lines.append("      - This justifies asymmetric cache designs in real processors")
    report_lines.append("")
    report_lines.append("   c) WORKLOAD-SPECIFIC INSIGHTS:")
    report_lines.append("      - If I-cache shows steep curve: code has complex control flow with conflicts")
    report_lines.append("      - If D-cache shows flat curve: data access is either very regular (no conflicts)")
    report_lines.append("        or very irregular (capacity misses dominate)")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("TRACE-SPECIFIC ANALYSIS:")
    report_lines.append("-" * 80)
    
    for trace_name in sorted(results.keys()):
        report_lines.append(f"\n{trace_name.upper()}:")
        i_rates = results[trace_name]['i_rates']
        d_rates = results[trace_name]['d_rates']
        
        # 计算改进幅度
        i_improvement = i_rates[-1] - i_rates[0]
        d_improvement = d_rates[-1] - d_rates[0]
        
        report_lines.append(f"  I-cache improvement (1-way → 64-way): {i_improvement:.4f} ({i_improvement*100:.2f}%)")
        report_lines.append(f"  D-cache improvement (1-way → 64-way): {d_improvement:.4f} ({d_improvement*100:.2f}%)")
        
        if i_improvement > d_improvement * 1.5:
            report_lines.append(f"  → Instruction cache is MORE sensitive to associativity")
            report_lines.append(f"     (Likely has more conflict misses in direct-mapped configuration)")
        elif d_improvement > i_improvement * 1.5:
            report_lines.append(f"  → Data cache is MORE sensitive to associativity")
            report_lines.append(f"     (Data access patterns create more conflicts)")
        else:
            report_lines.append(f"  → Both caches show similar sensitivity to associativity")
    
    report_lines.append("")
    report_lines.append("-" * 80)
    report_lines.append("End of Report")
    report_lines.append("=" * 80)
    
    # 保存报告
    report_path = OUTPUT_DIR / "experiment_report.txt"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report_lines))
    
    print(f"\n{'=' * 80}")
    print(f"Experiment completed!")
    print(f"Report saved: {report_path}")
    print(f"Plots saved in: {plots_dir}")
    print(f"{'=' * 80}")

if __name__ == "__main__":
    main()
