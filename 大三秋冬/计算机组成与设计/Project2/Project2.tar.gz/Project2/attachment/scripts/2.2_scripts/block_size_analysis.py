#!/usr/bin/env python3
"""
2.2 块大小影响分析
分析块大小对缓存命中率的影响
"""

import subprocess
import os
import re
import matplotlib.pyplot as plt
import matplotlib
from pathlib import Path

# 支持中文显示
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 配置参数
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
CODE_DIR = PROJECT_DIR / "code"
TRACES_DIR = PROJECT_DIR / "ext_traces"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "2.2_outputs"

# 三个样本trace文件
TRACE_FILES = ["cc.trace", "spice.trace", "tex.trace"]

# 块大小范围：从4字节到4K字节，按2的幂次变化
BLOCK_SIZES = [2**i for i in range(2, 13)]  # 4, 8, 16, 32, ..., 4096

# 固定参数
CACHE_SIZE = 8192       # 8KB (每个缓存)
ASSOCIATIVITY = 2       # 2路组相联

def run_simulation(trace_path, block_size):
    """
    运行缓存模拟器
    
    参数:
        trace_path: trace文件路径
        block_size: 块大小（字节）
    
    返回:
        (i_hit_rate, d_hit_rate): 指令和数据缓存的命中率
    """
    sim_path = CODE_DIR / "sim"
    
    # 构建命令：split cache, 每个8KB, 相联度2, write-back, write-allocate
    cmd = [str(sim_path), 
           "-is", str(CACHE_SIZE), 
           "-ds", str(CACHE_SIZE),
           "-bs", str(block_size), 
           "-a", str(ASSOCIATIVITY),
           "-wb", "-wa", 
           str(trace_path)]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, cwd=CODE_DIR)
        output = result.stdout
        
        i_hit_rate = 0.0
        d_hit_rate = 0.0
        
        # 解析指令缓存命中率
        lines = output.split('\n')
        in_inst_section = False
        in_data_section = False
        
        for line in lines:
            if 'INSTRUCTIONS' in line:
                in_inst_section = True
                in_data_section = False
            elif 'DATA' in line:
                in_inst_section = False
                in_data_section = True
            elif in_inst_section and 'miss rate:' in line:
                match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', line)
                if match:
                    i_hit_rate = float(match.group(2))
            elif in_data_section and 'miss rate:' in line:
                match = re.search(r'miss rate:\s+([\d.]+)\s+\(hit rate\s+([\d.]+)\)', line)
                if match:
                    d_hit_rate = float(match.group(2))
        
        return (i_hit_rate, d_hit_rate)
            
    except subprocess.TimeoutExpired:
        print(f"  Timeout for block_size={block_size}")
        return (0.0, 0.0)
    except Exception as e:
        print(f"  Error: {e}")
        return (0.0, 0.0)

def find_optimal_block_size(block_sizes, hit_rates):
    """
    找到最优块大小（命中率最高的块大小）
    """
    max_rate = max(hit_rates)
    max_idx = hit_rates.index(max_rate)
    return block_sizes[max_idx], max_rate

def format_size(size_bytes):
    """格式化字节大小"""
    if size_bytes >= 1024:
        return f"{size_bytes // 1024}KB"
    else:
        return f"{size_bytes}B"

def plot_block_size_impact(trace_name, block_sizes, i_rates, d_rates, output_dir):
    """
    绘制块大小影响图
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 指令缓存图
    ax1.semilogx(block_sizes, i_rates, 'b-o', linewidth=2, markersize=6, base=2)
    ax1.set_xlabel('Block Size (bytes)', fontsize=12)
    ax1.set_ylabel('Hit Rate', fontsize=12)
    ax1.set_title(f'Instruction Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax1.grid(True, alpha=0.3, which='both')
    ax1.set_ylim([0.7, 1.02])
    
    # 标记最优点
    opt_bs, opt_rate = find_optimal_block_size(block_sizes, i_rates)
    ax1.axvline(x=opt_bs, color='r', linestyle='--', alpha=0.5)
    ax1.plot(opt_bs, opt_rate, 'r*', markersize=15, label=f'Optimal: {format_size(opt_bs)}')
    ax1.legend()
    
    # 数据缓存图
    ax2.semilogx(block_sizes, d_rates, 'g-s', linewidth=2, markersize=6, base=2)
    ax2.set_xlabel('Block Size (bytes)', fontsize=12)
    ax2.set_ylabel('Hit Rate', fontsize=12)
    ax2.set_title(f'Data Cache - {trace_name}', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3, which='both')
    ax2.set_ylim([0.7, 1.02])
    
    # 标记最优点
    opt_bs, opt_rate = find_optimal_block_size(block_sizes, d_rates)
    ax2.axvline(x=opt_bs, color='r', linestyle='--', alpha=0.5)
    ax2.plot(opt_bs, opt_rate, 'r*', markersize=15, label=f'Optimal: {format_size(opt_bs)}')
    ax2.legend()
    
    plt.tight_layout()
    
    # 保存图像
    output_path = output_dir / f'block_size_impact_{trace_name}.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"  Plot saved: {output_path}")
    plt.close()

def main():
    """主函数"""
    # 创建输出目录
    plots_dir = OUTPUT_DIR / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)
    
    # 检查模拟器
    sim_path = CODE_DIR / "sim"
    if not sim_path.exists():
        print(f"Error: Simulator not found at {sim_path}")
        print("Please compile the simulator first using 'make' in the code directory")
        return
    
    print("=" * 80)
    print("2.2 Block Size Impact Analysis")
    print("=" * 80)
    print(f"Cache Configuration:")
    print(f"  - Type: Split I-D cache")
    print(f"  - Size: {CACHE_SIZE} bytes (8KB) each")
    print(f"  - Associativity: {ASSOCIATIVITY}-way")
    print(f"  - Write Policy: Write-Back with Write-Allocate")
    print(f"Block Size Range: {BLOCK_SIZES[0]} bytes to {BLOCK_SIZES[-1]} bytes")
    print(f"Traces: {', '.join(TRACE_FILES)}")
    print("=" * 80)
    
    results = {}
    
    # 对每个trace文件进行实验
    for trace_file in TRACE_FILES:
        trace_path = TRACES_DIR / trace_file
        trace_name = trace_path.stem
        
        if not trace_path.exists():
            print(f"\nWarning: Trace file not found: {trace_path}")
            continue
        
        print(f"\n{'=' * 80}")
        print(f"Processing: {trace_file}")
        print(f"{'=' * 80}")
        
        i_rates = []
        d_rates = []
        
        # 对每个块大小运行模拟
        for block_size in BLOCK_SIZES:
            print(f"  Block Size: {format_size(block_size):>6} ", end='', flush=True)
            
            # 运行模拟
            i_rate, d_rate = run_simulation(trace_path, block_size)
            i_rates.append(i_rate)
            d_rates.append(d_rate)
            
            print(f"-> I-Hit: {i_rate:.4f}, D-Hit: {d_rate:.4f}")
        
        # 保存结果
        results[trace_name] = {
            'i_rates': i_rates,
            'd_rates': d_rates
        }
        
        # 找到最优块大小
        i_opt_bs, i_opt_rate = find_optimal_block_size(BLOCK_SIZES, i_rates)
        d_opt_bs, d_opt_rate = find_optimal_block_size(BLOCK_SIZES, d_rates)
        
        print(f"\n  Optimal Instruction Block Size: {format_size(i_opt_bs)} (hit rate: {i_opt_rate:.4f})")
        print(f"  Optimal Data Block Size: {format_size(d_opt_bs)} (hit rate: {d_opt_rate:.4f})")
        
        # 绘制图表
        plot_block_size_impact(trace_name, BLOCK_SIZES, i_rates, d_rates, plots_dir)
    
    # 生成综合报告
    print(f"\n{'=' * 80}")
    print("ANALYSIS REPORT")
    print(f"{'=' * 80}")
    
    report_lines = []
    report_lines.append("=" * 80)
    report_lines.append("2.2 Block Size Impact Analysis - Experiment Report")
    report_lines.append("=" * 80)
    report_lines.append("")
    report_lines.append("QUESTION 1: Why Hit Rate vs. Block Size Has This Shape")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("The hit rate vs. block size curve typically shows the following pattern:")
    report_lines.append("")
    report_lines.append("1. Initial Rise (Small Block Sizes):")
    report_lines.append("   - As block size increases from very small values (4-16 bytes), hit rate")
    report_lines.append("     improves because larger blocks exploit SPATIAL LOCALITY.")
    report_lines.append("   - Spatial locality: when a program accesses memory location X, it is likely")
    report_lines.append("     to access nearby locations X+1, X+2, etc. in the near future.")
    report_lines.append("   - Larger blocks prefetch these nearby locations, reducing future misses.")
    report_lines.append("")
    report_lines.append("2. Peak/Plateau (Optimal Block Size):")
    report_lines.append("   - The curve reaches a maximum at the optimal block size.")
    report_lines.append("   - This represents the best balance between exploiting spatial locality")
    report_lines.append("     and avoiding the negative effects described below.")
    report_lines.append("")
    report_lines.append("3. Decline (Large Block Sizes):")
    report_lines.append("   - Beyond the optimal point, hit rate may decrease due to:")
    report_lines.append("")
    report_lines.append("   a) CACHE POLLUTION: Very large blocks bring in many unnecessary bytes,")
    report_lines.append("      wasting cache space that could hold other useful data.")
    report_lines.append("")
    report_lines.append("   b) FEWER CACHE LINES: With fixed cache size (8KB) and larger blocks,")
    report_lines.append("      the number of cache lines decreases (e.g., 8KB/4KB = only 2 blocks).")
    report_lines.append("      Fewer lines means less flexibility and more conflict misses.")
    report_lines.append("")
    report_lines.append("   c) LIMITED SPATIAL LOCALITY: If the program's access pattern doesn't")
    report_lines.append("      exhibit strong spatial locality, large blocks waste bandwidth and")
    report_lines.append("      cache space on data that will never be used.")
    report_lines.append("")
    report_lines.append("RELEVANCE OF SPATIAL LOCALITY:")
    report_lines.append("Spatial locality is the KEY factor in this curve's shape. Programs with:")
    report_lines.append("- HIGH spatial locality (e.g., array traversals) -> benefit from larger blocks")
    report_lines.append("- LOW spatial locality (e.g., pointer chasing) -> prefer smaller blocks")
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 2: Optimal Block Size for Each Trace")
    report_lines.append("-" * 80)
    report_lines.append(f"{'Trace':<15} {'I-Cache Optimal':<25} {'D-Cache Optimal':<25}")
    report_lines.append("-" * 80)
    
    print(f"{'Trace':<15} {'I-Cache Optimal':<30} {'D-Cache Optimal':<30}")
    print("-" * 80)
    
    for trace_name in sorted(results.keys()):
        i_opt_bs, i_opt_rate = find_optimal_block_size(BLOCK_SIZES, results[trace_name]['i_rates'])
        d_opt_bs, d_opt_rate = find_optimal_block_size(BLOCK_SIZES, results[trace_name]['d_rates'])
        
        i_str = f"{format_size(i_opt_bs)} (rate: {i_opt_rate:.4f})"
        d_str = f"{format_size(d_opt_bs)} (rate: {d_opt_rate:.4f})"
        
        line = f"{trace_name:<15} {i_str:<30} {d_str:<30}"
        print(line)
        report_lines.append(line)
    
    report_lines.append("")
    report_lines.append("")
    report_lines.append("QUESTION 3: Instruction vs. Data Block Size Differences")
    report_lines.append("-" * 80)
    report_lines.append("")
    report_lines.append("Observations about optimal block sizes:")
    report_lines.append("")
    
    # 分析每个trace的差异
    for trace_name in sorted(results.keys()):
        i_opt_bs, _ = find_optimal_block_size(BLOCK_SIZES, results[trace_name]['i_rates'])
        d_opt_bs, _ = find_optimal_block_size(BLOCK_SIZES, results[trace_name]['d_rates'])
        
        if i_opt_bs != d_opt_bs:
            report_lines.append(f"{trace_name}: Different optimal sizes (I: {format_size(i_opt_bs)}, D: {format_size(d_opt_bs)})")
        else:
            report_lines.append(f"{trace_name}: Same optimal size ({format_size(i_opt_bs)})")
    
    report_lines.append("")
    report_lines.append("Why instruction and data references behave differently:")
    report_lines.append("")
    report_lines.append("1. INSTRUCTION REFERENCES:")
    report_lines.append("   - Typically exhibit STRONG sequential spatial locality")
    report_lines.append("   - Programs execute instructions in order (mostly)")
    report_lines.append("   - Loops and sequential code benefit from larger instruction blocks")
    report_lines.append("   - Exception: branches and function calls disrupt sequential flow")
    report_lines.append("")
    report_lines.append("2. DATA REFERENCES:")
    report_lines.append("   - Access patterns vary widely by program type:")
    report_lines.append("     * Array processing: high spatial locality -> benefit from larger blocks")
    report_lines.append("     * Pointer/linked structures: low spatial locality -> prefer smaller blocks")
    report_lines.append("     * Random access: little spatial locality -> small blocks better")
    report_lines.append("   - Data structures determine access patterns")
    report_lines.append("")
    report_lines.append("3. KEY INSIGHT:")
    report_lines.append("   If optimal I-block size > optimal D-block size:")
    report_lines.append("   -> Instructions have higher spatial locality than data")
    report_lines.append("   -> The program likely uses scattered data structures or irregular patterns")
    report_lines.append("")
    report_lines.append("   If optimal I-block size < optimal D-block size:")
    report_lines.append("   -> Data has higher spatial locality (e.g., array-heavy code)")
    report_lines.append("   -> Instructions may have many branches/calls")
    report_lines.append("")
    report_lines.append("   If optimal sizes are similar:")
    report_lines.append("   -> Both instruction and data exhibit similar spatial locality patterns")
    report_lines.append("")
    
    # 保存报告
    report_path = OUTPUT_DIR / "experiment_report.txt"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report_lines))
    
    print(f"\n{'=' * 80}")
    print(f"Experiment completed!")
    print(f"Report saved: {report_path}")
    print(f"Plots saved in: {plots_dir}")
    print(f"{'=' * 80}")

if __name__ == "__main__":
    main()
