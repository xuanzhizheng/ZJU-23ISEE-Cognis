#!/usr/bin/env python3
"""
对比测试结果与参考表格
生成差异报告
"""

import csv
from pathlib import Path

# 项目目录
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
REPORTS_DIR = PROJECT_DIR / "outputs" / "1.3_outputs" / "reports"

# 参考表格数据
REFERENCE_TABLE = [
    {'CS': '8K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA', 
     'IMisses': 24681, 'IRepl': 24173, 'DMisses': 8283, 'DRepl': 7818, 'DF': 131856, 'CB': 12024},
    {'CS': '16K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 11514, 'IRepl': 10560, 'DMisses': 5839, 'DRepl': 5051, 'DF': 69412, 'CB': 8008},
    {'CS': '32K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 5922, 'IRepl': 4321, 'DMisses': 1567, 'DRepl': 520, 'DF': 29956, 'CB': 3628},
    {'CS': '64K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 2619, 'IRepl': 484, 'DMisses': 1290, 'DRepl': 103, 'DF': 15636, 'CB': 3324},
    {'CS': '8K', 'Type': 'Unified', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 36136, 'IRepl': 35787, 'DMisses': 21261, 'DRepl': 21098, 'DF': 229588, 'CB': 37844},
    {'CS': '8K', 'Type': 'Unified', 'BS': '32', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 26673, 'IRepl': 26502, 'DMisses': 19561, 'DRepl': 19476, 'DF': 369872, 'CB': 69104},
    {'CS': '8K', 'Type': 'Unified', 'BS': '64', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 23104, 'IRepl': 23029, 'DMisses': 20377, 'DRepl': 20324, 'DF': 695696, 'CB': 136112},
    {'CS': '32K', 'Type': 'Split', 'BS': '128', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 1964, 'IRepl': 1726, 'DMisses': 459, 'DRepl': 280, 'DF': 77536, 'CB': 7296},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '2', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 6590, 'IRepl': 6462, 'DMisses': 3160, 'DRepl': 3032, 'DF': 156000, 'CB': 18880},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '4', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 6025, 'IRepl': 5897, 'DMisses': 875, 'DRepl': 747, 'DF': 110400, 'CB': 7296},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '8', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 6435, 'IRepl': 6307, 'DMisses': 803, 'DRepl': 675, 'DF': 115808, 'CB': 6656},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '16', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 6536, 'IRepl': 6408, 'DMisses': 799, 'DRepl': 671, 'DF': 117360, 'CB': 6624},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '128', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 6523, 'IRepl': 6395, 'DMisses': 790, 'DRepl': 662, 'DF': 117008, 'CB': 6576},
    {'CS': '1K', 'Type': 'Split', 'BS': '64', 'Ass': '2', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 44962, 'IRepl': 44946, 'DMisses': 24767, 'DRepl': 24751, 'DF': 1115664, 'CB': 149200},
    {'CS': '1K', 'Type': 'Split', 'BS': '64', 'Ass': '8', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 45885, 'IRepl': 45869, 'DMisses': 22808, 'DRepl': 22792, 'DF': 1099088, 'CB': 112480},
    {'CS': '1K', 'Type': 'Split', 'BS': '64', 'Ass': '16', 'Write': 'WB', 'Alloc': 'WA',
     'IMisses': 45969, 'IRepl': 45953, 'DMisses': 20667, 'DRepl': 20651, 'DF': 1066176, 'CB': 90416},
    {'CS': '8K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WT', 'Alloc': 'WA',
     'IMisses': 24681, 'IRepl': 24173, 'DMisses': 8283, 'DRepl': 7818, 'DF': 131856, 'CB': 66538},
    {'CS': '8K', 'Type': 'Split', 'BS': '32', 'Ass': '1', 'Write': 'WT', 'Alloc': 'WA',
     'IMisses': 15868, 'IRepl': 15612, 'DMisses': 7504, 'DRepl': 7264, 'DF': 186976, 'CB': 66538},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '2', 'Write': 'WT', 'Alloc': 'WA',
     'IMisses': 6590, 'IRepl': 6462, 'DMisses': 3160, 'DRepl': 3032, 'DF': 156000, 'CB': 66538},
    {'CS': '8K', 'Type': 'Split', 'BS': '16', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WNA',
     'IMisses': 24681, 'IRepl': 24173, 'DMisses': 14904, 'DRepl': 6688, 'DF': 127304, 'CB': 14643},
    {'CS': '8K', 'Type': 'Split', 'BS': '32', 'Ass': '1', 'Write': 'WB', 'Alloc': 'WNA',
     'IMisses': 15868, 'IRepl': 15612, 'DMisses': 15098, 'DRepl': 6421, 'DF': 180200, 'CB': 22033},
    {'CS': '8K', 'Type': 'Split', 'BS': '64', 'Ass': '2', 'Write': 'WB', 'Alloc': 'WNA',
     'IMisses': 6590, 'IRepl': 6462, 'DMisses': 8638, 'DRepl': 2726, 'DF': 151104, 'CB': 13624},
]

def normalize_key(cs, cache_type, bs, assoc, write, alloc):
    """生成标准化的配置键"""
    return f"{cs}_{cache_type}_{bs}_{assoc}_{write}_{alloc}"

def compare_results():
    """对比测试结果与参考表格"""
    
    summary_csv = REPORTS_DIR / "summary.csv"
    
    if not summary_csv.exists():
        print("Error: summary.csv not found. Please run 'make analyze' first.")
        return
    
    # 读取测试结果
    test_results = {}
    with open(summary_csv, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = normalize_key(
                row['cache_size'], 
                row['cache_type'].capitalize(),
                row['block_size'],
                row['associativity'],
                row['write_policy'],
                row['alloc_policy']
            )
            test_results[key] = row
    
    # 构建参考表格索引
    reference_dict = {}
    for ref in REFERENCE_TABLE:
        key = normalize_key(
            ref['CS'],
            ref['Type'],
            ref['BS'],
            ref['Ass'],
            ref['Write'],
            ref['Alloc']
        )
        reference_dict[key] = ref
    
    # 对比结果
    print("\n" + "="*80)
    print("COMPARISON REPORT")
    print("="*80)
    
    total = len(reference_dict)
    passed = 0
    failed = 0
    missing = 0
    
    comparison_results = []
    
    for key, ref in reference_dict.items():
        if key not in test_results:
            print(f"\n✗ MISSING: {key}")
            missing += 1
            continue
        
        test = test_results[key]
        
        # 对比关键指标
        errors = []
        
        if test['inst_misses'] and int(test['inst_misses']) != ref['IMisses']:
            errors.append(f"Inst Misses - Expected: {ref['IMisses']}, Got: {test['inst_misses']}")
        
        if test['inst_replacements'] and int(test['inst_replacements']) != ref['IRepl']:
            errors.append(f"Inst Repl - Expected: {ref['IRepl']}, Got: {test['inst_replacements']}")
        
        if test['data_misses'] and int(test['data_misses']) != ref['DMisses']:
            errors.append(f"Data Misses - Expected: {ref['DMisses']}, Got: {test['data_misses']}")
        
        if test['data_replacements'] and int(test['data_replacements']) != ref['DRepl']:
            errors.append(f"Data Repl - Expected: {ref['DRepl']}, Got: {test['data_replacements']}")
        
        if test['demand_fetches'] and int(test['demand_fetches']) != ref['DF']:
            errors.append(f"Demand Fetch - Expected: {ref['DF']}, Got: {test['demand_fetches']}")
        
        if test['copies_back'] and int(test['copies_back']) != ref['CB']:
            errors.append(f"Copies Back - Expected: {ref['CB']}, Got: {test['copies_back']}")
        
        if errors:
            print(f"\n✗ FAILED: {key}")
            for error in errors:
                print(f"    {error}")
            failed += 1
            comparison_results.append({'config': key, 'status': 'FAILED', 'errors': '; '.join(errors)})
        else:
            print(f"✓ PASSED: {key}")
            passed += 1
            comparison_results.append({'config': key, 'status': 'PASSED', 'errors': ''})
    
    # 汇总
    print("\n" + "="*80)
    print(f"Total: {total} | Passed: {passed} | Failed: {failed} | Missing: {missing}")
    print("="*80)
    
    # 保存对比报告
    report_file = REPORTS_DIR / "comparison_report.csv"
    with open(report_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['config', 'status', 'errors'])
        writer.writeheader()
        writer.writerows(comparison_results)
    
    print(f"\nComparison report saved: {report_file}")

if __name__ == "__main__":
    compare_results()
