#!/bin/bash

# 批量测试脚本
# 读取配置文件并运行所有测试

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"
CODE_DIR="$PROJECT_DIR/code"
OUTPUT_DIR="$PROJECT_DIR/outputs/1.3_outputs/test_results"
CONFIG_FILE="$SCRIPT_DIR/test_configs.csv"

# 检查 sim 可执行文件
if [ ! -f "$CODE_DIR/sim" ]; then
    echo "Error: sim executable not found. Please run 'make' first."
    exit 1
fi

# 检查配置文件
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Configuration file not found: $CONFIG_FILE"
    exit 1
fi

echo "=========================================="
echo "Starting batch cache simulation tests"
echo "=========================================="

# 读取配置文件（跳过表头）
tail -n +2 "$CONFIG_FILE" | while IFS=, read -r cache_size cache_type block_size assoc write_policy alloc_policy trace_file; do
    
    # 构建命令参数
    if [ "$cache_type" = "split" ]; then
        CACHE_PARAM="-is $cache_size -ds $cache_size"
    else
        CACHE_PARAM="-us $cache_size"
    fi
    
    # 写策略
    if [ "$write_policy" = "wb" ]; then
        WRITE_PARAM="-wb"
        WRITE_STR="WB"
    else
        WRITE_PARAM="-wt"
        WRITE_STR="WT"
    fi
    
    # 分配策略
    if [ "$alloc_policy" = "wa" ]; then
        ALLOC_PARAM="-wa"
        ALLOC_STR="WA"
    elif [ "$alloc_policy" = "nwa" ]; then
        ALLOC_PARAM="-nw"
        ALLOC_STR="WNA"
    else
        ALLOC_PARAM="-nw"
        ALLOC_STR="WNA"
    fi
    
    # Trace 文件路径
    TRACE_PATH="$PROJECT_DIR/ext_traces/$trace_file"
    if [ ! -f "$TRACE_PATH" ]; then
        echo "Warning: Trace file not found: $TRACE_PATH, skipping..."
        continue
    fi
    
    # 生成输出文件名
    TRACE_NAME="${trace_file%.trace}"
    OUTPUT_SUBDIR="$OUTPUT_DIR/$TRACE_NAME"
    mkdir -p "$OUTPUT_SUBDIR"
    
    # 缓存大小格式化 (8192 -> 8K)
    if [ $cache_size -ge 1024 ]; then
        SIZE_STR="$((cache_size / 1024))K"
    else
        SIZE_STR="${cache_size}"
    fi
    
    OUTPUT_FILE="$OUTPUT_SUBDIR/${SIZE_STR}_${cache_type}_${block_size}_${assoc}_${WRITE_STR}_${ALLOC_STR}.txt"
    
    # 执行测试
    echo "Testing: $SIZE_STR $cache_type BS=$block_size Assoc=$assoc $write_policy $alloc_policy"
    
    cd "$CODE_DIR"
    ./sim $CACHE_PARAM -bs $block_size -a $assoc $WRITE_PARAM $ALLOC_PARAM "$TRACE_PATH" > "$OUTPUT_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        echo "  ✓ Success -> $OUTPUT_FILE"
    else
        echo "  ✗ Failed (exit code: $?)"
    fi
    
done

echo "=========================================="
echo "Batch testing completed!"
echo "Results saved in: $OUTPUT_DIR"
echo "=========================================="

# 自动运行分析脚本
echo ""
echo "Running parse_results.py..."
python3 "$SCRIPT_DIR/parse_results.py"

echo ""
echo "Running compare_table.py..."
python3 "$SCRIPT_DIR/compare_table.py"

echo ""
echo "=========================================="
echo "All analysis completed!"
echo "=========================================="
