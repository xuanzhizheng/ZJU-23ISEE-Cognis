#!/usr/bin/env python3
"""
解析 cache 模拟器输出结果
提取关键统计信息并生成 CSV 汇总报告
"""

import os
import re
import csv
from pathlib import Path

# 项目目录结构
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR.parent.parent
RESULTS_DIR = PROJECT_DIR / "outputs" / "1.3_outputs" / "test_results"
REPORTS_DIR = PROJECT_DIR / "outputs" / "1.3_outputs" / "reports"

def parse_output_file(filepath):
    """解析单个输出文件，提取统计信息"""
    
    data = {
        'filename': filepath.name,
        'cache_size': None,
        'cache_type': None,
        'block_size': None,
        'associativity': None,
        'write_policy': None,
        'alloc_policy': None,
        'inst_accesses': None,
        'inst_misses': None,
        'inst_replacements': None,
        'data_accesses': None,
        'data_misses': None,
        'data_replacements': None,
        'demand_fetches': None,
        'copies_back': None,
    }
    
    # 从文件名解析配置
    # 格式: 8K_split_16_1_WB_WA.txt
    name_parts = filepath.stem.split('_')
    if len(name_parts) >= 6:
        data['cache_size'] = name_parts[0]
        data['cache_type'] = name_parts[1]
        data['block_size'] = name_parts[2]
        data['associativity'] = name_parts[3]
        data['write_policy'] = name_parts[4]
        data['alloc_policy'] = name_parts[5]
    
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        
        # 提取指令统计
        inst_match = re.search(r'INSTRUCTIONS.*?accesses:\s+(\d+).*?misses:\s+(\d+).*?replace:\s+(\d+)', content, re.DOTALL)
        if inst_match:
            data['inst_accesses'] = int(inst_match.group(1))
            data['inst_misses'] = int(inst_match.group(2))
            data['inst_replacements'] = int(inst_match.group(3))
        
        # 提取数据统计
        data_match = re.search(r'DATA.*?accesses:\s+(\d+).*?misses:\s+(\d+).*?replace:\s+(\d+)', content, re.DOTALL)
        if data_match:
            data['data_accesses'] = int(data_match.group(1))
            data['data_misses'] = int(data_match.group(2))
            data['data_replacements'] = int(data_match.group(3))
        
        # 提取流量统计
        traffic_match = re.search(r'demand fetch:\s+(\d+).*?copies back:\s+(\d+)', content, re.DOTALL)
        if traffic_match:
            data['demand_fetches'] = int(traffic_match.group(1))
            data['copies_back'] = int(traffic_match.group(2))
        
    except Exception as e:
        print(f"Error parsing {filepath}: {e}")
    
    return data

def main():
    """主函数：遍历所有结果文件并生成汇总报告"""
    
    # 确保报告目录存在
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    all_results = []
    
    # 遍历所有测试结果
    for trace_dir in RESULTS_DIR.iterdir():
        if not trace_dir.is_dir():
            continue
        
        print(f"Processing trace: {trace_dir.name}")
        
        for result_file in trace_dir.glob("*.txt"):
            print(f"  Parsing: {result_file.name}")
            data = parse_output_file(result_file)
            data['trace'] = trace_dir.name
            all_results.append(data)
    
    # 生成 CSV 报告
    if all_results:
        csv_file = REPORTS_DIR / "summary.csv"
        
        fieldnames = [
            'trace', 'filename', 'cache_size', 'cache_type', 'block_size', 'associativity',
            'write_policy', 'alloc_policy',
            'inst_accesses', 'inst_misses', 'inst_replacements',
            'data_accesses', 'data_misses', 'data_replacements',
            'demand_fetches', 'copies_back'
        ]
        
        with open(csv_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_results)
        
        print(f"\n✓ Summary report generated: {csv_file}")
        print(f"  Total configurations analyzed: {len(all_results)}")
    else:
        print("\n✗ No results found to analyze")

if __name__ == "__main__":
    main()
