/*
 * cache.c
 */


#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "cache.h"
#include "main.h"

/* cache configuration parameters */
static int cache_split = 0;
static int cache_usize = DEFAULT_CACHE_SIZE;
static int cache_isize = DEFAULT_CACHE_SIZE; 
static int cache_dsize = DEFAULT_CACHE_SIZE;
static int cache_block_size = DEFAULT_CACHE_BLOCK_SIZE;
static int words_per_block = DEFAULT_CACHE_BLOCK_SIZE / WORD_SIZE;
static int cache_assoc = DEFAULT_CACHE_ASSOC;
static int cache_writeback = DEFAULT_CACHE_WRITEBACK;
static int cache_writealloc = DEFAULT_CACHE_WRITEALLOC;

/* cache model data structures */
static Pcache icache;
static Pcache dcache;
static cache c1;
static cache c2;
static cache_stat cache_stat_inst;
static cache_stat cache_stat_data;

/************************************************************/
void set_cache_param(param, value)
  int param;
  int value;
{

  switch (param) {
  case CACHE_PARAM_BLOCK_SIZE:
    cache_block_size = value;
    words_per_block = value / WORD_SIZE;
    break;
  case CACHE_PARAM_USIZE:
    cache_split = FALSE;
    cache_usize = value;
    break;
  case CACHE_PARAM_ISIZE:
    cache_split = TRUE;
    cache_isize = value;
    break;
  case CACHE_PARAM_DSIZE:
    cache_split = TRUE;
    cache_dsize = value;
    break;
  case CACHE_PARAM_ASSOC:
    cache_assoc = value;
    break;
  case CACHE_PARAM_WRITEBACK:
    cache_writeback = TRUE;
    break;
  case CACHE_PARAM_WRITETHROUGH:
    cache_writeback = FALSE;
    break;
  case CACHE_PARAM_WRITEALLOC:
    cache_writealloc = TRUE;
    break;
  case CACHE_PARAM_NOWRITEALLOC:
    cache_writealloc = FALSE;
    break;
  default:
    printf("error set_cache_param: bad parameter value\n");
    exit(-1);
  }

}
/************************************************************/

/************************************************************/
/* 辅助函数：初始化单个 Cache 结构体 */
void init_cache_structure(Pcache cp, int size) {
    cp->size = size;
    cp->associativity = cache_assoc;
    cp->n_sets = size / (cache_block_size * cache_assoc);
    
    // 计算掩码和偏移量
    // 偏移量 = log2(block_size)
    cp->index_mask_offset = LOG2(cache_block_size);
    // 掩码 = (n_sets - 1) << offset
    cp->index_mask = (cp->n_sets - 1) << cp->index_mask_offset;

    // 分配内存
    cp->LRU_head = (Pcache_line *)malloc(sizeof(Pcache_line) * cp->n_sets);
    cp->LRU_tail = (Pcache_line *)malloc(sizeof(Pcache_line) * cp->n_sets);
    cp->set_contents = (int *)malloc(sizeof(int) * cp->n_sets);

    // 初始化内容
    for (int i = 0; i < cp->n_sets; i++) {
        cp->LRU_head[i] = NULL;
        cp->LRU_tail[i] = NULL;
        cp->set_contents[i] = 0;
    }
}

void init_cache()
{

  /* initialize the cache, and cache statistics data structures */
  if (cache_split) {
      init_cache_structure(&c1, cache_isize);
      init_cache_structure(&c2, cache_dsize);
      icache = &c1;
      dcache = &c2;
  } else {
      init_cache_structure(&c1, cache_usize);
      icache = &c1;
      dcache = &c1; // 统一 Cache 时，I 和 D 指向同一个
  }

  // 初始化统计数据
  cache_stat_inst.accesses = 0;
  cache_stat_inst.misses = 0;
  cache_stat_inst.replacements = 0;
  cache_stat_inst.demand_fetches = 0;
  cache_stat_inst.copies_back = 0;

  cache_stat_data.accesses = 0;
  cache_stat_data.misses = 0;
  cache_stat_data.replacements = 0;
  cache_stat_data.demand_fetches = 0;
  cache_stat_data.copies_back = 0;
}
/************************************************************/

/************************************************************/
void perform_access(addr, access_type)
  unsigned addr, access_type;
{
  Pcache cp;
  Pcache_stat stat;
  int is_write = (access_type == TRACE_DATA_STORE);

  // 1. 确定是指令访问还是数据访问，并选择对应的 Cache 和统计结构
  if (access_type == TRACE_INST_LOAD) {
      cp = icache;
      stat = &cache_stat_inst;
  } else {
      cp = dcache;
      stat = &cache_stat_data;
  }

  stat->accesses++;

  // 2. 计算 Index 和 Tag
  unsigned index = (addr & cp->index_mask) >> cp->index_mask_offset;
  unsigned tag = addr >> (cp->index_mask_offset + LOG2(cp->n_sets));

  // 3. 在对应的 Set 中查找 Tag
  Pcache_line current_line = cp->LRU_head[index];
  Pcache_line matched_line = NULL;

  while (current_line != NULL) {
      if (current_line->tag == tag) {
          matched_line = current_line;
          break;
      }
      current_line = current_line->LRU_next;
  }

  // 4. 处理命中 (HIT) 或 缺失 (MISS)
  if (matched_line != NULL) {
      // --- HIT ---
      // 将命中的行移到 LRU 头部 (MRU位置)
      delete(&cp->LRU_head[index], &cp->LRU_tail[index], matched_line);
      insert(&cp->LRU_head[index], &cp->LRU_tail[index], matched_line);

      if (is_write) {
          if (cache_writeback) {
              matched_line->dirty = 1; // 写回策略：标记脏位
          } else {
              stat->copies_back += 1; // 写直达策略：直接写入内存（假设一次写一个字）
          }
      }
  } else {
      // --- MISS ---
      stat->misses++;

      // 决定是否需要分配 Cache Line
      // 读操作总是分配；写操作只有在 Write-Allocate 时分配
      int allocate = 1; 
      if (is_write && !cache_writealloc) {
          allocate = 0;
      }

      if (allocate) {
          // 需要从内存读取块
          stat->demand_fetches += words_per_block;

          // 检查 Set 是否已满
          if (cp->set_contents[index] < cp->associativity) {
              // 未满，增加计数
              cp->set_contents[index]++;
          } else {
              // 已满，执行 LRU 替换 (驱逐尾部)
              stat->replacements++;
              Pcache_line victim = cp->LRU_tail[index];
              
              // 如果是写回策略且被驱逐行是脏的，需要写回内存
              if (cache_writeback && victim->dirty) {
                  stat->copies_back += words_per_block;
              }
              
              delete(&cp->LRU_head[index], &cp->LRU_tail[index], victim);
              free(victim); // 释放旧行内存
          }

          // 创建新行并插入头部
          Pcache_line new_line = (Pcache_line)malloc(sizeof(cache_line));
          new_line->tag = tag;
          new_line->dirty = 0; // 新从内存读入，初始为 clean
          // 如果是 Write-Allocate，这一步写入会导致 dirty (如果是 WB)
          if (is_write) {
              if (cache_writeback) {
                  new_line->dirty = 1;
              } else {
                  stat->copies_back += 1; // Write-Through + Write-Allocate: 写入 Cache 同时也写入内存
              }
          }
          
          insert(&cp->LRU_head[index], &cp->LRU_tail[index], new_line);

      } else {
          // Write Miss + No-Write-Allocate
          // 直接写入内存，不进入 Cache
          stat->copies_back += 1;
      }
  }

}
/************************************************************/

/************************************************************/
void flush_cache_structure(Pcache cp, Pcache_stat stat) {
    for (int i = 0; i < cp->n_sets; i++) {
        Pcache_line current = cp->LRU_head[i];
        while (current != NULL) {
            if (cache_writeback && current->dirty) {
                stat->copies_back += words_per_block;
            }
            Pcache_line next = current->LRU_next;
            // 注意：这里只是为了统计 flush 带来的 copy back，实际释放可以略过或保留
            current = next;
        }
    }
}

void flush()
{
  /* flush the cache */
  // Write-Back 策略下，模拟结束时需要将所有脏块写回内存
  
  if (cache_split) {
      // 分离 Cache：分别 flush I-Cache 和 D-Cache
      flush_cache_structure(&c1, &cache_stat_inst);
      flush_cache_structure(&c2, &cache_stat_data);
  } else {
      // 统一 Cache：只需 flush c1
      flush_cache_structure(&c1, &cache_stat_data);
  }
}
/************************************************************/

/************************************************************/
void delete(head, tail, item)
  Pcache_line *head, *tail;
  Pcache_line item;
{
  if (item->LRU_prev) {
    item->LRU_prev->LRU_next = item->LRU_next;
  } else {
    /* item at head */
    *head = item->LRU_next;
  }

  if (item->LRU_next) {
    item->LRU_next->LRU_prev = item->LRU_prev;
  } else {
    /* item at tail */
    *tail = item->LRU_prev;
  }
}
/************************************************************/

/************************************************************/
/* inserts at the head of the list */
void insert(head, tail, item)
  Pcache_line *head, *tail;
  Pcache_line item;
{
  item->LRU_next = *head;
  item->LRU_prev = (Pcache_line)NULL;

  if (item->LRU_next)
    item->LRU_next->LRU_prev = item;
  else
    *tail = item;

  *head = item;
}
/************************************************************/

/************************************************************/
void dump_settings()
{
  printf("*** CACHE SETTINGS ***\n");
  if (cache_split) {
    printf("  Split I- D-cache\n");
    printf("  I-cache size: \t%d\n", cache_isize);
    printf("  D-cache size: \t%d\n", cache_dsize);
  } else {
    printf("  Unified I- D-cache\n");
    printf("  Size: \t%d\n", cache_usize);
  }
  printf("  Associativity: \t%d\n", cache_assoc);
  printf("  Block size: \t%d\n", cache_block_size);
  printf("  Write policy: \t%s\n", 
	 cache_writeback ? "WRITE BACK" : "WRITE THROUGH");
  printf("  Allocation policy: \t%s\n",
	 cache_writealloc ? "WRITE ALLOCATE" : "WRITE NO ALLOCATE");
}
/************************************************************/

/************************************************************/
void print_stats()
{
  printf("\n*** CACHE STATISTICS ***\n");

  printf(" INSTRUCTIONS\n");
  printf("  accesses:  %d\n", cache_stat_inst.accesses);
  printf("  misses:    %d\n", cache_stat_inst.misses);
  if (!cache_stat_inst.accesses)
    printf("  miss rate: 0 (0)\n"); 
  else
    printf("  miss rate: %2.4f (hit rate %2.4f)\n", 
	 (float)cache_stat_inst.misses / (float)cache_stat_inst.accesses,
	 1.0 - (float)cache_stat_inst.misses / (float)cache_stat_inst.accesses);
  printf("  replace:   %d\n", cache_stat_inst.replacements);

  printf(" DATA\n");
  printf("  accesses:  %d\n", cache_stat_data.accesses);
  printf("  misses:    %d\n", cache_stat_data.misses);
  if (!cache_stat_data.accesses)
    printf("  miss rate: 0 (0)\n"); 
  else
    printf("  miss rate: %2.4f (hit rate %2.4f)\n", 
	 (float)cache_stat_data.misses / (float)cache_stat_data.accesses,
	 1.0 - (float)cache_stat_data.misses / (float)cache_stat_data.accesses);
  printf("  replace:   %d\n", cache_stat_data.replacements);

  printf(" TRAFFIC (in words)\n");
  printf("  demand fetch:  %d\n", cache_stat_inst.demand_fetches + 
	 cache_stat_data.demand_fetches);
  printf("  copies back:   %d\n", cache_stat_inst.copies_back +
	 cache_stat_data.copies_back);
}
/************************************************************/
