# Project 2 - Cache Simulator Project Structure

## 目录结构

```
attachment/
├── code/                      # 缓存模拟器源代码
│   ├── cache.c
│   ├── cache.h
│   ├── main.c
│   ├── main.h
│   ├── Makefile
│   └── sim                    # 编译后的可执行文件
│
├── traces/                    # 公开测试trace（用于调试）
│   ├── public-*.trace
│   └── spice*.trace
│
├── ext_traces/                # 项目trace文件
│   ├── cc.trace              # C编译器trace
│   ├── spice.trace           # 电路模拟器trace
│   └── tex.trace             # 文档处理器trace
│
├── scripts/                   # 所有脚本
│   ├── 1.3_scripts/          # 任务1.3：基础测试
│   │   ├── run_tests.sh      # 批量测试脚本
│   │   ├── parse_results.py  # 结果解析
│   │   ├── compare_table.py  # 对比参考表
│   │   └── test_configs.csv  # 测试配置
│   │
│   ├── 2.1_scripts/          # 任务2.1：工作集特征化
│   │   └── working_set_analysis.py
│   │
│   ├── 2.2_scripts/          # 任务2.2：块大小影响
│   │   └── block_size_analysis.py
│   │
│   ├── 2.3_scripts/          # 任务2.3：相联度影响
│   │   └── associativity_analysis.py
│   │
│   └── 2.4_scripts/          # 任务2.4：内存带宽
│       └── memory_bandwidth_analysis.py
│
└── outputs/                   # 所有输出结果
    ├── 1.3_outputs/          # 任务1.3输出
    │   ├── test_results/     # 测试结果文件
    │   │   └── spice/        # 22个配置的测试结果
    │   └── reports/          # 分析报告
    │       ├── summary.csv
    │       └── comparison_report.csv
    │
    ├── 2.1_outputs/          # 任务2.1输出
    │   └── plots/
    │       ├── working_set_cc.png
    │       ├── working_set_spice.png
    │       └── working_set_tex.png
    │
    ├── 2.2_outputs/          # 任务2.2输出
    │   └── plots/
    │       ├── block_size_impact_cc.png
    │       ├── block_size_impact_spice.png
    │       └── block_size_impact_tex.png
    │
    ├── 2.3_outputs/          # 任务2.3输出
    │   └── plots/
    │       ├── associativity_cc.png
    │       ├── associativity_spice.png
    │       └── associativity_tex.png
    │
    └── 2.4_outputs/          # 任务2.4输出
        └── plots/
            ├── memory_bandwidth_cc.png
            ├── memory_bandwidth_spice.png
            └── memory_bandwidth_tex.png
```

## 快速开始

### 1. 编译模拟器

```bash
cd code
make clean
make
```

### 2. 运行任务1.3（基础测试）

```bash
cd scripts/1.3_scripts
./run_tests.sh
```

这将自动：
- 运行22个不同配置的测试
- 解析结果并生成summary.csv
- 与参考表对比并生成comparison_report.csv
- 所有结果保存在 `outputs/1.3_outputs/`

### 3. 运行任务2.1（工作集特征化）

```bash
cd scripts/2.1_scripts
python3 working_set_analysis.py
```

这将：
- 测试三个trace的工作集大小
- 生成3个图表（每个trace包含I-cache和D-cache）
- 生成完整的实验报告
- 所有结果保存在 `outputs/2.1_outputs/`

### 4. 运行任务2.2（块大小影响分析）

```bash
cd scripts/2.2_scripts
python3 block_size_analysis.py
```

这将：
- 分析块大小对命中率的影响（4B到4KB）
- 生成3个图表（每个trace包含I-cache和D-cache）
- 确定最优块大小
- 所有结果保存在 `outputs/2.2_outputs/`

### 5. 运行任务2.3（相联度影响分析）

```bash
cd scripts/2.3_scripts
python3 associativity_analysis.py
```

这将：
- 分析相联度对命中率的影响（1-way到64-way）
- 生成3个图表（每个trace包含I-cache和D-cache）
- 确定最优相联度
- 所有结果保存在 `outputs/2.3_outputs/`

### 6. 运行任务2.4（内存带宽分析）

```bash
cd scripts/2.4_scripts
python3 memory_bandwidth_analysis.py
```

这将：
- 比较Write-Through vs Write-Back的内存流量
- 比较Write-Allocate vs Write-No-Allocate的内存流量
- 生成3个综合对比图表（每个trace含4个子图）
- 所有结果保存在 `outputs/2.4_outputs/`

## 依赖项

- Python 3.x
- matplotlib (用于绘图)
- numpy (用于数据处理)

安装依赖：
```bash
pip install matplotlib numpy
```

或使用项目虚拟环境（已配置）：
```bash
source .venv/bin/activate  # Linux/Mac
# 或
.venv\Scripts\activate     # Windows
```
