// Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
// Date        : Thu Nov 20 11:23:36 2025
// Host        : LAPTOP-V15JOVGD running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               C:/Users/zzx/Desktop/SourceProgram/lab30_Risc5CPU/vivado201701/Risc5CPU.sim/sim_1/impl/timing/xsim/Risc5CPU_tb_v_time_impl.v
// Design      : PipelineCPUTest
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module RAM32M_UNIQ_BASE_
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD32
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD33
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD34
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD35
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD36
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD37
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD38
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD39
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD40
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD41
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD42
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM64X1S_UNIQ_BASE_
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD1
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD10
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD11
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD12
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD13
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD14
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD15
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD16
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD17
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD18
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD19
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD2
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD20
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD21
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD22
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD23
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD24
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD25
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD26
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD27
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD28
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD29
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD3
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD30
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD31
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD4
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD5
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD6
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD7
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD8
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD9
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module DCM_PLL
   (clk_out1,
    clk_out2,
    reset,
    locked,
    clk_in1,
    lopt);
  output clk_out1;
  output clk_out2;
  input reset;
  output locked;
  input clk_in1;
  output lopt;

  wire clk_in1;
  wire clk_out1;
  wire clk_out2;
  wire lopt;
  wire reset;
  wire NLW_inst_locked_UNCONNECTED;

  DCM_PLL_DCM_PLL_clk_wiz inst
       (.clk_in1(clk_in1),
        .clk_out1(clk_out1),
        .clk_out2(clk_out2),
        .locked(NLW_inst_locked_UNCONNECTED),
        .lopt(lopt),
        .reset(reset));
endmodule

(* ORIG_REF_NAME = "DCM_PLL_clk_wiz" *) 
module DCM_PLL_DCM_PLL_clk_wiz
   (clk_out1,
    clk_out2,
    reset,
    locked,
    clk_in1,
    lopt);
  output clk_out1;
  output clk_out2;
  input reset;
  output locked;
  input clk_in1;
  output lopt;

  wire clk_in1;
  wire clk_in1_DCM_PLL;
  wire clk_out1;
  wire clk_out1_DCM_PLL;
  wire clk_out2_DCM_PLL;
  wire clkfbout_DCM_PLL;
  wire clkfbout_buf_DCM_PLL;
  wire reset;
  wire NLW_mmcm_adv_inst_CLKFBOUTB_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKFBSTOPPED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKINSTOPPED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT0B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT1B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT2_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT2B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT3_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT3B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT4_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT5_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT6_UNCONNECTED;
  wire NLW_mmcm_adv_inst_DRDY_UNCONNECTED;
  wire NLW_mmcm_adv_inst_LOCKED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_PSDONE_UNCONNECTED;
  wire [15:0]NLW_mmcm_adv_inst_DO_UNCONNECTED;

  assign clk_out2 = clk_out2_DCM_PLL;
  assign lopt = clk_out1;
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG clkf_buf
       (.I(clkfbout_DCM_PLL),
        .O(clkfbout_buf_DCM_PLL));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* IBUF_DELAY_VALUE = "0" *) 
  (* IFD_DELAY_VALUE = "AUTO" *) 
  IBUF #(
    .IOSTANDARD("DEFAULT")) 
    clkin1_ibufg
       (.I(clk_in1),
        .O(clk_in1_DCM_PLL));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG clkout1_buf
       (.I(clk_out1_DCM_PLL),
        .O(clk_out1));
  (* BOX_TYPE = "PRIMITIVE" *) 
  MMCME2_ADV #(
    .BANDWIDTH("OPTIMIZED"),
    .CLKFBOUT_MULT_F(10.000000),
    .CLKFBOUT_PHASE(0.000000),
    .CLKFBOUT_USE_FINE_PS("FALSE"),
    .CLKIN1_PERIOD(10.000000),
    .CLKIN2_PERIOD(0.000000),
    .CLKOUT0_DIVIDE_F(40.000000),
    .CLKOUT0_DUTY_CYCLE(0.500000),
    .CLKOUT0_PHASE(0.000000),
    .CLKOUT0_USE_FINE_PS("FALSE"),
    .CLKOUT1_DIVIDE(4),
    .CLKOUT1_DUTY_CYCLE(0.500000),
    .CLKOUT1_PHASE(0.000000),
    .CLKOUT1_USE_FINE_PS("FALSE"),
    .CLKOUT2_DIVIDE(1),
    .CLKOUT2_DUTY_CYCLE(0.500000),
    .CLKOUT2_PHASE(0.000000),
    .CLKOUT2_USE_FINE_PS("FALSE"),
    .CLKOUT3_DIVIDE(1),
    .CLKOUT3_DUTY_CYCLE(0.500000),
    .CLKOUT3_PHASE(0.000000),
    .CLKOUT3_USE_FINE_PS("FALSE"),
    .CLKOUT4_CASCADE("FALSE"),
    .CLKOUT4_DIVIDE(1),
    .CLKOUT4_DUTY_CYCLE(0.500000),
    .CLKOUT4_PHASE(0.000000),
    .CLKOUT4_USE_FINE_PS("FALSE"),
    .CLKOUT5_DIVIDE(1),
    .CLKOUT5_DUTY_CYCLE(0.500000),
    .CLKOUT5_PHASE(0.000000),
    .CLKOUT5_USE_FINE_PS("FALSE"),
    .CLKOUT6_DIVIDE(1),
    .CLKOUT6_DUTY_CYCLE(0.500000),
    .CLKOUT6_PHASE(0.000000),
    .CLKOUT6_USE_FINE_PS("FALSE"),
    .COMPENSATION("ZHOLD"),
    .DIVCLK_DIVIDE(1),
    .IS_CLKINSEL_INVERTED(1'b0),
    .IS_PSEN_INVERTED(1'b0),
    .IS_PSINCDEC_INVERTED(1'b0),
    .IS_PWRDWN_INVERTED(1'b0),
    .IS_RST_INVERTED(1'b0),
    .REF_JITTER1(0.010000),
    .REF_JITTER2(0.010000),
    .SS_EN("FALSE"),
    .SS_MODE("CENTER_HIGH"),
    .SS_MOD_PERIOD(10000),
    .STARTUP_WAIT("FALSE")) 
    mmcm_adv_inst
       (.CLKFBIN(clkfbout_buf_DCM_PLL),
        .CLKFBOUT(clkfbout_DCM_PLL),
        .CLKFBOUTB(NLW_mmcm_adv_inst_CLKFBOUTB_UNCONNECTED),
        .CLKFBSTOPPED(NLW_mmcm_adv_inst_CLKFBSTOPPED_UNCONNECTED),
        .CLKIN1(clk_in1_DCM_PLL),
        .CLKIN2(1'b0),
        .CLKINSEL(1'b1),
        .CLKINSTOPPED(NLW_mmcm_adv_inst_CLKINSTOPPED_UNCONNECTED),
        .CLKOUT0(clk_out1_DCM_PLL),
        .CLKOUT0B(NLW_mmcm_adv_inst_CLKOUT0B_UNCONNECTED),
        .CLKOUT1(clk_out2_DCM_PLL),
        .CLKOUT1B(NLW_mmcm_adv_inst_CLKOUT1B_UNCONNECTED),
        .CLKOUT2(NLW_mmcm_adv_inst_CLKOUT2_UNCONNECTED),
        .CLKOUT2B(NLW_mmcm_adv_inst_CLKOUT2B_UNCONNECTED),
        .CLKOUT3(NLW_mmcm_adv_inst_CLKOUT3_UNCONNECTED),
        .CLKOUT3B(NLW_mmcm_adv_inst_CLKOUT3B_UNCONNECTED),
        .CLKOUT4(NLW_mmcm_adv_inst_CLKOUT4_UNCONNECTED),
        .CLKOUT5(NLW_mmcm_adv_inst_CLKOUT5_UNCONNECTED),
        .CLKOUT6(NLW_mmcm_adv_inst_CLKOUT6_UNCONNECTED),
        .DADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DCLK(1'b0),
        .DEN(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DO(NLW_mmcm_adv_inst_DO_UNCONNECTED[15:0]),
        .DRDY(NLW_mmcm_adv_inst_DRDY_UNCONNECTED),
        .DWE(1'b0),
        .LOCKED(NLW_mmcm_adv_inst_LOCKED_UNCONNECTED),
        .PSCLK(1'b0),
        .PSDONE(NLW_mmcm_adv_inst_PSDONE_UNCONNECTED),
        .PSEN(1'b0),
        .PSINCDEC(1'b0),
        .PWRDWN(1'b0),
        .RST(reset));
endmodule

module DFF
   (\TMDSn[2] ,
    \q_reg[152] ,
    Q,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \TMDSn[2]_2 ,
    offset_w,
    \PC_reg_reg[30] ,
    \PC_reg_reg[0] ,
    \q_reg[110] ,
    \q_reg[56]_0 ,
    \q_reg[78] ,
    \PC_reg_reg[31] ,
    S,
    \PC_reg_reg[7] ,
    \PC_reg_reg[11] ,
    \PC_reg_reg[15] ,
    \PC_reg_reg[19] ,
    \PC_reg_reg[23] ,
    \PC_reg_reg[27] ,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[5] ,
    \PosX_reg_reg[4]_2 ,
    \PosX_reg_reg[4]_3 ,
    \PosX_reg_reg[9] ,
    p_0_in__1,
    \PosX_reg_reg[2] ,
    w_JumpAddr,
    D,
    \PC_reg_reg[2] ,
    \PC_reg_reg[6] ,
    \PC_reg_reg[9] ,
    \PC_reg_reg[10] ,
    \PC_reg_reg[13] ,
    \PC_reg_reg[15]_0 ,
    \PC_reg_reg[17] ,
    \PC_reg_reg[19]_0 ,
    \PC_reg_reg[21] ,
    \PC_reg_reg[23]_0 ,
    \PC_reg_reg[25] ,
    \PC_reg_reg[27]_0 ,
    \PC_reg_reg[29] ,
    SR,
    \q_reg[43]_0 ,
    \q_reg[19]_0 ,
    ReadData10,
    \q_reg[42]_0 ,
    \q_reg[41]_0 ,
    \q_reg[54]_0 ,
    \q_reg[55]_0 ,
    \q_reg[69] ,
    \q_reg[70] ,
    \q_reg[2]_0 ,
    E,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [78:0]\q_reg[152] ;
  output [7:0]Q;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output \TMDSn[2]_2 ;
  output [16:0]offset_w;
  output [16:0]\PC_reg_reg[30] ;
  output \PC_reg_reg[0] ;
  output \q_reg[110] ;
  output \q_reg[56]_0 ;
  output \q_reg[78] ;
  output [3:0]\PC_reg_reg[31] ;
  output [3:0]S;
  output [3:0]\PC_reg_reg[7] ;
  output [3:0]\PC_reg_reg[11] ;
  output [3:0]\PC_reg_reg[15] ;
  output [3:0]\PC_reg_reg[19] ;
  output [3:0]\PC_reg_reg[23] ;
  output [3:0]\PC_reg_reg[27] ;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[5] ;
  input \PosX_reg_reg[4]_2 ;
  input \PosX_reg_reg[4]_3 ;
  input \PosX_reg_reg[9] ;
  input [0:0]p_0_in__1;
  input [0:0]\PosX_reg_reg[2] ;
  input [16:0]w_JumpAddr;
  input [57:0]D;
  input \PC_reg_reg[2] ;
  input \PC_reg_reg[6] ;
  input \PC_reg_reg[9] ;
  input \PC_reg_reg[10] ;
  input \PC_reg_reg[13] ;
  input \PC_reg_reg[15]_0 ;
  input \PC_reg_reg[17] ;
  input \PC_reg_reg[19]_0 ;
  input \PC_reg_reg[21] ;
  input \PC_reg_reg[23]_0 ;
  input \PC_reg_reg[25] ;
  input \PC_reg_reg[27]_0 ;
  input \PC_reg_reg[29] ;
  input [0:0]SR;
  input \q_reg[43]_0 ;
  input \q_reg[19]_0 ;
  input [2:0]ReadData10;
  input \q_reg[42]_0 ;
  input \q_reg[41]_0 ;
  input \q_reg[54]_0 ;
  input \q_reg[55]_0 ;
  input \q_reg[69] ;
  input [29:0]\q_reg[70] ;
  input [2:0]\q_reg[2]_0 ;
  input [0:0]E;
  input cpu_clk_BUFG;

  wire [57:0]D;
  wire [0:0]E;
  wire [13:1]Instruction_id;
  wire JumpAddr0_carry_i_10_n_0;
  wire JumpAddr0_carry_i_9_n_0;
  wire [0:0]JumpFlag;
  wire \PC_reg[31]_i_12_n_0 ;
  wire \PC_reg[31]_i_13_n_0 ;
  wire \PC_reg[31]_i_14_n_0 ;
  wire \PC_reg_reg[0] ;
  wire \PC_reg_reg[10] ;
  wire [3:0]\PC_reg_reg[11] ;
  wire \PC_reg_reg[13] ;
  wire [3:0]\PC_reg_reg[15] ;
  wire \PC_reg_reg[15]_0 ;
  wire \PC_reg_reg[17] ;
  wire [3:0]\PC_reg_reg[19] ;
  wire \PC_reg_reg[19]_0 ;
  wire \PC_reg_reg[21] ;
  wire [3:0]\PC_reg_reg[23] ;
  wire \PC_reg_reg[23]_0 ;
  wire \PC_reg_reg[25] ;
  wire [3:0]\PC_reg_reg[27] ;
  wire \PC_reg_reg[27]_0 ;
  wire \PC_reg_reg[29] ;
  wire \PC_reg_reg[2] ;
  wire [16:0]\PC_reg_reg[30] ;
  wire [3:0]\PC_reg_reg[31] ;
  wire \PC_reg_reg[6] ;
  wire [3:0]\PC_reg_reg[7] ;
  wire \PC_reg_reg[9] ;
  wire [0:0]\PosX_reg_reg[2] ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[5] ;
  wire \PosX_reg_reg[9] ;
  wire [7:0]Q;
  wire [2:0]ReadData10;
  wire [3:0]S;
  wire [0:0]SR;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_2 ;
  wire char_tab_i_123_n_0;
  wire char_tab_i_85_n_0;
  wire cpu_clk_BUFG;
  wire [16:0]offset_w;
  wire [0:0]p_0_in__1;
  wire \q[115]_i_2_n_0 ;
  wire \q[141]_i_2_n_0 ;
  wire \q[141]_i_3_n_0 ;
  wire \q[141]_i_4_n_0 ;
  wire \q[146]_i_2_n_0 ;
  wire \q[147]_i_2_n_0 ;
  wire \q[147]_i_3_n_0 ;
  wire \q[149]_i_2_n_0 ;
  wire \q[63]_i_1_n_0 ;
  wire \q_reg[110] ;
  wire [78:0]\q_reg[152] ;
  wire \q_reg[19]_0 ;
  wire [2:0]\q_reg[2]_0 ;
  wire \q_reg[41]_0 ;
  wire \q_reg[42]_0 ;
  wire \q_reg[43]_0 ;
  wire \q_reg[54]_0 ;
  wire \q_reg[55]_0 ;
  wire \q_reg[56]_0 ;
  wire \q_reg[69] ;
  wire [29:0]\q_reg[70] ;
  wire \q_reg[78] ;
  wire [4:2]\u_ID/p_0_in ;
  wire [16:0]w_JumpAddr;

  LUT4 #(
    .INIT(16'h8808)) 
    JumpAddr0_carry__0_i_1
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Q[6]),
        .I2(Q[1]),
        .I3(Q[0]),
        .O(offset_w[7]));
  LUT4 #(
    .INIT(16'h8808)) 
    JumpAddr0_carry__0_i_2
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Q[5]),
        .I2(Q[1]),
        .I3(Q[0]),
        .O(offset_w[6]));
  LUT4 #(
    .INIT(16'h8808)) 
    JumpAddr0_carry__0_i_3
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Q[4]),
        .I2(Q[1]),
        .I3(Q[0]),
        .O(offset_w[5]));
  LUT5 #(
    .INIT(32'h8B008800)) 
    JumpAddr0_carry__0_i_4
       (.I0(\q_reg[152] [40]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(JumpAddr0_carry_i_9_n_0),
        .I4(\q_reg[152] [36]),
        .O(offset_w[4]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__0_i_5
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [5]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [7]),
        .O(\PC_reg_reg[7] [3]));
  LUT6 #(
    .INIT(64'h5F65FFFFA06A0000)) 
    JumpAddr0_carry__0_i_6
       (.I0(Q[5]),
        .I1(\q_reg[70] [4]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(JumpAddr0_carry_i_9_n_0),
        .I5(\q_reg[152] [6]),
        .O(\PC_reg_reg[7] [2]));
  LUT6 #(
    .INIT(64'h5F65FFFFA06A0000)) 
    JumpAddr0_carry__0_i_7
       (.I0(Q[4]),
        .I1(\q_reg[70] [3]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(JumpAddr0_carry_i_9_n_0),
        .I5(\q_reg[152] [5]),
        .O(\PC_reg_reg[7] [1]));
  LUT6 #(
    .INIT(64'h33F7FFF7CC080008)) 
    JumpAddr0_carry__0_i_8
       (.I0(\q_reg[152] [36]),
        .I1(JumpAddr0_carry_i_9_n_0),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(\q_reg[152] [40]),
        .I5(\u_ID/p_0_in [4]),
        .O(\PC_reg_reg[7] [0]));
  LUT6 #(
    .INIT(64'hB888B888B8BBB888)) 
    JumpAddr0_carry__0_i_9
       (.I0(\q_reg[152] [4]),
        .I1(JumpAddr0_carry_i_10_n_0),
        .I2(\q_reg[43]_0 ),
        .I3(\q_reg[19]_0 ),
        .I4(ReadData10[2]),
        .I5(\q_reg[110] ),
        .O(\u_ID/p_0_in [4]));
  LUT6 #(
    .INIT(64'hA0A0A8080000A808)) 
    JumpAddr0_carry__1_i_1
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(\q_reg[152] [32]),
        .I2(Q[0]),
        .I3(Q[6]),
        .I4(Q[1]),
        .I5(\q_reg[152] [37]),
        .O(offset_w[9]));
  LUT4 #(
    .INIT(16'h8808)) 
    JumpAddr0_carry__1_i_2
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Q[7]),
        .I2(Q[1]),
        .I3(Q[0]),
        .O(offset_w[8]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__1_i_3
       (.I0(offset_w[9]),
        .I1(\q_reg[70] [9]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [11]),
        .O(\PC_reg_reg[11] [3]));
  LUT6 #(
    .INIT(64'h5F65FFFFA06A0000)) 
    JumpAddr0_carry__1_i_4
       (.I0(Q[7]),
        .I1(\q_reg[70] [8]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(JumpAddr0_carry_i_9_n_0),
        .I5(\q_reg[152] [10]),
        .O(\PC_reg_reg[11] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__1_i_5
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [7]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [9]),
        .O(\PC_reg_reg[11] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__1_i_6
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [6]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [8]),
        .O(\PC_reg_reg[11] [0]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__2_i_1
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(\q_reg[152] [41]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[13]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__2_i_2
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Q[3]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[12]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__2_i_3
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Instruction_id[13]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[11]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__2_i_4
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(Instruction_id[12]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[10]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__2_i_5
       (.I0(offset_w[13]),
        .I1(\q_reg[70] [13]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [15]),
        .O(\PC_reg_reg[15] [3]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__2_i_6
       (.I0(offset_w[12]),
        .I1(\q_reg[70] [12]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [14]),
        .O(\PC_reg_reg[15] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__2_i_7
       (.I0(offset_w[11]),
        .I1(\q_reg[70] [11]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [13]),
        .O(\PC_reg_reg[15] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__2_i_8
       (.I0(offset_w[10]),
        .I1(\q_reg[70] [10]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [12]),
        .O(\PC_reg_reg[15] [0]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__3_i_1
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(\q_reg[152] [44]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[16]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__3_i_2
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(\q_reg[152] [43]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[15]));
  LUT5 #(
    .INIT(32'h80AA8000)) 
    JumpAddr0_carry__3_i_3
       (.I0(JumpAddr0_carry_i_9_n_0),
        .I1(\q_reg[152] [42]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[6]),
        .O(offset_w[14]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__3_i_4
       (.I0(offset_w[16]),
        .I1(\q_reg[70] [17]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [19]),
        .O(\PC_reg_reg[19] [3]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__3_i_5
       (.I0(offset_w[16]),
        .I1(\q_reg[70] [16]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [18]),
        .O(\PC_reg_reg[19] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__3_i_6
       (.I0(offset_w[15]),
        .I1(\q_reg[70] [15]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [17]),
        .O(\PC_reg_reg[19] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__3_i_7
       (.I0(offset_w[14]),
        .I1(\q_reg[70] [14]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [16]),
        .O(\PC_reg_reg[19] [0]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__4_i_1
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [21]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [23]),
        .O(\PC_reg_reg[23] [3]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__4_i_2
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [20]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [22]),
        .O(\PC_reg_reg[23] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__4_i_3
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [19]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [21]),
        .O(\PC_reg_reg[23] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__4_i_4
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [18]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [20]),
        .O(\PC_reg_reg[23] [0]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__5_i_1
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [25]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [27]),
        .O(\PC_reg_reg[27] [3]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__5_i_2
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [24]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [26]),
        .O(\PC_reg_reg[27] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__5_i_3
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [23]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [25]),
        .O(\PC_reg_reg[27] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__5_i_4
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [22]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [24]),
        .O(\PC_reg_reg[27] [0]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__6_i_1
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [29]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [31]),
        .O(\PC_reg_reg[31] [3]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__6_i_2
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [28]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [30]),
        .O(\PC_reg_reg[31] [2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__6_i_3
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [27]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [29]),
        .O(\PC_reg_reg[31] [1]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry__6_i_4
       (.I0(offset_w[7]),
        .I1(\q_reg[70] [26]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [28]),
        .O(\PC_reg_reg[31] [0]));
  LUT5 #(
    .INIT(32'h8B008800)) 
    JumpAddr0_carry_i_1
       (.I0(\q_reg[152] [40]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(JumpAddr0_carry_i_9_n_0),
        .I4(\q_reg[152] [35]),
        .O(offset_w[3]));
  LUT6 #(
    .INIT(64'hFFFFBFFFFFFFFFFF)) 
    JumpAddr0_carry_i_10
       (.I0(Instruction_id[4]),
        .I1(Instruction_id[5]),
        .I2(Q[2]),
        .I3(Instruction_id[1]),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(JumpAddr0_carry_i_10_n_0));
  LUT6 #(
    .INIT(64'hB888B888B8BBB888)) 
    JumpAddr0_carry_i_11
       (.I0(\q_reg[152] [3]),
        .I1(JumpAddr0_carry_i_10_n_0),
        .I2(\q_reg[42]_0 ),
        .I3(\q_reg[19]_0 ),
        .I4(ReadData10[1]),
        .I5(\q_reg[110] ),
        .O(\u_ID/p_0_in [3]));
  LUT6 #(
    .INIT(64'hB888B888B8BBB888)) 
    JumpAddr0_carry_i_12
       (.I0(\q_reg[152] [2]),
        .I1(JumpAddr0_carry_i_10_n_0),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[19]_0 ),
        .I4(ReadData10[0]),
        .I5(\q_reg[110] ),
        .O(\u_ID/p_0_in [2]));
  LUT5 #(
    .INIT(32'h8B008800)) 
    JumpAddr0_carry_i_2
       (.I0(\q_reg[152] [39]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(JumpAddr0_carry_i_9_n_0),
        .I4(\q_reg[152] [34]),
        .O(offset_w[2]));
  LUT5 #(
    .INIT(32'h8B008800)) 
    JumpAddr0_carry_i_3
       (.I0(\q_reg[152] [38]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(JumpAddr0_carry_i_9_n_0),
        .I4(\q_reg[152] [33]),
        .O(offset_w[1]));
  LUT2 #(
    .INIT(4'h2)) 
    JumpAddr0_carry_i_4
       (.I0(\q_reg[152] [37]),
        .I1(JumpAddr0_carry_i_10_n_0),
        .O(offset_w[0]));
  LUT6 #(
    .INIT(64'h33F7FFF7CC080008)) 
    JumpAddr0_carry_i_5
       (.I0(\q_reg[152] [35]),
        .I1(JumpAddr0_carry_i_9_n_0),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(\q_reg[152] [40]),
        .I5(\u_ID/p_0_in [3]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'h33F7FFF7CC080008)) 
    JumpAddr0_carry_i_6
       (.I0(\q_reg[152] [34]),
        .I1(JumpAddr0_carry_i_9_n_0),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(\q_reg[152] [39]),
        .I5(\u_ID/p_0_in [2]),
        .O(S[2]));
  LUT4 #(
    .INIT(16'h56A6)) 
    JumpAddr0_carry_i_7
       (.I0(offset_w[1]),
        .I1(\q_reg[70] [2]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [1]),
        .O(S[1]));
  LUT4 #(
    .INIT(16'hF606)) 
    JumpAddr0_carry_i_8
       (.I0(\q_reg[152] [37]),
        .I1(\q_reg[70] [1]),
        .I2(JumpAddr0_carry_i_10_n_0),
        .I3(\q_reg[152] [0]),
        .O(S[0]));
  LUT4 #(
    .INIT(16'h4000)) 
    JumpAddr0_carry_i_9
       (.I0(Instruction_id[4]),
        .I1(Instruction_id[5]),
        .I2(Q[2]),
        .I3(Instruction_id[1]),
        .O(JumpAddr0_carry_i_9_n_0));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \PC_reg[0]_i_1 
       (.I0(w_JumpAddr[0]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[26]),
        .O(\PC_reg_reg[30] [0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[11]_i_1 
       (.I0(w_JumpAddr[6]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[37]),
        .I3(\PC_reg_reg[9] ),
        .O(\PC_reg_reg[30] [6]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[12]_i_1 
       (.I0(w_JumpAddr[7]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[38]),
        .I3(\PC_reg_reg[10] ),
        .O(\PC_reg_reg[30] [7]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[15]_i_1 
       (.I0(w_JumpAddr[8]),
        .I1(\PC_reg_reg[0] ),
        .I2(\PC_reg_reg[13] ),
        .I3(D[41]),
        .O(\PC_reg_reg[30] [8]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[16]_i_1 
       (.I0(w_JumpAddr[9]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[42]),
        .I3(\PC_reg_reg[15]_0 ),
        .O(\PC_reg_reg[30] [9]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[19]_i_1 
       (.I0(w_JumpAddr[10]),
        .I1(\PC_reg_reg[0] ),
        .I2(\PC_reg_reg[17] ),
        .I3(D[45]),
        .O(\PC_reg_reg[30] [10]));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \PC_reg[1]_i_1 
       (.I0(w_JumpAddr[1]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[27]),
        .O(\PC_reg_reg[30] [1]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[20]_i_1 
       (.I0(w_JumpAddr[11]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[46]),
        .I3(\PC_reg_reg[19]_0 ),
        .O(\PC_reg_reg[30] [11]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[23]_i_1 
       (.I0(w_JumpAddr[12]),
        .I1(\PC_reg_reg[0] ),
        .I2(\PC_reg_reg[21] ),
        .I3(D[49]),
        .O(\PC_reg_reg[30] [12]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[24]_i_1 
       (.I0(w_JumpAddr[13]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[50]),
        .I3(\PC_reg_reg[23]_0 ),
        .O(\PC_reg_reg[30] [13]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[27]_i_1 
       (.I0(w_JumpAddr[14]),
        .I1(\PC_reg_reg[0] ),
        .I2(\PC_reg_reg[25] ),
        .I3(D[53]),
        .O(\PC_reg_reg[30] [14]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[28]_i_1 
       (.I0(w_JumpAddr[15]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[54]),
        .I3(\PC_reg_reg[27]_0 ),
        .O(\PC_reg_reg[30] [15]));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'h8B)) 
    \PC_reg[2]_i_1 
       (.I0(w_JumpAddr[2]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[28]),
        .O(\PC_reg_reg[30] [2]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[30]_i_1 
       (.I0(w_JumpAddr[16]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[56]),
        .I3(\PC_reg_reg[29] ),
        .O(\PC_reg_reg[30] [16]));
  LUT2 #(
    .INIT(4'hE)) 
    \PC_reg[31]_i_12 
       (.I0(Q[3]),
        .I1(Instruction_id[13]),
        .O(\PC_reg[31]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h6656000065660000)) 
    \PC_reg[31]_i_13 
       (.I0(Instruction_id[12]),
        .I1(\q_reg[69] ),
        .I2(\q_reg[70] [0]),
        .I3(\q_reg[70] [29]),
        .I4(Q[3]),
        .I5(Instruction_id[13]),
        .O(\PC_reg[31]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFFFFFFF)) 
    \PC_reg[31]_i_14 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Instruction_id[1]),
        .I3(Q[2]),
        .I4(Instruction_id[5]),
        .I5(Instruction_id[4]),
        .O(\PC_reg[31]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF20000000)) 
    \PC_reg[31]_i_5 
       (.I0(Q[0]),
        .I1(Instruction_id[4]),
        .I2(Instruction_id[5]),
        .I3(Q[2]),
        .I4(Instruction_id[1]),
        .I5(JumpFlag),
        .O(\PC_reg_reg[0] ));
  LUT6 #(
    .INIT(64'h00000000FFFF00E1)) 
    \PC_reg[31]_i_9 
       (.I0(\q_reg[54]_0 ),
        .I1(\q_reg[55]_0 ),
        .I2(Instruction_id[12]),
        .I3(\PC_reg[31]_i_12_n_0 ),
        .I4(\PC_reg[31]_i_13_n_0 ),
        .I5(\PC_reg[31]_i_14_n_0 ),
        .O(JumpFlag));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[3]_i_1 
       (.I0(w_JumpAddr[3]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[28]),
        .I3(D[29]),
        .O(\PC_reg_reg[30] [3]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[7]_i_1 
       (.I0(w_JumpAddr[4]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[33]),
        .I3(\PC_reg_reg[2] ),
        .O(\PC_reg_reg[30] [4]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \PC_reg[8]_i_1 
       (.I0(w_JumpAddr[5]),
        .I1(\PC_reg_reg[0] ),
        .I2(D[34]),
        .I3(\PC_reg_reg[6] ),
        .O(\PC_reg_reg[30] [5]));
  LUT2 #(
    .INIT(4'h8)) 
    char_tab_i_100
       (.I0(\q_reg[152] [37]),
        .I1(\PosX_reg_reg[4]_0 ),
        .O(\TMDSn[2]_2 ));
  LUT6 #(
    .INIT(64'hFFFFEA400000EA40)) 
    char_tab_i_123
       (.I0(\PosX_reg_reg[4]_2 ),
        .I1(JumpAddr0_carry_i_9_n_0),
        .I2(Q[0]),
        .I3(Instruction_id[1]),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(Instruction_id[5]),
        .O(char_tab_i_123_n_0));
  LUT5 #(
    .INIT(32'hFFE400E4)) 
    char_tab_i_53
       (.I0(\PosX_reg_reg[4] ),
        .I1(char_tab_i_85_n_0),
        .I2(\q_reg[152] [43]),
        .I3(\PosX_reg_reg[4]_0 ),
        .I4(\q_reg[152] [38]),
        .O(\TMDSn[2] ));
  LUT5 #(
    .INIT(32'hFFE400E4)) 
    char_tab_i_85
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(char_tab_i_123_n_0),
        .I2(\q_reg[152] [34]),
        .I3(\PosX_reg_reg[5] ),
        .I4(Instruction_id[13]),
        .O(char_tab_i_85_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    char_tab_i_96
       (.I0(Instruction_id[12]),
        .I1(\PosX_reg_reg[5] ),
        .O(\TMDSn[2]_1 ));
  LUT6 #(
    .INIT(64'hB3F3B33380C08000)) 
    char_tab_i_98
       (.I0(Instruction_id[4]),
        .I1(\PosX_reg_reg[9] ),
        .I2(p_0_in__1),
        .I3(\PosX_reg_reg[2] ),
        .I4(Instruction_id[1]),
        .I5(JumpFlag),
        .O(\TMDSn[2]_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \q[110]_i_3 
       (.I0(\q_reg[152] [44]),
        .I1(\q_reg[152] [41]),
        .I2(\q_reg[152] [42]),
        .I3(\q_reg[152] [43]),
        .O(\q_reg[110] ));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[111]_i_1 
       (.I0(\q_reg[152] [77]),
        .I1(\q_reg[152] [32]),
        .I2(\q[115]_i_2_n_0 ),
        .I3(\q_reg[152] [37]),
        .O(\q_reg[152] [45]));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[112]_i_1 
       (.I0(\q_reg[152] [77]),
        .I1(\q_reg[152] [33]),
        .I2(\q[115]_i_2_n_0 ),
        .I3(\q_reg[152] [38]),
        .O(\q_reg[152] [46]));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[113]_i_1 
       (.I0(\q_reg[152] [77]),
        .I1(\q_reg[152] [34]),
        .I2(\q[115]_i_2_n_0 ),
        .I3(\q_reg[152] [39]),
        .O(\q_reg[152] [47]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \q[114]_i_1 
       (.I0(\q[115]_i_2_n_0 ),
        .I1(\q_reg[152] [40]),
        .I2(\q_reg[152] [77]),
        .I3(\q_reg[152] [35]),
        .O(\q_reg[152] [48]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \q[115]_i_1 
       (.I0(\q[115]_i_2_n_0 ),
        .I1(\q_reg[152] [40]),
        .I2(\q_reg[152] [77]),
        .I3(\q_reg[152] [36]),
        .O(\q_reg[152] [49]));
  LUT5 #(
    .INIT(32'h00000010)) 
    \q[115]_i_2 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Instruction_id[1]),
        .I3(Q[2]),
        .I4(Instruction_id[5]),
        .O(\q[115]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \q[116]_i_1 
       (.I0(\q[141]_i_2_n_0 ),
        .I1(Q[4]),
        .I2(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [50]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \q[117]_i_1 
       (.I0(\q[141]_i_2_n_0 ),
        .I1(Q[5]),
        .I2(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [51]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT3 #(
    .INIT(8'h02)) 
    \q[118]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [52]));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \q[121]_i_1 
       (.I0(\q[141]_i_2_n_0 ),
        .I1(Q[7]),
        .I2(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [53]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[123]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(Instruction_id[12]),
        .O(\q_reg[152] [54]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[124]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(Instruction_id[13]),
        .O(\q_reg[152] [55]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[125]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(Q[3]),
        .O(\q_reg[152] [56]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[126]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [41]),
        .O(\q_reg[152] [57]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[127]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [42]),
        .O(\q_reg[152] [58]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[128]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [43]),
        .O(\q_reg[152] [59]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[130]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [44]),
        .O(\q_reg[152] [60]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[131]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [37]),
        .O(\q_reg[152] [61]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[132]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [38]),
        .O(\q_reg[152] [62]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[133]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [39]),
        .O(\q_reg[152] [63]));
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[134]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q_reg[152] [40]),
        .O(\q_reg[152] [64]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[136]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(Q[4]),
        .O(\q_reg[152] [65]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT5 #(
    .INIT(32'h020F0202)) 
    \q[137]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(\q[141]_i_4_n_0 ),
        .I3(\q[141]_i_3_n_0 ),
        .I4(Q[5]),
        .O(\q_reg[152] [66]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT4 #(
    .INIT(16'h002A)) 
    \q[138]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_3_n_0 ),
        .I2(\q[141]_i_2_n_0 ),
        .I3(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [67]));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'h000022F2)) 
    \q[141]_i_1 
       (.I0(Q[6]),
        .I1(\q[141]_i_2_n_0 ),
        .I2(Q[7]),
        .I3(\q[141]_i_3_n_0 ),
        .I4(\q[141]_i_4_n_0 ),
        .O(\q_reg[152] [68]));
  LUT6 #(
    .INIT(64'hFFFFFFFBFFFFFBFB)) 
    \q[141]_i_2 
       (.I0(Q[2]),
        .I1(Instruction_id[1]),
        .I2(Q[1]),
        .I3(Instruction_id[5]),
        .I4(Q[0]),
        .I5(Instruction_id[4]),
        .O(\q[141]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFBFFFFFF)) 
    \q[141]_i_3 
       (.I0(Q[2]),
        .I1(Instruction_id[1]),
        .I2(Q[1]),
        .I3(Instruction_id[4]),
        .I4(Q[0]),
        .O(\q[141]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0800)) 
    \q[141]_i_4 
       (.I0(\q[115]_i_2_n_0 ),
        .I1(Instruction_id[4]),
        .I2(Instruction_id[13]),
        .I3(Instruction_id[12]),
        .O(\q[141]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hDFDFFFFFFFBFFFFF)) 
    \q[143]_i_1 
       (.I0(Q[0]),
        .I1(Instruction_id[4]),
        .I2(Instruction_id[5]),
        .I3(Q[1]),
        .I4(Instruction_id[1]),
        .I5(Q[2]),
        .O(\q_reg[152] [69]));
  LUT5 #(
    .INIT(32'h00800000)) 
    \q[144]_i_1 
       (.I0(Instruction_id[1]),
        .I1(Q[2]),
        .I2(Instruction_id[5]),
        .I3(Instruction_id[4]),
        .I4(Q[0]),
        .O(\q_reg[152] [70]));
  LUT6 #(
    .INIT(64'h0010000080800000)) 
    \q[145]_i_1 
       (.I0(Instruction_id[5]),
        .I1(Q[2]),
        .I2(Instruction_id[1]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(Instruction_id[4]),
        .O(\q_reg[152] [71]));
  LUT6 #(
    .INIT(64'h00000000F032FC30)) 
    \q[146]_i_1 
       (.I0(\q[146]_i_2_n_0 ),
        .I1(Instruction_id[12]),
        .I2(Instruction_id[13]),
        .I3(Q[3]),
        .I4(Q[7]),
        .I5(\q[149]_i_2_n_0 ),
        .O(\q_reg[152] [72]));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \q[146]_i_2 
       (.I0(Q[2]),
        .I1(Instruction_id[1]),
        .I2(Q[1]),
        .I3(Instruction_id[5]),
        .I4(Instruction_id[4]),
        .I5(Q[0]),
        .O(\q[146]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h2000200031002000)) 
    \q[147]_i_1 
       (.I0(Q[0]),
        .I1(\q[147]_i_2_n_0 ),
        .I2(Instruction_id[5]),
        .I3(Instruction_id[4]),
        .I4(Instruction_id[12]),
        .I5(\q[147]_i_3_n_0 ),
        .O(\q_reg[152] [73]));
  LUT3 #(
    .INIT(8'hFB)) 
    \q[147]_i_2 
       (.I0(Q[1]),
        .I1(Instruction_id[1]),
        .I2(Q[2]),
        .O(\q[147]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h40)) 
    \q[147]_i_3 
       (.I0(Instruction_id[13]),
        .I1(Q[3]),
        .I2(Q[7]),
        .O(\q[147]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT5 #(
    .INIT(32'h0000262E)) 
    \q[148]_i_1 
       (.I0(Q[3]),
        .I1(Instruction_id[12]),
        .I2(Instruction_id[13]),
        .I3(Q[7]),
        .I4(\q[149]_i_2_n_0 ),
        .O(\q_reg[152] [74]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT5 #(
    .INIT(32'h00006444)) 
    \q[149]_i_1 
       (.I0(Q[3]),
        .I1(Instruction_id[13]),
        .I2(Instruction_id[12]),
        .I3(Q[7]),
        .I4(\q[149]_i_2_n_0 ),
        .O(\q_reg[152] [75]));
  LUT5 #(
    .INIT(32'hFFEFFFFF)) 
    \q[149]_i_2 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Instruction_id[1]),
        .I3(Q[2]),
        .I4(Instruction_id[4]),
        .O(\q[149]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000100)) 
    \q[150]_i_1 
       (.I0(Instruction_id[4]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Instruction_id[1]),
        .I4(Q[2]),
        .I5(Instruction_id[5]),
        .O(\q_reg[152] [76]));
  LUT6 #(
    .INIT(64'h0000000000100000)) 
    \q[151]_i_1 
       (.I0(Instruction_id[4]),
        .I1(Q[0]),
        .I2(Instruction_id[5]),
        .I3(Q[1]),
        .I4(Instruction_id[1]),
        .I5(Q[2]),
        .O(\q_reg[152] [77]));
  LUT6 #(
    .INIT(64'h00300030A0000010)) 
    \q[152]_i_2 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Instruction_id[1]),
        .I3(Q[2]),
        .I4(Instruction_id[5]),
        .I5(Instruction_id[4]),
        .O(\q_reg[152] [78]));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[56]_i_3__0 
       (.I0(\q_reg[152] [39]),
        .I1(\q_reg[2]_0 [2]),
        .I2(\q_reg[152] [38]),
        .I3(\q_reg[2]_0 [1]),
        .I4(\q_reg[2]_0 [0]),
        .I5(\q_reg[152] [37]),
        .O(\q_reg[56]_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[63]_i_1 
       (.I0(SR),
        .I1(\PC_reg_reg[0] ),
        .O(\q[63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \q[78]_i_2 
       (.I0(\q_reg[152] [39]),
        .I1(\q_reg[152] [38]),
        .I2(\q_reg[152] [37]),
        .I3(\q_reg[152] [40]),
        .O(\q_reg[78] ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(Instruction_id[1]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[9]),
        .Q(\q_reg[152] [35]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[10]),
        .Q(\q_reg[152] [36]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[11]),
        .Q(Instruction_id[12]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[12]),
        .Q(Instruction_id[13]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[13]),
        .Q(Q[3]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[14]),
        .Q(\q_reg[152] [41]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[15]),
        .Q(\q_reg[152] [42]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[16]),
        .Q(\q_reg[152] [43]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[17]),
        .Q(\q_reg[152] [44]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[18]),
        .Q(\q_reg[152] [37]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[19]),
        .Q(\q_reg[152] [38]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[20]),
        .Q(\q_reg[152] [39]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[21]),
        .Q(\q_reg[152] [40]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[22]),
        .Q(Q[4]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[23]),
        .Q(Q[5]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[24]),
        .Q(Q[6]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(Q[0]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[25]),
        .Q(Q[7]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[26]),
        .Q(\q_reg[152] [0]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[27]),
        .Q(\q_reg[152] [1]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[28]),
        .Q(\q_reg[152] [2]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[29]),
        .Q(\q_reg[152] [3]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[30]),
        .Q(\q_reg[152] [4]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[31]),
        .Q(\q_reg[152] [5]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[32]),
        .Q(\q_reg[152] [6]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[33]),
        .Q(\q_reg[152] [7]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[2]),
        .Q(Q[1]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[34]),
        .Q(\q_reg[152] [8]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[35]),
        .Q(\q_reg[152] [9]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[36]),
        .Q(\q_reg[152] [10]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[37]),
        .Q(\q_reg[152] [11]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[38]),
        .Q(\q_reg[152] [12]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[39]),
        .Q(\q_reg[152] [13]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[40]),
        .Q(\q_reg[152] [14]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[41]),
        .Q(\q_reg[152] [15]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[42]),
        .Q(\q_reg[152] [16]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[43]),
        .Q(\q_reg[152] [17]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[3]),
        .Q(Instruction_id[4]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[44]),
        .Q(\q_reg[152] [18]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[45]),
        .Q(\q_reg[152] [19]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[46]),
        .Q(\q_reg[152] [20]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[47]),
        .Q(\q_reg[152] [21]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[48]),
        .Q(\q_reg[152] [22]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[49]),
        .Q(\q_reg[152] [23]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[50]),
        .Q(\q_reg[152] [24]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[51]),
        .Q(\q_reg[152] [25]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[52]),
        .Q(\q_reg[152] [26]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[53]),
        .Q(\q_reg[152] [27]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[4]),
        .Q(Instruction_id[5]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[54]),
        .Q(\q_reg[152] [28]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[55]),
        .Q(\q_reg[152] [29]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[56]),
        .Q(\q_reg[152] [30]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[57]),
        .Q(\q_reg[152] [31]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[5]),
        .Q(Q[2]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[6]),
        .Q(\q_reg[152] [32]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[7]),
        .Q(\q_reg[152] [33]),
        .R(\q[63]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[8]),
        .Q(\q_reg[152] [34]),
        .R(\q[63]_i_1_n_0 ));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized0
   (\TMDSn[2] ,
    \q_reg[71]_0 ,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    \q_reg[70]_0 ,
    \q_reg[40] ,
    \q_reg[69]_0 ,
    \q_reg[70]_1 ,
    \q_reg[69]_1 ,
    \q_reg[68]_0 ,
    \q_reg[66]_0 ,
    \q_reg[66]_1 ,
    \q_reg[67]_0 ,
    \q_reg[67]_1 ,
    \q_reg[64]_0 ,
    \q_reg[63]_0 ,
    \q_reg[63]_1 ,
    \q_reg[62]_0 ,
    \q_reg[62]_1 ,
    \q_reg[59]_0 ,
    \q_reg[59]_1 ,
    \q_reg[58]_0 ,
    \q_reg[58]_1 ,
    \q_reg[55]_0 ,
    \q_reg[55]_1 ,
    \q_reg[54]_0 ,
    \q_reg[54]_1 ,
    \q_reg[49]_0 ,
    \q_reg[64]_1 ,
    \q_reg[56]_0 ,
    \q_reg[65]_0 ,
    \q_reg[57]_0 ,
    \q_reg[53]_0 ,
    \q_reg[51]_0 ,
    \q_reg[60]_0 ,
    \q_reg[65]_1 ,
    \q_reg[52]_0 ,
    \TMDSn[2]_8 ,
    E,
    \TMDSn[2]_9 ,
    \TMDSn[2]_10 ,
    \TMDSn[2]_11 ,
    \TMDSn[2]_12 ,
    \TMDSn[2]_13 ,
    \TMDSn[2]_14 ,
    \TMDSn[2]_15 ,
    \TMDSn[2]_16 ,
    \TMDSn[2]_17 ,
    Q,
    \q_reg[10]_0 ,
    \q_reg[68]_1 ,
    \q_reg[65]_2 ,
    \q_reg[61]_0 ,
    \q_reg[61]_1 ,
    \q_reg[60]_1 ,
    \q_reg[57]_1 ,
    \q_reg[56]_1 ,
    \q_reg[53]_1 ,
    \q_reg[52]_1 ,
    \q_reg[10]_1 ,
    \q_reg[10]_2 ,
    \q_reg[42]_0 ,
    \q_reg[42]_1 ,
    D,
    \PosX_reg_reg[5] ,
    PosY__0,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[4]_2 ,
    \q_reg[147]_0 ,
    \PosX_reg_reg[4]_3 ,
    \PosX_reg_reg[5]_0 ,
    \PosX_reg_reg[4]_4 ,
    \PosX_reg_reg[4]_5 ,
    \PC_reg_reg[4] ,
    SR,
    \q_reg[70]_2 ,
    \q_reg[41]_0 ,
    \q_reg[69]_2 ,
    \q_reg[68]_2 ,
    \q_reg[67]_2 ,
    \q_reg[66]_2 ,
    \q_reg[65]_3 ,
    \q_reg[64]_2 ,
    \q_reg[63]_2 ,
    \q_reg[62]_2 ,
    \q_reg[61]_2 ,
    \q_reg[60]_2 ,
    \q_reg[59]_2 ,
    \q_reg[58]_2 ,
    \q_reg[57]_2 ,
    \q_reg[56]_2 ,
    \q_reg[55]_2 ,
    \q_reg[54]_2 ,
    \q_reg[53]_2 ,
    \q_reg[52]_2 ,
    \q_reg[51]_1 ,
    \q_reg[50]_0 ,
    \q_reg[49]_1 ,
    \q_reg[48]_0 ,
    \q_reg[47]_0 ,
    \q_reg[46]_0 ,
    \q_reg[45] ,
    \q_reg[6]_0 ,
    \q_reg[44]_0 ,
    \q_reg[45]_0 ,
    \q_reg[44]_1 ,
    \q_reg[43]_0 ,
    \q_reg[44]_2 ,
    \q_reg[42]_2 ,
    \q_reg[43]_1 ,
    \q_reg[41]_1 ,
    \q_reg[42]_3 ,
    \q_reg[41]_2 ,
    \q_reg[40]_0 ,
    \q_reg[41]_3 ,
    \q_reg[39]_0 ,
    \q_reg[40]_1 ,
    \q_reg[39]_1 ,
    \q_reg[41]_4 ,
    \q_reg[41]_5 ,
    \q_reg[2]_0 ,
    \q_reg[46]_1 ,
    \q_reg[145]_0 ,
    \q_reg[145]_1 ,
    \q_reg[46]_2 ,
    \q_reg[6]_1 ,
    \q_reg[45]_1 ,
    \q_reg[145]_2 ,
    \q_reg[43]_2 ,
    \q_reg[145]_3 ,
    \q_reg[42]_4 ,
    \q_reg[145]_4 ,
    \q_reg[145]_5 ,
    \q_reg[40]_2 ,
    \q_reg[46]_3 ,
    \q_reg[46]_4 ,
    \q_reg[2]_1 ,
    \q_reg[2]_2 ,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [41:0]\q_reg[71]_0 ;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output \q_reg[70]_0 ;
  output \q_reg[40] ;
  output \q_reg[69]_0 ;
  output \q_reg[70]_1 ;
  output \q_reg[69]_1 ;
  output \q_reg[68]_0 ;
  output \q_reg[66]_0 ;
  output \q_reg[66]_1 ;
  output \q_reg[67]_0 ;
  output \q_reg[67]_1 ;
  output \q_reg[64]_0 ;
  output \q_reg[63]_0 ;
  output \q_reg[63]_1 ;
  output \q_reg[62]_0 ;
  output \q_reg[62]_1 ;
  output \q_reg[59]_0 ;
  output \q_reg[59]_1 ;
  output \q_reg[58]_0 ;
  output \q_reg[58]_1 ;
  output \q_reg[55]_0 ;
  output \q_reg[55]_1 ;
  output \q_reg[54]_0 ;
  output \q_reg[54]_1 ;
  output \q_reg[49]_0 ;
  output \q_reg[64]_1 ;
  output \q_reg[56]_0 ;
  output \q_reg[65]_0 ;
  output \q_reg[57]_0 ;
  output \q_reg[53]_0 ;
  output \q_reg[51]_0 ;
  output \q_reg[60]_0 ;
  output \q_reg[65]_1 ;
  output \q_reg[52]_0 ;
  output \TMDSn[2]_8 ;
  output [0:0]E;
  output \TMDSn[2]_9 ;
  output \TMDSn[2]_10 ;
  output \TMDSn[2]_11 ;
  output \TMDSn[2]_12 ;
  output \TMDSn[2]_13 ;
  output \TMDSn[2]_14 ;
  output \TMDSn[2]_15 ;
  output \TMDSn[2]_16 ;
  output \TMDSn[2]_17 ;
  output [32:0]Q;
  output \q_reg[10]_0 ;
  output \q_reg[68]_1 ;
  output \q_reg[65]_2 ;
  output \q_reg[61]_0 ;
  output \q_reg[61]_1 ;
  output \q_reg[60]_1 ;
  output \q_reg[57]_1 ;
  output \q_reg[56]_1 ;
  output \q_reg[53]_1 ;
  output \q_reg[52]_1 ;
  output \q_reg[10]_1 ;
  output \q_reg[10]_2 ;
  output \q_reg[42]_0 ;
  output \q_reg[42]_1 ;
  input [36:0]D;
  input \PosX_reg_reg[5] ;
  input [0:0]PosY__0;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[4]_2 ;
  input \q_reg[147]_0 ;
  input \PosX_reg_reg[4]_3 ;
  input \PosX_reg_reg[5]_0 ;
  input \PosX_reg_reg[4]_4 ;
  input \PosX_reg_reg[4]_5 ;
  input [1:0]\PC_reg_reg[4] ;
  input [0:0]SR;
  input \q_reg[70]_2 ;
  input \q_reg[41]_0 ;
  input \q_reg[69]_2 ;
  input \q_reg[68]_2 ;
  input \q_reg[67]_2 ;
  input \q_reg[66]_2 ;
  input \q_reg[65]_3 ;
  input \q_reg[64]_2 ;
  input \q_reg[63]_2 ;
  input \q_reg[62]_2 ;
  input \q_reg[61]_2 ;
  input \q_reg[60]_2 ;
  input \q_reg[59]_2 ;
  input \q_reg[58]_2 ;
  input \q_reg[57]_2 ;
  input \q_reg[56]_2 ;
  input \q_reg[55]_2 ;
  input \q_reg[54]_2 ;
  input \q_reg[53]_2 ;
  input \q_reg[52]_2 ;
  input \q_reg[51]_1 ;
  input \q_reg[50]_0 ;
  input \q_reg[49]_1 ;
  input \q_reg[48]_0 ;
  input \q_reg[47]_0 ;
  input \q_reg[46]_0 ;
  input \q_reg[45] ;
  input \q_reg[6]_0 ;
  input \q_reg[44]_0 ;
  input \q_reg[45]_0 ;
  input \q_reg[44]_1 ;
  input \q_reg[43]_0 ;
  input \q_reg[44]_2 ;
  input \q_reg[42]_2 ;
  input \q_reg[43]_1 ;
  input \q_reg[41]_1 ;
  input \q_reg[42]_3 ;
  input \q_reg[41]_2 ;
  input \q_reg[40]_0 ;
  input \q_reg[41]_3 ;
  input \q_reg[39]_0 ;
  input \q_reg[40]_1 ;
  input \q_reg[39]_1 ;
  input \q_reg[41]_4 ;
  input \q_reg[41]_5 ;
  input \q_reg[2]_0 ;
  input \q_reg[46]_1 ;
  input \q_reg[145]_0 ;
  input \q_reg[145]_1 ;
  input \q_reg[46]_2 ;
  input \q_reg[6]_1 ;
  input \q_reg[45]_1 ;
  input \q_reg[145]_2 ;
  input \q_reg[43]_2 ;
  input \q_reg[145]_3 ;
  input \q_reg[42]_4 ;
  input \q_reg[145]_4 ;
  input \q_reg[145]_5 ;
  input \q_reg[40]_2 ;
  input \q_reg[46]_3 ;
  input \q_reg[46]_4 ;
  input [142:0]\q_reg[2]_1 ;
  input [2:0]\q_reg[2]_2 ;
  input cpu_clk_BUFG;

  wire [6:0]ALU_A;
  wire [0:0]ALU_B;
  wire [36:0]D;
  wire [0:0]E;
  wire \PC_reg[31]_i_3_n_0 ;
  wire \PC_reg[31]_i_4_n_0 ;
  wire \PC_reg[31]_i_7_n_0 ;
  wire \PC_reg[31]_i_8_n_0 ;
  wire [1:0]\PC_reg_reg[4] ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[4]_4 ;
  wire \PosX_reg_reg[4]_5 ;
  wire \PosX_reg_reg[5] ;
  wire \PosX_reg_reg[5]_0 ;
  wire [0:0]PosY__0;
  wire [32:0]Q;
  wire [0:0]SR;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_10 ;
  wire \TMDSn[2]_11 ;
  wire \TMDSn[2]_12 ;
  wire \TMDSn[2]_13 ;
  wire \TMDSn[2]_14 ;
  wire \TMDSn[2]_15 ;
  wire \TMDSn[2]_16 ;
  wire \TMDSn[2]_17 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire \TMDSn[2]_9 ;
  wire char_tab_i_103_n_0;
  wire char_tab_i_104_n_0;
  wire char_tab_i_105_n_0;
  wire char_tab_i_106_n_0;
  wire char_tab_i_107_n_0;
  wire char_tab_i_117_n_0;
  wire char_tab_i_118_n_0;
  wire char_tab_i_125_n_0;
  wire char_tab_i_126_n_0;
  wire char_tab_i_131_n_0;
  wire char_tab_i_132_n_0;
  wire char_tab_i_135_n_0;
  wire char_tab_i_87_n_0;
  wire char_tab_i_89_n_0;
  wire char_tab_i_90_n_0;
  wire char_tab_i_91_n_0;
  wire cpu_clk_BUFG;
  wire \q[152]_i_1_n_0 ;
  wire \q[40]_i_10_n_0 ;
  wire \q[40]_i_11_n_0 ;
  wire \q[40]_i_12_n_0 ;
  wire \q[40]_i_13_n_0 ;
  wire \q[40]_i_14_n_0 ;
  wire \q[40]_i_15_n_0 ;
  wire \q[40]_i_2_n_0 ;
  wire \q[40]_i_3_n_0 ;
  wire \q[40]_i_4_n_0 ;
  wire \q[40]_i_5_n_0 ;
  wire \q[40]_i_6_n_0 ;
  wire \q[40]_i_7_n_0 ;
  wire \q[40]_i_8_n_0 ;
  wire \q[40]_i_9_n_0 ;
  wire \q[41]_i_10_n_0 ;
  wire \q[41]_i_11_n_0 ;
  wire \q[41]_i_12_n_0 ;
  wire \q[41]_i_14_n_0 ;
  wire \q[41]_i_15_n_0 ;
  wire \q[41]_i_16_n_0 ;
  wire \q[41]_i_2_n_0 ;
  wire \q[41]_i_3_n_0 ;
  wire \q[41]_i_4_n_0 ;
  wire \q[41]_i_5_n_0 ;
  wire \q[41]_i_6_n_0 ;
  wire \q[41]_i_7_n_0 ;
  wire \q[41]_i_8_n_0 ;
  wire \q[41]_i_9_n_0 ;
  wire \q[42]_i_10_n_0 ;
  wire \q[42]_i_11_n_0 ;
  wire \q[42]_i_13_n_0 ;
  wire \q[42]_i_14_n_0 ;
  wire \q[42]_i_2_n_0 ;
  wire \q[42]_i_3_n_0 ;
  wire \q[42]_i_4_n_0 ;
  wire \q[42]_i_5_n_0 ;
  wire \q[42]_i_6_n_0 ;
  wire \q[42]_i_7_n_0 ;
  wire \q[42]_i_8_n_0 ;
  wire \q[42]_i_9_n_0 ;
  wire \q[43]_i_10_n_0 ;
  wire \q[43]_i_11_n_0 ;
  wire \q[43]_i_13_n_0 ;
  wire \q[43]_i_14_n_0 ;
  wire \q[43]_i_15_n_0 ;
  wire \q[43]_i_16_n_0 ;
  wire \q[43]_i_2_n_0 ;
  wire \q[43]_i_3_n_0 ;
  wire \q[43]_i_4_n_0 ;
  wire \q[43]_i_5_n_0 ;
  wire \q[43]_i_6_n_0 ;
  wire \q[43]_i_7_n_0 ;
  wire \q[43]_i_8_n_0 ;
  wire \q[43]_i_9_n_0 ;
  wire \q[44]_i_10_n_0 ;
  wire \q[44]_i_11_n_0 ;
  wire \q[44]_i_12_n_0 ;
  wire \q[44]_i_13_n_0 ;
  wire \q[44]_i_15_n_0 ;
  wire \q[44]_i_18_n_0 ;
  wire \q[44]_i_19_n_0 ;
  wire \q[44]_i_20_n_0 ;
  wire \q[44]_i_21_n_0 ;
  wire \q[44]_i_22_n_0 ;
  wire \q[44]_i_23_n_0 ;
  wire \q[44]_i_24_n_0 ;
  wire \q[44]_i_2_n_0 ;
  wire \q[44]_i_3_n_0 ;
  wire \q[44]_i_4_n_0 ;
  wire \q[44]_i_5_n_0 ;
  wire \q[44]_i_6_n_0 ;
  wire \q[44]_i_7_n_0 ;
  wire \q[44]_i_9_n_0 ;
  wire \q[45]_i_10_n_0 ;
  wire \q[45]_i_11_n_0 ;
  wire \q[45]_i_12_n_0 ;
  wire \q[45]_i_13_n_0 ;
  wire \q[45]_i_14_n_0 ;
  wire \q[45]_i_15_n_0 ;
  wire \q[45]_i_16_n_0 ;
  wire \q[45]_i_17_n_0 ;
  wire \q[45]_i_18_n_0 ;
  wire \q[45]_i_20_n_0 ;
  wire \q[45]_i_21_n_0 ;
  wire \q[45]_i_22_n_0 ;
  wire \q[45]_i_2_n_0 ;
  wire \q[45]_i_3_n_0 ;
  wire \q[45]_i_4_n_0 ;
  wire \q[45]_i_5_n_0 ;
  wire \q[45]_i_6_n_0 ;
  wire \q[45]_i_7_n_0 ;
  wire \q[45]_i_8_n_0 ;
  wire \q[45]_i_9_n_0 ;
  wire \q[46]_i_10_n_0 ;
  wire \q[46]_i_11_n_0 ;
  wire \q[46]_i_15_n_0 ;
  wire \q[46]_i_16_n_0 ;
  wire \q[46]_i_17_n_0 ;
  wire \q[46]_i_2_n_0 ;
  wire \q[46]_i_3_n_0 ;
  wire \q[46]_i_4_n_0 ;
  wire \q[46]_i_6_n_0 ;
  wire \q[46]_i_7_n_0 ;
  wire \q[46]_i_8_n_0 ;
  wire \q[46]_i_9_n_0 ;
  wire \q[47]_i_10_n_0 ;
  wire \q[47]_i_11_n_0 ;
  wire \q[47]_i_12_n_0 ;
  wire \q[47]_i_13_n_0 ;
  wire \q[47]_i_14_n_0 ;
  wire \q[47]_i_15_n_0 ;
  wire \q[47]_i_2_n_0 ;
  wire \q[47]_i_3_n_0 ;
  wire \q[47]_i_4_n_0 ;
  wire \q[47]_i_5_n_0 ;
  wire \q[47]_i_6_n_0 ;
  wire \q[47]_i_7_n_0 ;
  wire \q[47]_i_8_n_0 ;
  wire \q[47]_i_9_n_0 ;
  wire \q[48]_i_10_n_0 ;
  wire \q[48]_i_11_n_0 ;
  wire \q[48]_i_12_n_0 ;
  wire \q[48]_i_13_n_0 ;
  wire \q[48]_i_14_n_0 ;
  wire \q[48]_i_17_n_0 ;
  wire \q[48]_i_19_n_0 ;
  wire \q[48]_i_20_n_0 ;
  wire \q[48]_i_21_n_0 ;
  wire \q[48]_i_22_n_0 ;
  wire \q[48]_i_23_n_0 ;
  wire \q[48]_i_24_n_0 ;
  wire \q[48]_i_25_n_0 ;
  wire \q[48]_i_26_n_0 ;
  wire \q[48]_i_27_n_0 ;
  wire \q[48]_i_28_n_0 ;
  wire \q[48]_i_29_n_0 ;
  wire \q[48]_i_2_n_0 ;
  wire \q[48]_i_3_n_0 ;
  wire \q[48]_i_4_n_0 ;
  wire \q[48]_i_5_n_0 ;
  wire \q[48]_i_6_n_0 ;
  wire \q[48]_i_7_n_0 ;
  wire \q[48]_i_8_n_0 ;
  wire \q[48]_i_9_n_0 ;
  wire \q[49]_i_10_n_0 ;
  wire \q[49]_i_11_n_0 ;
  wire \q[49]_i_12_n_0 ;
  wire \q[49]_i_14_n_0 ;
  wire \q[49]_i_15_n_0 ;
  wire \q[49]_i_16_n_0 ;
  wire \q[49]_i_2_n_0 ;
  wire \q[49]_i_3_n_0 ;
  wire \q[49]_i_4_n_0 ;
  wire \q[49]_i_6_n_0 ;
  wire \q[49]_i_7_n_0 ;
  wire \q[49]_i_8_n_0 ;
  wire \q[49]_i_9_n_0 ;
  wire \q[50]_i_10_n_0 ;
  wire \q[50]_i_11_n_0 ;
  wire \q[50]_i_12_n_0 ;
  wire \q[50]_i_13_n_0 ;
  wire \q[50]_i_14_n_0 ;
  wire \q[50]_i_15_n_0 ;
  wire \q[50]_i_16_n_0 ;
  wire \q[50]_i_17_n_0 ;
  wire \q[50]_i_18_n_0 ;
  wire \q[50]_i_19_n_0 ;
  wire \q[50]_i_20_n_0 ;
  wire \q[50]_i_21_n_0 ;
  wire \q[50]_i_22_n_0 ;
  wire \q[50]_i_23_n_0 ;
  wire \q[50]_i_24_n_0 ;
  wire \q[50]_i_25_n_0 ;
  wire \q[50]_i_2_n_0 ;
  wire \q[50]_i_3_n_0 ;
  wire \q[50]_i_4_n_0 ;
  wire \q[50]_i_5_n_0 ;
  wire \q[50]_i_6_n_0 ;
  wire \q[50]_i_7_n_0 ;
  wire \q[50]_i_8_n_0 ;
  wire \q[50]_i_9_n_0 ;
  wire \q[51]_i_10_n_0 ;
  wire \q[51]_i_11_n_0 ;
  wire \q[51]_i_12_n_0 ;
  wire \q[51]_i_13_n_0 ;
  wire \q[51]_i_14_n_0 ;
  wire \q[51]_i_15_n_0 ;
  wire \q[51]_i_2_n_0 ;
  wire \q[51]_i_3_n_0 ;
  wire \q[51]_i_4_n_0 ;
  wire \q[51]_i_5_n_0 ;
  wire \q[51]_i_6_n_0 ;
  wire \q[51]_i_7_n_0 ;
  wire \q[51]_i_8_n_0 ;
  wire \q[51]_i_9_n_0 ;
  wire \q[52]_i_10_n_0 ;
  wire \q[52]_i_11_n_0 ;
  wire \q[52]_i_12_n_0 ;
  wire \q[52]_i_13_n_0 ;
  wire \q[52]_i_14_n_0 ;
  wire \q[52]_i_15_n_0 ;
  wire \q[52]_i_16_n_0 ;
  wire \q[52]_i_17_n_0 ;
  wire \q[52]_i_18_n_0 ;
  wire \q[52]_i_19_n_0 ;
  wire \q[52]_i_20_n_0 ;
  wire \q[52]_i_21_n_0 ;
  wire \q[52]_i_22_n_0 ;
  wire \q[52]_i_2_n_0 ;
  wire \q[52]_i_3_n_0 ;
  wire \q[52]_i_4_n_0 ;
  wire \q[52]_i_7_n_0 ;
  wire \q[52]_i_8_n_0 ;
  wire \q[52]_i_9_n_0 ;
  wire \q[53]_i_10_n_0 ;
  wire \q[53]_i_11_n_0 ;
  wire \q[53]_i_12_n_0 ;
  wire \q[53]_i_13_n_0 ;
  wire \q[53]_i_14_n_0 ;
  wire \q[53]_i_15_n_0 ;
  wire \q[53]_i_2_n_0 ;
  wire \q[53]_i_3_n_0 ;
  wire \q[53]_i_6_n_0 ;
  wire \q[53]_i_7_n_0 ;
  wire \q[53]_i_8_n_0 ;
  wire \q[53]_i_9_n_0 ;
  wire \q[54]_i_10_n_0 ;
  wire \q[54]_i_11_n_0 ;
  wire \q[54]_i_12_n_0 ;
  wire \q[54]_i_13_n_0 ;
  wire \q[54]_i_14_n_0 ;
  wire \q[54]_i_15_n_0 ;
  wire \q[54]_i_16_n_0 ;
  wire \q[54]_i_17_n_0 ;
  wire \q[54]_i_2_n_0 ;
  wire \q[54]_i_3_n_0 ;
  wire \q[54]_i_4_n_0 ;
  wire \q[54]_i_5_n_0 ;
  wire \q[54]_i_8_n_0 ;
  wire \q[54]_i_9_n_0 ;
  wire \q[55]_i_10_n_0 ;
  wire \q[55]_i_11_n_0 ;
  wire \q[55]_i_12_n_0 ;
  wire \q[55]_i_13_n_0 ;
  wire \q[55]_i_14_n_0 ;
  wire \q[55]_i_15_n_0 ;
  wire \q[55]_i_16_n_0 ;
  wire \q[55]_i_17_n_0 ;
  wire \q[55]_i_2_n_0 ;
  wire \q[55]_i_3_n_0 ;
  wire \q[55]_i_6_n_0 ;
  wire \q[55]_i_7_n_0 ;
  wire \q[55]_i_8_n_0 ;
  wire \q[55]_i_9_n_0 ;
  wire \q[56]_i_10_n_0 ;
  wire \q[56]_i_11_n_0 ;
  wire \q[56]_i_12_n_0 ;
  wire \q[56]_i_13_n_0 ;
  wire \q[56]_i_14_n_0 ;
  wire \q[56]_i_15_n_0 ;
  wire \q[56]_i_16_n_0 ;
  wire \q[56]_i_17_n_0 ;
  wire \q[56]_i_18_n_0 ;
  wire \q[56]_i_19_n_0 ;
  wire \q[56]_i_20_n_0 ;
  wire \q[56]_i_21_n_0 ;
  wire \q[56]_i_2__0_n_0 ;
  wire \q[56]_i_3_n_0 ;
  wire \q[56]_i_4_n_0 ;
  wire \q[56]_i_5_n_0 ;
  wire \q[56]_i_8_n_0 ;
  wire \q[56]_i_9_n_0 ;
  wire \q[57]_i_10_n_0 ;
  wire \q[57]_i_11_n_0 ;
  wire \q[57]_i_12_n_0 ;
  wire \q[57]_i_13_n_0 ;
  wire \q[57]_i_14_n_0 ;
  wire \q[57]_i_2_n_0 ;
  wire \q[57]_i_3_n_0 ;
  wire \q[57]_i_6_n_0 ;
  wire \q[57]_i_7_n_0 ;
  wire \q[57]_i_8_n_0 ;
  wire \q[57]_i_9_n_0 ;
  wire \q[58]_i_10_n_0 ;
  wire \q[58]_i_11_n_0 ;
  wire \q[58]_i_12_n_0 ;
  wire \q[58]_i_13_n_0 ;
  wire \q[58]_i_14_n_0 ;
  wire \q[58]_i_15_n_0 ;
  wire \q[58]_i_16_n_0 ;
  wire \q[58]_i_17_n_0 ;
  wire \q[58]_i_18_n_0 ;
  wire \q[58]_i_19_n_0 ;
  wire \q[58]_i_20_n_0 ;
  wire \q[58]_i_21_n_0 ;
  wire \q[58]_i_22_n_0 ;
  wire \q[58]_i_23_n_0 ;
  wire \q[58]_i_2_n_0 ;
  wire \q[58]_i_3_n_0 ;
  wire \q[58]_i_4_n_0 ;
  wire \q[58]_i_7_n_0 ;
  wire \q[58]_i_8_n_0 ;
  wire \q[58]_i_9_n_0 ;
  wire \q[59]_i_10_n_0 ;
  wire \q[59]_i_11_n_0 ;
  wire \q[59]_i_12_n_0 ;
  wire \q[59]_i_13_n_0 ;
  wire \q[59]_i_14_n_0 ;
  wire \q[59]_i_15_n_0 ;
  wire \q[59]_i_16_n_0 ;
  wire \q[59]_i_17_n_0 ;
  wire \q[59]_i_2_n_0 ;
  wire \q[59]_i_3_n_0 ;
  wire \q[59]_i_4_n_0 ;
  wire \q[59]_i_7_n_0 ;
  wire \q[59]_i_8_n_0 ;
  wire \q[59]_i_9_n_0 ;
  wire \q[60]_i_10_n_0 ;
  wire \q[60]_i_11_n_0 ;
  wire \q[60]_i_12_n_0 ;
  wire \q[60]_i_13_n_0 ;
  wire \q[60]_i_14_n_0 ;
  wire \q[60]_i_15_n_0 ;
  wire \q[60]_i_16_n_0 ;
  wire \q[60]_i_17_n_0 ;
  wire \q[60]_i_18_n_0 ;
  wire \q[60]_i_19_n_0 ;
  wire \q[60]_i_20_n_0 ;
  wire \q[60]_i_2_n_0 ;
  wire \q[60]_i_3_n_0 ;
  wire \q[60]_i_4_n_0 ;
  wire \q[60]_i_5_n_0 ;
  wire \q[60]_i_8_n_0 ;
  wire \q[60]_i_9_n_0 ;
  wire \q[61]_i_10_n_0 ;
  wire \q[61]_i_11_n_0 ;
  wire \q[61]_i_12_n_0 ;
  wire \q[61]_i_13_n_0 ;
  wire \q[61]_i_14_n_0 ;
  wire \q[61]_i_15_n_0 ;
  wire \q[61]_i_16_n_0 ;
  wire \q[61]_i_2_n_0 ;
  wire \q[61]_i_3_n_0 ;
  wire \q[61]_i_6_n_0 ;
  wire \q[61]_i_7_n_0 ;
  wire \q[61]_i_8_n_0 ;
  wire \q[61]_i_9_n_0 ;
  wire \q[62]_i_10_n_0 ;
  wire \q[62]_i_11_n_0 ;
  wire \q[62]_i_12_n_0 ;
  wire \q[62]_i_13_n_0 ;
  wire \q[62]_i_14_n_0 ;
  wire \q[62]_i_15_n_0 ;
  wire \q[62]_i_16_n_0 ;
  wire \q[62]_i_17_n_0 ;
  wire \q[62]_i_2_n_0 ;
  wire \q[62]_i_3_n_0 ;
  wire \q[62]_i_4_n_0 ;
  wire \q[62]_i_5_n_0 ;
  wire \q[62]_i_6_n_0 ;
  wire \q[62]_i_9_n_0 ;
  wire \q[63]_i_10_n_0 ;
  wire \q[63]_i_11_n_0 ;
  wire \q[63]_i_12_n_0 ;
  wire \q[63]_i_13_n_0 ;
  wire \q[63]_i_14_n_0 ;
  wire \q[63]_i_15_n_0 ;
  wire \q[63]_i_16_n_0 ;
  wire \q[63]_i_17_n_0 ;
  wire \q[63]_i_18_n_0 ;
  wire \q[63]_i_2_n_0 ;
  wire \q[63]_i_3_n_0 ;
  wire \q[63]_i_6_n_0 ;
  wire \q[63]_i_7_n_0 ;
  wire \q[63]_i_8_n_0 ;
  wire \q[63]_i_9_n_0 ;
  wire \q[64]_i_10_n_0 ;
  wire \q[64]_i_11_n_0 ;
  wire \q[64]_i_12_n_0 ;
  wire \q[64]_i_13_n_0 ;
  wire \q[64]_i_14_n_0 ;
  wire \q[64]_i_15_n_0 ;
  wire \q[64]_i_16_n_0 ;
  wire \q[64]_i_17_n_0 ;
  wire \q[64]_i_18_n_0 ;
  wire \q[64]_i_19_n_0 ;
  wire \q[64]_i_20_n_0 ;
  wire \q[64]_i_21_n_0 ;
  wire \q[64]_i_2_n_0 ;
  wire \q[64]_i_3_n_0 ;
  wire \q[64]_i_4_n_0 ;
  wire \q[64]_i_5_n_0 ;
  wire \q[64]_i_6_n_0 ;
  wire \q[64]_i_9_n_0 ;
  wire \q[65]_i_10_n_0 ;
  wire \q[65]_i_11_n_0 ;
  wire \q[65]_i_12_n_0 ;
  wire \q[65]_i_13_n_0 ;
  wire \q[65]_i_14_n_0 ;
  wire \q[65]_i_15_n_0 ;
  wire \q[65]_i_16_n_0 ;
  wire \q[65]_i_2_n_0 ;
  wire \q[65]_i_3_n_0 ;
  wire \q[65]_i_4_n_0 ;
  wire \q[65]_i_7_n_0 ;
  wire \q[65]_i_8_n_0 ;
  wire \q[65]_i_9_n_0 ;
  wire \q[66]_i_10_n_0 ;
  wire \q[66]_i_11_n_0 ;
  wire \q[66]_i_12_n_0 ;
  wire \q[66]_i_13_n_0 ;
  wire \q[66]_i_14_n_0 ;
  wire \q[66]_i_15_n_0 ;
  wire \q[66]_i_2_n_0 ;
  wire \q[66]_i_3_n_0 ;
  wire \q[66]_i_4_n_0 ;
  wire \q[66]_i_7_n_0 ;
  wire \q[66]_i_8_n_0 ;
  wire \q[66]_i_9_n_0 ;
  wire \q[67]_i_10_n_0 ;
  wire \q[67]_i_11_n_0 ;
  wire \q[67]_i_12_n_0 ;
  wire \q[67]_i_13_n_0 ;
  wire \q[67]_i_14_n_0 ;
  wire \q[67]_i_15_n_0 ;
  wire \q[67]_i_16_n_0 ;
  wire \q[67]_i_17_n_0 ;
  wire \q[67]_i_2_n_0 ;
  wire \q[67]_i_3_n_0 ;
  wire \q[67]_i_6_n_0 ;
  wire \q[67]_i_7_n_0 ;
  wire \q[67]_i_8_n_0 ;
  wire \q[67]_i_9_n_0 ;
  wire \q[68]_i_10_n_0 ;
  wire \q[68]_i_11_n_0 ;
  wire \q[68]_i_2_n_0 ;
  wire \q[68]_i_3_n_0 ;
  wire \q[68]_i_5_n_0 ;
  wire \q[68]_i_6_n_0 ;
  wire \q[68]_i_7_n_0 ;
  wire \q[68]_i_8_n_0 ;
  wire \q[68]_i_9_n_0 ;
  wire \q[69]_i_10_n_0 ;
  wire \q[69]_i_11_n_0 ;
  wire \q[69]_i_12_n_0 ;
  wire \q[69]_i_13_n_0 ;
  wire \q[69]_i_14_n_0 ;
  wire \q[69]_i_15_n_0 ;
  wire \q[69]_i_16_n_0 ;
  wire \q[69]_i_17_n_0 ;
  wire \q[69]_i_2_n_0 ;
  wire \q[69]_i_3_n_0 ;
  wire \q[69]_i_4_n_0 ;
  wire \q[69]_i_7_n_0 ;
  wire \q[69]_i_9_n_0 ;
  wire \q[70]_i_13_n_0 ;
  wire \q[70]_i_14_n_0 ;
  wire \q[70]_i_17_n_0 ;
  wire \q[70]_i_18_n_0 ;
  wire \q[70]_i_19_n_0 ;
  wire \q[70]_i_20_n_0 ;
  wire \q[70]_i_21_n_0 ;
  wire \q[70]_i_22_n_0 ;
  wire \q[70]_i_25_n_0 ;
  wire \q[70]_i_26_n_0 ;
  wire \q[70]_i_29_n_0 ;
  wire \q[70]_i_2_n_0 ;
  wire \q[70]_i_30_n_0 ;
  wire \q[70]_i_31_n_0 ;
  wire \q[70]_i_32_n_0 ;
  wire \q[70]_i_33_n_0 ;
  wire \q[70]_i_34_n_0 ;
  wire \q[70]_i_35_n_0 ;
  wire \q[70]_i_36_n_0 ;
  wire \q[70]_i_37_n_0 ;
  wire \q[70]_i_38_n_0 ;
  wire \q[70]_i_39_n_0 ;
  wire \q[70]_i_4_n_0 ;
  wire \q[70]_i_5_n_0 ;
  wire \q[70]_i_6_n_0 ;
  wire \q[70]_i_7_n_0 ;
  wire \q[70]_i_8_n_0 ;
  wire \q[71]_i_10_n_0 ;
  wire \q[71]_i_11_n_0 ;
  wire \q[71]_i_13_n_0 ;
  wire \q[71]_i_14_n_0 ;
  wire \q[71]_i_15_n_0 ;
  wire \q[71]_i_16_n_0 ;
  wire \q[71]_i_21_n_0 ;
  wire \q[71]_i_22_n_0 ;
  wire \q[71]_i_23_n_0 ;
  wire \q[71]_i_24_n_0 ;
  wire \q[71]_i_25_n_0 ;
  wire \q[71]_i_26_n_0 ;
  wire \q[71]_i_27_n_0 ;
  wire \q[71]_i_28_n_0 ;
  wire \q[71]_i_2_n_0 ;
  wire \q[71]_i_5_n_0 ;
  wire \q[71]_i_6_n_0 ;
  wire \q[71]_i_7_n_0 ;
  wire \q[71]_i_8_n_0 ;
  wire \q[71]_i_9_n_0 ;
  wire \q_reg[10]_0 ;
  wire \q_reg[10]_1 ;
  wire \q_reg[10]_2 ;
  wire \q_reg[145]_0 ;
  wire \q_reg[145]_1 ;
  wire \q_reg[145]_2 ;
  wire \q_reg[145]_3 ;
  wire \q_reg[145]_4 ;
  wire \q_reg[145]_5 ;
  wire \q_reg[147]_0 ;
  wire \q_reg[2]_0 ;
  wire [142:0]\q_reg[2]_1 ;
  wire [2:0]\q_reg[2]_2 ;
  wire \q_reg[39]_0 ;
  wire \q_reg[39]_1 ;
  wire \q_reg[40] ;
  wire \q_reg[40]_0 ;
  wire \q_reg[40]_1 ;
  wire \q_reg[40]_2 ;
  wire \q_reg[41]_0 ;
  wire \q_reg[41]_1 ;
  wire \q_reg[41]_2 ;
  wire \q_reg[41]_3 ;
  wire \q_reg[41]_4 ;
  wire \q_reg[41]_5 ;
  wire \q_reg[42]_0 ;
  wire \q_reg[42]_1 ;
  wire \q_reg[42]_2 ;
  wire \q_reg[42]_3 ;
  wire \q_reg[42]_4 ;
  wire \q_reg[43]_0 ;
  wire \q_reg[43]_1 ;
  wire \q_reg[43]_2 ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[45] ;
  wire \q_reg[45]_0 ;
  wire \q_reg[45]_1 ;
  wire \q_reg[46]_0 ;
  wire \q_reg[46]_1 ;
  wire \q_reg[46]_2 ;
  wire \q_reg[46]_3 ;
  wire \q_reg[46]_4 ;
  wire \q_reg[47]_0 ;
  wire \q_reg[48]_0 ;
  wire \q_reg[49]_0 ;
  wire \q_reg[49]_1 ;
  wire \q_reg[50]_0 ;
  wire \q_reg[51]_0 ;
  wire \q_reg[51]_1 ;
  wire \q_reg[52]_0 ;
  wire \q_reg[52]_1 ;
  wire \q_reg[52]_2 ;
  wire \q_reg[53]_0 ;
  wire \q_reg[53]_1 ;
  wire \q_reg[53]_2 ;
  wire \q_reg[54]_0 ;
  wire \q_reg[54]_1 ;
  wire \q_reg[54]_2 ;
  wire \q_reg[55]_0 ;
  wire \q_reg[55]_1 ;
  wire \q_reg[55]_2 ;
  wire \q_reg[56]_0 ;
  wire \q_reg[56]_1 ;
  wire \q_reg[56]_2 ;
  wire \q_reg[57]_0 ;
  wire \q_reg[57]_1 ;
  wire \q_reg[57]_2 ;
  wire \q_reg[58]_0 ;
  wire \q_reg[58]_1 ;
  wire \q_reg[58]_2 ;
  wire \q_reg[59]_0 ;
  wire \q_reg[59]_1 ;
  wire \q_reg[59]_2 ;
  wire \q_reg[60]_0 ;
  wire \q_reg[60]_1 ;
  wire \q_reg[60]_2 ;
  wire \q_reg[61]_0 ;
  wire \q_reg[61]_1 ;
  wire \q_reg[61]_2 ;
  wire \q_reg[62]_0 ;
  wire \q_reg[62]_1 ;
  wire \q_reg[62]_2 ;
  wire \q_reg[63]_0 ;
  wire \q_reg[63]_1 ;
  wire \q_reg[63]_2 ;
  wire \q_reg[64]_0 ;
  wire \q_reg[64]_1 ;
  wire \q_reg[64]_2 ;
  wire \q_reg[65]_0 ;
  wire \q_reg[65]_1 ;
  wire \q_reg[65]_2 ;
  wire \q_reg[65]_3 ;
  wire \q_reg[66]_0 ;
  wire \q_reg[66]_1 ;
  wire \q_reg[66]_2 ;
  wire \q_reg[67]_0 ;
  wire \q_reg[67]_1 ;
  wire \q_reg[67]_2 ;
  wire \q_reg[68]_0 ;
  wire \q_reg[68]_1 ;
  wire \q_reg[68]_2 ;
  wire \q_reg[69]_0 ;
  wire \q_reg[69]_1 ;
  wire \q_reg[69]_2 ;
  wire \q_reg[6]_0 ;
  wire \q_reg[6]_1 ;
  wire \q_reg[70]_0 ;
  wire \q_reg[70]_1 ;
  wire \q_reg[70]_2 ;
  wire [41:0]\q_reg[71]_0 ;
  wire \q_reg_n_0_[0] ;
  wire \q_reg_n_0_[10] ;
  wire \q_reg_n_0_[11] ;
  wire \q_reg_n_0_[12] ;
  wire \q_reg_n_0_[13] ;
  wire \q_reg_n_0_[14] ;
  wire \q_reg_n_0_[15] ;
  wire \q_reg_n_0_[16] ;
  wire \q_reg_n_0_[17] ;
  wire \q_reg_n_0_[18] ;
  wire \q_reg_n_0_[19] ;
  wire \q_reg_n_0_[1] ;
  wire \q_reg_n_0_[20] ;
  wire \q_reg_n_0_[21] ;
  wire \q_reg_n_0_[22] ;
  wire \q_reg_n_0_[23] ;
  wire \q_reg_n_0_[24] ;
  wire \q_reg_n_0_[25] ;
  wire \q_reg_n_0_[26] ;
  wire \q_reg_n_0_[27] ;
  wire \q_reg_n_0_[28] ;
  wire \q_reg_n_0_[29] ;
  wire \q_reg_n_0_[2] ;
  wire \q_reg_n_0_[30] ;
  wire \q_reg_n_0_[31] ;
  wire \q_reg_n_0_[3] ;
  wire \q_reg_n_0_[4] ;
  wire \q_reg_n_0_[5] ;
  wire \q_reg_n_0_[6] ;
  wire \q_reg_n_0_[7] ;
  wire \q_reg_n_0_[8] ;
  wire \q_reg_n_0_[9] ;
  wire [3:0]r_ALUCode_ex;
  wire [1:0]r_ALUSrcB_ex;
  wire [30:0]r_Imm_ex;
  wire [2:0]r_rs1Addr_ex;
  wire [31:0]r_rs1Data_ex;
  wire [2:0]r_rs2Addr_ex;
  wire [2:0]r_rs2Data_ex;

  LUT2 #(
    .INIT(4'hE)) 
    \PC_reg[31]_i_1 
       (.I0(\PC_reg[31]_i_3_n_0 ),
        .I1(\PC_reg[31]_i_4_n_0 ),
        .O(E));
  LUT6 #(
    .INIT(64'h77FF07FFFFBBFFB0)) 
    \PC_reg[31]_i_3 
       (.I0(\q_reg[2]_1 [44]),
        .I1(\PC_reg[31]_i_7_n_0 ),
        .I2(\q_reg[2]_1 [40]),
        .I3(\q_reg[71]_0 [3]),
        .I4(\PC_reg[31]_i_8_n_0 ),
        .I5(\q_reg[71]_0 [4]),
        .O(\PC_reg[31]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555557)) 
    \PC_reg[31]_i_4 
       (.I0(\q_reg[71]_0 [5]),
        .I1(\q_reg[71]_0 [0]),
        .I2(\q_reg[71]_0 [3]),
        .I3(\q_reg[71]_0 [2]),
        .I4(\q_reg[71]_0 [4]),
        .I5(\q_reg[71]_0 [1]),
        .O(\PC_reg[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \PC_reg[31]_i_7 
       (.I0(\q_reg[71]_0 [2]),
        .I1(\q_reg[2]_1 [43]),
        .I2(\q_reg[2]_1 [42]),
        .I3(\q_reg[71]_0 [1]),
        .I4(\q_reg[2]_1 [41]),
        .I5(\q_reg[71]_0 [0]),
        .O(\PC_reg[31]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \PC_reg[31]_i_8 
       (.I0(\q_reg[71]_0 [2]),
        .I1(\q_reg[2]_1 [39]),
        .I2(\q_reg[2]_1 [38]),
        .I3(\q_reg[71]_0 [1]),
        .I4(\q_reg[2]_1 [37]),
        .I5(\q_reg[71]_0 [0]),
        .O(\PC_reg[31]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA00022202)) 
    char_tab_i_103
       (.I0(\PosX_reg_reg[5]_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[52]_i_4_n_0 ),
        .I3(\q[44]_i_6_n_0 ),
        .I4(\q[52]_i_3_n_0 ),
        .I5(\q[52]_i_2_n_0 ),
        .O(char_tab_i_103_n_0));
  LUT5 #(
    .INIT(32'hFF0E0000)) 
    char_tab_i_104
       (.I0(\q[56]_i_9_n_0 ),
        .I1(char_tab_i_131_n_0),
        .I2(\q[56]_i_3_n_0 ),
        .I3(char_tab_i_132_n_0),
        .I4(\PosX_reg_reg[4]_3 ),
        .O(char_tab_i_104_n_0));
  LUT5 #(
    .INIT(32'h28828228)) 
    char_tab_i_105
       (.I0(\q[44]_i_4_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[64]_0 ),
        .I4(\q[64]_i_9_n_0 ),
        .O(char_tab_i_105_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_106
       (.I0(\q[65]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[64]_i_2_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_106_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_107
       (.I0(\q[69]_i_2_n_0 ),
        .I1(ALU_B),
        .I2(\q[68]_i_2_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_107_n_0));
  LUT5 #(
    .INIT(32'h1054BAFE)) 
    char_tab_i_108
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(ALU_B),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[48]_i_10_n_0 ),
        .O(\TMDSn[2]_13 ));
  LUT6 #(
    .INIT(64'h0000015155550151)) 
    char_tab_i_117
       (.I0(r_ALUCode_ex[3]),
        .I1(\q[51]_i_8_n_0 ),
        .I2(\q[44]_i_4_n_0 ),
        .I3(\q[51]_i_7_n_0 ),
        .I4(\q[44]_i_6_n_0 ),
        .I5(char_tab_i_135_n_0),
        .O(char_tab_i_117_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_118
       (.I0(\q[51]_i_4_n_0 ),
        .I1(ALU_B),
        .I2(\q[51]_i_3_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_118_n_0));
  LUT5 #(
    .INIT(32'h0145ABEF)) 
    char_tab_i_122
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q[41]_i_11_n_0 ),
        .I3(\q[45]_i_9_n_0 ),
        .I4(\q[49]_i_6_n_0 ),
        .O(\TMDSn[2]_16 ));
  LUT6 #(
    .INIT(64'h000000E200000000)) 
    char_tab_i_125
       (.I0(\q[61]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[62]_i_2_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_125_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_126
       (.I0(\q[54]_i_2_n_0 ),
        .I1(ALU_B),
        .I2(\q[53]_i_3_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_126_n_0));
  LUT6 #(
    .INIT(64'h2020202200000002)) 
    char_tab_i_127
       (.I0(\PosX_reg_reg[4]_4 ),
        .I1(\PosX_reg_reg[4]_5 ),
        .I2(r_ALUSrcB_ex[0]),
        .I3(r_ALUSrcB_ex[1]),
        .I4(\q[45]_i_20_n_0 ),
        .I5(r_Imm_ex[5]),
        .O(\TMDSn[2]_9 ));
  LUT5 #(
    .INIT(32'h5410FEBA)) 
    char_tab_i_128
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(ALU_A[0]),
        .I3(ALU_A[4]),
        .I4(\q[48]_i_9_n_0 ),
        .O(\TMDSn[2]_17 ));
  LUT4 #(
    .INIT(16'hA0C0)) 
    char_tab_i_13
       (.I0(D[36]),
        .I1(\q_reg[71]_0 [41]),
        .I2(\PosX_reg_reg[5] ),
        .I3(PosY__0),
        .O(\TMDSn[2] ));
  LUT5 #(
    .INIT(32'h28828228)) 
    char_tab_i_131
       (.I0(\q[44]_i_4_n_0 ),
        .I1(\q_reg[56]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[56]_1 ),
        .I4(\q[56]_i_8_n_0 ),
        .O(char_tab_i_131_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_132
       (.I0(\q[57]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[56]_i_2__0_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_132_n_0));
  LUT5 #(
    .INIT(32'hFFEAFF00)) 
    char_tab_i_135
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q[51]_i_5_n_0 ),
        .I4(\q[51]_i_6_n_0 ),
        .O(char_tab_i_135_n_0));
  LUT5 #(
    .INIT(32'h4501EFAB)) 
    char_tab_i_137
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q[42]_i_6_n_0 ),
        .I3(ALU_A[6]),
        .I4(\q[50]_i_6_n_0 ),
        .O(\TMDSn[2]_15 ));
  LUT5 #(
    .INIT(32'h0145ABEF)) 
    char_tab_i_139
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q[43]_i_5_n_0 ),
        .I3(\q[47]_i_7_n_0 ),
        .I4(\q[51]_i_6_n_0 ),
        .O(\TMDSn[2]_14 ));
  LUT4 #(
    .INIT(16'hA0C0)) 
    char_tab_i_18
       (.I0(D[35]),
        .I1(\q_reg[71]_0 [40]),
        .I2(\PosX_reg_reg[5] ),
        .I3(PosY__0),
        .O(\TMDSn[2]_1 ));
  LUT6 #(
    .INIT(64'hFFFEFEFEAAAAAAAA)) 
    char_tab_i_55
       (.I0(char_tab_i_87_n_0),
        .I1(\q_reg[147]_0 ),
        .I2(char_tab_i_89_n_0),
        .I3(\PosX_reg_reg[4]_3 ),
        .I4(\q_reg[71]_0 [27]),
        .I5(\PosX_reg_reg[4]_1 ),
        .O(\TMDSn[2]_6 ));
  LUT4 #(
    .INIT(16'hAB00)) 
    char_tab_i_56
       (.I0(char_tab_i_90_n_0),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[65]_i_2_n_0 ),
        .I3(\PosX_reg_reg[4]_2 ),
        .O(\TMDSn[2]_4 ));
  LUT6 #(
    .INIT(64'hAAAA0000CFCC0000)) 
    char_tab_i_57
       (.I0(D[34]),
        .I1(char_tab_i_91_n_0),
        .I2(\q[69]_i_3_n_0 ),
        .I3(\q[69]_i_4_n_0 ),
        .I4(\PosX_reg_reg[5] ),
        .I5(PosY__0),
        .O(\TMDSn[2]_2 ));
  LUT6 #(
    .INIT(64'hFFFFF1010000F101)) 
    char_tab_i_60
       (.I0(\PC_reg[31]_i_3_n_0 ),
        .I1(\PC_reg[31]_i_4_n_0 ),
        .I2(\PosX_reg_reg[4]_2 ),
        .I3(\PC_reg_reg[4] [0]),
        .I4(\PosX_reg_reg[5] ),
        .I5(\PC_reg_reg[4] [1]),
        .O(\TMDSn[2]_8 ));
  LUT6 #(
    .INIT(64'hFFFFFFF888888888)) 
    char_tab_i_63
       (.I0(\q_reg[71]_0 [30]),
        .I1(\PosX_reg_reg[4] ),
        .I2(\PosX_reg_reg[4]_0 ),
        .I3(char_tab_i_103_n_0),
        .I4(char_tab_i_104_n_0),
        .I5(\PosX_reg_reg[4]_1 ),
        .O(\TMDSn[2]_0 ));
  LUT5 #(
    .INIT(32'hFF0E0000)) 
    char_tab_i_64
       (.I0(\q[64]_i_10_n_0 ),
        .I1(char_tab_i_105_n_0),
        .I2(\q[64]_i_3_n_0 ),
        .I3(char_tab_i_106_n_0),
        .I4(\PosX_reg_reg[4]_2 ),
        .O(\TMDSn[2]_5 ));
  LUT6 #(
    .INIT(64'hAAAA0000CCCF0000)) 
    char_tab_i_65
       (.I0(D[33]),
        .I1(char_tab_i_107_n_0),
        .I2(\q[68]_i_3_n_0 ),
        .I3(r_ALUCode_ex[3]),
        .I4(\PosX_reg_reg[5] ),
        .I5(PosY__0),
        .O(\TMDSn[2]_3 ));
  LUT6 #(
    .INIT(64'hFFE4FFE4FFE400E4)) 
    char_tab_i_76
       (.I0(\PosX_reg_reg[4]_4 ),
        .I1(\q_reg[71]_0 [13]),
        .I2(\q_reg[71]_0 [17]),
        .I3(\PosX_reg_reg[4]_5 ),
        .I4(char_tab_i_117_n_0),
        .I5(char_tab_i_118_n_0),
        .O(\TMDSn[2]_7 ));
  LUT5 #(
    .INIT(32'h0145ABEF)) 
    char_tab_i_77
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[47]_i_6_n_0 ),
        .I4(\q[51]_i_5_n_0 ),
        .O(\TMDSn[2]_10 ));
  LUT5 #(
    .INIT(32'hFEBA5410)) 
    char_tab_i_82
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q_reg[71]_0 [12]),
        .I3(\q_reg[71]_0 [16]),
        .I4(\q_reg[71]_0 [20]),
        .O(\TMDSn[2]_11 ));
  LUT5 #(
    .INIT(32'h0145ABEF)) 
    char_tab_i_83
       (.I0(\PosX_reg_reg[4]_5 ),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[46]_i_6_n_0 ),
        .I4(\q[50]_i_5_n_0 ),
        .O(\TMDSn[2]_12 ));
  LUT4 #(
    .INIT(16'h888A)) 
    char_tab_i_87
       (.I0(\PosX_reg_reg[4] ),
        .I1(char_tab_i_125_n_0),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[61]_i_2_n_0 ),
        .O(char_tab_i_87_n_0));
  LUT4 #(
    .INIT(16'h888A)) 
    char_tab_i_89
       (.I0(\PosX_reg_reg[5]_0 ),
        .I1(char_tab_i_126_n_0),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[53]_i_2_n_0 ),
        .O(char_tab_i_89_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_90
       (.I0(\q[65]_i_4_n_0 ),
        .I1(ALU_B),
        .I2(\q[65]_i_3_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_90_n_0));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    char_tab_i_91
       (.I0(\q[70]_i_4_n_0 ),
        .I1(ALU_B),
        .I2(\q[69]_i_2_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(char_tab_i_91_n_0));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[10]_i_1 
       (.I0(r_rs2Data_ex[2]),
        .I1(\q_reg[41]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[5]),
        .I4(\q_reg[41]_0 ),
        .O(\q_reg[71]_0 [9]));
  LUT3 #(
    .INIT(8'hF1)) 
    \q[152]_i_1 
       (.I0(\PC_reg[31]_i_3_n_0 ),
        .I1(\PC_reg[31]_i_4_n_0 ),
        .I2(SR),
        .O(\q[152]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFF4)) 
    \q[39]_i_3 
       (.I0(\q_reg[41]_4 ),
        .I1(\q_reg[10]_1 ),
        .I2(\q_reg[41]_5 ),
        .I3(\q_reg[10]_2 ),
        .I4(\q_reg[2]_0 ),
        .O(\q_reg[10]_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \q[39]_i_5 
       (.I0(r_rs2Addr_ex[2]),
        .I1(D[2]),
        .I2(D[0]),
        .I3(r_rs2Addr_ex[0]),
        .I4(D[1]),
        .I5(r_rs2Addr_ex[1]),
        .O(\q_reg[10]_1 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[39]_i_8 
       (.I0(r_rs2Addr_ex[2]),
        .I1(\q_reg[2]_2 [2]),
        .I2(\q_reg[2]_2 [0]),
        .I3(r_rs2Addr_ex[0]),
        .I4(\q_reg[2]_2 [1]),
        .I5(r_rs2Addr_ex[1]),
        .O(\q_reg[10]_2 ));
  LUT6 #(
    .INIT(64'h0F000FFF55335533)) 
    \q[40]_i_1 
       (.I0(\q[40]_i_2_n_0 ),
        .I1(\q[40]_i_3_n_0 ),
        .I2(\q[40]_i_4_n_0 ),
        .I3(\q[41]_i_2_n_0 ),
        .I4(\q[40]_i_5_n_0 ),
        .I5(\q[41]_i_5_n_0 ),
        .O(\q_reg[71]_0 [10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[40]_i_10 
       (.I0(\q[40]_i_14_n_0 ),
        .I1(\q[45]_i_21_n_0 ),
        .I2(\q_reg[51]_0 ),
        .I3(\q[43]_i_15_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[45]_i_22_n_0 ),
        .O(\q[40]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[40]_i_11 
       (.I0(\q[40]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[43]_i_16_n_0 ),
        .O(\q[40]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[40]_i_12 
       (.I0(\q[42]_i_14_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[45]_i_16_n_0 ),
        .O(\q[40]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \q[40]_i_13 
       (.I0(ALU_A[0]),
        .I1(\q[44]_i_9_n_0 ),
        .I2(\q_reg[51]_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .O(\q[40]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA03030AFA03F3F)) 
    \q[40]_i_14 
       (.I0(\q[41]_i_11_n_0 ),
        .I1(\q_reg[57]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[49]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[65]_0 ),
        .O(\q[40]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h5F5030305F503F3F)) 
    \q[40]_i_15 
       (.I0(ALU_A[0]),
        .I1(\q_reg[56]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[48]_i_9_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[64]_1 ),
        .O(\q[40]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hF440FBB0F770F880)) 
    \q[40]_i_2 
       (.I0(\q[40]_i_6_n_0 ),
        .I1(\q[70]_i_18_n_0 ),
        .I2(\q_reg[40] ),
        .I3(\q_reg[70]_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[40]_i_7_n_0 ),
        .O(\q[40]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F7AAFF)) 
    \q[40]_i_3 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q[40]_i_4_n_0 ),
        .I3(\q[40]_i_8_n_0 ),
        .I4(r_ALUCode_ex[2]),
        .I5(\q[40]_i_9_n_0 ),
        .O(\q[40]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \q[40]_i_4 
       (.I0(\q[40]_i_10_n_0 ),
        .I1(ALU_B),
        .I2(\q[40]_i_11_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[40]_i_12_n_0 ),
        .O(\q[40]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h044F0BBF077F088F)) 
    \q[40]_i_5 
       (.I0(\q[40]_i_6_n_0 ),
        .I1(\q[70]_i_18_n_0 ),
        .I2(\q_reg[40] ),
        .I3(\q_reg[70]_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[40]_i_7_n_0 ),
        .O(\q[40]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h2BB2)) 
    \q[40]_i_6 
       (.I0(\q[70]_i_17_n_0 ),
        .I1(\q_reg[69]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[70]_1 ),
        .O(\q[40]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h2BB2)) 
    \q[40]_i_7 
       (.I0(\q[70]_i_19_n_0 ),
        .I1(\q_reg[69]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[70]_1 ),
        .O(\q[40]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h010ED5AA0102D5AA)) 
    \q[40]_i_8 
       (.I0(ALU_A[0]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[40]_i_13_n_0 ),
        .O(\q[40]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h00D00000)) 
    \q[40]_i_9 
       (.I0(r_ALUCode_ex[0]),
        .I1(ALU_A[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(ALU_B),
        .O(\q[40]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00000151)) 
    \q[41]_i_1 
       (.I0(\q[41]_i_2_n_0 ),
        .I1(\q[41]_i_3_n_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[41]_i_4_n_0 ),
        .I4(\q[41]_i_5_n_0 ),
        .I5(\q[41]_i_6_n_0 ),
        .O(\q_reg[71]_0 [11]));
  LUT2 #(
    .INIT(4'h2)) 
    \q[41]_i_10 
       (.I0(\q[40]_i_10_n_0 ),
        .I1(ALU_B),
        .O(\q[41]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'hF4)) 
    \q[41]_i_11 
       (.I0(\q_reg_n_0_[1] ),
        .I1(Q[32]),
        .I2(\q[41]_i_14_n_0 ),
        .O(\q[41]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000C04040)) 
    \q[41]_i_12 
       (.I0(\q[41]_i_15_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[41]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(r_ALUCode_ex[0]),
        .O(\q[41]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[41]_i_13 
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[32]),
        .I2(\q[44]_i_24_n_0 ),
        .O(ALU_A[0]));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[41]_i_14 
       (.I0(r_rs1Data_ex[1]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[4]),
        .I4(\q_reg[40]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[41]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'hDF)) 
    \q[41]_i_15 
       (.I0(\q[44]_i_9_n_0 ),
        .I1(\q[41]_i_11_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .O(\q[41]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h7F)) 
    \q[41]_i_16 
       (.I0(ALU_A[0]),
        .I1(\q[44]_i_9_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .O(\q[41]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h8A)) 
    \q[41]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .O(\q[41]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h2222222202222222)) 
    \q[41]_i_3 
       (.I0(\q[41]_i_7_n_0 ),
        .I1(\q[41]_i_8_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[41]_i_9_n_0 ),
        .I5(\q[41]_i_10_n_0 ),
        .O(\q[41]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFEA00)) 
    \q[41]_i_4 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q[41]_i_11_n_0 ),
        .I4(\q_reg[51]_0 ),
        .O(\q[41]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[41]_i_5 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[1]),
        .O(\q[41]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AABA)) 
    \q[41]_i_6 
       (.I0(\q[41]_i_9_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[48]_i_3_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[41]_i_10_n_0 ),
        .I5(\q[70]_i_2_n_0 ),
        .O(\q[41]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0055D5D7FFFFD5D7)) 
    \q[41]_i_7 
       (.I0(r_ALUCode_ex[2]),
        .I1(\q_reg[51]_0 ),
        .I2(\q[41]_i_11_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[41]_i_12_n_0 ),
        .O(\q[41]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h2882228882282288)) 
    \q[41]_i_8 
       (.I0(\q[44]_i_4_n_0 ),
        .I1(\q[41]_i_11_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(ALU_B),
        .I5(ALU_A[0]),
        .O(\q[41]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \q[41]_i_9 
       (.I0(ALU_B),
        .I1(\q[42]_i_10_n_0 ),
        .O(\q[41]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0D0D0D0DFFFF0DFF)) 
    \q[42]_i_1 
       (.I0(\q[42]_i_2_n_0 ),
        .I1(\q[42]_i_3_n_0 ),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[42]_i_4_n_0 ),
        .I4(\q[42]_i_5_n_0 ),
        .I5(\q[70]_i_2_n_0 ),
        .O(\q_reg[71]_0 [12]));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[42]_i_10 
       (.I0(\q[43]_i_16_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[48]_i_13_n_0 ),
        .I3(\q[42]_i_14_n_0 ),
        .I4(\q[45]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[42]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[42]_i_11 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[2] ),
        .O(\q[42]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hF7FFFFFF)) 
    \q[42]_i_13 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q[44]_i_9_n_0 ),
        .I2(\q[41]_i_11_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[51]_0 ),
        .O(\q[42]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA03030AFA03F3F)) 
    \q[42]_i_14 
       (.I0(\q[42]_i_6_n_0 ),
        .I1(\q_reg[58]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[50]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[66]_0 ),
        .O(\q[42]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFF8F)) 
    \q[42]_i_2 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[42]_i_6_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[70]_i_14_n_0 ),
        .O(\q[42]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDD00CCF0)) 
    \q[42]_i_3 
       (.I0(\q[42]_i_7_n_0 ),
        .I1(\q[42]_i_8_n_0 ),
        .I2(\q[42]_i_9_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[1]),
        .O(\q[42]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[42]_i_4 
       (.I0(\q[43]_i_9_n_0 ),
        .I1(ALU_B),
        .I2(\q[42]_i_10_n_0 ),
        .O(\q[42]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h04)) 
    \q[42]_i_5 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q[48]_i_3_n_0 ),
        .I2(\q_reg[51]_0 ),
        .O(\q[42]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[42]_i_6 
       (.I0(\q[42]_i_11_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[41]_2 ),
        .I3(\q_reg[145]_5 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[2]),
        .O(\q[42]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[42]_i_7 
       (.I0(\q[43]_i_9_n_0 ),
        .I1(\q[42]_i_10_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[42]_i_13_n_0 ),
        .I4(ALU_B),
        .I5(\q[43]_i_13_n_0 ),
        .O(\q[42]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h003E)) 
    \q[42]_i_8 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[42]_i_6_n_0 ),
        .I3(r_ALUCode_ex[1]),
        .O(\q[42]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \q[42]_i_9 
       (.I0(\q[43]_i_14_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[42]_i_6_n_0 ),
        .O(\q[42]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0000000FDDDDDDDD)) 
    \q[43]_i_1 
       (.I0(\q[43]_i_2_n_0 ),
        .I1(\q[43]_i_3_n_0 ),
        .I2(\q[43]_i_4_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q_reg[71]_0 [13]));
  LUT6 #(
    .INIT(64'h4700473347CC47FF)) 
    \q[43]_i_10 
       (.I0(\q[43]_i_16_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[48]_i_13_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[45]_i_15_n_0 ),
        .I5(\q[45]_i_16_n_0 ),
        .O(\q[43]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[43]_i_11 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[3] ),
        .O(\q[43]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h8FBFFFFFFFFFFFFF)) 
    \q[43]_i_13 
       (.I0(\q[42]_i_6_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(ALU_A[0]),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[43]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hD008FD8F)) 
    \q[43]_i_14 
       (.I0(ALU_B),
        .I1(ALU_A[0]),
        .I2(\q_reg[51]_0 ),
        .I3(\q[66]_i_7_n_0 ),
        .I4(\q[41]_i_11_n_0 ),
        .O(\q[43]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hAFA03030AFA03F3F)) 
    \q[43]_i_15 
       (.I0(\q[43]_i_5_n_0 ),
        .I1(\q_reg[59]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[51]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[67]_0 ),
        .O(\q[43]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h2700275527AA27FF)) 
    \q[43]_i_16 
       (.I0(\q[44]_i_9_n_0 ),
        .I1(ALU_A[4]),
        .I2(\q_reg[60]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[65]_1 ),
        .I5(\q_reg[52]_0 ),
        .O(\q[43]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hFFFDFDFD)) 
    \q[43]_i_2 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .I2(\q[48]_i_8_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[43]_i_5_n_0 ),
        .O(\q[43]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBB00AAF0)) 
    \q[43]_i_3 
       (.I0(\q[43]_i_6_n_0 ),
        .I1(\q[43]_i_7_n_0 ),
        .I2(\q[43]_i_8_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[1]),
        .O(\q[43]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h4E4E4E4E44004E4E)) 
    \q[43]_i_4 
       (.I0(ALU_B),
        .I1(\q[43]_i_9_n_0 ),
        .I2(\q[43]_i_10_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[48]_i_3_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[43]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[43]_i_5 
       (.I0(\q[43]_i_11_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[42]_4 ),
        .I3(\q_reg[145]_4 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[3]),
        .O(\q[43]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h1154)) 
    \q[43]_i_6 
       (.I0(r_ALUCode_ex[1]),
        .I1(\q[43]_i_5_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[48]_i_8_n_0 ),
        .O(\q[43]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[43]_i_7 
       (.I0(\q[43]_i_10_n_0 ),
        .I1(\q[43]_i_9_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[43]_i_13_n_0 ),
        .I4(ALU_B),
        .I5(\q[44]_i_18_n_0 ),
        .O(\q[43]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h4DB2718EB24D8E71)) 
    \q[43]_i_8 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q[42]_i_6_n_0 ),
        .I2(\q[43]_i_14_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[43]_i_5_n_0 ),
        .O(\q[43]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[43]_i_9 
       (.I0(\q[45]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[49]_i_15_n_0 ),
        .I3(\q[43]_i_15_n_0 ),
        .I4(\q[45]_i_22_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[43]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55550151)) 
    \q[44]_i_1 
       (.I0(\q[44]_i_2_n_0 ),
        .I1(\q[44]_i_3_n_0 ),
        .I2(\q[44]_i_4_n_0 ),
        .I3(\q[44]_i_5_n_0 ),
        .I4(\q[44]_i_6_n_0 ),
        .I5(\q[44]_i_7_n_0 ),
        .O(\q_reg[71]_0 [14]));
  LUT3 #(
    .INIT(8'hA3)) 
    \q[44]_i_10 
       (.I0(\q[45]_i_13_n_0 ),
        .I1(\q[43]_i_10_n_0 ),
        .I2(ALU_B),
        .O(\q[44]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[44]_i_11 
       (.I0(\q[44]_i_18_n_0 ),
        .I1(ALU_B),
        .I2(\q[45]_i_14_n_0 ),
        .O(\q[44]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00010007)) 
    \q[44]_i_12 
       (.I0(\q[44]_i_19_n_0 ),
        .I1(\q[41]_i_11_n_0 ),
        .I2(\q[44]_i_20_n_0 ),
        .I3(\q[44]_i_21_n_0 ),
        .I4(\q[44]_i_22_n_0 ),
        .I5(\q[44]_i_23_n_0 ),
        .O(\q[44]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[44]_i_13 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[4] ),
        .O(\q[44]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[44]_i_15 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[4]),
        .O(\q[44]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hBF8FFFFFFFFFFFFF)) 
    \q[44]_i_18 
       (.I0(\q[43]_i_5_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[41]_i_11_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[44]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[44]_i_19 
       (.I0(\q_reg[51]_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[44]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[44]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_A[4]),
        .I3(\q[44]_i_9_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[44]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hA8A88AAA02022000)) 
    \q[44]_i_20 
       (.I0(\q[42]_i_6_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[44]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hA8A88AAA02022000)) 
    \q[44]_i_21 
       (.I0(\q[43]_i_5_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[44]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'h1D111DDD)) 
    \q[44]_i_22 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(ALU_B),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[32]),
        .I4(\q[44]_i_24_n_0 ),
        .O(\q[44]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'h2211B217)) 
    \q[44]_i_23 
       (.I0(\q[48]_i_8_n_0 ),
        .I1(\q[43]_i_5_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[66]_i_7_n_0 ),
        .I4(\q[42]_i_6_n_0 ),
        .O(\q[44]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[44]_i_24 
       (.I0(r_rs1Data_ex[0]),
        .I1(D[3]),
        .I2(\q_reg[46]_1 ),
        .I3(\q_reg[39]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .O(\q[44]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hA0C0A0CFAFCFA0C0)) 
    \q[44]_i_3 
       (.I0(\q[44]_i_10_n_0 ),
        .I1(\q[44]_i_11_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[44]_i_9_n_0 ),
        .I5(ALU_A[4]),
        .O(\q[44]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h15)) 
    \q[44]_i_4 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .O(\q[44]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \q[44]_i_5 
       (.I0(\q[44]_i_12_n_0 ),
        .I1(\q[44]_i_9_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(ALU_A[4]),
        .O(\q[44]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[44]_i_6 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .O(\q[44]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000020002020202)) 
    \q[44]_i_7 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[48]_i_3_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[44]_i_10_n_0 ),
        .O(\q[44]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h5554551055105510)) 
    \q[44]_i_8 
       (.I0(\q[44]_i_13_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[43]_2 ),
        .I3(\q_reg[145]_3 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[4]),
        .O(ALU_A[4]));
  LUT6 #(
    .INIT(64'h0000005155555555)) 
    \q[44]_i_9 
       (.I0(\q[44]_i_15_n_0 ),
        .I1(Q[4]),
        .I2(\q_reg[6]_0 ),
        .I3(\q_reg[43]_0 ),
        .I4(\q_reg[44]_2 ),
        .I5(\q[70]_i_8_n_0 ),
        .O(\q[44]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF00F1)) 
    \q[45]_i_1 
       (.I0(\q[45]_i_2_n_0 ),
        .I1(\q[45]_i_3_n_0 ),
        .I2(\q[45]_i_4_n_0 ),
        .I3(r_ALUCode_ex[3]),
        .I4(\q[45]_i_5_n_0 ),
        .O(\q_reg[71]_0 [15]));
  LUT5 #(
    .INIT(32'hAB0154FE)) 
    \q[45]_i_10 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_ALUSrcB_ex[1]),
        .I2(\q[45]_i_20_n_0 ),
        .I3(r_Imm_ex[5]),
        .I4(\q[66]_i_7_n_0 ),
        .O(\q[45]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'hEB82)) 
    \q[45]_i_11 
       (.I0(ALU_A[4]),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[44]_i_12_n_0 ),
        .O(\q[45]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[45]_i_12 
       (.I0(\q[70]_i_8_n_0 ),
        .I1(\q_reg[41]_0 ),
        .I2(D[6]),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[44]_1 ),
        .I5(Q[5]),
        .O(\q[45]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \q[45]_i_13 
       (.I0(\q[45]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[49]_i_15_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[45]_i_22_n_0 ),
        .I5(\q[51]_i_9_n_0 ),
        .O(\q[45]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hBB8BBBBBBBBBBBBB)) 
    \q[45]_i_14 
       (.I0(\q[47]_i_15_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[42]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[45]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hA03FAF3F)) 
    \q[45]_i_15 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(\q_reg[66]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[58]_1 ),
        .O(\q[45]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hCC44CC440C000CCC)) 
    \q[45]_i_16 
       (.I0(\q_reg[62]_0 ),
        .I1(\q[50]_i_24_n_0 ),
        .I2(\q_reg[54]_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[69]_0 ),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[45]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \q[45]_i_17 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .O(\q[45]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[45]_i_18 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[5] ),
        .O(\q[45]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF1555)) 
    \q[45]_i_2 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(ALU_B),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[45]_i_7_n_0 ),
        .I4(\q[45]_i_8_n_0 ),
        .I5(\q[44]_i_6_n_0 ),
        .O(\q[45]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[45]_i_20 
       (.I0(Q[5]),
        .I1(\q_reg[44]_1 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[6]),
        .I4(\q_reg[41]_0 ),
        .O(\q[45]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hA0AF3030A0AF3F3F)) 
    \q[45]_i_21 
       (.I0(\q[45]_i_9_n_0 ),
        .I1(\q_reg[61]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[53]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[68]_1 ),
        .O(\q[45]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hA0A0A0AF303F303F)) 
    \q[45]_i_22 
       (.I0(\q[47]_i_7_n_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[58]_i_10_n_0 ),
        .I4(\q_reg[55]_0 ),
        .I5(\q[44]_i_9_n_0 ),
        .O(\q[45]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'h0069)) 
    \q[45]_i_3 
       (.I0(\q[45]_i_9_n_0 ),
        .I1(\q[45]_i_10_n_0 ),
        .I2(\q[45]_i_11_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .O(\q[45]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000EA00EA00EA00)) 
    \q[45]_i_4 
       (.I0(\q[45]_i_12_n_0 ),
        .I1(r_ALUSrcB_ex[0]),
        .I2(r_Imm_ex[5]),
        .I3(\q[44]_i_6_n_0 ),
        .I4(\q[45]_i_9_n_0 ),
        .I5(r_ALUCode_ex[0]),
        .O(\q[45]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAA33F3)) 
    \q[45]_i_5 
       (.I0(\q[46]_i_11_n_0 ),
        .I1(\q[45]_i_13_n_0 ),
        .I2(\q[48]_i_3_n_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[70]_i_2_n_0 ),
        .O(\q[45]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0530FFFF053FFFFF)) 
    \q[45]_i_6 
       (.I0(\q[45]_i_13_n_0 ),
        .I1(\q[45]_i_14_n_0 ),
        .I2(ALU_B),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[46]_i_16_n_0 ),
        .O(\q[45]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0033CCFF74747474)) 
    \q[45]_i_7 
       (.I0(\q[48]_i_13_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[51]_i_15_n_0 ),
        .I3(\q[45]_i_15_n_0 ),
        .I4(\q[45]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[45]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000000003335444)) 
    \q[45]_i_8 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[45]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[0]),
        .I3(r_Imm_ex[5]),
        .I4(\q[45]_i_9_n_0 ),
        .I5(\q[45]_i_17_n_0 ),
        .O(\q[45]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[45]_i_9 
       (.I0(\q[45]_i_18_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[145]_2 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[5]),
        .O(\q[45]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'hFF0D)) 
    \q[46]_i_1 
       (.I0(\q[46]_i_2_n_0 ),
        .I1(\q[46]_i_3_n_0 ),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[46]_i_4_n_0 ),
        .O(\q_reg[71]_0 [16]));
  LUT6 #(
    .INIT(64'hFFFF177117710000)) 
    \q[46]_i_10 
       (.I0(\q[44]_i_12_n_0 ),
        .I1(ALU_A[4]),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[45]_i_9_n_0 ),
        .I5(\q[45]_i_10_n_0 ),
        .O(\q[46]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFF33FFFFFF007474)) 
    \q[46]_i_11 
       (.I0(\q[48]_i_13_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[51]_i_15_n_0 ),
        .I3(\q[46]_i_17_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[48]_i_3_n_0 ),
        .O(\q[46]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[46]_i_15 
       (.I0(Q[6]),
        .I1(\q_reg[45] ),
        .I2(\q_reg[10]_0 ),
        .I3(D[7]),
        .I4(\q_reg[41]_0 ),
        .O(\q[46]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hBB8BBBBBBBBBBBBB)) 
    \q[46]_i_16 
       (.I0(\q[48]_i_28_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[43]_i_5_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[46]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h1D)) 
    \q[46]_i_17 
       (.I0(\q[45]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[45]_i_16_n_0 ),
        .O(\q[46]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFF460046FFFFFFFF)) 
    \q[46]_i_2 
       (.I0(ALU_A[6]),
        .I1(\q[46]_i_6_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(r_ALUCode_ex[1]),
        .I4(\q[46]_i_7_n_0 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[46]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAEB)) 
    \q[46]_i_3 
       (.I0(\q[46]_i_8_n_0 ),
        .I1(\q[46]_i_9_n_0 ),
        .I2(\q[46]_i_10_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[1]),
        .O(\q[46]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000E200000000)) 
    \q[46]_i_4 
       (.I0(\q[46]_i_11_n_0 ),
        .I1(ALU_B),
        .I2(\q[47]_i_5_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q[46]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBB8BBB8B8)) 
    \q[46]_i_5 
       (.I0(\q_reg_n_0_[6] ),
        .I1(Q[32]),
        .I2(\q_reg[46]_2 ),
        .I3(\q_reg[6]_1 ),
        .I4(r_rs1Data_ex[6]),
        .I5(\q_reg[45]_1 ),
        .O(ALU_A[6]));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[46]_i_6 
       (.I0(r_Imm_ex[6]),
        .I1(\q[46]_i_15_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[46]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h8FBF8CBC83B380B0)) 
    \q[46]_i_7 
       (.I0(\q[47]_i_11_n_0 ),
        .I1(ALU_B),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[45]_i_7_n_0 ),
        .I4(\q[47]_i_14_n_0 ),
        .I5(\q[46]_i_16_n_0 ),
        .O(\q[46]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h04040004)) 
    \q[46]_i_8 
       (.I0(\q[46]_i_6_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[6]),
        .O(\q[46]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h9999999996996969)) 
    \q[46]_i_9 
       (.I0(ALU_A[6]),
        .I1(\q[46]_i_6_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[46]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAABAFFBF)) 
    \q[47]_i_1 
       (.I0(\q[47]_i_2_n_0 ),
        .I1(\q[47]_i_3_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[47]_i_4_n_0 ),
        .I5(r_ALUCode_ex[3]),
        .O(\q_reg[71]_0 [17]));
  LUT3 #(
    .INIT(8'hC1)) 
    \q[47]_i_10 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[47]_i_6_n_0 ),
        .I2(\q[47]_i_7_n_0 ),
        .O(\q[47]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[47]_i_11 
       (.I0(\q[49]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[53]_i_12_n_0 ),
        .I3(\q[45]_i_22_n_0 ),
        .I4(\q[51]_i_9_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[47]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[47]_i_12 
       (.I0(Q[7]),
        .I1(\q_reg[46]_0 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[8]),
        .I4(\q_reg[41]_0 ),
        .O(\q[47]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[47]_i_13 
       (.I0(r_rs1Data_ex[7]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[8]),
        .I4(\q_reg[46]_0 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[47]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[47]_i_14 
       (.I0(\q[49]_i_16_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[47]_i_15_n_0 ),
        .O(\q[47]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h775FFFFF)) 
    \q[47]_i_15 
       (.I0(\q[44]_i_9_n_0 ),
        .I1(ALU_A[4]),
        .I2(ALU_A[0]),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .O(\q[47]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h0000FACA)) 
    \q[47]_i_2 
       (.I0(\q[47]_i_5_n_0 ),
        .I1(\q[48]_i_3_n_0 ),
        .I2(ALU_B),
        .I3(\q[48]_i_7_n_0 ),
        .I4(\q[70]_i_2_n_0 ),
        .O(\q[47]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFEAFF00)) 
    \q[47]_i_3 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q[47]_i_6_n_0 ),
        .I4(\q[47]_i_7_n_0 ),
        .O(\q[47]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFEEE02EEFE220222)) 
    \q[47]_i_4 
       (.I0(\q[47]_i_8_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[0]),
        .I3(r_ALUCode_ex[1]),
        .I4(\q[47]_i_9_n_0 ),
        .I5(\q[47]_i_10_n_0 ),
        .O(\q[47]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \q[47]_i_5 
       (.I0(\q[48]_i_3_n_0 ),
        .I1(\q[47]_i_11_n_0 ),
        .O(\q[47]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[47]_i_6 
       (.I0(r_Imm_ex[7]),
        .I1(\q[47]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[47]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'hF4)) 
    \q[47]_i_7 
       (.I0(\q_reg_n_0_[7] ),
        .I1(Q[32]),
        .I2(\q[47]_i_13_n_0 ),
        .O(\q[47]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h9696669999669696)) 
    \q[47]_i_8 
       (.I0(\q[47]_i_6_n_0 ),
        .I1(\q[47]_i_7_n_0 ),
        .I2(\q[46]_i_6_n_0 ),
        .I3(\q[66]_i_7_n_0 ),
        .I4(ALU_A[6]),
        .I5(\q[46]_i_10_n_0 ),
        .O(\q[47]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[47]_i_9 
       (.I0(\q[48]_i_7_n_0 ),
        .I1(\q[47]_i_11_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[47]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[48]_i_24_n_0 ),
        .O(\q[47]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0DFF0DFF0DFF0D0D)) 
    \q[48]_i_1 
       (.I0(\q[48]_i_2_n_0 ),
        .I1(\q[48]_i_3_n_0 ),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[48]_i_4_n_0 ),
        .I4(\q[48]_i_5_n_0 ),
        .I5(\q[48]_i_6_n_0 ),
        .O(\q_reg[71]_0 [18]));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[48]_i_10 
       (.I0(r_Imm_ex[7]),
        .I1(\q[48]_i_19_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[48]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hF4F7F0F0)) 
    \q[48]_i_11 
       (.I0(\q[48]_i_20_n_0 ),
        .I1(\q[44]_i_12_n_0 ),
        .I2(\q[48]_i_21_n_0 ),
        .I3(\q[48]_i_22_n_0 ),
        .I4(\q[48]_i_23_n_0 ),
        .O(\q[48]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hAFA03F3FAFA03030)) 
    \q[48]_i_12 
       (.I0(\q[49]_i_10_n_0 ),
        .I1(\q[48]_i_7_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[48]_i_24_n_0 ),
        .I4(ALU_B),
        .I5(\q[49]_i_14_n_0 ),
        .O(\q[48]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hA03FAF3F)) 
    \q[48]_i_13 
       (.I0(\q[48]_i_9_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[56]_0 ),
        .O(\q[48]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[48]_i_14 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[3]),
        .O(\q[48]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[48]_i_17 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[8] ),
        .O(\q[48]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[48]_i_19 
       (.I0(Q[8]),
        .I1(\q_reg[47]_0 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[9]),
        .I4(\q_reg[41]_0 ),
        .O(\q[48]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'hA3)) 
    \q[48]_i_2 
       (.I0(\q[49]_i_10_n_0 ),
        .I1(\q[48]_i_7_n_0 ),
        .I2(ALU_B),
        .O(\q[48]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h57AE0402)) 
    \q[48]_i_20 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\q[44]_i_9_n_0 ),
        .I2(ALU_A[4]),
        .I3(\q[48]_i_25_n_0 ),
        .I4(\q[45]_i_9_n_0 ),
        .O(\q[48]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'h7117)) 
    \q[48]_i_21 
       (.I0(\q[48]_i_26_n_0 ),
        .I1(\q[47]_i_7_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[47]_i_6_n_0 ),
        .O(\q[48]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'h7F31FD4C)) 
    \q[48]_i_22 
       (.I0(ALU_A[4]),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[45]_i_9_n_0 ),
        .I4(\q[48]_i_25_n_0 ),
        .O(\q[48]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'h82AA)) 
    \q[48]_i_23 
       (.I0(\q[48]_i_27_n_0 ),
        .I1(\q[47]_i_6_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[47]_i_7_n_0 ),
        .O(\q[48]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[48]_i_24 
       (.I0(\q[50]_i_22_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[48]_i_28_n_0 ),
        .O(\q[48]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h0000005155555555)) 
    \q[48]_i_25 
       (.I0(\q[48]_i_29_n_0 ),
        .I1(Q[5]),
        .I2(\q_reg[6]_0 ),
        .I3(\q_reg[44]_0 ),
        .I4(\q_reg[45]_0 ),
        .I5(\q[70]_i_8_n_0 ),
        .O(\q[48]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h9999555AFFFFFFFF)) 
    \q[48]_i_26 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(r_Imm_ex[6]),
        .I2(\q[46]_i_15_n_0 ),
        .I3(r_ALUSrcB_ex[1]),
        .I4(r_ALUSrcB_ex[0]),
        .I5(ALU_A[6]),
        .O(\q[48]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hBEBEBEBEEEEEEEBB)) 
    \q[48]_i_27 
       (.I0(ALU_A[6]),
        .I1(\q[66]_i_7_n_0 ),
        .I2(r_Imm_ex[6]),
        .I3(\q[46]_i_15_n_0 ),
        .I4(r_ALUSrcB_ex[1]),
        .I5(r_ALUSrcB_ex[0]),
        .O(\q[48]_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hBF8FFFFF)) 
    \q[48]_i_28 
       (.I0(\q[45]_i_9_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[41]_i_11_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .O(\q[48]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[48]_i_29 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[5]),
        .O(\q[48]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[48]_i_3 
       (.I0(\q[58]_i_10_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .O(\q[48]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFEAAAAA)) 
    \q[48]_i_4 
       (.I0(r_ALUCode_ex[3]),
        .I1(\q[48]_i_9_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[48]_i_10_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[48]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h28828228)) 
    \q[48]_i_5 
       (.I0(\q[44]_i_4_n_0 ),
        .I1(\q[48]_i_9_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[48]_i_10_n_0 ),
        .I4(\q[48]_i_11_n_0 ),
        .O(\q[48]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h44777774CCCCCCCC)) 
    \q[48]_i_6 
       (.I0(\q[48]_i_12_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[48]_i_10_n_0 ),
        .I4(\q[48]_i_9_n_0 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[48]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h74FF7400)) 
    \q[48]_i_7 
       (.I0(\q[48]_i_13_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[51]_i_15_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[50]_i_18_n_0 ),
        .O(\q[48]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000005155555555)) 
    \q[48]_i_8 
       (.I0(\q[48]_i_14_n_0 ),
        .I1(Q[3]),
        .I2(\q_reg[6]_0 ),
        .I3(\q_reg[42]_2 ),
        .I4(\q_reg[43]_1 ),
        .I5(\q[70]_i_8_n_0 ),
        .O(\q[48]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[48]_i_9 
       (.I0(\q[48]_i_17_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[47]_0 ),
        .I3(\q_reg[145]_1 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[8]),
        .O(\q[48]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF000004F7)) 
    \q[49]_i_1 
       (.I0(\q[49]_i_2_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[49]_i_3_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[49]_i_4_n_0 ),
        .O(\q_reg[71]_0 [19]));
  LUT6 #(
    .INIT(64'hB8CCB800B8FFB833)) 
    \q[49]_i_10 
       (.I0(\q[49]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[53]_i_12_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[51]_i_9_n_0 ),
        .I5(\q[55]_i_8_n_0 ),
        .O(\q[49]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[49]_i_11 
       (.I0(Q[9]),
        .I1(\q_reg[48]_0 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[10]),
        .I4(\q_reg[41]_0 ),
        .O(\q[49]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[49]_i_12 
       (.I0(Q[32]),
        .I1(\q_reg_n_0_[9] ),
        .O(\q[49]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[49]_i_14 
       (.I0(\q[50]_i_25_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[49]_i_16_n_0 ),
        .O(\q[49]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hA03FAF3F)) 
    \q[49]_i_15 
       (.I0(\q[49]_i_6_n_0 ),
        .I1(\q_reg[65]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[57]_0 ),
        .O(\q[49]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hBB8BBBBB)) 
    \q[49]_i_16 
       (.I0(\q[50]_i_24_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[42]_i_6_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .O(\q[49]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hFFEAFF00)) 
    \q[49]_i_2 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[49]_0 ),
        .I4(\q[49]_i_6_n_0 ),
        .O(\q[49]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFEEE02EEFE220222)) 
    \q[49]_i_3 
       (.I0(\q[49]_i_7_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[0]),
        .I3(r_ALUCode_ex[1]),
        .I4(\q[49]_i_8_n_0 ),
        .I5(\q[49]_i_9_n_0 ),
        .O(\q[49]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h0000AAF3)) 
    \q[49]_i_4 
       (.I0(\q[50]_i_11_n_0 ),
        .I1(\q[49]_i_10_n_0 ),
        .I2(\q[48]_i_3_n_0 ),
        .I3(ALU_B),
        .I4(\q[70]_i_2_n_0 ),
        .O(\q[49]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[49]_i_5 
       (.I0(r_Imm_ex[7]),
        .I1(\q[49]_i_11_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[49]_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[49]_i_6 
       (.I0(\q[49]_i_12_n_0 ),
        .I1(\q[71]_i_13_n_0 ),
        .I2(\q_reg[48]_0 ),
        .I3(\q_reg[145]_0 ),
        .I4(\q_reg[46]_1 ),
        .I5(r_rs1Data_ex[9]),
        .O(\q[49]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h8E71D42B718E2BD4)) 
    \q[49]_i_7 
       (.I0(\q[48]_i_11_n_0 ),
        .I1(\q[48]_i_10_n_0 ),
        .I2(\q[48]_i_9_n_0 ),
        .I3(\q_reg[49]_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[49]_i_6_n_0 ),
        .O(\q[49]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[49]_i_8 
       (.I0(\q[50]_i_15_n_0 ),
        .I1(\q[49]_i_10_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[49]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[50]_i_16_n_0 ),
        .O(\q[49]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hC1)) 
    \q[49]_i_9 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q_reg[49]_0 ),
        .I2(\q[49]_i_6_n_0 ),
        .O(\q[49]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF000004F7)) 
    \q[50]_i_1 
       (.I0(\q[50]_i_2_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[50]_i_3_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[50]_i_4_n_0 ),
        .O(\q_reg[71]_0 [20]));
  LUT3 #(
    .INIT(8'hC1)) 
    \q[50]_i_10 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[50]_i_5_n_0 ),
        .I2(\q[50]_i_6_n_0 ),
        .O(\q[50]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFAAAABABBBABB)) 
    \q[50]_i_11 
       (.I0(\q[48]_i_3_n_0 ),
        .I1(\q[51]_i_10_n_0 ),
        .I2(\q[58]_i_10_n_0 ),
        .I3(\q[51]_i_11_n_0 ),
        .I4(\q[50]_i_18_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[50]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[50]_i_12 
       (.I0(Q[10]),
        .I1(\q_reg[49]_1 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[11]),
        .I4(\q_reg[41]_0 ),
        .O(\q[50]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[50]_i_13 
       (.I0(r_rs1Data_ex[10]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[11]),
        .I4(\q_reg[49]_1 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[50]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h8BFF8B00)) 
    \q[50]_i_14 
       (.I0(\q[51]_i_9_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[55]_i_8_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[50]_i_19_n_0 ),
        .O(\q[50]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h3A)) 
    \q[50]_i_15 
       (.I0(\q[50]_i_20_n_0 ),
        .I1(\q[50]_i_18_n_0 ),
        .I2(\q_reg[51]_0 ),
        .O(\q[50]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[50]_i_16 
       (.I0(\q[50]_i_21_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[50]_i_22_n_0 ),
        .O(\q[50]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \q[50]_i_17 
       (.I0(\q[50]_i_23_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[50]_i_24_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[50]_i_25_n_0 ),
        .O(\q[50]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \q[50]_i_18 
       (.I0(\q[45]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[54]_i_10_n_0 ),
        .O(\q[50]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF4F7F00004F7F)) 
    \q[50]_i_19 
       (.I0(\q_reg[57]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[65]_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[53]_i_12_n_0 ),
        .O(\q[50]_i_19_n_0 ));
  LUT5 #(
    .INIT(32'hFFEAFF00)) 
    \q[50]_i_2 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q[50]_i_5_n_0 ),
        .I4(\q[50]_i_6_n_0 ),
        .O(\q[50]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF4F7F4F7F)) 
    \q[50]_i_20 
       (.I0(\q_reg[56]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[64]_1 ),
        .I4(\q[51]_i_15_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[50]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0FFFFCFCFFFFF)) 
    \q[50]_i_21 
       (.I0(\q[49]_i_6_n_0 ),
        .I1(\q[41]_i_11_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[45]_i_9_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[50]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hBF8FFFFF)) 
    \q[50]_i_22 
       (.I0(\q[47]_i_7_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[43]_i_5_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .O(\q[50]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'hB8FF)) 
    \q[50]_i_23 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[42]_i_6_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .O(\q[50]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \q[50]_i_24 
       (.I0(ALU_A[6]),
        .I1(\q[70]_i_13_n_0 ),
        .O(\q[50]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hF5F5777755FFFFFF)) 
    \q[50]_i_25 
       (.I0(\q[44]_i_9_n_0 ),
        .I1(ALU_A[4]),
        .I2(\q[48]_i_9_n_0 ),
        .I3(ALU_A[0]),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[50]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h6F606F6F6F606060)) 
    \q[50]_i_3 
       (.I0(\q[50]_i_7_n_0 ),
        .I1(\q[50]_i_8_n_0 ),
        .I2(\q[44]_i_4_n_0 ),
        .I3(\q[50]_i_9_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[50]_i_10_n_0 ),
        .O(\q[50]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    \q[50]_i_4 
       (.I0(\q[51]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[50]_i_11_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q[50]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[50]_i_5 
       (.I0(r_Imm_ex[10]),
        .I1(\q[50]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[50]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'hF4)) 
    \q[50]_i_6 
       (.I0(\q_reg_n_0_[10] ),
        .I1(Q[32]),
        .I2(\q[50]_i_13_n_0 ),
        .O(\q[50]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hC4DF13F740CD0173)) 
    \q[50]_i_7 
       (.I0(\q[48]_i_9_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q[48]_i_10_n_0 ),
        .I3(\q[49]_i_6_n_0 ),
        .I4(\q_reg[49]_0 ),
        .I5(\q[48]_i_11_n_0 ),
        .O(\q[50]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hA9A99AAA56566555)) 
    \q[50]_i_8 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[50]_i_5_n_0 ),
        .O(\q[50]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[50]_i_9 
       (.I0(\q[50]_i_14_n_0 ),
        .I1(\q[50]_i_15_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[50]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(\q[50]_i_17_n_0 ),
        .O(\q[50]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F1F1F1111111F11)) 
    \q[51]_i_1 
       (.I0(\q[51]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[51]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[51]_i_4_n_0 ),
        .O(\q_reg[71]_0 [21]));
  LUT2 #(
    .INIT(4'h2)) 
    \q[51]_i_10 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q[51]_i_15_n_0 ),
        .O(\q[51]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h05155515)) 
    \q[51]_i_11 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[56]_0 ),
        .O(\q[51]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[51]_i_12 
       (.I0(Q[11]),
        .I1(\q_reg[50]_0 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[12]),
        .I4(\q_reg[41]_0 ),
        .O(\q[51]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[51]_i_13 
       (.I0(r_rs1Data_ex[11]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[12]),
        .I4(\q_reg[50]_0 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[51]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[51]_i_14 
       (.I0(\q[52]_i_18_n_0 ),
        .I1(\q[50]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[50]_i_17_n_0 ),
        .I4(ALU_B),
        .I5(\q[52]_i_19_n_0 ),
        .O(\q[51]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hCFA0C0A0)) 
    \q[51]_i_15 
       (.I0(\q_reg[65]_1 ),
        .I1(\q_reg[52]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[60]_0 ),
        .O(\q[51]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0EFEFAFA0E0E0)) 
    \q[51]_i_2 
       (.I0(\q[51]_i_5_n_0 ),
        .I1(\q[51]_i_6_n_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[51]_i_7_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[51]_i_8_n_0 ),
        .O(\q[51]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF74FFFFFF740000)) 
    \q[51]_i_3 
       (.I0(\q[51]_i_9_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[55]_i_8_n_0 ),
        .I3(\q[48]_i_3_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[53]_i_8_n_0 ),
        .O(\q[51]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBABBFFFFBABB0000)) 
    \q[51]_i_4 
       (.I0(\q[48]_i_3_n_0 ),
        .I1(\q[51]_i_10_n_0 ),
        .I2(\q[58]_i_10_n_0 ),
        .I3(\q[51]_i_11_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[54]_i_5_n_0 ),
        .O(\q[51]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[51]_i_5 
       (.I0(r_Imm_ex[7]),
        .I1(\q[51]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[51]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'hF4)) 
    \q[51]_i_6 
       (.I0(\q_reg_n_0_[11] ),
        .I1(Q[32]),
        .I2(\q[51]_i_13_n_0 ),
        .O(\q[51]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h9696996666999696)) 
    \q[51]_i_7 
       (.I0(\q[51]_i_5_n_0 ),
        .I1(\q[51]_i_6_n_0 ),
        .I2(\q[50]_i_5_n_0 ),
        .I3(\q[66]_i_7_n_0 ),
        .I4(\q[50]_i_6_n_0 ),
        .I5(\q[50]_i_7_n_0 ),
        .O(\q[51]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hBB88888B)) 
    \q[51]_i_8 
       (.I0(\q[51]_i_14_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[51]_i_5_n_0 ),
        .I4(\q[51]_i_6_n_0 ),
        .O(\q[51]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hA03FAF3F)) 
    \q[51]_i_9 
       (.I0(\q[51]_i_6_n_0 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[59]_0 ),
        .O(\q[51]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAABAFFBF)) 
    \q[52]_i_1 
       (.I0(\q[52]_i_2_n_0 ),
        .I1(\q[52]_i_3_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[52]_i_4_n_0 ),
        .I5(r_ALUCode_ex[3]),
        .O(\q_reg[71]_0 [22]));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[52]_i_10 
       (.I0(r_rs1Data_ex[12]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[13]),
        .I4(\q_reg[51]_1 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[52]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h4D000017FF4D17FF)) 
    \q[52]_i_11 
       (.I0(\q[52]_i_16_n_0 ),
        .I1(\q[50]_i_5_n_0 ),
        .I2(\q[50]_i_6_n_0 ),
        .I3(\q[51]_i_5_n_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[51]_i_6_n_0 ),
        .O(\q[52]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hCF4D4D0C17033F17)) 
    \q[52]_i_12 
       (.I0(\q[48]_i_20_n_0 ),
        .I1(\q[47]_i_6_n_0 ),
        .I2(\q[47]_i_7_n_0 ),
        .I3(ALU_A[6]),
        .I4(\q[46]_i_6_n_0 ),
        .I5(\q[66]_i_7_n_0 ),
        .O(\q[52]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hD4000071FFD471FF)) 
    \q[52]_i_13 
       (.I0(\q[48]_i_22_n_0 ),
        .I1(\q[46]_i_6_n_0 ),
        .I2(ALU_A[6]),
        .I3(\q[47]_i_6_n_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[47]_i_7_n_0 ),
        .O(\q[52]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h4D0C0317CF4D173F)) 
    \q[52]_i_14 
       (.I0(\q[52]_i_17_n_0 ),
        .I1(\q[51]_i_5_n_0 ),
        .I2(\q[51]_i_6_n_0 ),
        .I3(\q[50]_i_5_n_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q[50]_i_6_n_0 ),
        .O(\q[52]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[52]_i_15 
       (.I0(\q[53]_i_14_n_0 ),
        .I1(\q[52]_i_18_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[52]_i_19_n_0 ),
        .I4(ALU_B),
        .I5(\q[53]_i_15_n_0 ),
        .O(\q[52]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hCCCE8880CBC38082)) 
    \q[52]_i_16 
       (.I0(\q[48]_i_9_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q[52]_i_20_n_0 ),
        .I3(\q[52]_i_21_n_0 ),
        .I4(\q[49]_i_6_n_0 ),
        .I5(\q[52]_i_22_n_0 ),
        .O(\q[52]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hEEEFCCC8EFEBC2C3)) 
    \q[52]_i_17 
       (.I0(\q[48]_i_9_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q[52]_i_20_n_0 ),
        .I3(\q[52]_i_21_n_0 ),
        .I4(\q[49]_i_6_n_0 ),
        .I5(\q[52]_i_22_n_0 ),
        .O(\q[52]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[52]_i_18 
       (.I0(\q[50]_i_20_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[54]_i_16_n_0 ),
        .O(\q[52]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[52]_i_19 
       (.I0(\q[54]_i_17_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[50]_i_21_n_0 ),
        .O(\q[52]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    \q[52]_i_2 
       (.I0(\q[53]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[51]_i_4_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q[52]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[52]_i_20 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[7]),
        .O(\q[52]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[52]_i_21 
       (.I0(\q[70]_i_8_n_0 ),
        .I1(\q_reg[41]_0 ),
        .I2(D[9]),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[47]_0 ),
        .I5(Q[8]),
        .O(\q[52]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[52]_i_22 
       (.I0(\q[70]_i_8_n_0 ),
        .I1(\q_reg[41]_0 ),
        .I2(D[10]),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[48]_0 ),
        .I5(Q[9]),
        .O(\q[52]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hFF00FFEA)) 
    \q[52]_i_3 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[52]_1 ),
        .I4(\q_reg[52]_0 ),
        .O(\q[52]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h6996FFFF69960000)) 
    \q[52]_i_4 
       (.I0(\q[52]_i_7_n_0 ),
        .I1(\q_reg[52]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[52]_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[52]_i_8_n_0 ),
        .O(\q[52]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[52]_i_5 
       (.I0(r_Imm_ex[12]),
        .I1(\q[52]_i_9_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[52]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[52]_i_6 
       (.I0(\q_reg_n_0_[12] ),
        .I1(Q[32]),
        .I2(\q[52]_i_10_n_0 ),
        .O(\q_reg[52]_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \q[52]_i_7 
       (.I0(\q[52]_i_11_n_0 ),
        .I1(\q[52]_i_12_n_0 ),
        .I2(\q[44]_i_12_n_0 ),
        .I3(\q[52]_i_13_n_0 ),
        .I4(\q[52]_i_14_n_0 ),
        .O(\q[52]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[52]_i_8 
       (.I0(\q[52]_i_15_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[52]_1 ),
        .I4(\q_reg[52]_0 ),
        .O(\q[52]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[52]_i_9 
       (.I0(Q[12]),
        .I1(\q_reg[51]_1 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[13]),
        .I4(\q_reg[41]_0 ),
        .O(\q[52]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F1F1F1111111F11)) 
    \q[53]_i_1 
       (.I0(\q[53]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[53]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[54]_i_2_n_0 ),
        .O(\q_reg[71]_0 [23]));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[53]_i_10 
       (.I0(r_rs1Data_ex[13]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[14]),
        .I4(\q_reg[52]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[53]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[53]_i_11 
       (.I0(\q[54]_i_14_n_0 ),
        .I1(\q[53]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[53]_i_15_n_0 ),
        .I4(ALU_B),
        .I5(\q[54]_i_15_n_0 ),
        .O(\q[53]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h503F5F3F)) 
    \q[53]_i_12 
       (.I0(\q_reg[53]_0 ),
        .I1(\q_reg[68]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[61]_1 ),
        .O(\q[53]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h05155515)) 
    \q[53]_i_13 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q_reg[65]_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[57]_0 ),
        .O(\q[53]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h8B888BBB)) 
    \q[53]_i_14 
       (.I0(\q[50]_i_19_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[55]_i_8_n_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[58]_i_19_n_0 ),
        .O(\q[53]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[53]_i_15 
       (.I0(\q[59]_i_17_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[55]_i_17_n_0 ),
        .I3(\q[50]_i_23_n_0 ),
        .I4(\q[50]_i_24_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[53]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[53]_i_2 
       (.I0(\q_reg[53]_1 ),
        .I1(\q_reg[53]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[53]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[53]_i_7_n_0 ),
        .O(\q[53]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF0000EFE0EFE0)) 
    \q[53]_i_3 
       (.I0(\q[55]_i_8_n_0 ),
        .I1(\q[48]_i_3_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[55]_i_9_n_0 ),
        .I4(\q[53]_i_8_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[53]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[53]_i_4 
       (.I0(r_Imm_ex[13]),
        .I1(\q[53]_i_9_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[53]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[53]_i_5 
       (.I0(\q_reg_n_0_[13] ),
        .I1(Q[32]),
        .I2(\q[53]_i_10_n_0 ),
        .O(\q_reg[53]_0 ));
  LUT6 #(
    .INIT(64'h6696699969669996)) 
    \q[53]_i_6 
       (.I0(\q_reg[53]_1 ),
        .I1(\q_reg[53]_0 ),
        .I2(\q_reg[52]_0 ),
        .I3(\q[66]_i_7_n_0 ),
        .I4(\q_reg[52]_1 ),
        .I5(\q[52]_i_7_n_0 ),
        .O(\q[53]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[53]_i_7 
       (.I0(\q[53]_i_11_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[53]_1 ),
        .I4(\q_reg[53]_0 ),
        .O(\q[53]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hF7F0F7F7)) 
    \q[53]_i_8 
       (.I0(\q[53]_i_12_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[48]_i_3_n_0 ),
        .I3(\q[58]_i_10_n_0 ),
        .I4(\q[53]_i_13_n_0 ),
        .O(\q[53]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[53]_i_9 
       (.I0(Q[13]),
        .I1(\q_reg[52]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[14]),
        .I4(\q_reg[41]_0 ),
        .O(\q[53]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h454045404540FFFF)) 
    \q[54]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[55]_i_3_n_0 ),
        .I2(ALU_B),
        .I3(\q[54]_i_2_n_0 ),
        .I4(\q[54]_i_3_n_0 ),
        .I5(r_ALUCode_ex[3]),
        .O(\q_reg[71]_0 [24]));
  LUT5 #(
    .INIT(32'hAFC0A0C0)) 
    \q[54]_i_10 
       (.I0(\q_reg[54]_0 ),
        .I1(\q_reg[69]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[62]_0 ),
        .O(\q[54]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[54]_i_11 
       (.I0(Q[14]),
        .I1(\q_reg[53]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[15]),
        .I4(\q_reg[41]_0 ),
        .O(\q[54]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[54]_i_12 
       (.I0(\q_reg[53]_2 ),
        .I1(Q[32]),
        .I2(D[15]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[14]),
        .O(\q[54]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[54]_i_13 
       (.I0(\q[55]_i_15_n_0 ),
        .I1(\q[54]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[54]_i_15_n_0 ),
        .I4(ALU_B),
        .I5(\q[55]_i_16_n_0 ),
        .O(\q[54]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h8B)) 
    \q[54]_i_14 
       (.I0(\q[54]_i_16_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[54]_i_4_n_0 ),
        .O(\q[54]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \q[54]_i_15 
       (.I0(\q[60]_i_20_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[56]_i_21_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[54]_i_17_n_0 ),
        .O(\q[54]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF4F7F4F7F)) 
    \q[54]_i_16 
       (.I0(\q_reg[58]_1 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[66]_0 ),
        .I4(\q[54]_i_10_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[54]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFFFA0FFCFFFCFFF)) 
    \q[54]_i_17 
       (.I0(\q[51]_i_6_n_0 ),
        .I1(\q[43]_i_5_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[47]_i_7_n_0 ),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[54]_i_17_n_0 ));
  LUT4 #(
    .INIT(16'hF0EE)) 
    \q[54]_i_2 
       (.I0(\q[54]_i_4_n_0 ),
        .I1(\q[58]_i_10_n_0 ),
        .I2(\q[54]_i_5_n_0 ),
        .I3(\q_reg[51]_0 ),
        .O(\q[54]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[54]_i_3 
       (.I0(\q_reg[54]_1 ),
        .I1(\q_reg[54]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[54]_i_8_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[54]_i_9_n_0 ),
        .O(\q[54]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB080FFFFB0800000)) 
    \q[54]_i_4 
       (.I0(\q_reg[56]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[64]_1 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[60]_i_10_n_0 ),
        .O(\q[54]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hEFE0)) 
    \q[54]_i_5 
       (.I0(\q[48]_i_3_n_0 ),
        .I1(\q[54]_i_10_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[58]_i_9_n_0 ),
        .O(\q[54]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[54]_i_6 
       (.I0(r_Imm_ex[14]),
        .I1(\q[54]_i_11_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[54]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[54]_i_7 
       (.I0(\q_reg_n_0_[14] ),
        .I1(Q[32]),
        .I2(\q[54]_i_12_n_0 ),
        .O(\q_reg[54]_0 ));
  LUT6 #(
    .INIT(64'hB84747B847B8B847)) 
    \q[54]_i_8 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(\q[52]_i_7_n_0 ),
        .I2(\q[56]_i_15_n_0 ),
        .I3(\q_reg[54]_1 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[54]_0 ),
        .O(\q[54]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[54]_i_9 
       (.I0(\q[54]_i_13_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[54]_1 ),
        .I4(\q_reg[54]_0 ),
        .O(\q[54]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F111F1F1F111111)) 
    \q[55]_i_1 
       (.I0(\q[55]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[56]_i_2__0_n_0 ),
        .I4(ALU_B),
        .I5(\q[55]_i_3_n_0 ),
        .O(\q_reg[71]_0 [25]));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[55]_i_10 
       (.I0(Q[15]),
        .I1(\q_reg[54]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[16]),
        .I4(\q_reg[41]_0 ),
        .O(\q[55]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[55]_i_11 
       (.I0(\q_reg[54]_2 ),
        .I1(Q[32]),
        .I2(D[16]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[15]),
        .O(\q[55]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hA9A99AAA56566555)) 
    \q[55]_i_12 
       (.I0(\q_reg[55]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[55]_1 ),
        .O(\q[55]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[55]_i_13 
       (.I0(\q_reg[54]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[55]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[55]_i_14 
       (.I0(\q[56]_i_5_n_0 ),
        .I1(\q[55]_i_15_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[55]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(\q[56]_i_20_n_0 ),
        .O(\q[55]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h470047FF)) 
    \q[55]_i_15 
       (.I0(\q[55]_i_8_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[58]_i_19_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[57]_i_12_n_0 ),
        .O(\q[55]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[55]_i_16 
       (.I0(\q[59]_i_17_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[55]_i_17_n_0 ),
        .I3(\q[61]_i_16_n_0 ),
        .I4(\q[50]_i_23_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[55]_i_16_n_0 ));
  LUT4 #(
    .INIT(16'h8BFF)) 
    \q[55]_i_17 
       (.I0(\q[48]_i_9_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(ALU_A[0]),
        .I3(\q[44]_i_9_n_0 ),
        .O(\q[55]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[55]_i_2 
       (.I0(\q_reg[55]_1 ),
        .I1(\q_reg[55]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[55]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[55]_i_7_n_0 ),
        .O(\q[55]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEFE0FFFFEFE00000)) 
    \q[55]_i_3 
       (.I0(\q[55]_i_8_n_0 ),
        .I1(\q[48]_i_3_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[55]_i_9_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[57]_i_8_n_0 ),
        .O(\q[55]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[55]_i_4 
       (.I0(r_Imm_ex[15]),
        .I1(\q[55]_i_10_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[55]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[55]_i_5 
       (.I0(\q_reg_n_0_[15] ),
        .I1(Q[32]),
        .I2(\q[55]_i_11_n_0 ),
        .O(\q_reg[55]_0 ));
  LUT6 #(
    .INIT(64'h4B0FF04B780FF078)) 
    \q[55]_i_6 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(\q[52]_i_7_n_0 ),
        .I2(\q[55]_i_12_n_0 ),
        .I3(\q_reg[54]_0 ),
        .I4(\q[55]_i_13_n_0 ),
        .I5(\q[56]_i_15_n_0 ),
        .O(\q[55]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[55]_i_7 
       (.I0(\q[55]_i_14_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[55]_1 ),
        .I4(\q_reg[55]_0 ),
        .O(\q[55]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hEEE2C0C0)) 
    \q[55]_i_8 
       (.I0(\q_reg[63]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[58]_i_10_n_0 ),
        .I3(\q_reg[55]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[55]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hFAEAAAEA)) 
    \q[55]_i_9 
       (.I0(\q[58]_i_10_n_0 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[59]_0 ),
        .O(\q[55]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h5404FFFF54045404)) 
    \q[56]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[56]_i_2__0_n_0 ),
        .I2(ALU_B),
        .I3(\q[57]_i_3_n_0 ),
        .I4(\q[56]_i_3_n_0 ),
        .I5(\q[56]_i_4_n_0 ),
        .O(\q_reg[71]_0 [26]));
  LUT6 #(
    .INIT(64'h11DD1DDDDDDD1DDD)) 
    \q[56]_i_10 
       (.I0(\q[58]_i_11_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[66]_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .I5(\q_reg[58]_1 ),
        .O(\q[56]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[56]_i_11 
       (.I0(\q_reg[55]_2 ),
        .I1(Q[32]),
        .I2(D[17]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[16]),
        .O(\q[56]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[56]_i_12 
       (.I0(Q[16]),
        .I1(\q_reg[55]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[17]),
        .I4(\q_reg[41]_0 ),
        .O(\q[56]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h100437DC)) 
    \q[56]_i_13 
       (.I0(\q_reg[52]_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[52]_1 ),
        .I3(\q_reg[53]_1 ),
        .I4(\q_reg[53]_0 ),
        .O(\q[56]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h00EB)) 
    \q[56]_i_14 
       (.I0(\q_reg[55]_0 ),
        .I1(\q_reg[55]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[56]_i_18_n_0 ),
        .O(\q[56]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h314C7FFD)) 
    \q[56]_i_15 
       (.I0(\q_reg[52]_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[52]_1 ),
        .I3(\q_reg[53]_1 ),
        .I4(\q_reg[53]_0 ),
        .O(\q[56]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'hE88E)) 
    \q[56]_i_16 
       (.I0(\q[56]_i_19_n_0 ),
        .I1(\q_reg[55]_0 ),
        .I2(\q_reg[55]_1 ),
        .I3(\q[66]_i_7_n_0 ),
        .O(\q[56]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[56]_i_17 
       (.I0(\q[57]_i_13_n_0 ),
        .I1(\q[56]_i_5_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[56]_i_20_n_0 ),
        .I4(ALU_B),
        .I5(\q[57]_i_14_n_0 ),
        .O(\q[56]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEBF1140)) 
    \q[56]_i_18 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[54]_1 ),
        .I5(\q_reg[54]_0 ),
        .O(\q[56]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h02022000A8A88AAA)) 
    \q[56]_i_19 
       (.I0(\q_reg[54]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[54]_1 ),
        .O(\q[56]_i_19_n_0 ));
  LUT5 #(
    .INIT(32'hFF00B8B8)) 
    \q[56]_i_20 
       (.I0(\q[60]_i_20_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[56]_i_21_n_0 ),
        .I3(\q[58]_i_22_n_0 ),
        .I4(\q_reg[51]_0 ),
        .O(\q[56]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'hB8FF)) 
    \q[56]_i_21 
       (.I0(\q[49]_i_6_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[41]_i_11_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .O(\q[56]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \q[56]_i_2__0 
       (.I0(\q[58]_i_10_n_0 ),
        .I1(\q[56]_i_5_n_0 ),
        .O(\q[56]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[56]_i_3 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[56]_0 ),
        .I3(\q_reg[56]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[56]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69960000)) 
    \q[56]_i_4 
       (.I0(\q[56]_i_8_n_0 ),
        .I1(\q_reg[56]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[56]_i_9_n_0 ),
        .O(\q[56]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \q[56]_i_5 
       (.I0(\q[54]_i_4_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[56]_i_10_n_0 ),
        .O(\q[56]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[56]_i_6 
       (.I0(\q_reg_n_0_[16] ),
        .I1(Q[32]),
        .I2(\q[56]_i_11_n_0 ),
        .O(\q_reg[56]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[56]_i_7 
       (.I0(r_Imm_ex[16]),
        .I1(\q[56]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[56]_1 ));
  LUT5 #(
    .INIT(32'h0000BF8F)) 
    \q[56]_i_8 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(\q[52]_i_7_n_0 ),
        .I2(\q[56]_i_14_n_0 ),
        .I3(\q[56]_i_15_n_0 ),
        .I4(\q[56]_i_16_n_0 ),
        .O(\q[56]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h77744477CCCCCCCC)) 
    \q[56]_i_9 
       (.I0(\q[56]_i_17_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[56]_1 ),
        .I4(\q_reg[56]_0 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[56]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F111F1F1F111111)) 
    \q[57]_i_1 
       (.I0(\q[57]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[58]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[57]_i_3_n_0 ),
        .O(\q_reg[71]_0 [27]));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[57]_i_10 
       (.I0(r_rs1Data_ex[17]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[18]),
        .I4(\q_reg[56]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[57]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[57]_i_11 
       (.I0(\q[58]_i_20_n_0 ),
        .I1(\q[57]_i_13_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[57]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[58]_i_21_n_0 ),
        .O(\q[57]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hB080FFFFB0800000)) 
    \q[57]_i_12 
       (.I0(\q_reg[57]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[65]_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[61]_i_12_n_0 ),
        .O(\q[57]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \q[57]_i_13 
       (.I0(\q[57]_i_12_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[59]_i_16_n_0 ),
        .O(\q[57]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[57]_i_14 
       (.I0(\q[63]_i_18_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[59]_i_17_n_0 ),
        .I3(\q[61]_i_16_n_0 ),
        .I4(\q[50]_i_23_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[57]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[57]_i_2 
       (.I0(\q_reg[57]_1 ),
        .I1(\q_reg[57]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[57]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[57]_i_7_n_0 ),
        .O(\q[57]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[57]_i_3 
       (.I0(\q[57]_i_8_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[58]_i_12_n_0 ),
        .O(\q[57]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[57]_i_4 
       (.I0(r_Imm_ex[17]),
        .I1(\q[57]_i_9_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[57]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[57]_i_5 
       (.I0(\q_reg_n_0_[17] ),
        .I1(Q[32]),
        .I2(\q[57]_i_10_n_0 ),
        .O(\q_reg[57]_0 ));
  LUT6 #(
    .INIT(64'h2BD44DB2D42BB24D)) 
    \q[57]_i_6 
       (.I0(\q[56]_i_8_n_0 ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[56]_1 ),
        .I3(\q_reg[57]_1 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[57]_0 ),
        .O(\q[57]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[57]_i_7 
       (.I0(\q[57]_i_11_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[57]_1 ),
        .I4(\q_reg[57]_0 ),
        .O(\q[57]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[57]_i_8 
       (.I0(\q[58]_i_10_n_0 ),
        .I1(\q[57]_i_12_n_0 ),
        .O(\q[57]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[57]_i_9 
       (.I0(Q[17]),
        .I1(\q_reg[56]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[18]),
        .I4(\q_reg[41]_0 ),
        .O(\q[57]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F1F1F1111111F11)) 
    \q[58]_i_1 
       (.I0(\q[58]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[58]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[58]_i_4_n_0 ),
        .O(\q_reg[71]_0 [28]));
  LUT2 #(
    .INIT(4'h2)) 
    \q[58]_i_10 
       (.I0(\q_reg[70]_0 ),
        .I1(\q[44]_i_9_n_0 ),
        .O(\q[58]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[58]_i_11 
       (.I0(\q_reg[62]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[69]_0 ),
        .O(\q[58]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8F8F888B8F8F8)) 
    \q[58]_i_12 
       (.I0(\q[58]_i_19_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[70]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[63]_0 ),
        .O(\q[58]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[58]_i_13 
       (.I0(Q[18]),
        .I1(\q_reg[57]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[19]),
        .I4(\q_reg[41]_0 ),
        .O(\q[58]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[58]_i_14 
       (.I0(\q_reg[57]_2 ),
        .I1(Q[32]),
        .I2(D[19]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[18]),
        .O(\q[58]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[58]_i_15 
       (.I0(\q_reg[57]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[58]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[58]_i_16 
       (.I0(\q_reg[56]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[58]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hA9A99AAA56566555)) 
    \q[58]_i_17 
       (.I0(\q_reg[58]_1 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[58]_0 ),
        .O(\q[58]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[58]_i_18 
       (.I0(\q[59]_i_14_n_0 ),
        .I1(\q[58]_i_20_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[58]_i_21_n_0 ),
        .I4(ALU_B),
        .I5(\q[59]_i_15_n_0 ),
        .O(\q[58]_i_18_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[58]_i_19 
       (.I0(\q_reg[59]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[67]_0 ),
        .O(\q[58]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[58]_i_2 
       (.I0(\q_reg[58]_0 ),
        .I1(\q_reg[58]_1 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[58]_i_7_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[58]_i_8_n_0 ),
        .O(\q[58]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF00000F770F77)) 
    \q[58]_i_20 
       (.I0(\q[70]_i_13_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q[60]_i_10_n_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[56]_i_10_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[58]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \q[58]_i_21 
       (.I0(\q[64]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[60]_i_20_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[58]_i_22_n_0 ),
        .O(\q[58]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h74FFFFFF74FF0000)) 
    \q[58]_i_22 
       (.I0(\q_reg[55]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[47]_i_7_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[58]_i_23_n_0 ),
        .O(\q[58]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'hB8FF)) 
    \q[58]_i_23 
       (.I0(\q[51]_i_6_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[43]_i_5_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .O(\q[58]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8FFFFBBB80000)) 
    \q[58]_i_3 
       (.I0(\q[58]_i_9_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[58]_i_10_n_0 ),
        .I3(\q[58]_i_11_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[60]_i_5_n_0 ),
        .O(\q[58]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[58]_i_4 
       (.I0(\q[58]_i_12_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[61]_i_8_n_0 ),
        .O(\q[58]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[58]_i_5 
       (.I0(r_Imm_ex[19]),
        .I1(\q[58]_i_13_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[58]_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[58]_i_6 
       (.I0(\q_reg_n_0_[18] ),
        .I1(Q[32]),
        .I2(\q[58]_i_14_n_0 ),
        .O(\q_reg[58]_1 ));
  LUT6 #(
    .INIT(64'h4D0CCF4DB2F330B2)) 
    \q[58]_i_7 
       (.I0(\q[56]_i_8_n_0 ),
        .I1(\q_reg[57]_0 ),
        .I2(\q[58]_i_15_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(\q[58]_i_16_n_0 ),
        .I5(\q[58]_i_17_n_0 ),
        .O(\q[58]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h88BB8B88)) 
    \q[58]_i_8 
       (.I0(\q[58]_i_18_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[58]_1 ),
        .I4(\q_reg[58]_0 ),
        .O(\q[58]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFB800)) 
    \q[58]_i_9 
       (.I0(\q_reg[58]_1 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q_reg[66]_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[58]_i_10_n_0 ),
        .O(\q[58]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF000004F7)) 
    \q[59]_i_1 
       (.I0(\q[59]_i_2_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[59]_i_3_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[59]_i_4_n_0 ),
        .O(\q_reg[71]_0 [29]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[59]_i_10 
       (.I0(\q_reg[58]_2 ),
        .I1(Q[32]),
        .I2(D[20]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[19]),
        .O(\q[59]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h314C7FFD)) 
    \q[59]_i_11 
       (.I0(\q_reg[56]_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[56]_1 ),
        .I3(\q_reg[57]_1 ),
        .I4(\q_reg[57]_0 ),
        .O(\q[59]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h040257AE)) 
    \q[59]_i_12 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\q_reg[56]_1 ),
        .I2(\q_reg[56]_0 ),
        .I3(\q_reg[57]_1 ),
        .I4(\q_reg[57]_0 ),
        .O(\q[59]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[59]_i_13 
       (.I0(\q[60]_i_18_n_0 ),
        .I1(\q[59]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[59]_i_15_n_0 ),
        .I4(ALU_B),
        .I5(\q[60]_i_19_n_0 ),
        .O(\q[59]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[59]_i_14 
       (.I0(\q[59]_i_16_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[61]_i_15_n_0 ),
        .O(\q[59]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[59]_i_15 
       (.I0(\q[63]_i_18_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[59]_i_17_n_0 ),
        .I3(\q[65]_i_16_n_0 ),
        .I4(\q[61]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[59]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h4447777777477777)) 
    \q[59]_i_16 
       (.I0(\q[58]_i_19_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[70]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q_reg[63]_0 ),
        .O(\q[59]_i_16_n_0 ));
  LUT4 #(
    .INIT(16'h5F77)) 
    \q[59]_i_17 
       (.I0(\q[44]_i_9_n_0 ),
        .I1(ALU_A[4]),
        .I2(\q_reg[52]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .O(\q[59]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hFF00FFEA)) 
    \q[59]_i_2 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[59]_1 ),
        .I4(\q_reg[59]_0 ),
        .O(\q[59]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6996FFFF69960000)) 
    \q[59]_i_3 
       (.I0(\q_reg[59]_1 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[59]_0 ),
        .I3(\q[59]_i_7_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[59]_i_8_n_0 ),
        .O(\q[59]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000E200000000)) 
    \q[59]_i_4 
       (.I0(\q[58]_i_4_n_0 ),
        .I1(ALU_B),
        .I2(\q[60]_i_2_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q[59]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[59]_i_5 
       (.I0(r_Imm_ex[19]),
        .I1(\q[59]_i_9_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[59]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[59]_i_6 
       (.I0(\q_reg_n_0_[19] ),
        .I1(Q[32]),
        .I2(\q[59]_i_10_n_0 ),
        .O(\q_reg[59]_0 ));
  LUT6 #(
    .INIT(64'hFF4747004700FF47)) 
    \q[59]_i_7 
       (.I0(\q[59]_i_11_n_0 ),
        .I1(\q[56]_i_8_n_0 ),
        .I2(\q[59]_i_12_n_0 ),
        .I3(\q_reg[58]_1 ),
        .I4(\q_reg[58]_0 ),
        .I5(\q[66]_i_7_n_0 ),
        .O(\q[59]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[59]_i_8 
       (.I0(\q[59]_i_13_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[59]_1 ),
        .I4(\q_reg[59]_0 ),
        .O(\q[59]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[59]_i_9 
       (.I0(Q[19]),
        .I1(\q_reg[58]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[20]),
        .I4(\q_reg[41]_0 ),
        .O(\q[59]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h5404FFFF54045404)) 
    \q[60]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[60]_i_2_n_0 ),
        .I2(ALU_B),
        .I3(\q[61]_i_3_n_0 ),
        .I4(\q[60]_i_3_n_0 ),
        .I5(\q[60]_i_4_n_0 ),
        .O(\q_reg[71]_0 [30]));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[60]_i_10 
       (.I0(\q_reg[60]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[65]_1 ),
        .O(\q[60]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[60]_i_11 
       (.I0(\q_reg[59]_2 ),
        .I1(Q[32]),
        .I2(D[21]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[20]),
        .O(\q[60]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[60]_i_12 
       (.I0(Q[20]),
        .I1(\q_reg[59]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[21]),
        .I4(\q_reg[41]_0 ),
        .O(\q[60]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hF2FB8FEF80E0020B)) 
    \q[60]_i_13 
       (.I0(\q_reg[58]_1 ),
        .I1(\q_reg[58]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[59]_i_11_n_0 ),
        .I4(\q_reg[59]_1 ),
        .I5(\q_reg[59]_0 ),
        .O(\q[60]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h032B2B3FB2F330B2)) 
    \q[60]_i_14 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(\q_reg[55]_0 ),
        .I2(\q_reg[55]_1 ),
        .I3(\q_reg[54]_0 ),
        .I4(\q_reg[54]_1 ),
        .I5(\q[66]_i_7_n_0 ),
        .O(\q[60]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h203E08BC38BF2CFE)) 
    \q[60]_i_15 
       (.I0(\q[56]_i_15_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[55]_1 ),
        .I3(\q_reg[55]_0 ),
        .I4(\q_reg[54]_1 ),
        .I5(\q_reg[54]_0 ),
        .O(\q[60]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFCD44DCFD4C00C4D)) 
    \q[60]_i_16 
       (.I0(\q[59]_i_12_n_0 ),
        .I1(\q_reg[59]_0 ),
        .I2(\q_reg[59]_1 ),
        .I3(\q_reg[58]_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[58]_1 ),
        .O(\q[60]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[60]_i_17 
       (.I0(\q[61]_i_13_n_0 ),
        .I1(\q[60]_i_18_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[60]_i_19_n_0 ),
        .I4(ALU_B),
        .I5(\q[61]_i_14_n_0 ),
        .O(\q[60]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h0F77FFFF0F770000)) 
    \q[60]_i_18 
       (.I0(\q[70]_i_13_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q[60]_i_10_n_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[62]_i_16_n_0 ),
        .O(\q[60]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hFF00B8B8)) 
    \q[60]_i_19 
       (.I0(\q[64]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[60]_i_20_n_0 ),
        .I3(\q[62]_i_17_n_0 ),
        .I4(\q_reg[51]_0 ),
        .O(\q[60]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[60]_i_2 
       (.I0(\q[60]_i_5_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[62]_i_6_n_0 ),
        .O(\q[60]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h2EFF)) 
    \q[60]_i_20 
       (.I0(\q[45]_i_9_n_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q_reg[53]_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .O(\q[60]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[60]_i_3 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[60]_0 ),
        .I3(\q_reg[60]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[60]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF96690000)) 
    \q[60]_i_4 
       (.I0(\q[60]_i_8_n_0 ),
        .I1(\q_reg[60]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[60]_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[60]_i_9_n_0 ),
        .O(\q[60]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF00F8F8F8F8)) 
    \q[60]_i_5 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q[64]_i_5_n_0 ),
        .I3(\q[58]_i_10_n_0 ),
        .I4(\q[60]_i_10_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[60]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[60]_i_6 
       (.I0(\q_reg_n_0_[20] ),
        .I1(Q[32]),
        .I2(\q[60]_i_11_n_0 ),
        .O(\q_reg[60]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[60]_i_7 
       (.I0(r_Imm_ex[20]),
        .I1(\q[60]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[60]_1 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \q[60]_i_8 
       (.I0(\q[60]_i_13_n_0 ),
        .I1(\q[60]_i_14_n_0 ),
        .I2(\q[52]_i_7_n_0 ),
        .I3(\q[60]_i_15_n_0 ),
        .I4(\q[60]_i_16_n_0 ),
        .O(\q[60]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h77744477CCCCCCCC)) 
    \q[60]_i_9 
       (.I0(\q[60]_i_17_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[60]_1 ),
        .I4(\q_reg[60]_0 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[60]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F111F1F1F111111)) 
    \q[61]_i_1 
       (.I0(\q[61]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[62]_i_2_n_0 ),
        .I4(ALU_B),
        .I5(\q[61]_i_3_n_0 ),
        .O(\q_reg[71]_0 [31]));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[61]_i_10 
       (.I0(r_rs1Data_ex[21]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[22]),
        .I4(\q_reg[60]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[61]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[61]_i_11 
       (.I0(\q[62]_i_14_n_0 ),
        .I1(\q[61]_i_13_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[61]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[62]_i_15_n_0 ),
        .O(\q[61]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[61]_i_12 
       (.I0(\q_reg[61]_1 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[68]_1 ),
        .O(\q[61]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[61]_i_13 
       (.I0(\q[61]_i_15_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[63]_i_17_n_0 ),
        .O(\q[61]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[61]_i_14 
       (.I0(\q[67]_i_17_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[63]_i_18_n_0 ),
        .I3(\q[65]_i_16_n_0 ),
        .I4(\q[61]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[61]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h30FF3FFF5FFF5FFF)) 
    \q[61]_i_15 
       (.I0(\q_reg[65]_0 ),
        .I1(\q_reg[61]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[68]_1 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[61]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'h4F7F)) 
    \q[61]_i_16 
       (.I0(\q_reg[54]_0 ),
        .I1(\q[48]_i_8_n_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(ALU_A[6]),
        .O(\q[61]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[61]_i_2 
       (.I0(\q_reg[61]_0 ),
        .I1(\q_reg[61]_1 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[61]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[61]_i_7_n_0 ),
        .O(\q[61]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[61]_i_3 
       (.I0(\q[61]_i_8_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[63]_i_8_n_0 ),
        .O(\q[61]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[61]_i_4 
       (.I0(r_Imm_ex[21]),
        .I1(\q[61]_i_9_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[61]_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[61]_i_5 
       (.I0(\q_reg_n_0_[21] ),
        .I1(Q[32]),
        .I2(\q[61]_i_10_n_0 ),
        .O(\q_reg[61]_1 ));
  LUT6 #(
    .INIT(64'h17E8B24DE8174DB2)) 
    \q[61]_i_6 
       (.I0(\q[60]_i_8_n_0 ),
        .I1(\q_reg[60]_1 ),
        .I2(\q_reg[60]_0 ),
        .I3(\q_reg[61]_0 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[61]_1 ),
        .O(\q[61]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[61]_i_7 
       (.I0(\q[61]_i_11_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[61]_0 ),
        .I4(\q_reg[61]_1 ),
        .O(\q[61]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF8F8FF00F8F8)) 
    \q[61]_i_8 
       (.I0(\q_reg[65]_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q[64]_i_5_n_0 ),
        .I3(\q[58]_i_10_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q[61]_i_12_n_0 ),
        .O(\q[61]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[61]_i_9 
       (.I0(Q[21]),
        .I1(\q_reg[60]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[22]),
        .I4(\q_reg[41]_0 ),
        .O(\q[61]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h4540FFFF45404540)) 
    \q[62]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[63]_i_3_n_0 ),
        .I2(ALU_B),
        .I3(\q[62]_i_2_n_0 ),
        .I4(\q[62]_i_3_n_0 ),
        .I5(\q[62]_i_4_n_0 ),
        .O(\q_reg[71]_0 [32]));
  LUT6 #(
    .INIT(64'h77744477CCCCCCCC)) 
    \q[62]_i_10 
       (.I0(\q[62]_i_13_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[62]_1 ),
        .I4(\q_reg[62]_0 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[62]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[62]_i_11 
       (.I0(r_rs1Data_ex[22]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[23]),
        .I4(\q_reg[61]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[62]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[62]_i_12 
       (.I0(Q[22]),
        .I1(\q_reg[61]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[23]),
        .I4(\q_reg[41]_0 ),
        .O(\q[62]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[62]_i_13 
       (.I0(\q[63]_i_15_n_0 ),
        .I1(\q[62]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[62]_i_15_n_0 ),
        .I4(ALU_B),
        .I5(\q[63]_i_16_n_0 ),
        .O(\q[62]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF00004F7F4F7F)) 
    \q[62]_i_14 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[65]_1 ),
        .I4(\q[62]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[62]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \q[62]_i_15 
       (.I0(\q[68]_i_11_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[64]_i_21_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q[62]_i_17_n_0 ),
        .O(\q[62]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'h0F77)) 
    \q[62]_i_16 
       (.I0(\q[70]_i_13_n_0 ),
        .I1(\q_reg[66]_0 ),
        .I2(\q[58]_i_11_n_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .O(\q[62]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h8BBB8B88BBBBBBBB)) 
    \q[62]_i_17 
       (.I0(\q[66]_i_15_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[55]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q[47]_i_7_n_0 ),
        .I5(\q[44]_i_9_n_0 ),
        .O(\q[62]_i_17_n_0 ));
  LUT4 #(
    .INIT(16'hF0EE)) 
    \q[62]_i_2 
       (.I0(\q[62]_i_5_n_0 ),
        .I1(\q[64]_i_5_n_0 ),
        .I2(\q[62]_i_6_n_0 ),
        .I3(\q_reg[51]_0 ),
        .O(\q[62]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[62]_i_3 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[62]_0 ),
        .I3(\q_reg[62]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[62]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69960000)) 
    \q[62]_i_4 
       (.I0(\q[62]_i_9_n_0 ),
        .I1(\q_reg[62]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[62]_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[62]_i_10_n_0 ),
        .O(\q[62]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[62]_i_5 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[65]_1 ),
        .O(\q[62]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF00F8F8F8F8)) 
    \q[62]_i_6 
       (.I0(\q_reg[66]_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q[64]_i_5_n_0 ),
        .I3(\q[58]_i_10_n_0 ),
        .I4(\q[58]_i_11_n_0 ),
        .I5(\q[70]_i_14_n_0 ),
        .O(\q[62]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[62]_i_7 
       (.I0(\q_reg_n_0_[22] ),
        .I1(Q[32]),
        .I2(\q[62]_i_11_n_0 ),
        .O(\q_reg[62]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[62]_i_8 
       (.I0(r_Imm_ex[22]),
        .I1(\q[62]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[62]_1 ));
  LUT6 #(
    .INIT(64'h070110701F7FF7F1)) 
    \q[62]_i_9 
       (.I0(\q[60]_i_8_n_0 ),
        .I1(\q_reg[60]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[60]_1 ),
        .I4(\q_reg[61]_0 ),
        .I5(\q_reg[61]_1 ),
        .O(\q[62]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[63]_i_10 
       (.I0(Q[23]),
        .I1(\q_reg[62]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[24]),
        .I4(\q_reg[41]_0 ),
        .O(\q[63]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[63]_i_11 
       (.I0(r_rs1Data_ex[23]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[24]),
        .I4(\q_reg[62]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[63]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hA9A99AAA56566555)) 
    \q[63]_i_12 
       (.I0(\q_reg[63]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[63]_1 ),
        .O(\q[63]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[63]_i_13 
       (.I0(\q_reg[62]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[63]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[63]_i_14 
       (.I0(\q[64]_i_6_n_0 ),
        .I1(\q[63]_i_15_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[63]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(\q[64]_i_20_n_0 ),
        .O(\q[63]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h888BBBBBB8BBBBBB)) 
    \q[63]_i_15 
       (.I0(\q[63]_i_17_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q_reg[68]_1 ),
        .I4(\q[70]_i_13_n_0 ),
        .I5(\q_reg[65]_0 ),
        .O(\q[63]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[63]_i_16 
       (.I0(\q[67]_i_17_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[63]_i_18_n_0 ),
        .I3(\q[69]_i_17_n_0 ),
        .I4(\q[65]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[63]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h303F5F5FFFFFFFFF)) 
    \q[63]_i_17 
       (.I0(\q_reg[70]_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q_reg[67]_0 ),
        .I4(\q[48]_i_8_n_0 ),
        .I5(\q[44]_i_9_n_0 ),
        .O(\q[63]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h3F305F5F)) 
    \q[63]_i_18 
       (.I0(ALU_A[0]),
        .I1(\q_reg[56]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[48]_i_9_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[63]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h1F1F1F1111111F11)) 
    \q[63]_i_1__0 
       (.I0(\q[63]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[63]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[64]_i_2_n_0 ),
        .O(\q_reg[71]_0 [33]));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[63]_i_2 
       (.I0(\q_reg[63]_1 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[63]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[63]_i_7_n_0 ),
        .O(\q[63]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[63]_i_3 
       (.I0(\q[63]_i_8_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[63]_i_9_n_0 ),
        .O(\q[63]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[63]_i_4 
       (.I0(r_Imm_ex[23]),
        .I1(\q[63]_i_10_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[63]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[63]_i_5 
       (.I0(\q_reg_n_0_[23] ),
        .I1(Q[32]),
        .I2(\q[63]_i_11_n_0 ),
        .O(\q_reg[63]_0 ));
  LUT6 #(
    .INIT(64'h4B0FF04B780FF078)) 
    \q[63]_i_6 
       (.I0(\q[64]_i_13_n_0 ),
        .I1(\q[60]_i_8_n_0 ),
        .I2(\q[63]_i_12_n_0 ),
        .I3(\q_reg[62]_0 ),
        .I4(\q[63]_i_13_n_0 ),
        .I5(\q[64]_i_15_n_0 ),
        .O(\q[63]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[63]_i_7 
       (.I0(\q[63]_i_14_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[63]_1 ),
        .I4(\q_reg[63]_0 ),
        .O(\q[63]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFB8000000)) 
    \q[63]_i_8 
       (.I0(\q_reg[63]_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[67]_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[64]_i_5_n_0 ),
        .O(\q[63]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hFEAABAAA)) 
    \q[63]_i_9 
       (.I0(\q[64]_i_5_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[68]_1 ),
        .I3(\q[70]_i_13_n_0 ),
        .I4(\q_reg[65]_0 ),
        .O(\q[63]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h5404FFFF54045404)) 
    \q[64]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[64]_i_2_n_0 ),
        .I2(ALU_B),
        .I3(\q[65]_i_3_n_0 ),
        .I4(\q[64]_i_3_n_0 ),
        .I5(\q[64]_i_4_n_0 ),
        .O(\q_reg[71]_0 [34]));
  LUT6 #(
    .INIT(64'h77744477CCCCCCCC)) 
    \q[64]_i_10 
       (.I0(\q[64]_i_17_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[64]_0 ),
        .I4(\q_reg[64]_1 ),
        .I5(r_ALUCode_ex[2]),
        .O(\q[64]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[64]_i_11 
       (.I0(\q_reg[63]_2 ),
        .I1(Q[32]),
        .I2(D[25]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[24]),
        .O(\q[64]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[64]_i_12 
       (.I0(Q[24]),
        .I1(\q_reg[63]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[25]),
        .I4(\q_reg[41]_0 ),
        .O(\q[64]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h040257AE)) 
    \q[64]_i_13 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\q_reg[60]_1 ),
        .I2(\q_reg[60]_0 ),
        .I3(\q_reg[61]_0 ),
        .I4(\q_reg[61]_1 ),
        .O(\q[64]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h00EB)) 
    \q[64]_i_14 
       (.I0(\q_reg[63]_0 ),
        .I1(\q_reg[63]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[64]_i_18_n_0 ),
        .O(\q[64]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h314C7FFD)) 
    \q[64]_i_15 
       (.I0(\q_reg[60]_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[60]_1 ),
        .I3(\q_reg[61]_0 ),
        .I4(\q_reg[61]_1 ),
        .O(\q[64]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'hEB82)) 
    \q[64]_i_16 
       (.I0(\q[64]_i_19_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[63]_1 ),
        .I3(\q_reg[63]_0 ),
        .O(\q[64]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hC5FFC5F0C50FC500)) 
    \q[64]_i_17 
       (.I0(\q[64]_i_6_n_0 ),
        .I1(\q[65]_i_14_n_0 ),
        .I2(ALU_B),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[65]_i_15_n_0 ),
        .I5(\q[64]_i_20_n_0 ),
        .O(\q[64]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEBF1140)) 
    \q[64]_i_18 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[62]_1 ),
        .I5(\q_reg[62]_0 ),
        .O(\q[64]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h02022000A8A88AAA)) 
    \q[64]_i_19 
       (.I0(\q_reg[62]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[62]_1 ),
        .O(\q[64]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[64]_i_2 
       (.I0(\q[64]_i_5_n_0 ),
        .I1(\q[64]_i_6_n_0 ),
        .O(\q[64]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[64]_i_20 
       (.I0(\q[68]_i_11_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[64]_i_21_n_0 ),
        .I3(\q[70]_i_39_n_0 ),
        .I4(\q[66]_i_15_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[64]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'h5F50CFCF)) 
    \q[64]_i_21 
       (.I0(\q_reg[57]_0 ),
        .I1(\q[41]_i_11_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[49]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[64]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[64]_i_3 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[64]_1 ),
        .I3(\q_reg[64]_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[64]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69960000)) 
    \q[64]_i_4 
       (.I0(\q[64]_i_9_n_0 ),
        .I1(\q_reg[64]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[64]_1 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[64]_i_10_n_0 ),
        .O(\q[64]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[64]_i_5 
       (.I0(\q_reg[70]_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .O(\q[64]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB080FFFFB0800000)) 
    \q[64]_i_6 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[65]_1 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[65]_i_10_n_0 ),
        .O(\q[64]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[64]_i_7 
       (.I0(\q_reg_n_0_[24] ),
        .I1(Q[32]),
        .I2(\q[64]_i_11_n_0 ),
        .O(\q_reg[64]_1 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[64]_i_8 
       (.I0(r_Imm_ex[23]),
        .I1(\q[64]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[64]_0 ));
  LUT5 #(
    .INIT(32'h0000BF8F)) 
    \q[64]_i_9 
       (.I0(\q[64]_i_13_n_0 ),
        .I1(\q[60]_i_8_n_0 ),
        .I2(\q[64]_i_14_n_0 ),
        .I3(\q[64]_i_15_n_0 ),
        .I4(\q[64]_i_16_n_0 ),
        .O(\q[64]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F1F1F1111111F11)) 
    \q[65]_i_1 
       (.I0(\q[65]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[65]_i_3_n_0 ),
        .I4(ALU_B),
        .I5(\q[65]_i_4_n_0 ),
        .O(\q_reg[71]_0 [35]));
  LUT4 #(
    .INIT(16'hB080)) 
    \q[65]_i_10 
       (.I0(\q_reg[66]_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[69]_0 ),
        .O(\q[65]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[65]_i_11 
       (.I0(Q[25]),
        .I1(\q_reg[64]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[26]),
        .I4(\q_reg[41]_0 ),
        .O(\q[65]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[65]_i_12 
       (.I0(r_rs1Data_ex[25]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[26]),
        .I4(\q_reg[64]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[65]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[65]_i_13 
       (.I0(\q[66]_i_13_n_0 ),
        .I1(\q[65]_i_14_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[65]_i_15_n_0 ),
        .I4(ALU_B),
        .I5(\q[66]_i_14_n_0 ),
        .O(\q[65]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h4744477777777777)) 
    \q[65]_i_14 
       (.I0(\q[65]_i_9_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q_reg[67]_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q_reg[70]_0 ),
        .I5(\q[70]_i_13_n_0 ),
        .O(\q[65]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[65]_i_15 
       (.I0(\q[71]_i_22_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[67]_i_17_n_0 ),
        .I3(\q[69]_i_17_n_0 ),
        .I4(\q[65]_i_16_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[65]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h5F50CFCF)) 
    \q[65]_i_16 
       (.I0(\q_reg[58]_1 ),
        .I1(\q[42]_i_6_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[50]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[65]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[65]_i_2 
       (.I0(\q_reg[65]_2 ),
        .I1(\q_reg[65]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[65]_i_7_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[65]_i_8_n_0 ),
        .O(\q[65]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFBBFFB8888888)) 
    \q[65]_i_3 
       (.I0(\q[65]_i_9_n_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q_reg[67]_0 ),
        .I3(\q[70]_i_13_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .I5(\q_reg[70]_0 ),
        .O(\q[65]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFD8F000F0D8F0)) 
    \q[65]_i_4 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q_reg[65]_1 ),
        .I2(\q_reg[70]_0 ),
        .I3(\q[70]_i_13_n_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q[65]_i_10_n_0 ),
        .O(\q[65]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[65]_i_5 
       (.I0(r_Imm_ex[25]),
        .I1(\q[65]_i_11_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[65]_2 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[65]_i_6 
       (.I0(\q_reg_n_0_[25] ),
        .I1(Q[32]),
        .I2(\q[65]_i_12_n_0 ),
        .O(\q_reg[65]_0 ));
  LUT6 #(
    .INIT(64'h2BD44DB2D42BB24D)) 
    \q[65]_i_7 
       (.I0(\q[64]_i_9_n_0 ),
        .I1(\q_reg[64]_1 ),
        .I2(\q_reg[64]_0 ),
        .I3(\q_reg[65]_2 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[65]_0 ),
        .O(\q[65]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[65]_i_8 
       (.I0(\q[65]_i_13_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[65]_2 ),
        .I4(\q_reg[65]_0 ),
        .O(\q[65]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h88C0)) 
    \q[65]_i_9 
       (.I0(\q_reg[65]_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q_reg[68]_1 ),
        .I3(\q[70]_i_14_n_0 ),
        .O(\q[65]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF000004F7)) 
    \q[66]_i_1 
       (.I0(\q[66]_i_2_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[66]_i_3_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[66]_i_4_n_0 ),
        .O(\q_reg[71]_0 [36]));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[66]_i_10 
       (.I0(Q[26]),
        .I1(\q_reg[65]_3 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[27]),
        .I4(\q_reg[41]_0 ),
        .O(\q[66]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[66]_i_11 
       (.I0(r_rs1Data_ex[26]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[27]),
        .I4(\q_reg[65]_3 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[66]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[66]_i_12 
       (.I0(\q[67]_i_15_n_0 ),
        .I1(\q[66]_i_13_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[66]_i_14_n_0 ),
        .I4(ALU_B),
        .I5(\q[67]_i_16_n_0 ),
        .O(\q[66]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h30FF3FFF5FFF5FFF)) 
    \q[66]_i_13 
       (.I0(\q_reg[65]_1 ),
        .I1(\q_reg[66]_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q[70]_i_13_n_0 ),
        .I4(\q_reg[69]_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[66]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[66]_i_14 
       (.I0(\q[71]_i_26_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[68]_i_11_n_0 ),
        .I3(\q[70]_i_39_n_0 ),
        .I4(\q[66]_i_15_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[66]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h5F50CFCF)) 
    \q[66]_i_15 
       (.I0(\q_reg[59]_0 ),
        .I1(\q[43]_i_5_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[51]_i_6_n_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[66]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hFF00FFEA)) 
    \q[66]_i_2 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[66]_1 ),
        .I4(\q_reg[66]_0 ),
        .O(\q[66]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h9669FFFF96690000)) 
    \q[66]_i_3 
       (.I0(\q_reg[66]_1 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[66]_0 ),
        .I3(\q[66]_i_8_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[66]_i_9_n_0 ),
        .O(\q[66]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000B800000000)) 
    \q[66]_i_4 
       (.I0(\q[67]_i_3_n_0 ),
        .I1(ALU_B),
        .I2(\q[65]_i_4_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[3]),
        .O(\q[66]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[66]_i_5 
       (.I0(r_Imm_ex[26]),
        .I1(\q[66]_i_10_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[66]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[66]_i_6 
       (.I0(\q_reg_n_0_[26] ),
        .I1(Q[32]),
        .I2(\q[66]_i_11_n_0 ),
        .O(\q_reg[66]_0 ));
  LUT4 #(
    .INIT(16'h1140)) 
    \q[66]_i_7 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .O(\q[66]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h2032088C3BBFECFE)) 
    \q[66]_i_8 
       (.I0(\q[64]_i_9_n_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[64]_0 ),
        .I3(\q_reg[64]_1 ),
        .I4(\q_reg[65]_2 ),
        .I5(\q_reg[65]_0 ),
        .O(\q[66]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[66]_i_9 
       (.I0(\q[66]_i_12_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[66]_1 ),
        .I4(\q_reg[66]_0 ),
        .O(\q[66]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h1F111F1F1F111111)) 
    \q[67]_i_1 
       (.I0(\q[67]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[70]_i_2_n_0 ),
        .I3(\q[68]_i_2_n_0 ),
        .I4(ALU_B),
        .I5(\q[67]_i_3_n_0 ),
        .O(\q_reg[71]_0 [37]));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[67]_i_10 
       (.I0(\q_reg[67]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[67]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h00EB)) 
    \q[67]_i_11 
       (.I0(\q_reg[66]_0 ),
        .I1(\q_reg[66]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[70]_i_36_n_0 ),
        .O(\q[67]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h02022000A8A88AAA)) 
    \q[67]_i_12 
       (.I0(\q_reg[66]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[66]_1 ),
        .O(\q[67]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h00EB)) 
    \q[67]_i_13 
       (.I0(\q_reg[66]_0 ),
        .I1(\q_reg[66]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[70]_i_35_n_0 ),
        .O(\q[67]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[67]_i_14 
       (.I0(\q[68]_i_9_n_0 ),
        .I1(\q[67]_i_15_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[67]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(\q[68]_i_10_n_0 ),
        .O(\q[67]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h503FFFFF5F3FFFFF)) 
    \q[67]_i_15 
       (.I0(\q_reg[67]_0 ),
        .I1(\q_reg[70]_0 ),
        .I2(\q_reg[51]_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[70]_i_13_n_0 ),
        .I5(\q_reg[68]_1 ),
        .O(\q[67]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[67]_i_16 
       (.I0(\q[71]_i_22_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[67]_i_17_n_0 ),
        .I3(\q[71]_i_24_n_0 ),
        .I4(\q[69]_i_17_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[67]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h303F5F5F)) 
    \q[67]_i_17 
       (.I0(ALU_A[4]),
        .I1(\q_reg[60]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[52]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[67]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[67]_i_2 
       (.I0(\q_reg[67]_1 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[67]_i_6_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[67]_i_7_n_0 ),
        .O(\q[67]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBF0F0F088F0F0F0)) 
    \q[67]_i_3 
       (.I0(\q_reg[67]_0 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q_reg[70]_0 ),
        .I3(\q[70]_i_14_n_0 ),
        .I4(\q[70]_i_13_n_0 ),
        .I5(\q_reg[68]_1 ),
        .O(\q[67]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[67]_i_4 
       (.I0(r_Imm_ex[27]),
        .I1(\q[67]_i_8_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[67]_1 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[67]_i_5 
       (.I0(\q_reg_n_0_[27] ),
        .I1(Q[32]),
        .I2(\q[67]_i_9_n_0 ),
        .O(\q_reg[67]_0 ));
  LUT6 #(
    .INIT(64'h9999999699669996)) 
    \q[67]_i_6 
       (.I0(\q[67]_i_10_n_0 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[67]_i_11_n_0 ),
        .I3(\q[67]_i_12_n_0 ),
        .I4(\q[64]_i_9_n_0 ),
        .I5(\q[67]_i_13_n_0 ),
        .O(\q[67]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h88B88BB8)) 
    \q[67]_i_7 
       (.I0(\q[67]_i_14_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(\q_reg[67]_1 ),
        .I3(\q_reg[67]_0 ),
        .I4(r_ALUCode_ex[0]),
        .O(\q[67]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[67]_i_8 
       (.I0(Q[27]),
        .I1(\q_reg[66]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[28]),
        .I4(\q_reg[41]_0 ),
        .O(\q[67]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[67]_i_9 
       (.I0(\q_reg[66]_2 ),
        .I1(Q[32]),
        .I2(D[28]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[27]),
        .O(\q[67]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h540454045404FFFF)) 
    \q[68]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[68]_i_2_n_0 ),
        .I2(ALU_B),
        .I3(\q[69]_i_2_n_0 ),
        .I4(\q[68]_i_3_n_0 ),
        .I5(r_ALUCode_ex[3]),
        .O(\q_reg[71]_0 [38]));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[68]_i_10 
       (.I0(\q[71]_i_26_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[68]_i_11_n_0 ),
        .I3(\q[71]_i_28_n_0 ),
        .I4(\q[70]_i_39_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[68]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h50CF5FCF)) 
    \q[68]_i_11 
       (.I0(\q_reg[61]_1 ),
        .I1(\q[45]_i_9_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q_reg[53]_0 ),
        .O(\q[68]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hEAEAEA2A2A2AEA2A)) 
    \q[68]_i_2 
       (.I0(\q_reg[70]_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[69]_0 ),
        .I4(\q_reg[51]_0 ),
        .I5(\q_reg[65]_1 ),
        .O(\q[68]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[68]_i_3 
       (.I0(\q_reg[68]_0 ),
        .I1(\q_reg[65]_1 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[68]_i_5_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[68]_i_6_n_0 ),
        .O(\q[68]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[68]_i_4 
       (.I0(r_Imm_ex[27]),
        .I1(\q[68]_i_7_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[68]_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \q[68]_i_5 
       (.I0(\q[70]_i_18_n_0 ),
        .I1(\q_reg[68]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q_reg[65]_1 ),
        .O(\q[68]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h888BBB88)) 
    \q[68]_i_6 
       (.I0(\q[68]_i_8_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q_reg[68]_0 ),
        .I4(\q_reg[65]_1 ),
        .O(\q[68]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[68]_i_7 
       (.I0(Q[28]),
        .I1(\q_reg[67]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[29]),
        .I4(\q_reg[41]_0 ),
        .O(\q[68]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA03F3FAFA03030)) 
    \q[68]_i_8 
       (.I0(\q[69]_i_15_n_0 ),
        .I1(\q[68]_i_9_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[68]_i_10_n_0 ),
        .I4(ALU_B),
        .I5(\q[69]_i_16_n_0 ),
        .O(\q[68]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hB8000000)) 
    \q[68]_i_9 
       (.I0(\q_reg[65]_1 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q_reg[69]_0 ),
        .I3(\q[70]_i_13_n_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .O(\q[68]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h5404FFFF54045404)) 
    \q[69]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q[69]_i_2_n_0 ),
        .I2(ALU_B),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q[69]_i_3_n_0 ),
        .I5(\q[69]_i_4_n_0 ),
        .O(\q_reg[71]_0 [39]));
  LUT6 #(
    .INIT(64'h77477447CCCCCCCC)) 
    \q[69]_i_10 
       (.I0(\q[69]_i_14_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(\q_reg[69]_1 ),
        .I3(\q_reg[68]_1 ),
        .I4(r_ALUCode_ex[0]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[69]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[69]_i_11 
       (.I0(r_rs1Data_ex[29]),
        .I1(Q[32]),
        .I2(\q_reg[46]_1 ),
        .I3(D[30]),
        .I4(\q_reg[68]_2 ),
        .I5(\q[71]_i_13_n_0 ),
        .O(\q[69]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[69]_i_12 
       (.I0(Q[29]),
        .I1(\q_reg[68]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[30]),
        .I4(\q_reg[41]_0 ),
        .O(\q[69]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[69]_i_13 
       (.I0(\q_reg[67]_2 ),
        .I1(Q[32]),
        .I2(D[29]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[28]),
        .O(\q[69]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[69]_i_14 
       (.I0(\q[70]_i_38_n_0 ),
        .I1(\q[69]_i_15_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[69]_i_16_n_0 ),
        .I4(ALU_B),
        .I5(\q[70]_i_37_n_0 ),
        .O(\q[69]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h4F7FFFFF)) 
    \q[69]_i_15 
       (.I0(\q_reg[68]_1 ),
        .I1(\q_reg[51]_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[70]_0 ),
        .I4(\q[70]_i_14_n_0 ),
        .O(\q[69]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[69]_i_16 
       (.I0(\q[71]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[71]_i_22_n_0 ),
        .I3(\q[71]_i_24_n_0 ),
        .I4(\q[69]_i_17_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[69]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h350F35FF)) 
    \q[69]_i_17 
       (.I0(ALU_A[6]),
        .I1(\q_reg[62]_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q[48]_i_8_n_0 ),
        .I4(\q_reg[54]_0 ),
        .O(\q[69]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hF7FF8000)) 
    \q[69]_i_2 
       (.I0(\q[70]_i_14_n_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q_reg[68]_1 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q_reg[70]_0 ),
        .O(\q[69]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[69]_i_3 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[68]_1 ),
        .I3(\q_reg[69]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[69]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFB24D0000)) 
    \q[69]_i_4 
       (.I0(\q[70]_i_18_n_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q_reg[65]_1 ),
        .I3(\q[69]_i_9_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[69]_i_10_n_0 ),
        .O(\q[69]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[69]_i_5 
       (.I0(\q_reg_n_0_[29] ),
        .I1(Q[32]),
        .I2(\q[69]_i_11_n_0 ),
        .O(\q_reg[68]_1 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[69]_i_6 
       (.I0(r_Imm_ex[27]),
        .I1(\q[69]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[69]_1 ));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[69]_i_7 
       (.I0(\q_reg[68]_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[69]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[69]_i_8 
       (.I0(\q_reg_n_0_[28] ),
        .I1(Q[32]),
        .I2(\q[69]_i_13_n_0 ),
        .O(\q_reg[65]_1 ));
  LUT6 #(
    .INIT(64'h56566555A9A99AAA)) 
    \q[69]_i_9 
       (.I0(\q_reg[68]_1 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[69]_1 ),
        .O(\q[69]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h4540FFFF45404540)) 
    \q[70]_i_1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q_reg[70]_0 ),
        .I2(ALU_B),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q[70]_i_5_n_0 ),
        .I5(\q[70]_i_6_n_0 ),
        .O(\q_reg[71]_0 [40]));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[70]_i_12 
       (.I0(\q_reg_n_0_[30] ),
        .I1(Q[32]),
        .I2(\q[70]_i_22_n_0 ),
        .O(\q_reg[69]_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[70]_i_13 
       (.I0(\q[48]_i_8_n_0 ),
        .I1(\q[44]_i_9_n_0 ),
        .O(\q[70]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF000B0000)) 
    \q[70]_i_14 
       (.I0(\q_reg[6]_0 ),
        .I1(r_rs2Data_ex[2]),
        .I2(\q_reg[41]_1 ),
        .I3(\q_reg[42]_3 ),
        .I4(\q[70]_i_8_n_0 ),
        .I5(\q[70]_i_25_n_0 ),
        .O(\q[70]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h0000005155555555)) 
    \q[70]_i_15 
       (.I0(\q[70]_i_26_n_0 ),
        .I1(Q[2]),
        .I2(\q_reg[6]_0 ),
        .I3(\q_reg[40]_0 ),
        .I4(\q_reg[41]_3 ),
        .I5(\q[70]_i_8_n_0 ),
        .O(\q_reg[51]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[70]_i_16 
       (.I0(r_Imm_ex[30]),
        .I1(\q[70]_i_29_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[70]_1 ));
  LUT5 #(
    .INIT(32'h040257AE)) 
    \q[70]_i_17 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\q_reg[68]_0 ),
        .I2(\q_reg[65]_1 ),
        .I3(\q_reg[69]_1 ),
        .I4(\q_reg[68]_1 ),
        .O(\q[70]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \q[70]_i_18 
       (.I0(\q[70]_i_30_n_0 ),
        .I1(\q[70]_i_31_n_0 ),
        .I2(\q[60]_i_8_n_0 ),
        .I3(\q[70]_i_32_n_0 ),
        .I4(\q[70]_i_33_n_0 ),
        .O(\q[70]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h314C7FFD)) 
    \q[70]_i_19 
       (.I0(\q_reg[65]_1 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[68]_0 ),
        .I3(\q_reg[69]_1 ),
        .I4(\q_reg[68]_1 ),
        .O(\q[70]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \q[70]_i_2 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .O(\q[70]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hA9A99AAA56566555)) 
    \q[70]_i_20 
       (.I0(\q_reg[69]_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q_reg[70]_1 ),
        .O(\q[70]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C4C4C7C4C7C7C)) 
    \q[70]_i_21 
       (.I0(\q[70]_i_34_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[69]_0 ),
        .I5(\q_reg[70]_1 ),
        .O(\q[70]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[70]_i_22 
       (.I0(\q_reg[69]_2 ),
        .I1(Q[32]),
        .I2(D[31]),
        .I3(\q_reg[46]_1 ),
        .I4(\q[71]_i_13_n_0 ),
        .I5(r_rs1Data_ex[30]),
        .O(\q[70]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[70]_i_25 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[2]),
        .O(\q[70]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[70]_i_26 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[1]),
        .O(\q[70]_i_26_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[70]_i_29 
       (.I0(Q[30]),
        .I1(\q_reg[69]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[31]),
        .I4(\q_reg[41]_0 ),
        .O(\q[70]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEEEEEAEAA)) 
    \q[70]_i_3 
       (.I0(\q[70]_i_7_n_0 ),
        .I1(\q[70]_i_8_n_0 ),
        .I2(\q_reg[6]_0 ),
        .I3(r_rs2Data_ex[0]),
        .I4(\q_reg[39]_0 ),
        .I5(\q_reg[40]_1 ),
        .O(ALU_B));
  LUT6 #(
    .INIT(64'hF2FB80E08FEF020B)) 
    \q[70]_i_30 
       (.I0(\q_reg[66]_0 ),
        .I1(\q_reg[66]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[70]_i_35_n_0 ),
        .I4(\q_reg[67]_0 ),
        .I5(\q_reg[67]_1 ),
        .O(\q[70]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h032BB2302B3FF3B2)) 
    \q[70]_i_31 
       (.I0(\q[64]_i_13_n_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q_reg[63]_1 ),
        .I3(\q_reg[62]_1 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[62]_0 ),
        .O(\q[70]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h032BB2302B3FF3B2)) 
    \q[70]_i_32 
       (.I0(\q[64]_i_15_n_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q_reg[63]_1 ),
        .I3(\q_reg[62]_1 ),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[62]_0 ),
        .O(\q[70]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hF2FB80E08FEF020B)) 
    \q[70]_i_33 
       (.I0(\q_reg[66]_0 ),
        .I1(\q_reg[66]_1 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[70]_i_36_n_0 ),
        .I4(\q_reg[67]_0 ),
        .I5(\q_reg[67]_1 ),
        .O(\q[70]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h3B38FBF80B08CBC8)) 
    \q[70]_i_34 
       (.I0(\q[70]_i_37_n_0 ),
        .I1(ALU_B),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[71]_i_15_n_0 ),
        .I4(\q[71]_i_14_n_0 ),
        .I5(\q[70]_i_38_n_0 ),
        .O(\q[70]_i_34_n_0 ));
  LUT5 #(
    .INIT(32'h314C7FFD)) 
    \q[70]_i_35 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(\q_reg[64]_0 ),
        .I3(\q_reg[65]_2 ),
        .I4(\q_reg[65]_0 ),
        .O(\q[70]_i_35_n_0 ));
  LUT5 #(
    .INIT(32'h040257AE)) 
    \q[70]_i_36 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\q_reg[64]_0 ),
        .I2(\q_reg[64]_1 ),
        .I3(\q_reg[65]_2 ),
        .I4(\q_reg[65]_0 ),
        .O(\q[70]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[70]_i_37 
       (.I0(\q[71]_i_25_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[71]_i_26_n_0 ),
        .I3(\q[71]_i_28_n_0 ),
        .I4(\q[70]_i_39_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[70]_i_37_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \q[70]_i_38 
       (.I0(\q_reg[51]_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(\q_reg[69]_0 ),
        .O(\q[70]_i_38_n_0 ));
  LUT5 #(
    .INIT(32'h505FCFCF)) 
    \q[70]_i_39 
       (.I0(\q_reg[63]_0 ),
        .I1(\q[47]_i_7_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[55]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .O(\q[70]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hBFFF8000)) 
    \q[70]_i_4 
       (.I0(\q_reg[69]_0 ),
        .I1(\q[70]_i_13_n_0 ),
        .I2(\q[70]_i_14_n_0 ),
        .I3(\q_reg[51]_0 ),
        .I4(\q_reg[70]_0 ),
        .O(\q[70]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[70]_i_5 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[69]_0 ),
        .I3(\q_reg[70]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[70]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFB8470000)) 
    \q[70]_i_6 
       (.I0(\q[70]_i_17_n_0 ),
        .I1(\q[70]_i_18_n_0 ),
        .I2(\q[70]_i_19_n_0 ),
        .I3(\q[70]_i_20_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[70]_i_21_n_0 ),
        .O(\q[70]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[70]_i_7 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[0]),
        .O(\q[70]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[70]_i_8 
       (.I0(r_ALUSrcB_ex[1]),
        .I1(r_ALUSrcB_ex[0]),
        .O(\q[70]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h03550055)) 
    \q[71]_i_1 
       (.I0(\q[71]_i_2_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(\q_reg[70]_0 ),
        .O(\q_reg[71]_0 [41]));
  LUT5 #(
    .INIT(32'hAAAA9A66)) 
    \q[71]_i_10 
       (.I0(\q_reg[70]_1 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[71]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFC77FC44)) 
    \q[71]_i_11 
       (.I0(\q[71]_i_14_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(\q[71]_i_15_n_0 ),
        .I3(ALU_B),
        .I4(\q[71]_i_16_n_0 ),
        .O(\q[71]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFF4)) 
    \q[71]_i_13 
       (.I0(\q_reg[46]_3 ),
        .I1(\q_reg[42]_0 ),
        .I2(\q_reg[46]_4 ),
        .I3(\q_reg[42]_1 ),
        .I4(\q_reg[2]_0 ),
        .O(\q[71]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \q[71]_i_14 
       (.I0(\q_reg[51]_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q_reg[70]_0 ),
        .I3(\q[70]_i_13_n_0 ),
        .O(\q[71]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[71]_i_15 
       (.I0(\q[71]_i_21_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[71]_i_22_n_0 ),
        .I3(\q[71]_i_23_n_0 ),
        .I4(\q[71]_i_24_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[71]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[71]_i_16 
       (.I0(\q[71]_i_25_n_0 ),
        .I1(\q[70]_i_14_n_0 ),
        .I2(\q[71]_i_26_n_0 ),
        .I3(\q[71]_i_27_n_0 ),
        .I4(\q[71]_i_28_n_0 ),
        .I5(\q_reg[51]_0 ),
        .O(\q[71]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \q[71]_i_17 
       (.I0(r_rs1Addr_ex[2]),
        .I1(D[2]),
        .I2(D[0]),
        .I3(r_rs1Addr_ex[0]),
        .I4(D[1]),
        .I5(r_rs1Addr_ex[1]),
        .O(\q_reg[42]_0 ));
  LUT6 #(
    .INIT(64'hAFA0BFBFAFA0B0B0)) 
    \q[71]_i_2 
       (.I0(\q_reg[40] ),
        .I1(\q_reg[70]_0 ),
        .I2(\q[44]_i_6_n_0 ),
        .I3(\q[71]_i_5_n_0 ),
        .I4(\q[44]_i_4_n_0 ),
        .I5(\q[71]_i_6_n_0 ),
        .O(\q[71]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[71]_i_20 
       (.I0(r_rs1Addr_ex[2]),
        .I1(\q_reg[2]_2 [2]),
        .I2(\q_reg[2]_2 [0]),
        .I3(r_rs1Addr_ex[0]),
        .I4(\q_reg[2]_2 [1]),
        .I5(r_rs1Addr_ex[1]),
        .O(\q_reg[42]_1 ));
  LUT6 #(
    .INIT(64'h30303F3F505F505F)) 
    \q[71]_i_21 
       (.I0(\q_reg[52]_0 ),
        .I1(\q_reg[65]_1 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(ALU_A[4]),
        .I4(\q_reg[60]_0 ),
        .I5(\q[44]_i_9_n_0 ),
        .O(\q[71]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h50505F5FC0CFC0CF)) 
    \q[71]_i_22 
       (.I0(\q_reg[64]_1 ),
        .I1(\q[48]_i_9_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(ALU_A[0]),
        .I4(\q_reg[56]_0 ),
        .I5(\q[44]_i_9_n_0 ),
        .O(\q[71]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h00F00FFF35353535)) 
    \q[71]_i_23 
       (.I0(ALU_A[6]),
        .I1(\q_reg[62]_0 ),
        .I2(\q[44]_i_9_n_0 ),
        .I3(\q_reg[69]_0 ),
        .I4(\q_reg[54]_0 ),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[71]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h505FCFCF505FC0C0)) 
    \q[71]_i_24 
       (.I0(\q_reg[66]_0 ),
        .I1(\q[50]_i_6_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[58]_1 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[42]_i_6_n_0 ),
        .O(\q[71]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h505F3F3F505F3030)) 
    \q[71]_i_25 
       (.I0(\q_reg[68]_1 ),
        .I1(\q_reg[53]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[61]_1 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[45]_i_9_n_0 ),
        .O(\q[71]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h303FAFAF303FA0A0)) 
    \q[71]_i_26 
       (.I0(\q[49]_i_6_n_0 ),
        .I1(\q_reg[65]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[57]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[41]_i_11_n_0 ),
        .O(\q[71]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h505F3F3F505F3030)) 
    \q[71]_i_27 
       (.I0(\q_reg[70]_0 ),
        .I1(\q_reg[55]_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[63]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[47]_i_7_n_0 ),
        .O(\q[71]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'h505FCFCF505FC0C0)) 
    \q[71]_i_28 
       (.I0(\q_reg[67]_0 ),
        .I1(\q[51]_i_6_n_0 ),
        .I2(\q[48]_i_8_n_0 ),
        .I3(\q_reg[59]_0 ),
        .I4(\q[44]_i_9_n_0 ),
        .I5(\q[43]_i_5_n_0 ),
        .O(\q[71]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[71]_i_3 
       (.I0(\q_reg_n_0_[31] ),
        .I1(Q[32]),
        .I2(\q[71]_i_7_n_0 ),
        .O(\q_reg[70]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[71]_i_4 
       (.I0(r_Imm_ex[27]),
        .I1(\q[71]_i_8_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[40] ));
  LUT6 #(
    .INIT(64'h4BF00F4B78F00F78)) 
    \q[71]_i_5 
       (.I0(\q[70]_i_17_n_0 ),
        .I1(\q[70]_i_18_n_0 ),
        .I2(\q[71]_i_9_n_0 ),
        .I3(\q[71]_i_10_n_0 ),
        .I4(\q_reg[69]_0 ),
        .I5(\q[70]_i_19_n_0 ),
        .O(\q[71]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h8B8B88B8)) 
    \q[71]_i_6 
       (.I0(\q[71]_i_11_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(\q_reg[70]_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[40] ),
        .O(\q[71]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[71]_i_7 
       (.I0(r_rs1Data_ex[31]),
        .I1(D[32]),
        .I2(\q_reg[46]_1 ),
        .I3(\q_reg[70]_2 ),
        .I4(\q[71]_i_13_n_0 ),
        .O(\q[71]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[71]_i_8 
       (.I0(Q[31]),
        .I1(\q_reg[70]_2 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[32]),
        .I4(\q_reg[41]_0 ),
        .O(\q[71]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFB5004A004AFFB5)) 
    \q[71]_i_9 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q_reg[70]_0 ),
        .I5(\q_reg[40] ),
        .O(\q[71]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[8]_i_1 
       (.I0(r_rs2Data_ex[0]),
        .I1(\q_reg[39]_1 ),
        .I2(\q_reg[10]_0 ),
        .I3(D[3]),
        .I4(\q_reg[41]_0 ),
        .O(\q_reg[71]_0 [8]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [0]),
        .Q(\q_reg_n_0_[0] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[100] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [98]),
        .Q(r_rs1Data_ex[21]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[101] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [99]),
        .Q(r_rs1Data_ex[22]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[102] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [100]),
        .Q(r_rs1Data_ex[23]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[103] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [101]),
        .Q(r_rs1Data_ex[24]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[104] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [102]),
        .Q(r_rs1Data_ex[25]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[105] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [103]),
        .Q(r_rs1Data_ex[26]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[106] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [104]),
        .Q(r_rs1Data_ex[27]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[107] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [105]),
        .Q(r_rs1Data_ex[28]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[108] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [106]),
        .Q(r_rs1Data_ex[29]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[109] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [107]),
        .Q(r_rs1Data_ex[30]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [10]),
        .Q(\q_reg_n_0_[10] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[110] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [108]),
        .Q(r_rs1Data_ex[31]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[111] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [109]),
        .Q(r_Imm_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[112] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [110]),
        .Q(r_Imm_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[113] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [111]),
        .Q(r_Imm_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[114] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [112]),
        .Q(r_Imm_ex[3]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[115] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [113]),
        .Q(r_Imm_ex[4]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[116] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [114]),
        .Q(r_Imm_ex[5]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[117] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [115]),
        .Q(r_Imm_ex[6]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[118] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [116]),
        .Q(r_Imm_ex[7]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [11]),
        .Q(\q_reg_n_0_[11] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[121] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [117]),
        .Q(r_Imm_ex[10]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[123] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [118]),
        .Q(r_Imm_ex[12]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[124] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [119]),
        .Q(r_Imm_ex[13]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[125] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [120]),
        .Q(r_Imm_ex[14]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[126] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [121]),
        .Q(r_Imm_ex[15]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[127] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [122]),
        .Q(r_Imm_ex[16]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[128] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [123]),
        .Q(r_Imm_ex[17]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [12]),
        .Q(\q_reg_n_0_[12] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[130] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [124]),
        .Q(r_Imm_ex[19]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[131] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [125]),
        .Q(r_Imm_ex[20]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[132] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [126]),
        .Q(r_Imm_ex[21]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[133] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [127]),
        .Q(r_Imm_ex[22]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[134] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [128]),
        .Q(r_Imm_ex[23]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[136] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [129]),
        .Q(r_Imm_ex[25]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[137] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [130]),
        .Q(r_Imm_ex[26]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[138] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [131]),
        .Q(r_Imm_ex[27]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [13]),
        .Q(\q_reg_n_0_[13] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[141] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [132]),
        .Q(r_Imm_ex[30]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[143] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [133]),
        .Q(r_ALUSrcB_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[144] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [134]),
        .Q(r_ALUSrcB_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[145] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [135]),
        .Q(Q[32]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[146] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [136]),
        .Q(r_ALUCode_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[147] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [137]),
        .Q(r_ALUCode_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[148] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [138]),
        .Q(r_ALUCode_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[149] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [139]),
        .Q(r_ALUCode_ex[3]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [14]),
        .Q(\q_reg_n_0_[14] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[150] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [140]),
        .Q(\q_reg[71]_0 [5]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[151] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [141]),
        .Q(\q_reg[71]_0 [7]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[152] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [142]),
        .Q(\q_reg[71]_0 [6]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [15]),
        .Q(\q_reg_n_0_[15] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [16]),
        .Q(\q_reg_n_0_[16] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [17]),
        .Q(\q_reg_n_0_[17] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [18]),
        .Q(\q_reg_n_0_[18] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [19]),
        .Q(\q_reg_n_0_[19] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [1]),
        .Q(\q_reg_n_0_[1] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [20]),
        .Q(\q_reg_n_0_[20] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [21]),
        .Q(\q_reg_n_0_[21] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [22]),
        .Q(\q_reg_n_0_[22] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [23]),
        .Q(\q_reg_n_0_[23] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [24]),
        .Q(\q_reg_n_0_[24] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [25]),
        .Q(\q_reg_n_0_[25] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [26]),
        .Q(\q_reg_n_0_[26] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [27]),
        .Q(\q_reg_n_0_[27] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [28]),
        .Q(\q_reg_n_0_[28] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [29]),
        .Q(\q_reg_n_0_[29] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [2]),
        .Q(\q_reg_n_0_[2] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [30]),
        .Q(\q_reg_n_0_[30] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [31]),
        .Q(\q_reg_n_0_[31] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [32]),
        .Q(\q_reg[71]_0 [0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [33]),
        .Q(\q_reg[71]_0 [1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [34]),
        .Q(\q_reg[71]_0 [2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [35]),
        .Q(\q_reg[71]_0 [3]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [36]),
        .Q(\q_reg[71]_0 [4]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [37]),
        .Q(r_rs2Addr_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [38]),
        .Q(r_rs2Addr_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [39]),
        .Q(r_rs2Addr_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [3]),
        .Q(\q_reg_n_0_[3] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [40]),
        .Q(Q[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [41]),
        .Q(r_rs1Addr_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [42]),
        .Q(r_rs1Addr_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [43]),
        .Q(r_rs1Addr_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [44]),
        .Q(Q[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [45]),
        .Q(r_rs2Data_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [46]),
        .Q(Q[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [47]),
        .Q(r_rs2Data_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [4]),
        .Q(\q_reg_n_0_[4] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [48]),
        .Q(Q[3]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [49]),
        .Q(Q[4]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [50]),
        .Q(Q[5]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [51]),
        .Q(Q[6]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [52]),
        .Q(Q[7]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [53]),
        .Q(Q[8]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [54]),
        .Q(Q[9]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [55]),
        .Q(Q[10]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [56]),
        .Q(Q[11]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [57]),
        .Q(Q[12]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [5]),
        .Q(\q_reg_n_0_[5] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [58]),
        .Q(Q[13]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [59]),
        .Q(Q[14]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [60]),
        .Q(Q[15]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [61]),
        .Q(Q[16]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [62]),
        .Q(Q[17]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [63]),
        .Q(Q[18]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [64]),
        .Q(Q[19]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [65]),
        .Q(Q[20]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [66]),
        .Q(Q[21]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [67]),
        .Q(Q[22]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [6]),
        .Q(\q_reg_n_0_[6] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [68]),
        .Q(Q[23]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[71] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [69]),
        .Q(Q[24]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[72] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [70]),
        .Q(Q[25]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[73] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [71]),
        .Q(Q[26]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[74] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [72]),
        .Q(Q[27]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[75] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [73]),
        .Q(Q[28]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[76] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [74]),
        .Q(Q[29]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[77] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [75]),
        .Q(Q[30]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[78] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [76]),
        .Q(Q[31]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[79] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [77]),
        .Q(r_rs1Data_ex[0]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [7]),
        .Q(\q_reg_n_0_[7] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[80] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [78]),
        .Q(r_rs1Data_ex[1]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[81] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [79]),
        .Q(r_rs1Data_ex[2]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[82] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [80]),
        .Q(r_rs1Data_ex[3]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[83] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [81]),
        .Q(r_rs1Data_ex[4]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[84] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [82]),
        .Q(r_rs1Data_ex[5]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[85] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [83]),
        .Q(r_rs1Data_ex[6]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[86] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [84]),
        .Q(r_rs1Data_ex[7]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[87] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [85]),
        .Q(r_rs1Data_ex[8]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[88] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [86]),
        .Q(r_rs1Data_ex[9]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[89] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [87]),
        .Q(r_rs1Data_ex[10]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [8]),
        .Q(\q_reg_n_0_[8] ),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[90] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [88]),
        .Q(r_rs1Data_ex[11]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[91] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [89]),
        .Q(r_rs1Data_ex[12]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[92] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [90]),
        .Q(r_rs1Data_ex[13]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[93] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [91]),
        .Q(r_rs1Data_ex[14]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[94] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [92]),
        .Q(r_rs1Data_ex[15]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[95] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [93]),
        .Q(r_rs1Data_ex[16]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[96] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [94]),
        .Q(r_rs1Data_ex[17]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[97] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [95]),
        .Q(r_rs1Data_ex[18]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[98] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [96]),
        .Q(r_rs1Data_ex[19]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[99] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [97]),
        .Q(r_rs1Data_ex[20]),
        .R(\q[152]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[2]_1 [9]),
        .Q(\q_reg_n_0_[9] ),
        .R(\q[152]_i_1_n_0 ));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized1
   (\q_reg[39]_0 ,
    Q,
    \q_reg[51]_0 ,
    \q_reg[10]_0 ,
    \q_reg[46]_0 ,
    \q_reg[46]_1 ,
    \q_reg[48]_0 ,
    \q_reg[44]_0 ,
    \q_reg[43]_0 ,
    \q_reg[53]_0 ,
    \q_reg[51]_1 ,
    \q_reg[51]_2 ,
    \q_reg[49]_0 ,
    \q_reg[48]_1 ,
    \q_reg[46]_2 ,
    \q_reg[45]_0 ,
    \q_reg[44]_1 ,
    \q_reg[43]_1 ,
    \q_reg[42]_0 ,
    \q_reg[70]_0 ,
    D,
    \q_reg[41]_0 ,
    \q_reg[70]_1 ,
    \q_reg[145] ,
    \q_reg[69]_0 ,
    \q_reg[68]_0 ,
    \q_reg[67]_0 ,
    \q_reg[66]_0 ,
    \q_reg[65]_0 ,
    \q_reg[64]_0 ,
    \q_reg[63]_0 ,
    \q_reg[62]_0 ,
    \q_reg[61]_0 ,
    \q_reg[60]_0 ,
    \q_reg[59]_0 ,
    \q_reg[58]_0 ,
    \q_reg[57]_0 ,
    \q_reg[56]_0 ,
    \q_reg[55]_0 ,
    \q_reg[54]_0 ,
    \q_reg[53]_1 ,
    \q_reg[52]_0 ,
    \q_reg[51]_3 ,
    \q_reg[50]_0 ,
    \q_reg[49]_1 ,
    \q_reg[48]_2 ,
    \q_reg[47]_0 ,
    \q_reg[46]_3 ,
    \q_reg[45]_1 ,
    \q_reg[44]_2 ,
    \q_reg[43]_2 ,
    \q_reg[42]_1 ,
    \q_reg[40]_0 ,
    \q_reg[2]_0 ,
    \q_reg[39]_1 ,
    \q_reg[41]_1 ,
    \q_reg[39]_2 ,
    \q_reg[44]_3 ,
    \q_reg[46]_4 ,
    \q_reg[44]_4 ,
    SR,
    cpu_clk_BUFG);
  output \q_reg[39]_0 ;
  output [71:0]Q;
  output \q_reg[51]_0 ;
  output \q_reg[10]_0 ;
  output \q_reg[46]_0 ;
  output \q_reg[46]_1 ;
  output \q_reg[48]_0 ;
  output \q_reg[44]_0 ;
  output \q_reg[43]_0 ;
  output \q_reg[53]_0 ;
  output \q_reg[51]_1 ;
  output \q_reg[51]_2 ;
  output \q_reg[49]_0 ;
  output \q_reg[48]_1 ;
  output \q_reg[46]_2 ;
  output \q_reg[45]_0 ;
  output \q_reg[44]_1 ;
  output \q_reg[43]_1 ;
  output \q_reg[42]_0 ;
  output \q_reg[70]_0 ;
  input [41:0]D;
  input \q_reg[41]_0 ;
  input \q_reg[70]_1 ;
  input [32:0]\q_reg[145] ;
  input \q_reg[69]_0 ;
  input \q_reg[68]_0 ;
  input \q_reg[67]_0 ;
  input \q_reg[66]_0 ;
  input \q_reg[65]_0 ;
  input \q_reg[64]_0 ;
  input \q_reg[63]_0 ;
  input \q_reg[62]_0 ;
  input \q_reg[61]_0 ;
  input \q_reg[60]_0 ;
  input \q_reg[59]_0 ;
  input \q_reg[58]_0 ;
  input \q_reg[57]_0 ;
  input \q_reg[56]_0 ;
  input \q_reg[55]_0 ;
  input \q_reg[54]_0 ;
  input \q_reg[53]_1 ;
  input \q_reg[52]_0 ;
  input \q_reg[51]_3 ;
  input \q_reg[50]_0 ;
  input \q_reg[49]_1 ;
  input \q_reg[48]_2 ;
  input \q_reg[47]_0 ;
  input \q_reg[46]_3 ;
  input \q_reg[45]_1 ;
  input \q_reg[44]_2 ;
  input \q_reg[43]_2 ;
  input \q_reg[42]_1 ;
  input \q_reg[40]_0 ;
  input \q_reg[2]_0 ;
  input \q_reg[39]_1 ;
  input \q_reg[41]_1 ;
  input \q_reg[39]_2 ;
  input \q_reg[44]_3 ;
  input \q_reg[46]_4 ;
  input \q_reg[44]_4 ;
  input [0:0]SR;
  input cpu_clk_BUFG;

  wire [41:0]D;
  wire [71:0]Q;
  wire [0:0]SR;
  wire cpu_clk_BUFG;
  wire \q[39]_i_4_n_0 ;
  wire \q_reg[10]_0 ;
  wire [32:0]\q_reg[145] ;
  wire \q_reg[2]_0 ;
  wire \q_reg[39]_0 ;
  wire \q_reg[39]_1 ;
  wire \q_reg[39]_2 ;
  wire \q_reg[40]_0 ;
  wire \q_reg[41]_0 ;
  wire \q_reg[41]_1 ;
  wire \q_reg[42]_0 ;
  wire \q_reg[42]_1 ;
  wire \q_reg[43]_0 ;
  wire \q_reg[43]_1 ;
  wire \q_reg[43]_2 ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[44]_3 ;
  wire \q_reg[44]_4 ;
  wire \q_reg[45]_0 ;
  wire \q_reg[45]_1 ;
  wire \q_reg[46]_0 ;
  wire \q_reg[46]_1 ;
  wire \q_reg[46]_2 ;
  wire \q_reg[46]_3 ;
  wire \q_reg[46]_4 ;
  wire \q_reg[47]_0 ;
  wire \q_reg[48]_0 ;
  wire \q_reg[48]_1 ;
  wire \q_reg[48]_2 ;
  wire \q_reg[49]_0 ;
  wire \q_reg[49]_1 ;
  wire \q_reg[50]_0 ;
  wire \q_reg[51]_0 ;
  wire \q_reg[51]_1 ;
  wire \q_reg[51]_2 ;
  wire \q_reg[51]_3 ;
  wire \q_reg[52]_0 ;
  wire \q_reg[53]_0 ;
  wire \q_reg[53]_1 ;
  wire \q_reg[54]_0 ;
  wire \q_reg[55]_0 ;
  wire \q_reg[56]_0 ;
  wire \q_reg[57]_0 ;
  wire \q_reg[58]_0 ;
  wire \q_reg[59]_0 ;
  wire \q_reg[60]_0 ;
  wire \q_reg[61]_0 ;
  wire \q_reg[62]_0 ;
  wire \q_reg[63]_0 ;
  wire \q_reg[64]_0 ;
  wire \q_reg[65]_0 ;
  wire \q_reg[66]_0 ;
  wire \q_reg[67]_0 ;
  wire \q_reg[68]_0 ;
  wire \q_reg[69]_0 ;
  wire \q_reg[70]_0 ;
  wire \q_reg[70]_1 ;
  wire [31:1]w_MemWriteData_ex;

  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[11]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[43]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[42]_1 ),
        .I4(\q_reg[145] [3]),
        .O(w_MemWriteData_ex[3]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[12]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[44]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[43]_2 ),
        .I4(\q_reg[145] [4]),
        .O(w_MemWriteData_ex[4]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[13]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[45]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[44]_2 ),
        .I4(\q_reg[145] [5]),
        .O(w_MemWriteData_ex[5]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[14]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[46]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[45]_1 ),
        .I4(\q_reg[145] [6]),
        .O(w_MemWriteData_ex[6]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[15]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[47]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[46]_3 ),
        .I4(\q_reg[145] [7]),
        .O(w_MemWriteData_ex[7]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[16]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[48]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[47]_0 ),
        .I4(\q_reg[145] [8]),
        .O(w_MemWriteData_ex[8]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[17]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[49]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[48]_2 ),
        .I4(\q_reg[145] [9]),
        .O(w_MemWriteData_ex[9]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[18]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[50]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[49]_1 ),
        .I4(\q_reg[145] [10]),
        .O(w_MemWriteData_ex[10]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[19]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[51]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[50]_0 ),
        .I4(\q_reg[145] [11]),
        .O(w_MemWriteData_ex[11]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[20]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[52]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[51]_3 ),
        .I4(\q_reg[145] [12]),
        .O(w_MemWriteData_ex[12]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[21]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[53]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[52]_0 ),
        .I4(\q_reg[145] [13]),
        .O(w_MemWriteData_ex[13]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[22]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[54]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[53]_1 ),
        .I4(\q_reg[145] [14]),
        .O(w_MemWriteData_ex[14]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[23]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[55]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[54]_0 ),
        .I4(\q_reg[145] [15]),
        .O(w_MemWriteData_ex[15]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[24]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[56]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[55]_0 ),
        .I4(\q_reg[145] [16]),
        .O(w_MemWriteData_ex[16]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[25]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[57]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(\q_reg[145] [17]),
        .O(w_MemWriteData_ex[17]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[26]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[58]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[57]_0 ),
        .I4(\q_reg[145] [18]),
        .O(w_MemWriteData_ex[18]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[27]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[59]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[58]_0 ),
        .I4(\q_reg[145] [19]),
        .O(w_MemWriteData_ex[19]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[28]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[60]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[59]_0 ),
        .I4(\q_reg[145] [20]),
        .O(w_MemWriteData_ex[20]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[29]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[61]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[60]_0 ),
        .I4(\q_reg[145] [21]),
        .O(w_MemWriteData_ex[21]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[30]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[62]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[61]_0 ),
        .I4(\q_reg[145] [22]),
        .O(w_MemWriteData_ex[22]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[31]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[63]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[62]_0 ),
        .I4(\q_reg[145] [23]),
        .O(w_MemWriteData_ex[23]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[32]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[64]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[63]_0 ),
        .I4(\q_reg[145] [24]),
        .O(w_MemWriteData_ex[24]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[33]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[65]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[64]_0 ),
        .I4(\q_reg[145] [25]),
        .O(w_MemWriteData_ex[25]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[34]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[66]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[65]_0 ),
        .I4(\q_reg[145] [26]),
        .O(w_MemWriteData_ex[26]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[35]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[67]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[66]_0 ),
        .I4(\q_reg[145] [27]),
        .O(w_MemWriteData_ex[27]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[36]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[68]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[67]_0 ),
        .I4(\q_reg[145] [28]),
        .O(w_MemWriteData_ex[28]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[37]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[69]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[68]_0 ),
        .I4(\q_reg[145] [29]),
        .O(w_MemWriteData_ex[29]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[38]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[70]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[69]_0 ),
        .I4(\q_reg[145] [30]),
        .O(w_MemWriteData_ex[30]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[39]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[71]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[70]_1 ),
        .I4(\q_reg[145] [31]),
        .O(w_MemWriteData_ex[31]));
  LUT5 #(
    .INIT(32'h7FFDFFFF)) 
    \q[39]_i_2 
       (.I0(\q[39]_i_4_n_0 ),
        .I1(\q_reg[145] [0]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(\q_reg[39]_2 ),
        .O(\q_reg[39]_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \q[39]_i_4 
       (.I0(Q[6]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(\q[39]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[39]_i_6 
       (.I0(\q_reg[145] [0]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q_reg[10]_0 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[42]_i_12 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[42]),
        .O(\q_reg[42]_0 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[43]_i_12 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[43]),
        .O(\q_reg[43]_1 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[44]_i_14 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[44]),
        .O(\q_reg[44]_1 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[44]_i_17 
       (.I0(Q[44]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[44]_0 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[45]_i_19 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[45]),
        .O(\q_reg[45]_0 ));
  LUT6 #(
    .INIT(64'h8000000000000080)) 
    \q[46]_i_12 
       (.I0(Q[46]),
        .I1(\q[39]_i_4_n_0 ),
        .I2(\q_reg[44]_4 ),
        .I3(Q[3]),
        .I4(Q[4]),
        .I5(\q_reg[145] [1]),
        .O(\q_reg[46]_2 ));
  LUT6 #(
    .INIT(64'h00030003AAAA0003)) 
    \q[46]_i_13 
       (.I0(\q[39]_i_4_n_0 ),
        .I1(\q_reg[2]_0 ),
        .I2(\q_reg[44]_3 ),
        .I3(\q_reg[46]_4 ),
        .I4(\q_reg[44]_4 ),
        .I5(\q_reg[46]_1 ),
        .O(\q_reg[46]_0 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[48]_i_16 
       (.I0(Q[43]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[43]_0 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[48]_i_18 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[48]),
        .O(\q_reg[48]_1 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[48]_i_31 
       (.I0(Q[45]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[48]_0 ));
  LUT5 #(
    .INIT(32'hBAAAAAAA)) 
    \q[49]_i_13 
       (.I0(\q_reg[145] [32]),
        .I1(\q_reg[46]_1 ),
        .I2(\q_reg[44]_4 ),
        .I3(\q[39]_i_4_n_0 ),
        .I4(Q[49]),
        .O(\q_reg[49]_0 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[70]_i_11 
       (.I0(Q[40]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[51]_2 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[70]_i_24 
       (.I0(Q[42]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[53]_0 ));
  LUT6 #(
    .INIT(64'h8000000800000000)) 
    \q[70]_i_28 
       (.I0(Q[41]),
        .I1(\q_reg[39]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(\q_reg[145] [0]),
        .I5(\q[39]_i_4_n_0 ),
        .O(\q_reg[51]_1 ));
  LUT6 #(
    .INIT(64'h00030003AAAA0003)) 
    \q[70]_i_9 
       (.I0(\q[39]_i_4_n_0 ),
        .I1(\q_reg[2]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[41]_1 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[10]_0 ),
        .O(\q_reg[51]_0 ));
  LUT5 #(
    .INIT(32'h7EFFFFFF)) 
    \q[71]_i_12 
       (.I0(\q_reg[145] [1]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(\q_reg[44]_4 ),
        .I4(\q[39]_i_4_n_0 ),
        .O(\q_reg[70]_0 ));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[71]_i_18 
       (.I0(\q_reg[145] [1]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q_reg[46]_1 ));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[9]_i_1 
       (.I0(\q_reg[39]_0 ),
        .I1(Q[41]),
        .I2(\q_reg[41]_0 ),
        .I3(\q_reg[40]_0 ),
        .I4(\q_reg[145] [2]),
        .O(w_MemWriteData_ex[1]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[0]),
        .Q(Q[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[9]),
        .Q(Q[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[3]),
        .Q(Q[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[4]),
        .Q(Q[12]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[5]),
        .Q(Q[13]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[6]),
        .Q(Q[14]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[7]),
        .Q(Q[15]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[8]),
        .Q(Q[16]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[9]),
        .Q(Q[17]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[10]),
        .Q(Q[18]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[11]),
        .Q(Q[19]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[1]),
        .Q(Q[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[12]),
        .Q(Q[20]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[13]),
        .Q(Q[21]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[14]),
        .Q(Q[22]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[15]),
        .Q(Q[23]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[16]),
        .Q(Q[24]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[17]),
        .Q(Q[25]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[18]),
        .Q(Q[26]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[19]),
        .Q(Q[27]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[20]),
        .Q(Q[28]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[21]),
        .Q(Q[29]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[2]),
        .Q(Q[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[22]),
        .Q(Q[30]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[23]),
        .Q(Q[31]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[24]),
        .Q(Q[32]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[25]),
        .Q(Q[33]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[26]),
        .Q(Q[34]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[27]),
        .Q(Q[35]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[28]),
        .Q(Q[36]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[29]),
        .Q(Q[37]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[30]),
        .Q(Q[38]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[31]),
        .Q(Q[39]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[3]),
        .Q(Q[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[10]),
        .Q(Q[40]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[11]),
        .Q(Q[41]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[12]),
        .Q(Q[42]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[13]),
        .Q(Q[43]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[14]),
        .Q(Q[44]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[15]),
        .Q(Q[45]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[16]),
        .Q(Q[46]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[17]),
        .Q(Q[47]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[18]),
        .Q(Q[48]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[19]),
        .Q(Q[49]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[4]),
        .Q(Q[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[20]),
        .Q(Q[50]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[21]),
        .Q(Q[51]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[22]),
        .Q(Q[52]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[23]),
        .Q(Q[53]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[24]),
        .Q(Q[54]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[25]),
        .Q(Q[55]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[26]),
        .Q(Q[56]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[27]),
        .Q(Q[57]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[28]),
        .Q(Q[58]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[29]),
        .Q(Q[59]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[5]),
        .Q(Q[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[30]),
        .Q(Q[60]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[31]),
        .Q(Q[61]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[32]),
        .Q(Q[62]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[33]),
        .Q(Q[63]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[34]),
        .Q(Q[64]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[35]),
        .Q(Q[65]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[36]),
        .Q(Q[66]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[37]),
        .Q(Q[67]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[38]),
        .Q(Q[68]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[39]),
        .Q(Q[69]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[6]),
        .Q(Q[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[40]),
        .Q(Q[70]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[71] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[41]),
        .Q(Q[71]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[7]),
        .Q(Q[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[8]),
        .Q(Q[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex[1]),
        .Q(Q[9]),
        .R(SR));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized2
   (\q_reg[110] ,
    \q_reg[82] ,
    \q_reg[48]_0 ,
    \q_reg[84] ,
    \q_reg[56]_0 ,
    \q_reg[10]_0 ,
    \q_reg[44]_0 ,
    \q_reg[83] ,
    \q_reg[43]_0 ,
    \q_reg[53]_0 ,
    \q_reg[81] ,
    \q_reg[51]_0 ,
    \q_reg[9]_0 ,
    \q_reg[51]_1 ,
    \q_reg[79] ,
    \q_reg[46]_0 ,
    \q_reg[85] ,
    \q_reg[46]_1 ,
    \PC_reg_reg[0] ,
    \PC_reg_reg[0]_0 ,
    \q_reg[39]_0 ,
    \q_reg[35]_0 ,
    \q_reg[29]_0 ,
    \q_reg[28]_0 ,
    \q_reg[31]_0 ,
    \q_reg[30]_0 ,
    \q_reg[27]_0 ,
    \PC_reg_reg[0]_1 ,
    \q_reg[23]_0 ,
    \q_reg[22]_0 ,
    \q_reg[21]_0 ,
    \q_reg[20]_0 ,
    \q_reg[19]_0 ,
    \q_reg[88] ,
    \q_reg[87] ,
    \q_reg[86] ,
    \q_reg[110]_0 ,
    Q,
    \q_reg[89] ,
    w_RegWriteData_wb,
    \q_reg[22]_1 ,
    ReadData20,
    \q_reg[39]_1 ,
    \q_reg[39]_2 ,
    \q_reg[41]_0 ,
    \q_reg[44]_1 ,
    \q_reg[44]_2 ,
    \q_reg[46]_2 ,
    \q_reg[22]_2 ,
    ReadData10,
    \q_reg[19]_1 ,
    \q_reg[19]_2 ,
    \q_reg[46]_3 ,
    SR,
    D,
    cpu_clk_BUFG);
  output [63:0]\q_reg[110] ;
  output \q_reg[82] ;
  output \q_reg[48]_0 ;
  output \q_reg[84] ;
  output \q_reg[56]_0 ;
  output \q_reg[10]_0 ;
  output \q_reg[44]_0 ;
  output \q_reg[83] ;
  output \q_reg[43]_0 ;
  output \q_reg[53]_0 ;
  output \q_reg[81] ;
  output \q_reg[51]_0 ;
  output \q_reg[9]_0 ;
  output \q_reg[51]_1 ;
  output \q_reg[79] ;
  output \q_reg[46]_0 ;
  output \q_reg[85] ;
  output \q_reg[46]_1 ;
  output \PC_reg_reg[0] ;
  output \PC_reg_reg[0]_0 ;
  output \q_reg[39]_0 ;
  output \q_reg[35]_0 ;
  output \q_reg[29]_0 ;
  output \q_reg[28]_0 ;
  output \q_reg[31]_0 ;
  output \q_reg[30]_0 ;
  output \q_reg[27]_0 ;
  output \PC_reg_reg[0]_1 ;
  output \q_reg[23]_0 ;
  output \q_reg[22]_0 ;
  output \q_reg[21]_0 ;
  output \q_reg[20]_0 ;
  output \q_reg[19]_0 ;
  output \q_reg[88] ;
  output \q_reg[87] ;
  output \q_reg[86] ;
  output \q_reg[110]_0 ;
  output [5:0]Q;
  output \q_reg[89] ;
  output [8:0]w_RegWriteData_wb;
  input \q_reg[22]_1 ;
  input [31:0]ReadData20;
  input \q_reg[39]_1 ;
  input \q_reg[39]_2 ;
  input \q_reg[41]_0 ;
  input \q_reg[44]_1 ;
  input \q_reg[44]_2 ;
  input \q_reg[46]_2 ;
  input \q_reg[22]_2 ;
  input [31:0]ReadData10;
  input \q_reg[19]_1 ;
  input [4:0]\q_reg[19]_2 ;
  input [1:0]\q_reg[46]_3 ;
  input [0:0]SR;
  input [70:0]D;
  input cpu_clk_BUFG;

  wire [70:0]D;
  wire \PC_reg[31]_i_100_n_0 ;
  wire \PC_reg[31]_i_101_n_0 ;
  wire \PC_reg[31]_i_102_n_0 ;
  wire \PC_reg[31]_i_15_n_0 ;
  wire \PC_reg[31]_i_16_n_0 ;
  wire \PC_reg[31]_i_17_n_0 ;
  wire \PC_reg[31]_i_18_n_0 ;
  wire \PC_reg[31]_i_19_n_0 ;
  wire \PC_reg[31]_i_20_n_0 ;
  wire \PC_reg[31]_i_21_n_0 ;
  wire \PC_reg[31]_i_22_n_0 ;
  wire \PC_reg[31]_i_23_n_0 ;
  wire \PC_reg[31]_i_25_n_0 ;
  wire \PC_reg[31]_i_26_n_0 ;
  wire \PC_reg[31]_i_27_n_0 ;
  wire \PC_reg[31]_i_28_n_0 ;
  wire \PC_reg[31]_i_29_n_0 ;
  wire \PC_reg[31]_i_30_n_0 ;
  wire \PC_reg[31]_i_31_n_0 ;
  wire \PC_reg[31]_i_32_n_0 ;
  wire \PC_reg[31]_i_33_n_0 ;
  wire \PC_reg[31]_i_34_n_0 ;
  wire \PC_reg[31]_i_35_n_0 ;
  wire \PC_reg[31]_i_36_n_0 ;
  wire \PC_reg[31]_i_37_n_0 ;
  wire \PC_reg[31]_i_38_n_0 ;
  wire \PC_reg[31]_i_39_n_0 ;
  wire \PC_reg[31]_i_40_n_0 ;
  wire \PC_reg[31]_i_41_n_0 ;
  wire \PC_reg[31]_i_42_n_0 ;
  wire \PC_reg[31]_i_43_n_0 ;
  wire \PC_reg[31]_i_44_n_0 ;
  wire \PC_reg[31]_i_45_n_0 ;
  wire \PC_reg[31]_i_46_n_0 ;
  wire \PC_reg[31]_i_47_n_0 ;
  wire \PC_reg[31]_i_48_n_0 ;
  wire \PC_reg[31]_i_49_n_0 ;
  wire \PC_reg[31]_i_50_n_0 ;
  wire \PC_reg[31]_i_51_n_0 ;
  wire \PC_reg[31]_i_52_n_0 ;
  wire \PC_reg[31]_i_53_n_0 ;
  wire \PC_reg[31]_i_54_n_0 ;
  wire \PC_reg[31]_i_55_n_0 ;
  wire \PC_reg[31]_i_56_n_0 ;
  wire \PC_reg[31]_i_57_n_0 ;
  wire \PC_reg[31]_i_58_n_0 ;
  wire \PC_reg[31]_i_59_n_0 ;
  wire \PC_reg[31]_i_60_n_0 ;
  wire \PC_reg[31]_i_61_n_0 ;
  wire \PC_reg[31]_i_62_n_0 ;
  wire \PC_reg[31]_i_63_n_0 ;
  wire \PC_reg[31]_i_64_n_0 ;
  wire \PC_reg[31]_i_65_n_0 ;
  wire \PC_reg[31]_i_66_n_0 ;
  wire \PC_reg[31]_i_67_n_0 ;
  wire \PC_reg[31]_i_68_n_0 ;
  wire \PC_reg[31]_i_69_n_0 ;
  wire \PC_reg[31]_i_70_n_0 ;
  wire \PC_reg[31]_i_71_n_0 ;
  wire \PC_reg[31]_i_72_n_0 ;
  wire \PC_reg[31]_i_73_n_0 ;
  wire \PC_reg[31]_i_74_n_0 ;
  wire \PC_reg[31]_i_75_n_0 ;
  wire \PC_reg[31]_i_76_n_0 ;
  wire \PC_reg[31]_i_77_n_0 ;
  wire \PC_reg[31]_i_78_n_0 ;
  wire \PC_reg[31]_i_79_n_0 ;
  wire \PC_reg[31]_i_80_n_0 ;
  wire \PC_reg[31]_i_81_n_0 ;
  wire \PC_reg[31]_i_82_n_0 ;
  wire \PC_reg[31]_i_83_n_0 ;
  wire \PC_reg[31]_i_84_n_0 ;
  wire \PC_reg[31]_i_85_n_0 ;
  wire \PC_reg[31]_i_86_n_0 ;
  wire \PC_reg[31]_i_87_n_0 ;
  wire \PC_reg[31]_i_88_n_0 ;
  wire \PC_reg[31]_i_89_n_0 ;
  wire \PC_reg[31]_i_90_n_0 ;
  wire \PC_reg[31]_i_91_n_0 ;
  wire \PC_reg[31]_i_92_n_0 ;
  wire \PC_reg[31]_i_93_n_0 ;
  wire \PC_reg[31]_i_94_n_0 ;
  wire \PC_reg[31]_i_95_n_0 ;
  wire \PC_reg[31]_i_96_n_0 ;
  wire \PC_reg[31]_i_97_n_0 ;
  wire \PC_reg[31]_i_98_n_0 ;
  wire \PC_reg[31]_i_99_n_0 ;
  wire \PC_reg_reg[0] ;
  wire \PC_reg_reg[0]_0 ;
  wire \PC_reg_reg[0]_1 ;
  wire [5:0]Q;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire [0:0]SR;
  wire cpu_clk_BUFG;
  wire \q[56]_i_2_n_0 ;
  wire \q[78]_i_3_n_0 ;
  wire \q[89]_i_2_n_0 ;
  wire \q[89]_i_3_n_0 ;
  wire \q_reg[10]_0 ;
  wire [63:0]\q_reg[110] ;
  wire \q_reg[110]_0 ;
  wire \q_reg[19]_0 ;
  wire \q_reg[19]_1 ;
  wire [4:0]\q_reg[19]_2 ;
  wire \q_reg[20]_0 ;
  wire \q_reg[21]_0 ;
  wire \q_reg[22]_0 ;
  wire \q_reg[22]_1 ;
  wire \q_reg[22]_2 ;
  wire \q_reg[23]_0 ;
  wire \q_reg[27]_0 ;
  wire \q_reg[28]_0 ;
  wire \q_reg[29]_0 ;
  wire \q_reg[30]_0 ;
  wire \q_reg[31]_0 ;
  wire \q_reg[35]_0 ;
  wire \q_reg[39]_0 ;
  wire \q_reg[39]_1 ;
  wire \q_reg[39]_2 ;
  wire \q_reg[41]_0 ;
  wire \q_reg[43]_0 ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[46]_0 ;
  wire \q_reg[46]_1 ;
  wire \q_reg[46]_2 ;
  wire [1:0]\q_reg[46]_3 ;
  wire \q_reg[48]_0 ;
  wire \q_reg[51]_0 ;
  wire \q_reg[51]_1 ;
  wire \q_reg[53]_0 ;
  wire \q_reg[56]_0 ;
  wire \q_reg[79] ;
  wire \q_reg[81] ;
  wire \q_reg[82] ;
  wire \q_reg[83] ;
  wire \q_reg[84] ;
  wire \q_reg[85] ;
  wire \q_reg[86] ;
  wire \q_reg[87] ;
  wire \q_reg[88] ;
  wire \q_reg[89] ;
  wire \q_reg[9]_0 ;
  wire \q_reg_n_0_[10] ;
  wire \q_reg_n_0_[11] ;
  wire \q_reg_n_0_[12] ;
  wire \q_reg_n_0_[13] ;
  wire \q_reg_n_0_[14] ;
  wire \q_reg_n_0_[15] ;
  wire \q_reg_n_0_[16] ;
  wire \q_reg_n_0_[17] ;
  wire \q_reg_n_0_[18] ;
  wire \q_reg_n_0_[19] ;
  wire \q_reg_n_0_[20] ;
  wire \q_reg_n_0_[21] ;
  wire \q_reg_n_0_[22] ;
  wire \q_reg_n_0_[23] ;
  wire \q_reg_n_0_[24] ;
  wire \q_reg_n_0_[25] ;
  wire \q_reg_n_0_[26] ;
  wire \q_reg_n_0_[27] ;
  wire \q_reg_n_0_[28] ;
  wire \q_reg_n_0_[29] ;
  wire \q_reg_n_0_[30] ;
  wire \q_reg_n_0_[31] ;
  wire \q_reg_n_0_[32] ;
  wire \q_reg_n_0_[33] ;
  wire \q_reg_n_0_[34] ;
  wire \q_reg_n_0_[35] ;
  wire \q_reg_n_0_[36] ;
  wire \q_reg_n_0_[37] ;
  wire \q_reg_n_0_[38] ;
  wire \q_reg_n_0_[39] ;
  wire \q_reg_n_0_[40] ;
  wire \q_reg_n_0_[41] ;
  wire \q_reg_n_0_[42] ;
  wire \q_reg_n_0_[43] ;
  wire \q_reg_n_0_[44] ;
  wire \q_reg_n_0_[45] ;
  wire \q_reg_n_0_[46] ;
  wire \q_reg_n_0_[47] ;
  wire \q_reg_n_0_[48] ;
  wire \q_reg_n_0_[49] ;
  wire \q_reg_n_0_[50] ;
  wire \q_reg_n_0_[51] ;
  wire \q_reg_n_0_[52] ;
  wire \q_reg_n_0_[53] ;
  wire \q_reg_n_0_[54] ;
  wire \q_reg_n_0_[55] ;
  wire \q_reg_n_0_[56] ;
  wire \q_reg_n_0_[57] ;
  wire \q_reg_n_0_[58] ;
  wire \q_reg_n_0_[59] ;
  wire \q_reg_n_0_[5] ;
  wire \q_reg_n_0_[60] ;
  wire \q_reg_n_0_[61] ;
  wire \q_reg_n_0_[62] ;
  wire \q_reg_n_0_[63] ;
  wire \q_reg_n_0_[64] ;
  wire \q_reg_n_0_[65] ;
  wire \q_reg_n_0_[66] ;
  wire \q_reg_n_0_[67] ;
  wire \q_reg_n_0_[68] ;
  wire \q_reg_n_0_[69] ;
  wire \q_reg_n_0_[70] ;
  wire \q_reg_n_0_[7] ;
  wire \q_reg_n_0_[8] ;
  wire \q_reg_n_0_[9] ;
  wire [8:0]w_RegWriteData_wb;

  LUT3 #(
    .INIT(8'hFE)) 
    \PC_reg[31]_i_10 
       (.I0(\PC_reg[31]_i_15_n_0 ),
        .I1(\PC_reg[31]_i_16_n_0 ),
        .I2(\PC_reg[31]_i_17_n_0 ),
        .O(\PC_reg_reg[0]_1 ));
  LUT5 #(
    .INIT(32'hA202A2A2)) 
    \PC_reg[31]_i_100 
       (.I0(\q_reg[110] [52]),
        .I1(\q_reg[28]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[20]),
        .O(\PC_reg[31]_i_100_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_101 
       (.I0(\q_reg[30]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[22]),
        .I4(\q_reg[110] [54]),
        .O(\PC_reg[31]_i_101_n_0 ));
  LUT5 #(
    .INIT(32'h2E22FFFF)) 
    \PC_reg[31]_i_102 
       (.I0(\q_reg[30]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[22]),
        .I4(\q_reg[110] [54]),
        .O(\PC_reg[31]_i_102_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \PC_reg[31]_i_11 
       (.I0(\PC_reg[31]_i_18_n_0 ),
        .I1(\PC_reg[31]_i_19_n_0 ),
        .I2(\PC_reg[31]_i_20_n_0 ),
        .I3(\PC_reg[31]_i_21_n_0 ),
        .I4(\PC_reg[31]_i_22_n_0 ),
        .I5(\PC_reg[31]_i_23_n_0 ),
        .O(\PC_reg_reg[0]_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF7DEBBE7D)) 
    \PC_reg[31]_i_15 
       (.I0(\PC_reg[31]_i_25_n_0 ),
        .I1(\q_reg[110] [47]),
        .I2(\q_reg[110] [15]),
        .I3(\q_reg[110] [46]),
        .I4(\q_reg[110] [14]),
        .I5(\PC_reg[31]_i_26_n_0 ),
        .O(\PC_reg[31]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFDBED)) 
    \PC_reg[31]_i_16 
       (.I0(\PC_reg[31]_i_27_n_0 ),
        .I1(\PC_reg[31]_i_28_n_0 ),
        .I2(\q_reg[110] [40]),
        .I3(\q_reg[110] [8]),
        .I4(\PC_reg[31]_i_29_n_0 ),
        .O(\PC_reg[31]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEEFFFFFEFFFFE)) 
    \PC_reg[31]_i_17 
       (.I0(\PC_reg[31]_i_30_n_0 ),
        .I1(\PC_reg[31]_i_31_n_0 ),
        .I2(\PC_reg[31]_i_32_n_0 ),
        .I3(\PC_reg[31]_i_33_n_0 ),
        .I4(\q_reg[110] [36]),
        .I5(\q_reg[110] [4]),
        .O(\PC_reg[31]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFB6DFDFB6)) 
    \PC_reg[31]_i_18 
       (.I0(\PC_reg[31]_i_34_n_0 ),
        .I1(\q_reg[110] [48]),
        .I2(\q_reg[110] [16]),
        .I3(\q_reg[110] [17]),
        .I4(\q_reg[110] [49]),
        .I5(\PC_reg[31]_i_35_n_0 ),
        .O(\PC_reg[31]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFB6DFDFB6)) 
    \PC_reg[31]_i_19 
       (.I0(\PC_reg[31]_i_36_n_0 ),
        .I1(\q_reg[110] [52]),
        .I2(\q_reg[110] [20]),
        .I3(\q_reg[110] [53]),
        .I4(\q_reg[110] [21]),
        .I5(\PC_reg[31]_i_37_n_0 ),
        .O(\PC_reg[31]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hE7E7E7BEBEBEE7BE)) 
    \PC_reg[31]_i_20 
       (.I0(\PC_reg[31]_i_38_n_0 ),
        .I1(\q_reg[110] [30]),
        .I2(\q_reg[110] [62]),
        .I3(\PC_reg[31]_i_39_n_0 ),
        .I4(\PC_reg[31]_i_40_n_0 ),
        .I5(\PC_reg[31]_i_41_n_0 ),
        .O(\PC_reg[31]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hF69F6FF6)) 
    \PC_reg[31]_i_21 
       (.I0(\q_reg[110] [61]),
        .I1(\q_reg[110] [29]),
        .I2(\q_reg[110] [28]),
        .I3(\q_reg[110] [60]),
        .I4(\PC_reg[31]_i_40_n_0 ),
        .O(\PC_reg[31]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'h6FF6F69F)) 
    \PC_reg[31]_i_22 
       (.I0(\q_reg[110] [25]),
        .I1(\q_reg[110] [57]),
        .I2(\q_reg[110] [24]),
        .I3(\q_reg[110] [56]),
        .I4(\PC_reg[31]_i_42_n_0 ),
        .O(\PC_reg[31]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'hEFEABABF757FEFEA)) 
    \PC_reg[31]_i_23 
       (.I0(\PC_reg[31]_i_43_n_0 ),
        .I1(\PC_reg[31]_i_44_n_0 ),
        .I2(\PC_reg[31]_i_42_n_0 ),
        .I3(\PC_reg[31]_i_45_n_0 ),
        .I4(\q_reg[110] [26]),
        .I5(\q_reg[110] [58]),
        .O(\PC_reg[31]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F3B230B2)) 
    \PC_reg[31]_i_24 
       (.I0(\PC_reg[31]_i_39_n_0 ),
        .I1(\q_reg[110] [62]),
        .I2(\q_reg[110] [30]),
        .I3(\PC_reg[31]_i_40_n_0 ),
        .I4(\PC_reg[31]_i_41_n_0 ),
        .I5(\PC_reg[31]_i_38_n_0 ),
        .O(\PC_reg_reg[0] ));
  LUT5 #(
    .INIT(32'hBF0B2F02)) 
    \PC_reg[31]_i_25 
       (.I0(\q_reg[110] [44]),
        .I1(\q_reg[110] [12]),
        .I2(\q_reg[110] [13]),
        .I3(\q_reg[110] [45]),
        .I4(\PC_reg[31]_i_46_n_0 ),
        .O(\PC_reg[31]_i_25_n_0 ));
  LUT5 #(
    .INIT(32'h6FF6F69F)) 
    \PC_reg[31]_i_26 
       (.I0(\q_reg[110] [45]),
        .I1(\q_reg[110] [13]),
        .I2(\q_reg[110] [12]),
        .I3(\q_reg[110] [44]),
        .I4(\PC_reg[31]_i_46_n_0 ),
        .O(\PC_reg[31]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF4F0F7F0)) 
    \PC_reg[31]_i_27 
       (.I0(\PC_reg[31]_i_47_n_0 ),
        .I1(\PC_reg[31]_i_32_n_0 ),
        .I2(\PC_reg[31]_i_48_n_0 ),
        .I3(\PC_reg[31]_i_49_n_0 ),
        .I4(\PC_reg[31]_i_50_n_0 ),
        .I5(\PC_reg[31]_i_51_n_0 ),
        .O(\PC_reg[31]_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_28 
       (.I0(\q_reg[88] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[9]),
        .I4(\q_reg[110] [41]),
        .O(\PC_reg[31]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'hCFF3DFB6FF3CDFB6)) 
    \PC_reg[31]_i_29 
       (.I0(\PC_reg[31]_i_52_n_0 ),
        .I1(\q_reg[110] [42]),
        .I2(\q_reg[110] [10]),
        .I3(\PC_reg[31]_i_53_n_0 ),
        .I4(\PC_reg[31]_i_27_n_0 ),
        .I5(\PC_reg[31]_i_54_n_0 ),
        .O(\PC_reg[31]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hBFFBFFFFFFFFBFFB)) 
    \PC_reg[31]_i_30 
       (.I0(\PC_reg[31]_i_55_n_0 ),
        .I1(\PC_reg[31]_i_56_n_0 ),
        .I2(\q_reg[110] [32]),
        .I3(\q_reg[110] [0]),
        .I4(\q_reg[110] [33]),
        .I5(\q_reg[110] [1]),
        .O(\PC_reg[31]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hBEBEE7BEE7E7E7BE)) 
    \PC_reg[31]_i_31 
       (.I0(\PC_reg[31]_i_57_n_0 ),
        .I1(\q_reg[110] [6]),
        .I2(\q_reg[110] [38]),
        .I3(\PC_reg[31]_i_58_n_0 ),
        .I4(\PC_reg[31]_i_32_n_0 ),
        .I5(\PC_reg[31]_i_59_n_0 ),
        .O(\PC_reg[31]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFBFFF2)) 
    \PC_reg[31]_i_32 
       (.I0(\q_reg[110] [1]),
        .I1(\q_reg[110] [33]),
        .I2(\PC_reg[31]_i_60_n_0 ),
        .I3(\PC_reg[31]_i_61_n_0 ),
        .I4(\PC_reg[31]_i_62_n_0 ),
        .I5(\PC_reg[31]_i_63_n_0 ),
        .O(\PC_reg[31]_i_32_n_0 ));
  LUT5 #(
    .INIT(32'h559AAA9A)) 
    \PC_reg[31]_i_33 
       (.I0(\q_reg[110] [5]),
        .I1(\q_reg[19]_1 ),
        .I2(ReadData10[5]),
        .I3(\q_reg[110]_0 ),
        .I4(\q_reg[84] ),
        .O(\PC_reg[31]_i_33_n_0 ));
  LUT5 #(
    .INIT(32'h0B080F0F)) 
    \PC_reg[31]_i_34 
       (.I0(\PC_reg[31]_i_64_n_0 ),
        .I1(\PC_reg[31]_i_46_n_0 ),
        .I2(\PC_reg[31]_i_65_n_0 ),
        .I3(\PC_reg[31]_i_66_n_0 ),
        .I4(\PC_reg[31]_i_67_n_0 ),
        .O(\PC_reg[31]_i_34_n_0 ));
  LUT6 #(
    .INIT(64'hE7E7E7BEBEBEE7BE)) 
    \PC_reg[31]_i_35 
       (.I0(\PC_reg[31]_i_68_n_0 ),
        .I1(\q_reg[110] [18]),
        .I2(\q_reg[110] [50]),
        .I3(\PC_reg[31]_i_69_n_0 ),
        .I4(\PC_reg[31]_i_34_n_0 ),
        .I5(\PC_reg[31]_i_70_n_0 ),
        .O(\PC_reg[31]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hFFBFFFBA0080008A)) 
    \PC_reg[31]_i_36 
       (.I0(\PC_reg[31]_i_71_n_0 ),
        .I1(\PC_reg[31]_i_72_n_0 ),
        .I2(\PC_reg[31]_i_46_n_0 ),
        .I3(\PC_reg[31]_i_65_n_0 ),
        .I4(\PC_reg[31]_i_73_n_0 ),
        .I5(\PC_reg[31]_i_74_n_0 ),
        .O(\PC_reg[31]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hF3CFF79EFF3CF79E)) 
    \PC_reg[31]_i_37 
       (.I0(\PC_reg[31]_i_75_n_0 ),
        .I1(\q_reg[110] [22]),
        .I2(\q_reg[110] [54]),
        .I3(\PC_reg[31]_i_76_n_0 ),
        .I4(\PC_reg[31]_i_36_n_0 ),
        .I5(\PC_reg[31]_i_77_n_0 ),
        .O(\PC_reg[31]_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_38 
       (.I0(\q_reg[39]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[31]),
        .I4(\q_reg[110] [63]),
        .O(\PC_reg[31]_i_38_n_0 ));
  LUT4 #(
    .INIT(16'h20F2)) 
    \PC_reg[31]_i_39 
       (.I0(\q_reg[110] [28]),
        .I1(\q_reg[110] [60]),
        .I2(\q_reg[110] [29]),
        .I3(\q_reg[110] [61]),
        .O(\PC_reg[31]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \PC_reg[31]_i_40 
       (.I0(\PC_reg[31]_i_78_n_0 ),
        .I1(\PC_reg[31]_i_79_n_0 ),
        .I2(\PC_reg[31]_i_36_n_0 ),
        .I3(\PC_reg[31]_i_80_n_0 ),
        .I4(\PC_reg[31]_i_81_n_0 ),
        .O(\PC_reg[31]_i_40_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_41 
       (.I0(\q_reg[110] [60]),
        .I1(\q_reg[110] [28]),
        .I2(\q_reg[110] [29]),
        .I3(\q_reg[110] [61]),
        .O(\PC_reg[31]_i_41_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF4700)) 
    \PC_reg[31]_i_42 
       (.I0(\PC_reg[31]_i_77_n_0 ),
        .I1(\PC_reg[31]_i_36_n_0 ),
        .I2(\PC_reg[31]_i_75_n_0 ),
        .I3(\PC_reg[31]_i_82_n_0 ),
        .I4(\PC_reg[31]_i_83_n_0 ),
        .O(\PC_reg[31]_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_43 
       (.I0(\q_reg[35]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[27]),
        .I4(\q_reg[110] [59]),
        .O(\PC_reg[31]_i_43_n_0 ));
  LUT4 #(
    .INIT(16'h40F4)) 
    \PC_reg[31]_i_44 
       (.I0(\q_reg[110] [56]),
        .I1(\q_reg[110] [24]),
        .I2(\q_reg[110] [25]),
        .I3(\q_reg[110] [57]),
        .O(\PC_reg[31]_i_44_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_45 
       (.I0(\q_reg[110] [56]),
        .I1(\q_reg[110] [24]),
        .I2(\q_reg[110] [25]),
        .I3(\q_reg[110] [57]),
        .O(\PC_reg[31]_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hAABAAABFAA8AAA80)) 
    \PC_reg[31]_i_46 
       (.I0(\PC_reg[31]_i_84_n_0 ),
        .I1(\PC_reg[31]_i_85_n_0 ),
        .I2(\PC_reg[31]_i_32_n_0 ),
        .I3(\PC_reg[31]_i_48_n_0 ),
        .I4(\PC_reg[31]_i_86_n_0 ),
        .I5(\PC_reg[31]_i_87_n_0 ),
        .O(\PC_reg[31]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFBFBFBABF)) 
    \PC_reg[31]_i_47 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\q_reg[83] ),
        .I2(\q_reg[110]_0 ),
        .I3(ReadData10[4]),
        .I4(\q_reg[19]_1 ),
        .I5(\q_reg[110] [4]),
        .O(\PC_reg[31]_i_47_n_0 ));
  LUT4 #(
    .INIT(16'h40F4)) 
    \PC_reg[31]_i_48 
       (.I0(\q_reg[110] [6]),
        .I1(\q_reg[110] [38]),
        .I2(\q_reg[110] [39]),
        .I3(\q_reg[110] [7]),
        .O(\PC_reg[31]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h00000000D5D5DFD5)) 
    \PC_reg[31]_i_49 
       (.I0(\q_reg[110] [7]),
        .I1(\q_reg[86] ),
        .I2(\q_reg[110]_0 ),
        .I3(ReadData10[7]),
        .I4(\q_reg[19]_1 ),
        .I5(\PC_reg[31]_i_89_n_0 ),
        .O(\PC_reg[31]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hBFBFBABFAAAAAAAA)) 
    \PC_reg[31]_i_50 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\q_reg[83] ),
        .I2(\q_reg[110]_0 ),
        .I3(ReadData10[4]),
        .I4(\q_reg[19]_1 ),
        .I5(\q_reg[110] [4]),
        .O(\PC_reg[31]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h04)) 
    \PC_reg[31]_i_51 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\PC_reg[31]_i_90_n_0 ),
        .I2(\PC_reg[31]_i_91_n_0 ),
        .O(\PC_reg[31]_i_51_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_52 
       (.I0(\q_reg[110] [40]),
        .I1(\q_reg[110] [8]),
        .I2(\q_reg[110] [9]),
        .I3(\q_reg[110] [41]),
        .O(\PC_reg[31]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_53 
       (.I0(\q_reg[19]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[11]),
        .I4(\q_reg[110] [43]),
        .O(\PC_reg[31]_i_53_n_0 ));
  LUT4 #(
    .INIT(16'h40F4)) 
    \PC_reg[31]_i_54 
       (.I0(\q_reg[110] [40]),
        .I1(\q_reg[110] [8]),
        .I2(\q_reg[110] [9]),
        .I3(\q_reg[110] [41]),
        .O(\PC_reg[31]_i_54_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \PC_reg[31]_i_55 
       (.I0(\q_reg[110] [35]),
        .I1(\q_reg[110] [3]),
        .I2(\q_reg[110] [34]),
        .I3(\q_reg[110] [2]),
        .O(\PC_reg[31]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'h000000005DFD5D5D)) 
    \PC_reg[31]_i_56 
       (.I0(\q_reg[110] [35]),
        .I1(\q_reg[82] ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[3]),
        .I5(\PC_reg[31]_i_92_n_0 ),
        .O(\PC_reg[31]_i_56_n_0 ));
  LUT5 #(
    .INIT(32'h559AAA9A)) 
    \PC_reg[31]_i_57 
       (.I0(\q_reg[110] [7]),
        .I1(\q_reg[19]_1 ),
        .I2(ReadData10[7]),
        .I3(\q_reg[110]_0 ),
        .I4(\q_reg[86] ),
        .O(\PC_reg[31]_i_57_n_0 ));
  LUT6 #(
    .INIT(64'h8888E8EEEEEEE8EE)) 
    \PC_reg[31]_i_58 
       (.I0(\PC_reg[31]_i_93_n_0 ),
        .I1(\q_reg[110] [5]),
        .I2(\q_reg[19]_1 ),
        .I3(ReadData10[5]),
        .I4(\q_reg[110]_0 ),
        .I5(\q_reg[84] ),
        .O(\PC_reg[31]_i_58_n_0 ));
  LUT6 #(
    .INIT(64'h7777171111111711)) 
    \PC_reg[31]_i_59 
       (.I0(\PC_reg[31]_i_94_n_0 ),
        .I1(\q_reg[110] [5]),
        .I2(\q_reg[19]_1 ),
        .I3(ReadData10[5]),
        .I4(\q_reg[110]_0 ),
        .I5(\q_reg[84] ),
        .O(\PC_reg[31]_i_59_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_60 
       (.I0(\q_reg[81] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[2]),
        .I4(\q_reg[110] [34]),
        .O(\PC_reg[31]_i_60_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_61 
       (.I0(\q_reg[82] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[3]),
        .I4(\q_reg[110] [35]),
        .O(\PC_reg[31]_i_61_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_62 
       (.I0(\q_reg[79] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[0]),
        .I4(\q_reg[110] [32]),
        .O(\PC_reg[31]_i_62_n_0 ));
  LUT4 #(
    .INIT(16'h22B2)) 
    \PC_reg[31]_i_63 
       (.I0(\q_reg[110] [35]),
        .I1(\q_reg[110] [3]),
        .I2(\q_reg[110] [34]),
        .I3(\q_reg[110] [2]),
        .O(\PC_reg[31]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'h045404045DFD5D5D)) 
    \PC_reg[31]_i_64 
       (.I0(\PC_reg[31]_i_95_n_0 ),
        .I1(\q_reg[21]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[13]),
        .I5(\q_reg[110] [45]),
        .O(\PC_reg[31]_i_64_n_0 ));
  LUT4 #(
    .INIT(16'h4F04)) 
    \PC_reg[31]_i_65 
       (.I0(\q_reg[110] [14]),
        .I1(\q_reg[110] [46]),
        .I2(\q_reg[110] [15]),
        .I3(\q_reg[110] [47]),
        .O(\PC_reg[31]_i_65_n_0 ));
  LUT6 #(
    .INIT(64'h045404045DFD5D5D)) 
    \PC_reg[31]_i_66 
       (.I0(\PC_reg[31]_i_96_n_0 ),
        .I1(\q_reg[21]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[13]),
        .I5(\q_reg[110] [45]),
        .O(\PC_reg[31]_i_66_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFD0DF)) 
    \PC_reg[31]_i_67 
       (.I0(ReadData20[15]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[23]_0 ),
        .I4(\q_reg[110] [47]),
        .I5(\PC_reg[31]_i_97_n_0 ),
        .O(\PC_reg[31]_i_67_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_68 
       (.I0(\q_reg[27]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[19]),
        .I4(\q_reg[110] [51]),
        .O(\PC_reg[31]_i_68_n_0 ));
  LUT4 #(
    .INIT(16'h20F2)) 
    \PC_reg[31]_i_69 
       (.I0(\q_reg[110] [16]),
        .I1(\q_reg[110] [48]),
        .I2(\q_reg[110] [17]),
        .I3(\q_reg[110] [49]),
        .O(\PC_reg[31]_i_69_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_70 
       (.I0(\q_reg[110] [48]),
        .I1(\q_reg[110] [16]),
        .I2(\q_reg[110] [17]),
        .I3(\q_reg[110] [49]),
        .O(\PC_reg[31]_i_70_n_0 ));
  LUT5 #(
    .INIT(32'hB2F330B2)) 
    \PC_reg[31]_i_71 
       (.I0(\PC_reg[31]_i_70_n_0 ),
        .I1(\q_reg[110] [51]),
        .I2(\q_reg[110] [19]),
        .I3(\q_reg[110] [50]),
        .I4(\q_reg[110] [18]),
        .O(\PC_reg[31]_i_71_n_0 ));
  LUT5 #(
    .INIT(32'hFF4DFFFF)) 
    \PC_reg[31]_i_72 
       (.I0(\q_reg[110] [45]),
        .I1(\q_reg[110] [13]),
        .I2(\PC_reg[31]_i_95_n_0 ),
        .I3(\PC_reg[31]_i_97_n_0 ),
        .I4(\PC_reg[31]_i_98_n_0 ),
        .O(\PC_reg[31]_i_72_n_0 ));
  LUT5 #(
    .INIT(32'h40440040)) 
    \PC_reg[31]_i_73 
       (.I0(\PC_reg[31]_i_97_n_0 ),
        .I1(\PC_reg[31]_i_98_n_0 ),
        .I2(\q_reg[110] [45]),
        .I3(\q_reg[110] [13]),
        .I4(\PC_reg[31]_i_96_n_0 ),
        .O(\PC_reg[31]_i_73_n_0 ));
  LUT5 #(
    .INIT(32'h8ECF0C8E)) 
    \PC_reg[31]_i_74 
       (.I0(\PC_reg[31]_i_69_n_0 ),
        .I1(\q_reg[110] [19]),
        .I2(\q_reg[110] [51]),
        .I3(\q_reg[110] [50]),
        .I4(\q_reg[110] [18]),
        .O(\PC_reg[31]_i_74_n_0 ));
  LUT6 #(
    .INIT(64'h045404045DFD5D5D)) 
    \PC_reg[31]_i_75 
       (.I0(\PC_reg[31]_i_99_n_0 ),
        .I1(\q_reg[29]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[21]),
        .I5(\q_reg[110] [53]),
        .O(\PC_reg[31]_i_75_n_0 ));
  LUT5 #(
    .INIT(32'hD1DD2E22)) 
    \PC_reg[31]_i_76 
       (.I0(\q_reg[31]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[23]),
        .I4(\q_reg[110] [55]),
        .O(\PC_reg[31]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'h045404045DFD5D5D)) 
    \PC_reg[31]_i_77 
       (.I0(\PC_reg[31]_i_100_n_0 ),
        .I1(\q_reg[29]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[21]),
        .I5(\q_reg[110] [53]),
        .O(\PC_reg[31]_i_77_n_0 ));
  LUT5 #(
    .INIT(32'h8ECF0C8E)) 
    \PC_reg[31]_i_78 
       (.I0(\PC_reg[31]_i_44_n_0 ),
        .I1(\q_reg[110] [27]),
        .I2(\q_reg[110] [59]),
        .I3(\q_reg[110] [58]),
        .I4(\q_reg[110] [26]),
        .O(\PC_reg[31]_i_78_n_0 ));
  LUT5 #(
    .INIT(32'h4D0CCF4D)) 
    \PC_reg[31]_i_79 
       (.I0(\PC_reg[31]_i_77_n_0 ),
        .I1(\q_reg[110] [55]),
        .I2(\q_reg[110] [23]),
        .I3(\q_reg[110] [54]),
        .I4(\q_reg[110] [22]),
        .O(\PC_reg[31]_i_79_n_0 ));
  LUT5 #(
    .INIT(32'h7130F371)) 
    \PC_reg[31]_i_80 
       (.I0(\PC_reg[31]_i_75_n_0 ),
        .I1(\q_reg[110] [23]),
        .I2(\q_reg[110] [55]),
        .I3(\q_reg[110] [54]),
        .I4(\q_reg[110] [22]),
        .O(\PC_reg[31]_i_80_n_0 ));
  LUT5 #(
    .INIT(32'h8ECF0C8E)) 
    \PC_reg[31]_i_81 
       (.I0(\PC_reg[31]_i_45_n_0 ),
        .I1(\q_reg[110] [27]),
        .I2(\q_reg[110] [59]),
        .I3(\q_reg[110] [58]),
        .I4(\q_reg[110] [26]),
        .O(\PC_reg[31]_i_81_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FBAAFBFF)) 
    \PC_reg[31]_i_82 
       (.I0(\q_reg[110] [55]),
        .I1(ReadData20[23]),
        .I2(\q_reg[22]_1 ),
        .I3(\q[78]_i_3_n_0 ),
        .I4(\q_reg[31]_0 ),
        .I5(\PC_reg[31]_i_101_n_0 ),
        .O(\PC_reg[31]_i_82_n_0 ));
  LUT6 #(
    .INIT(64'hDD4D4444DD4DDDDD)) 
    \PC_reg[31]_i_83 
       (.I0(\PC_reg[31]_i_102_n_0 ),
        .I1(\q_reg[110] [55]),
        .I2(ReadData20[23]),
        .I3(\q_reg[22]_1 ),
        .I4(\q[78]_i_3_n_0 ),
        .I5(\q_reg[31]_0 ),
        .O(\PC_reg[31]_i_83_n_0 ));
  LUT5 #(
    .INIT(32'h4D0CCF4D)) 
    \PC_reg[31]_i_84 
       (.I0(\PC_reg[31]_i_54_n_0 ),
        .I1(\q_reg[110] [43]),
        .I2(\q_reg[110] [11]),
        .I3(\q_reg[110] [42]),
        .I4(\q_reg[110] [10]),
        .O(\PC_reg[31]_i_84_n_0 ));
  LUT5 #(
    .INIT(32'h10005010)) 
    \PC_reg[31]_i_85 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\PC_reg[31]_i_94_n_0 ),
        .I2(\PC_reg[31]_i_90_n_0 ),
        .I3(\q_reg[110] [37]),
        .I4(\q_reg[110] [5]),
        .O(\PC_reg[31]_i_85_n_0 ));
  LUT5 #(
    .INIT(32'h10005010)) 
    \PC_reg[31]_i_86 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\PC_reg[31]_i_93_n_0 ),
        .I2(\PC_reg[31]_i_90_n_0 ),
        .I3(\q_reg[110] [37]),
        .I4(\q_reg[110] [5]),
        .O(\PC_reg[31]_i_86_n_0 ));
  LUT5 #(
    .INIT(32'h7100FF71)) 
    \PC_reg[31]_i_87 
       (.I0(\PC_reg[31]_i_52_n_0 ),
        .I1(\q_reg[110] [10]),
        .I2(\q_reg[110] [42]),
        .I3(\q_reg[110] [43]),
        .I4(\q_reg[110] [11]),
        .O(\PC_reg[31]_i_87_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_88 
       (.I0(\q_reg[85] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[6]),
        .I4(\q_reg[110] [38]),
        .O(\PC_reg[31]_i_88_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_89 
       (.I0(\q_reg[84] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[5]),
        .I4(\q_reg[110] [37]),
        .O(\PC_reg[31]_i_89_n_0 ));
  LUT5 #(
    .INIT(32'hFBABFBFB)) 
    \PC_reg[31]_i_90 
       (.I0(\q_reg[110] [39]),
        .I1(\q_reg[86] ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[7]),
        .O(\PC_reg[31]_i_90_n_0 ));
  LUT5 #(
    .INIT(32'h2E22FFFF)) 
    \PC_reg[31]_i_91 
       (.I0(\q_reg[84] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[5]),
        .I4(\q_reg[110] [37]),
        .O(\PC_reg[31]_i_91_n_0 ));
  LUT5 #(
    .INIT(32'hA202A2A2)) 
    \PC_reg[31]_i_92 
       (.I0(\q_reg[110] [34]),
        .I1(\q_reg[81] ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[2]),
        .O(\PC_reg[31]_i_92_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_93 
       (.I0(\q_reg[83] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[4]),
        .I4(\q_reg[110] [36]),
        .O(\PC_reg[31]_i_93_n_0 ));
  LUT5 #(
    .INIT(32'h2E22FFFF)) 
    \PC_reg[31]_i_94 
       (.I0(\q_reg[83] ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[4]),
        .I4(\q_reg[110] [36]),
        .O(\PC_reg[31]_i_94_n_0 ));
  LUT5 #(
    .INIT(32'hFBABFBFB)) 
    \PC_reg[31]_i_95 
       (.I0(\q_reg[110] [44]),
        .I1(\q_reg[20]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[12]),
        .O(\PC_reg[31]_i_95_n_0 ));
  LUT5 #(
    .INIT(32'hA202A2A2)) 
    \PC_reg[31]_i_96 
       (.I0(\q_reg[110] [44]),
        .I1(\q_reg[20]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[12]),
        .O(\PC_reg[31]_i_96_n_0 ));
  LUT5 #(
    .INIT(32'h00002E22)) 
    \PC_reg[31]_i_97 
       (.I0(\q_reg[22]_0 ),
        .I1(\q[78]_i_3_n_0 ),
        .I2(\q_reg[22]_1 ),
        .I3(ReadData20[14]),
        .I4(\q_reg[110] [46]),
        .O(\PC_reg[31]_i_97_n_0 ));
  LUT5 #(
    .INIT(32'hFBABFBFB)) 
    \PC_reg[31]_i_98 
       (.I0(\q_reg[110] [47]),
        .I1(\q_reg[23]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[15]),
        .O(\PC_reg[31]_i_98_n_0 ));
  LUT5 #(
    .INIT(32'hFBABFBFB)) 
    \PC_reg[31]_i_99 
       (.I0(\q_reg[110] [52]),
        .I1(\q_reg[28]_0 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg[22]_1 ),
        .I4(ReadData20[20]),
        .O(\PC_reg[31]_i_99_n_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[100]_i_1 
       (.I0(\q_reg_n_0_[60] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[28] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[21]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [53]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[101]_i_1 
       (.I0(\q_reg_n_0_[61] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[29] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[22]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [54]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[102]_i_1 
       (.I0(\q_reg_n_0_[62] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[30] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[23]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [55]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[103]_i_1 
       (.I0(\q_reg_n_0_[63] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[31] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[24]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [56]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[104]_i_1 
       (.I0(\q_reg_n_0_[64] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[32] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[25]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [57]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[105]_i_1 
       (.I0(\q_reg_n_0_[65] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[33] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[26]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [58]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[106]_i_1 
       (.I0(\q_reg_n_0_[66] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[34] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[27]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [59]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[107]_i_1 
       (.I0(\q_reg_n_0_[67] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[35] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[28]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [60]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[108]_i_1 
       (.I0(\q_reg_n_0_[68] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[36] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[29]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [61]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[109]_i_1 
       (.I0(\q_reg_n_0_[69] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[37] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[30]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [62]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[110]_i_1 
       (.I0(\q_reg_n_0_[70] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[38] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[31]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [63]));
  LUT5 #(
    .INIT(32'h00000081)) 
    \q[110]_i_2 
       (.I0(\q_reg[19]_2 [4]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(\q[89]_i_3_n_0 ),
        .I4(\q_reg[56]_0 ),
        .O(\q_reg[110]_0 ));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[39]_i_7 
       (.I0(\q_reg[46]_3 [0]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q_reg[10]_0 ));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[44]_i_16 
       (.I0(\q_reg[83] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[44]_0 ));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[46]_i_14 
       (.I0(\q_reg[85] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[46]_1 ),
        .I4(\q_reg[44]_2 ),
        .I5(\q_reg[46]_2 ),
        .O(\q_reg[46]_0 ));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[47]_i_1__0 
       (.I0(ReadData20[0]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[39] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[7] ),
        .O(\q_reg[110] [0]));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[48]_i_15 
       (.I0(\q_reg[82] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[43]_0 ));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[48]_i_1__0 
       (.I0(ReadData20[1]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[40] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[8] ),
        .O(\q_reg[110] [1]));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[48]_i_30 
       (.I0(\q_reg[84] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[48]_0 ));
  LUT6 #(
    .INIT(64'h2222222F22222220)) 
    \q[49]_i_1__0 
       (.I0(ReadData20[2]),
        .I1(\q_reg[22]_1 ),
        .I2(\q_reg[56]_0 ),
        .I3(\q[56]_i_2_n_0 ),
        .I4(\q_reg[22]_2 ),
        .I5(\q_reg[81] ),
        .O(\q_reg[110] [2]));
  LUT6 #(
    .INIT(64'h2222222F22222220)) 
    \q[50]_i_1__0 
       (.I0(ReadData20[3]),
        .I1(\q_reg[22]_1 ),
        .I2(\q_reg[56]_0 ),
        .I3(\q[56]_i_2_n_0 ),
        .I4(\q_reg[22]_2 ),
        .I5(\q_reg[82] ),
        .O(\q_reg[110] [3]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[51]_i_1__0 
       (.I0(ReadData20[4]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[43] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[11] ),
        .O(\q_reg[110] [4]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[52]_i_1__0 
       (.I0(ReadData20[5]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[44] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[12] ),
        .O(\q_reg[110] [5]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[53]_i_1__0 
       (.I0(ReadData20[6]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[45] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[13] ),
        .O(\q_reg[110] [6]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[54]_i_1__0 
       (.I0(ReadData20[7]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[46] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[14] ),
        .O(\q_reg[110] [7]));
  LUT6 #(
    .INIT(64'h2222222F22222220)) 
    \q[55]_i_1__0 
       (.I0(ReadData20[8]),
        .I1(\q_reg[22]_1 ),
        .I2(\q_reg[56]_0 ),
        .I3(\q[56]_i_2_n_0 ),
        .I4(\q_reg[22]_2 ),
        .I5(\q_reg[87] ),
        .O(\q_reg[110] [8]));
  LUT6 #(
    .INIT(64'h2222222F22222220)) 
    \q[56]_i_1__0 
       (.I0(ReadData20[9]),
        .I1(\q_reg[22]_1 ),
        .I2(\q_reg[56]_0 ),
        .I3(\q[56]_i_2_n_0 ),
        .I4(\q_reg[22]_2 ),
        .I5(\q_reg[88] ),
        .O(\q_reg[110] [9]));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[56]_i_2 
       (.I0(\q_reg[19]_2 [0]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q[56]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[57]_i_1__0 
       (.I0(ReadData20[10]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[49] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[17] ),
        .O(\q_reg[110] [10]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[58]_i_1__0 
       (.I0(ReadData20[11]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[50] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[18] ),
        .O(\q_reg[110] [11]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[59]_i_1__0 
       (.I0(ReadData20[12]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[51] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[19] ),
        .O(\q_reg[110] [12]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[60]_i_1__0 
       (.I0(ReadData20[13]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[52] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[20] ),
        .O(\q_reg[110] [13]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[61]_i_1__0 
       (.I0(ReadData20[14]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[53] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[21] ),
        .O(\q_reg[110] [14]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[62]_i_1__0 
       (.I0(ReadData20[15]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[54] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[22] ),
        .O(\q_reg[110] [15]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[63]_i_1__1 
       (.I0(ReadData20[16]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[55] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[23] ),
        .O(\q_reg[110] [16]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[64]_i_1__0 
       (.I0(ReadData20[17]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[56] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[24] ),
        .O(\q_reg[110] [17]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[65]_i_1__0 
       (.I0(ReadData20[18]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[57] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[25] ),
        .O(\q_reg[110] [18]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[66]_i_1__0 
       (.I0(ReadData20[19]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[58] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[26] ),
        .O(\q_reg[110] [19]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[67]_i_1__0 
       (.I0(ReadData20[20]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[59] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[27] ),
        .O(\q_reg[110] [20]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[68]_i_1__0 
       (.I0(ReadData20[21]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[60] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[28] ),
        .O(\q_reg[110] [21]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[69]_i_1__0 
       (.I0(ReadData20[22]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[61] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[29] ),
        .O(\q_reg[110] [22]));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[70]_i_10 
       (.I0(\q_reg[79] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[51]_1 ));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[70]_i_1__0 
       (.I0(ReadData20[23]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[62] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[30] ),
        .O(\q_reg[110] [23]));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[70]_i_23 
       (.I0(\q_reg[81] ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[53]_0 ));
  LUT6 #(
    .INIT(64'h0002000200000002)) 
    \q[70]_i_27 
       (.I0(\q_reg[9]_0 ),
        .I1(\q_reg[56]_0 ),
        .I2(\q_reg[39]_1 ),
        .I3(\q_reg[10]_0 ),
        .I4(\q_reg[39]_2 ),
        .I5(\q_reg[41]_0 ),
        .O(\q_reg[51]_0 ));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[71]_i_19 
       (.I0(\q_reg[46]_3 [1]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q_reg[46]_1 ));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[71]_i_1__0 
       (.I0(ReadData20[24]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[63] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[31] ),
        .O(\q_reg[110] [24]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[72]_i_1 
       (.I0(ReadData20[25]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[64] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[32] ),
        .O(\q_reg[110] [25]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[73]_i_1 
       (.I0(ReadData20[26]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[65] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[33] ),
        .O(\q_reg[110] [26]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[74]_i_1 
       (.I0(ReadData20[27]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[66] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[34] ),
        .O(\q_reg[110] [27]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[75]_i_1 
       (.I0(ReadData20[28]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[67] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[35] ),
        .O(\q_reg[110] [28]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[76]_i_1 
       (.I0(ReadData20[29]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[68] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[36] ),
        .O(\q_reg[110] [29]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[77]_i_1 
       (.I0(ReadData20[30]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[69] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[37] ),
        .O(\q_reg[110] [30]));
  LUT6 #(
    .INIT(64'h2F202F2F2F202020)) 
    \q[78]_i_1 
       (.I0(ReadData20[31]),
        .I1(\q_reg[22]_1 ),
        .I2(\q[78]_i_3_n_0 ),
        .I3(\q_reg_n_0_[70] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[38] ),
        .O(\q_reg[110] [31]));
  LUT5 #(
    .INIT(32'hFFFFBFFE)) 
    \q[78]_i_3 
       (.I0(\q_reg[56]_0 ),
        .I1(\q_reg[19]_2 [0]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(\q_reg[22]_2 ),
        .O(\q[78]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[79]_i_1 
       (.I0(\q_reg[79] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[0]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [32]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[80]_i_1 
       (.I0(\q_reg_n_0_[40] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[8] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[1]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [33]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[81]_i_1 
       (.I0(\q_reg[81] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[2]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [34]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[82]_i_1 
       (.I0(\q_reg[82] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[3]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [35]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[83]_i_1 
       (.I0(\q_reg[83] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[4]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [36]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[84]_i_1 
       (.I0(\q_reg[84] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[5]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [37]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[85]_i_1 
       (.I0(\q_reg[85] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[6]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [38]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[86]_i_1 
       (.I0(\q_reg[86] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[7]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [39]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[87]_i_1 
       (.I0(\q_reg[87] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[8]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [40]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[88]_i_1 
       (.I0(\q_reg[88] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[9]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [41]));
  LUT6 #(
    .INIT(64'h00020002FFFE0002)) 
    \q[89]_i_1 
       (.I0(\q_reg[89] ),
        .I1(\q[89]_i_2_n_0 ),
        .I2(\q[89]_i_3_n_0 ),
        .I3(\q_reg[56]_0 ),
        .I4(ReadData10[10]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [42]));
  LUT3 #(
    .INIT(8'h7E)) 
    \q[89]_i_2 
       (.I0(\q_reg[19]_2 [4]),
        .I1(Q[4]),
        .I2(Q[3]),
        .O(\q[89]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[89]_i_3 
       (.I0(Q[1]),
        .I1(\q_reg[19]_2 [2]),
        .I2(\q_reg[19]_2 [3]),
        .I3(Q[2]),
        .I4(\q_reg[19]_2 [1]),
        .I5(Q[0]),
        .O(\q[89]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000001FFFFFFFF)) 
    \q[89]_i_4 
       (.I0(Q[2]),
        .I1(Q[4]),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(Q[3]),
        .I5(Q[5]),
        .O(\q_reg[56]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[90]_i_1 
       (.I0(\q_reg_n_0_[50] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[18] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[11]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [43]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[91]_i_1 
       (.I0(\q_reg_n_0_[51] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[19] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[12]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [44]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[92]_i_1 
       (.I0(\q_reg_n_0_[52] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[20] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[13]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [45]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[93]_i_1 
       (.I0(\q_reg_n_0_[53] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[21] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[14]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [46]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[94]_i_1 
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[15]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [47]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[95]_i_1 
       (.I0(\q_reg_n_0_[55] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[23] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[16]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [48]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[96]_i_1 
       (.I0(\q_reg_n_0_[56] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[24] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[17]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [49]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[97]_i_1 
       (.I0(\q_reg_n_0_[57] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[25] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[18]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [50]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[98]_i_1 
       (.I0(\q_reg_n_0_[58] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[26] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[19]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [51]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[99]_i_1 
       (.I0(\q_reg_n_0_[59] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[27] ),
        .I3(\q_reg[110]_0 ),
        .I4(ReadData10[20]),
        .I5(\q_reg[19]_1 ),
        .O(\q_reg[110] [52]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[0]),
        .Q(Q[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[10]),
        .Q(\q_reg_n_0_[10] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[11]),
        .Q(\q_reg_n_0_[11] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[12]),
        .Q(\q_reg_n_0_[12] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[13]),
        .Q(\q_reg_n_0_[13] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[14]),
        .Q(\q_reg_n_0_[14] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[15]),
        .Q(\q_reg_n_0_[15] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[16]),
        .Q(\q_reg_n_0_[16] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[17]),
        .Q(\q_reg_n_0_[17] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[18]),
        .Q(\q_reg_n_0_[18] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[19]),
        .Q(\q_reg_n_0_[19] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[1]),
        .Q(Q[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[20]),
        .Q(\q_reg_n_0_[20] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[21]),
        .Q(\q_reg_n_0_[21] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[22]),
        .Q(\q_reg_n_0_[22] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[23]),
        .Q(\q_reg_n_0_[23] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[24]),
        .Q(\q_reg_n_0_[24] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[25]),
        .Q(\q_reg_n_0_[25] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[26]),
        .Q(\q_reg_n_0_[26] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[27]),
        .Q(\q_reg_n_0_[27] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[28]),
        .Q(\q_reg_n_0_[28] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[29]),
        .Q(\q_reg_n_0_[29] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[2]),
        .Q(Q[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[30]),
        .Q(\q_reg_n_0_[30] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[31]),
        .Q(\q_reg_n_0_[31] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[32]),
        .Q(\q_reg_n_0_[32] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[33]),
        .Q(\q_reg_n_0_[33] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[34]),
        .Q(\q_reg_n_0_[34] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[35]),
        .Q(\q_reg_n_0_[35] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[36]),
        .Q(\q_reg_n_0_[36] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[37]),
        .Q(\q_reg_n_0_[37] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[38]),
        .Q(\q_reg_n_0_[38] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[39]),
        .Q(\q_reg_n_0_[39] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[3]),
        .Q(Q[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[40]),
        .Q(\q_reg_n_0_[40] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[41]),
        .Q(\q_reg_n_0_[41] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[42]),
        .Q(\q_reg_n_0_[42] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[43]),
        .Q(\q_reg_n_0_[43] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[44]),
        .Q(\q_reg_n_0_[44] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[45]),
        .Q(\q_reg_n_0_[45] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[46]),
        .Q(\q_reg_n_0_[46] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[47]),
        .Q(\q_reg_n_0_[47] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[48]),
        .Q(\q_reg_n_0_[48] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[49]),
        .Q(\q_reg_n_0_[49] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[4]),
        .Q(Q[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[50]),
        .Q(\q_reg_n_0_[50] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[51]),
        .Q(\q_reg_n_0_[51] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[52]),
        .Q(\q_reg_n_0_[52] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[53]),
        .Q(\q_reg_n_0_[53] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[54]),
        .Q(\q_reg_n_0_[54] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[55]),
        .Q(\q_reg_n_0_[55] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[56]),
        .Q(\q_reg_n_0_[56] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[57]),
        .Q(\q_reg_n_0_[57] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[58]),
        .Q(\q_reg_n_0_[58] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[59]),
        .Q(\q_reg_n_0_[59] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[5]),
        .Q(\q_reg_n_0_[5] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[60]),
        .Q(\q_reg_n_0_[60] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[61]),
        .Q(\q_reg_n_0_[61] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[62]),
        .Q(\q_reg_n_0_[62] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[63]),
        .Q(\q_reg_n_0_[63] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[64]),
        .Q(\q_reg_n_0_[64] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[65]),
        .Q(\q_reg_n_0_[65] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[66]),
        .Q(\q_reg_n_0_[66] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[67]),
        .Q(\q_reg_n_0_[67] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[68]),
        .Q(\q_reg_n_0_[68] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[69]),
        .Q(\q_reg_n_0_[69] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[6]),
        .Q(Q[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[70]),
        .Q(\q_reg_n_0_[70] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[7]),
        .Q(\q_reg_n_0_[7] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[8]),
        .Q(\q_reg_n_0_[8] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[9]),
        .Q(\q_reg_n_0_[9] ),
        .R(SR));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_1
       (.I0(\q_reg_n_0_[40] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[8] ),
        .O(\q_reg[9]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_2
       (.I0(\q_reg_n_0_[39] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[7] ),
        .O(\q_reg[79] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_3
       (.I0(\q_reg_n_0_[42] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[10] ),
        .O(\q_reg[82] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_4
       (.I0(\q_reg_n_0_[41] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[9] ),
        .O(\q_reg[81] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_5
       (.I0(\q_reg_n_0_[44] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[12] ),
        .O(\q_reg[84] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_6
       (.I0(\q_reg_n_0_[43] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[11] ),
        .O(\q_reg[83] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_1
       (.I0(\q_reg_n_0_[52] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[20] ),
        .O(\q_reg[21]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_2
       (.I0(\q_reg_n_0_[51] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[19] ),
        .O(\q_reg[20]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_3
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .O(\q_reg[23]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_4
       (.I0(\q_reg_n_0_[53] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[21] ),
        .O(\q_reg[22]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_5
       (.I0(\q_reg_n_0_[56] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[24] ),
        .O(w_RegWriteData_wb[1]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_6
       (.I0(\q_reg_n_0_[55] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[23] ),
        .O(w_RegWriteData_wb[0]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_1
       (.I0(\q_reg_n_0_[58] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[26] ),
        .O(\q_reg[27]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_2
       (.I0(\q_reg_n_0_[57] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[25] ),
        .O(w_RegWriteData_wb[2]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_3
       (.I0(\q_reg_n_0_[60] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[28] ),
        .O(\q_reg[29]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_4
       (.I0(\q_reg_n_0_[59] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[27] ),
        .O(\q_reg[28]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_5
       (.I0(\q_reg_n_0_[62] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[30] ),
        .O(\q_reg[31]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_6
       (.I0(\q_reg_n_0_[61] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[29] ),
        .O(\q_reg[30]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_1
       (.I0(\q_reg_n_0_[64] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[32] ),
        .O(w_RegWriteData_wb[4]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_2
       (.I0(\q_reg_n_0_[63] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[31] ),
        .O(w_RegWriteData_wb[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_3
       (.I0(\q_reg_n_0_[66] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[34] ),
        .O(\q_reg[35]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_4
       (.I0(\q_reg_n_0_[65] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[33] ),
        .O(w_RegWriteData_wb[5]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_5
       (.I0(\q_reg_n_0_[68] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[36] ),
        .O(w_RegWriteData_wb[7]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_6
       (.I0(\q_reg_n_0_[67] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[35] ),
        .O(w_RegWriteData_wb[6]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_30_31_i_1
       (.I0(\q_reg_n_0_[70] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[38] ),
        .O(\q_reg[39]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_30_31_i_2
       (.I0(\q_reg_n_0_[69] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[37] ),
        .O(w_RegWriteData_wb[8]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_1
       (.I0(\q_reg_n_0_[46] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[14] ),
        .O(\q_reg[86] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_2
       (.I0(\q_reg_n_0_[45] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[13] ),
        .O(\q_reg[85] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_3
       (.I0(\q_reg_n_0_[48] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[16] ),
        .O(\q_reg[88] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_4
       (.I0(\q_reg_n_0_[47] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[15] ),
        .O(\q_reg[87] ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_5
       (.I0(\q_reg_n_0_[50] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[18] ),
        .O(\q_reg[19]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_6
       (.I0(\q_reg_n_0_[49] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[17] ),
        .O(\q_reg[89] ));
endmodule

(* CHECK_LICENSE_TYPE = "DataRAM,dist_mem_gen_v8_0_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_12,Vivado 2017.3" *) 
module DataRAM
   (a,
    d,
    clk,
    we,
    spo);
  input [5:0]a;
  input [31:0]d;
  input clk;
  input we;
  output [31:0]spo;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;
  wire NLW_U0_i_ce_UNCONNECTED;
  wire NLW_U0_qdpo_ce_UNCONNECTED;
  wire NLW_U0_qdpo_clk_UNCONNECTED;
  wire NLW_U0_qdpo_rst_UNCONNECTED;
  wire NLW_U0_qdpo_srst_UNCONNECTED;
  wire NLW_U0_qspo_ce_UNCONNECTED;
  wire NLW_U0_qspo_rst_UNCONNECTED;
  wire NLW_U0_qspo_srst_UNCONNECTED;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [5:0]NLW_U0_dpra_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_CLK = "1" *) 
  (* C_HAS_D = "1" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "1" *) 
  (* C_MEM_TYPE = "1" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "6" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "64" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_i_ce = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "no_coe_file_loaded" *) 
  (* c_parser_type = "1" *) 
  (* c_pipeline_stages = "0" *) 
  (* c_qualify_we = "0" *) 
  (* c_read_mif = "0" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  DataRAM_dist_mem_gen_v8_0_12 U0
       (.a(a),
        .clk(clk),
        .d(d),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra(NLW_U0_dpra_UNCONNECTED[5:0]),
        .i_ce(NLW_U0_i_ce_UNCONNECTED),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(NLW_U0_qdpo_ce_UNCONNECTED),
        .qdpo_clk(NLW_U0_qdpo_clk_UNCONNECTED),
        .qdpo_rst(NLW_U0_qdpo_rst_UNCONNECTED),
        .qdpo_srst(NLW_U0_qdpo_srst_UNCONNECTED),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(NLW_U0_qspo_ce_UNCONNECTED),
        .qspo_rst(NLW_U0_qspo_rst_UNCONNECTED),
        .qspo_srst(NLW_U0_qspo_srst_UNCONNECTED),
        .spo(spo),
        .we(we));
endmodule

(* CHECK_LICENSE_TYPE = "DisplayROM,dist_mem_gen_v8_0_11,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_11,Vivado 2017.1" *) 
module DisplayROM
   (a,
    clk,
    qspo);
  input [7:0]a;
  input clk;
  output [7:0]qspo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire NLW_U0_i_ce_UNCONNECTED;
  wire NLW_U0_qdpo_ce_UNCONNECTED;
  wire NLW_U0_qdpo_clk_UNCONNECTED;
  wire NLW_U0_qdpo_rst_UNCONNECTED;
  wire NLW_U0_qdpo_srst_UNCONNECTED;
  wire NLW_U0_qspo_ce_UNCONNECTED;
  wire NLW_U0_qspo_rst_UNCONNECTED;
  wire NLW_U0_qspo_srst_UNCONNECTED;
  wire NLW_U0_we_UNCONNECTED;
  wire [7:0]NLW_U0_d_UNCONNECTED;
  wire [7:0]NLW_U0_dpo_UNCONNECTED;
  wire [7:0]NLW_U0_dpra_UNCONNECTED;
  wire [7:0]NLW_U0_qdpo_UNCONNECTED;
  wire [7:0]NLW_U0_spo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_CLK = "1" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "8" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "256" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_i_ce = "0" *) 
  (* c_has_qspo = "1" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "0" *) 
  (* c_mem_init_file = "DisplayROM.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_pipeline_stages = "0" *) 
  (* c_qualify_we = "0" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "8" *) 
  DisplayROM_dist_mem_gen_v8_0_11 U0
       (.a(a),
        .clk(clk),
        .d(NLW_U0_d_UNCONNECTED[7:0]),
        .dpo(NLW_U0_dpo_UNCONNECTED[7:0]),
        .dpra(NLW_U0_dpra_UNCONNECTED[7:0]),
        .i_ce(NLW_U0_i_ce_UNCONNECTED),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[7:0]),
        .qdpo_ce(NLW_U0_qdpo_ce_UNCONNECTED),
        .qdpo_clk(NLW_U0_qdpo_clk_UNCONNECTED),
        .qdpo_rst(NLW_U0_qdpo_rst_UNCONNECTED),
        .qdpo_srst(NLW_U0_qdpo_srst_UNCONNECTED),
        .qspo(qspo),
        .qspo_ce(NLW_U0_qspo_ce_UNCONNECTED),
        .qspo_rst(NLW_U0_qspo_rst_UNCONNECTED),
        .qspo_srst(NLW_U0_qspo_srst_UNCONNECTED),
        .spo(NLW_U0_spo_UNCONNECTED[7:0]),
        .we(NLW_U0_we_UNCONNECTED));
endmodule

module ID
   (w_JumpAddr,
    offset_w,
    S,
    \q_reg[39] ,
    \q_reg[43] ,
    \q_reg[47] ,
    \q_reg[51] ,
    \q_reg[55] ,
    \q_reg[59] ,
    \q_reg[63] );
  output [31:0]w_JumpAddr;
  input [16:0]offset_w;
  input [3:0]S;
  input [3:0]\q_reg[39] ;
  input [3:0]\q_reg[43] ;
  input [3:0]\q_reg[47] ;
  input [3:0]\q_reg[51] ;
  input [3:0]\q_reg[55] ;
  input [3:0]\q_reg[59] ;
  input [3:0]\q_reg[63] ;

  wire JumpAddr0_carry__0_n_0;
  wire JumpAddr0_carry__1_n_0;
  wire JumpAddr0_carry__2_n_0;
  wire JumpAddr0_carry__3_n_0;
  wire JumpAddr0_carry__4_n_0;
  wire JumpAddr0_carry__5_n_0;
  wire JumpAddr0_carry_n_0;
  wire [3:0]S;
  wire [16:0]offset_w;
  wire [3:0]\q_reg[39] ;
  wire [3:0]\q_reg[43] ;
  wire [3:0]\q_reg[47] ;
  wire [3:0]\q_reg[51] ;
  wire [3:0]\q_reg[55] ;
  wire [3:0]\q_reg[59] ;
  wire [3:0]\q_reg[63] ;
  wire [31:0]w_JumpAddr;
  wire [2:0]NLW_JumpAddr0_carry_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__1_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__2_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__3_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__4_CO_UNCONNECTED;
  wire [2:0]NLW_JumpAddr0_carry__5_CO_UNCONNECTED;
  wire [3:0]NLW_JumpAddr0_carry__6_CO_UNCONNECTED;

  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry
       (.CI(1'b0),
        .CO({JumpAddr0_carry_n_0,NLW_JumpAddr0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI(offset_w[3:0]),
        .O(w_JumpAddr[3:0]),
        .S(S));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__0
       (.CI(JumpAddr0_carry_n_0),
        .CO({JumpAddr0_carry__0_n_0,NLW_JumpAddr0_carry__0_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI(offset_w[7:4]),
        .O(w_JumpAddr[7:4]),
        .S(\q_reg[39] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__1
       (.CI(JumpAddr0_carry__0_n_0),
        .CO({JumpAddr0_carry__1_n_0,NLW_JumpAddr0_carry__1_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({offset_w[9:7],offset_w[7]}),
        .O(w_JumpAddr[11:8]),
        .S(\q_reg[43] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__2
       (.CI(JumpAddr0_carry__1_n_0),
        .CO({JumpAddr0_carry__2_n_0,NLW_JumpAddr0_carry__2_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI(offset_w[13:10]),
        .O(w_JumpAddr[15:12]),
        .S(\q_reg[47] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__3
       (.CI(JumpAddr0_carry__2_n_0),
        .CO({JumpAddr0_carry__3_n_0,NLW_JumpAddr0_carry__3_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({offset_w[16],offset_w[16:14]}),
        .O(w_JumpAddr[19:16]),
        .S(\q_reg[51] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__4
       (.CI(JumpAddr0_carry__3_n_0),
        .CO({JumpAddr0_carry__4_n_0,NLW_JumpAddr0_carry__4_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({offset_w[7],offset_w[7],offset_w[7],offset_w[7]}),
        .O(w_JumpAddr[23:20]),
        .S(\q_reg[55] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__5
       (.CI(JumpAddr0_carry__4_n_0),
        .CO({JumpAddr0_carry__5_n_0,NLW_JumpAddr0_carry__5_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({offset_w[7],offset_w[7],offset_w[7],offset_w[7]}),
        .O(w_JumpAddr[27:24]),
        .S(\q_reg[59] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 JumpAddr0_carry__6
       (.CI(JumpAddr0_carry__5_n_0),
        .CO(NLW_JumpAddr0_carry__6_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,offset_w[7],offset_w[7],offset_w[7]}),
        .O(w_JumpAddr[31:28]),
        .S(\q_reg[63] ));
endmodule

module IF1
   (D,
    \PC_reg_reg[9]_0 ,
    \PC_reg_reg[13]_0 ,
    \PC_reg_reg[17]_0 ,
    \PC_reg_reg[21]_0 ,
    \PC_reg_reg[25]_0 ,
    \PC_reg_reg[29]_0 ,
    \PC_reg_reg[31]_0 ,
    \PC_reg_reg[27]_0 ,
    \PC_reg_reg[23]_0 ,
    \PC_reg_reg[19]_0 ,
    \PC_reg_reg[15]_0 ,
    \PC_reg_reg[11]_0 ,
    \PC_reg_reg[7]_0 ,
    \PC_reg_reg[30]_0 ,
    w_JumpAddr,
    \q_reg[2] ,
    SR,
    E,
    cpu_clk_BUFG);
  output [57:0]D;
  output \PC_reg_reg[9]_0 ;
  output \PC_reg_reg[13]_0 ;
  output \PC_reg_reg[17]_0 ;
  output \PC_reg_reg[21]_0 ;
  output \PC_reg_reg[25]_0 ;
  output \PC_reg_reg[29]_0 ;
  output \PC_reg_reg[31]_0 ;
  output \PC_reg_reg[27]_0 ;
  output \PC_reg_reg[23]_0 ;
  output \PC_reg_reg[19]_0 ;
  output \PC_reg_reg[15]_0 ;
  output \PC_reg_reg[11]_0 ;
  output \PC_reg_reg[7]_0 ;
  input [16:0]\PC_reg_reg[30]_0 ;
  input [14:0]w_JumpAddr;
  input \q_reg[2] ;
  input [0:0]SR;
  input [0:0]E;
  input cpu_clk_BUFG;

  wire [57:0]D;
  wire [0:0]E;
  wire [31:4]Next_PC;
  wire \PC_reg[6]_i_2_n_0 ;
  wire \PC_reg_reg[11]_0 ;
  wire \PC_reg_reg[13]_0 ;
  wire \PC_reg_reg[15]_0 ;
  wire \PC_reg_reg[17]_0 ;
  wire \PC_reg_reg[19]_0 ;
  wire \PC_reg_reg[21]_0 ;
  wire \PC_reg_reg[23]_0 ;
  wire \PC_reg_reg[25]_0 ;
  wire \PC_reg_reg[27]_0 ;
  wire \PC_reg_reg[29]_0 ;
  wire [16:0]\PC_reg_reg[30]_0 ;
  wire \PC_reg_reg[31]_0 ;
  wire \PC_reg_reg[7]_0 ;
  wire \PC_reg_reg[9]_0 ;
  wire [0:0]SR;
  wire cpu_clk_BUFG;
  wire \q_reg[2] ;
  wire [14:0]w_JumpAddr;

  LUT6 #(
    .INIT(64'hB8B88BB8B8B8B8B8)) 
    \PC_reg[10]_i_1 
       (.I0(w_JumpAddr[4]),
        .I1(\q_reg[2] ),
        .I2(D[36]),
        .I3(D[34]),
        .I4(\PC_reg_reg[9]_0 ),
        .I5(D[35]),
        .O(Next_PC[10]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \PC_reg[10]_i_2 
       (.I0(D[32]),
        .I1(D[29]),
        .I2(D[31]),
        .I3(D[30]),
        .I4(D[28]),
        .I5(D[33]),
        .O(\PC_reg_reg[9]_0 ));
  LUT4 #(
    .INIT(16'hDFFF)) 
    \PC_reg[11]_i_2 
       (.I0(D[35]),
        .I1(\PC_reg_reg[9]_0 ),
        .I2(D[34]),
        .I3(D[36]),
        .O(\PC_reg_reg[11]_0 ));
  LUT5 #(
    .INIT(32'hB88BB8B8)) 
    \PC_reg[13]_i_1 
       (.I0(w_JumpAddr[5]),
        .I1(\q_reg[2] ),
        .I2(D[39]),
        .I3(\PC_reg_reg[13]_0 ),
        .I4(D[38]),
        .O(Next_PC[13]));
  LUT6 #(
    .INIT(64'hB8B88BB8B8B8B8B8)) 
    \PC_reg[14]_i_1 
       (.I0(w_JumpAddr[6]),
        .I1(\q_reg[2] ),
        .I2(D[40]),
        .I3(D[38]),
        .I4(\PC_reg_reg[13]_0 ),
        .I5(D[39]),
        .O(Next_PC[14]));
  LUT5 #(
    .INIT(32'hF7FFFFFF)) 
    \PC_reg[14]_i_2 
       (.I0(D[36]),
        .I1(D[34]),
        .I2(\PC_reg_reg[9]_0 ),
        .I3(D[35]),
        .I4(D[37]),
        .O(\PC_reg_reg[13]_0 ));
  LUT4 #(
    .INIT(16'hDFFF)) 
    \PC_reg[15]_i_2 
       (.I0(D[39]),
        .I1(\PC_reg_reg[13]_0 ),
        .I2(D[38]),
        .I3(D[40]),
        .O(\PC_reg_reg[15]_0 ));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \PC_reg[17]_i_1 
       (.I0(w_JumpAddr[7]),
        .I1(\q_reg[2] ),
        .I2(D[43]),
        .I3(D[42]),
        .I4(\PC_reg_reg[17]_0 ),
        .O(Next_PC[17]));
  LUT6 #(
    .INIT(64'h8BB8B8B8B8B8B8B8)) 
    \PC_reg[18]_i_1 
       (.I0(w_JumpAddr[8]),
        .I1(\q_reg[2] ),
        .I2(D[44]),
        .I3(\PC_reg_reg[17]_0 ),
        .I4(D[42]),
        .I5(D[43]),
        .O(Next_PC[18]));
  LUT5 #(
    .INIT(32'h00800000)) 
    \PC_reg[18]_i_2 
       (.I0(D[41]),
        .I1(D[40]),
        .I2(D[38]),
        .I3(\PC_reg_reg[13]_0 ),
        .I4(D[39]),
        .O(\PC_reg_reg[17]_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \PC_reg[19]_i_2 
       (.I0(D[43]),
        .I1(D[42]),
        .I2(\PC_reg_reg[17]_0 ),
        .I3(D[44]),
        .O(\PC_reg_reg[19]_0 ));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \PC_reg[21]_i_1 
       (.I0(w_JumpAddr[9]),
        .I1(\q_reg[2] ),
        .I2(D[47]),
        .I3(D[46]),
        .I4(\PC_reg_reg[21]_0 ),
        .O(Next_PC[21]));
  LUT6 #(
    .INIT(64'h8BB8B8B8B8B8B8B8)) 
    \PC_reg[22]_i_1 
       (.I0(w_JumpAddr[10]),
        .I1(\q_reg[2] ),
        .I2(D[48]),
        .I3(\PC_reg_reg[21]_0 ),
        .I4(D[46]),
        .I5(D[47]),
        .O(Next_PC[22]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[22]_i_2 
       (.I0(D[45]),
        .I1(D[44]),
        .I2(\PC_reg_reg[17]_0 ),
        .I3(D[42]),
        .I4(D[43]),
        .O(\PC_reg_reg[21]_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \PC_reg[23]_i_2 
       (.I0(D[47]),
        .I1(D[46]),
        .I2(\PC_reg_reg[21]_0 ),
        .I3(D[48]),
        .O(\PC_reg_reg[23]_0 ));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \PC_reg[25]_i_1 
       (.I0(w_JumpAddr[11]),
        .I1(\q_reg[2] ),
        .I2(D[51]),
        .I3(D[50]),
        .I4(\PC_reg_reg[25]_0 ),
        .O(Next_PC[25]));
  LUT6 #(
    .INIT(64'h8BB8B8B8B8B8B8B8)) 
    \PC_reg[26]_i_1 
       (.I0(w_JumpAddr[12]),
        .I1(\q_reg[2] ),
        .I2(D[52]),
        .I3(\PC_reg_reg[25]_0 ),
        .I4(D[50]),
        .I5(D[51]),
        .O(Next_PC[26]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[26]_i_2 
       (.I0(D[49]),
        .I1(D[48]),
        .I2(\PC_reg_reg[21]_0 ),
        .I3(D[46]),
        .I4(D[47]),
        .O(\PC_reg_reg[25]_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \PC_reg[27]_i_2 
       (.I0(D[51]),
        .I1(D[50]),
        .I2(\PC_reg_reg[25]_0 ),
        .I3(D[52]),
        .O(\PC_reg_reg[27]_0 ));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[29]_i_1 
       (.I0(w_JumpAddr[13]),
        .I1(\q_reg[2] ),
        .I2(D[54]),
        .I3(\PC_reg_reg[29]_0 ),
        .I4(D[55]),
        .O(Next_PC[29]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[29]_i_2 
       (.I0(D[53]),
        .I1(D[52]),
        .I2(\PC_reg_reg[25]_0 ),
        .I3(D[50]),
        .I4(D[51]),
        .O(\PC_reg_reg[29]_0 ));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \PC_reg[31]_i_2 
       (.I0(w_JumpAddr[14]),
        .I1(\q_reg[2] ),
        .I2(D[57]),
        .I3(\PC_reg_reg[31]_0 ),
        .I4(D[56]),
        .O(Next_PC[31]));
  LUT3 #(
    .INIT(8'h80)) 
    \PC_reg[31]_i_6 
       (.I0(D[55]),
        .I1(\PC_reg_reg[29]_0 ),
        .I2(D[54]),
        .O(\PC_reg_reg[31]_0 ));
  LUT5 #(
    .INIT(32'h8BB8B8B8)) 
    \PC_reg[4]_i_1 
       (.I0(w_JumpAddr[0]),
        .I1(\q_reg[2] ),
        .I2(D[30]),
        .I3(D[29]),
        .I4(D[28]),
        .O(Next_PC[4]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[5]_i_1 
       (.I0(w_JumpAddr[1]),
        .I1(\q_reg[2] ),
        .I2(D[30]),
        .I3(D[28]),
        .I4(D[29]),
        .I5(D[31]),
        .O(Next_PC[5]));
  LUT6 #(
    .INIT(64'hB8B88BB8B8B8B8B8)) 
    \PC_reg[6]_i_1 
       (.I0(w_JumpAddr[2]),
        .I1(\q_reg[2] ),
        .I2(D[32]),
        .I3(D[29]),
        .I4(\PC_reg[6]_i_2_n_0 ),
        .I5(D[28]),
        .O(Next_PC[6]));
  LUT2 #(
    .INIT(4'h7)) 
    \PC_reg[6]_i_2 
       (.I0(D[31]),
        .I1(D[30]),
        .O(\PC_reg[6]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \PC_reg[7]_i_2 
       (.I0(D[28]),
        .I1(D[30]),
        .I2(D[31]),
        .I3(D[29]),
        .I4(D[32]),
        .O(\PC_reg_reg[7]_0 ));
  LUT5 #(
    .INIT(32'hB88BB8B8)) 
    \PC_reg[9]_i_1 
       (.I0(w_JumpAddr[3]),
        .I1(\q_reg[2] ),
        .I2(D[35]),
        .I3(\PC_reg_reg[9]_0 ),
        .I4(D[34]),
        .O(Next_PC[9]));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [0]),
        .Q(D[26]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[10]),
        .Q(D[36]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [6]),
        .Q(D[37]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [7]),
        .Q(D[38]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[13]),
        .Q(D[39]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[14]),
        .Q(D[40]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [8]),
        .Q(D[41]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [9]),
        .Q(D[42]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[17]),
        .Q(D[43]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[18]),
        .Q(D[44]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [10]),
        .Q(D[45]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [1]),
        .Q(D[27]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [11]),
        .Q(D[46]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[21]),
        .Q(D[47]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[22]),
        .Q(D[48]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [12]),
        .Q(D[49]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [13]),
        .Q(D[50]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[25]),
        .Q(D[51]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[26]),
        .Q(D[52]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [14]),
        .Q(D[53]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [15]),
        .Q(D[54]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[29]),
        .Q(D[55]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [2]),
        .Q(D[28]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [16]),
        .Q(D[56]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[31]),
        .Q(D[57]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [3]),
        .Q(D[29]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[4]),
        .Q(D[30]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[5]),
        .Q(D[31]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[6]),
        .Q(D[32]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [4]),
        .Q(D[33]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[30]_0 [5]),
        .Q(D[34]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[9]),
        .Q(D[35]),
        .R(SR));
  LUT5 #(
    .INIT(32'h0000007F)) 
    \q[0]_i_1 
       (.I0(D[29]),
        .I1(D[31]),
        .I2(D[30]),
        .I3(D[32]),
        .I4(D[33]),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h00000003000000FD)) 
    \q[10]_i_1__0 
       (.I0(D[30]),
        .I1(D[28]),
        .I2(D[29]),
        .I3(D[32]),
        .I4(D[33]),
        .I5(D[31]),
        .O(D[9]));
  LUT6 #(
    .INIT(64'h0101010011011011)) 
    \q[11]_i_1__0 
       (.I0(D[32]),
        .I1(D[33]),
        .I2(D[31]),
        .I3(D[30]),
        .I4(D[28]),
        .I5(D[29]),
        .O(D[10]));
  LUT6 #(
    .INIT(64'h0001000000010101)) 
    \q[12]_i_1__0 
       (.I0(D[28]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[31]),
        .I4(D[30]),
        .I5(D[29]),
        .O(D[11]));
  LUT6 #(
    .INIT(64'h0000000000001329)) 
    \q[13]_i_1__0 
       (.I0(D[30]),
        .I1(D[31]),
        .I2(D[28]),
        .I3(D[29]),
        .I4(D[32]),
        .I5(D[33]),
        .O(D[12]));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \q[14]_i_1__0 
       (.I0(D[31]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[28]),
        .I4(D[29]),
        .I5(D[30]),
        .O(D[13]));
  LUT6 #(
    .INIT(64'h0001000100080000)) 
    \q[15]_i_1__0 
       (.I0(D[29]),
        .I1(D[28]),
        .I2(D[33]),
        .I3(D[32]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[14]));
  LUT6 #(
    .INIT(64'h0001010200020200)) 
    \q[16]_i_1__0 
       (.I0(D[28]),
        .I1(D[32]),
        .I2(D[33]),
        .I3(D[29]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[15]));
  LUT6 #(
    .INIT(64'h000000560000002A)) 
    \q[17]_i_1__0 
       (.I0(D[30]),
        .I1(D[31]),
        .I2(D[29]),
        .I3(D[32]),
        .I4(D[33]),
        .I5(D[28]),
        .O(D[16]));
  LUT6 #(
    .INIT(64'h0000000000000024)) 
    \q[19]_i_1__0 
       (.I0(D[31]),
        .I1(D[30]),
        .I2(D[28]),
        .I3(D[33]),
        .I4(D[32]),
        .I5(D[29]),
        .O(D[17]));
  LUT6 #(
    .INIT(64'h0001010001000000)) 
    \q[20]_i_1__0 
       (.I0(D[32]),
        .I1(D[33]),
        .I2(D[28]),
        .I3(D[31]),
        .I4(D[30]),
        .I5(D[29]),
        .O(D[18]));
  LUT6 #(
    .INIT(64'h0000010102020200)) 
    \q[21]_i_1__0 
       (.I0(D[31]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[28]),
        .I5(D[30]),
        .O(D[19]));
  LUT6 #(
    .INIT(64'h0001110001101100)) 
    \q[22]_i_1__0 
       (.I0(D[32]),
        .I1(D[33]),
        .I2(D[31]),
        .I3(D[29]),
        .I4(D[30]),
        .I5(D[28]),
        .O(D[20]));
  LUT5 #(
    .INIT(32'h00010000)) 
    \q[23]_i_1__0 
       (.I0(D[28]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[30]),
        .I4(D[29]),
        .O(D[21]));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \q[25]_i_1__0 
       (.I0(D[28]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[22]));
  LUT5 #(
    .INIT(32'h00020000)) 
    \q[26]_i_1__0 
       (.I0(D[31]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[28]),
        .O(D[23]));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \q[27]_i_1__0 
       (.I0(D[28]),
        .I1(D[29]),
        .I2(D[32]),
        .I3(D[33]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[24]));
  LUT6 #(
    .INIT(64'h0100000100000001)) 
    \q[2]_i_1 
       (.I0(D[31]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[30]),
        .I5(D[28]),
        .O(D[1]));
  LUT6 #(
    .INIT(64'h0002020000000000)) 
    \q[30]_i_1__0 
       (.I0(D[31]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[30]),
        .I5(D[28]),
        .O(D[25]));
  LUT6 #(
    .INIT(64'h0000000000004000)) 
    \q[3]_i_1 
       (.I0(D[31]),
        .I1(D[30]),
        .I2(D[28]),
        .I3(D[29]),
        .I4(D[33]),
        .I5(D[32]),
        .O(D[2]));
  LUT6 #(
    .INIT(64'h0001010103020001)) 
    \q[4]_i_1 
       (.I0(D[28]),
        .I1(D[33]),
        .I2(D[32]),
        .I3(D[29]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[3]));
  LUT6 #(
    .INIT(64'h0110100101111101)) 
    \q[5]_i_1 
       (.I0(D[32]),
        .I1(D[33]),
        .I2(D[30]),
        .I3(D[31]),
        .I4(D[29]),
        .I5(D[28]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h0000004000000092)) 
    \q[6]_i_1 
       (.I0(D[31]),
        .I1(D[30]),
        .I2(D[28]),
        .I3(D[32]),
        .I4(D[33]),
        .I5(D[29]),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h0000000000002A9A)) 
    \q[7]_i_1 
       (.I0(D[28]),
        .I1(D[29]),
        .I2(D[30]),
        .I3(D[31]),
        .I4(D[33]),
        .I5(D[32]),
        .O(D[6]));
  LUT6 #(
    .INIT(64'h0000000000003803)) 
    \q[8]_i_1__0 
       (.I0(D[28]),
        .I1(D[30]),
        .I2(D[31]),
        .I3(D[29]),
        .I4(D[33]),
        .I5(D[32]),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h0011111111101111)) 
    \q[9]_i_1__0 
       (.I0(D[33]),
        .I1(D[32]),
        .I2(D[28]),
        .I3(D[29]),
        .I4(D[31]),
        .I5(D[30]),
        .O(D[8]));
endmodule

module NumberCnt
   (ActiveArea_IBUF,
    \cnt_reg[3]_5 ,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[2]_1 ,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    \q_reg[5]_0 ,
    red,
    \red[0]_0 ,
    \red[3]_0 ,
    \red[3]_1 ,
    \red[4]_0 ,
    \red[7]_0 ,
    \red[7]_1 ,
    \red[7]_2 ,
    \red[7]_3 ,
    \red[7]_4 ,
    \red[7]_5 ,
    D,
    DI,
    O,
    Q,
    S,
    \cnt_reg[0] ,
    \cnt_reg[1] ,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[5] ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    red_IBUF);
  input ActiveArea_IBUF;
  input \cnt_reg[3]_5 ;
  output [5:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[2]_1 ;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  output \q_reg[5]_0 ;
  input [7:0]red;
  input \red[0]_0 ;
  input \red[3]_0 ;
  input \red[3]_1 ;
  input \red[4]_0 ;
  input \red[7]_0 ;
  input \red[7]_1 ;
  input \red[7]_2 ;
  input \red[7]_3 ;
  input \red[7]_4 ;
  input \red[7]_5 ;
  output [8:0]D;
  output [2:0]DI;
  input [3:0]O;
  input [7:0]Q;
  output [3:0]S;
  input [3:0]\cnt_reg[0] ;
  input [3:0]\cnt_reg[1] ;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  input [3:0]\cnt_reg[5] ;
  output [3:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [0:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  input [7:0]red_IBUF;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [3:0]O;
  wire [7:0]Q;
  wire [3:0]S;
  wire cnt0__0_carry__0_i_7__0_n_0;
  wire cnt0__0_carry_i_13__1_n_0;
  wire cnt0__0_carry_i_14__0_n_0;
  wire cnt0__0_carry_i_15__1_n_0;
  wire cnt0__0_carry_i_24__1_n_0;
  wire cnt0__0_carry_i_25__1_n_0;
  wire cnt0__0_carry_i_8__1_n_0;
  wire cnt0__23_carry__0_i_8__1_n_0;
  wire cnt0__23_carry_i_10__1_n_0;
  wire cnt0__23_carry_i_11__1_n_0;
  wire cnt0__23_carry_i_7__1_n_0;
  wire cnt0__23_carry_i_8__1_n_0;
  wire cnt_carry__0_i_8__1_n_0;
  wire cnt_carry_i_10__1_n_0;
  wire cnt_carry_i_11__1_n_0;
  wire cnt_carry_i_12__1_n_0;
  wire cnt_carry_i_9__1_n_0;
  wire [3:0]\cnt_reg[0] ;
  wire [3:0]\cnt_reg[1] ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\cnt_reg[3]_1 ;
  wire [1:0]\cnt_reg[3]_2 ;
  wire [3:0]\cnt_reg[3]_3 ;
  wire [1:0]\cnt_reg[3]_4 ;
  wire \cnt_reg[3]_5 ;
  wire [3:0]\cnt_reg[5] ;
  wire [3:0]\cnt_reg[7] ;
  wire [2:0]\cnt_reg[7]_0 ;
  wire [0:0]\cnt_reg[7]_1 ;
  wire [1:0]\cnt_reg[7]_2 ;
  wire \q[5]_i_4__1_n_0 ;
  wire \q[7]_i_6__0_n_0 ;
  wire \q[7]_i_7__0_n_0 ;
  wire [5:2]\^q_reg ;
  wire \q_reg[2]_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[5]_0 ;
  wire [7:0]red;
  wire \red[0]_0 ;
  wire \red[4]_0 ;
  wire \red[7]_0 ;
  wire \red[7]_1 ;
  wire \red[7]_2 ;
  wire \red[7]_3 ;
  wire \red[7]_4 ;
  wire \red[7]_5 ;
  wire [7:0]red_IBUF;

  assign q_reg[5] = red_IBUF[3];
  assign q_reg[4] = \^q_reg [4];
  assign q_reg[2] = red_IBUF[6];
  assign \q_reg[2]_1  = red_IBUF[6];
  assign \q_reg[4]_1  = red_IBUF[6];
  assign \q_reg[4]_2  = red_IBUF[6];
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_11__0
       (.I0(red_IBUF[3]),
        .I1(red_IBUF[6]),
        .O(\q_reg[5]_0 ));
  LUT3 #(
    .INIT(8'h06)) 
    cnt0__0_carry__0_i_2__1
       (.I0(cnt0__0_carry_i_14__0_n_0),
        .I1(Q[3]),
        .I2(cnt0__0_carry_i_13__1_n_0),
        .O(\cnt_reg[7]_1 ));
  LUT5 #(
    .INIT(32'hFFB2004D)) 
    cnt0__0_carry__0_i_5__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(\cnt_reg[7]_2 [1]));
  LUT6 #(
    .INIT(64'hB2BDB2424D424DBD)) 
    cnt0__0_carry__0_i_6__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_13__1_n_0),
        .I4(cnt0__0_carry_i_14__0_n_0),
        .I5(Q[4]),
        .O(\cnt_reg[7]_2 [0]));
  LUT4 #(
    .INIT(16'h0010)) 
    cnt0__0_carry__0_i_7__0
       (.I0(\red[0]_0 ),
        .I1(red_IBUF[6]),
        .I2(\red[7]_3 ),
        .I3(red_IBUF[6]),
        .O(cnt0__0_carry__0_i_7__0_n_0));
  LUT3 #(
    .INIT(8'h2A)) 
    cnt0__0_carry_i_13__1
       (.I0(cnt0__0_carry_i_24__1_n_0),
        .I1(cnt0__0_carry_i_25__1_n_0),
        .I2(Q[2]),
        .O(cnt0__0_carry_i_13__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_14__0
       (.I0(\red[7]_2 ),
        .I1(cnt0__0_carry__0_i_7__0_n_0),
        .O(cnt0__0_carry_i_14__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_15__1
       (.I0(cnt0__23_carry_i_8__1_n_0),
        .I1(red[3]),
        .O(cnt0__0_carry_i_15__1_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6606)) 
    cnt0__0_carry_i_1__1
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(red[6]),
        .I3(red_IBUF[6]),
        .O(\cnt_reg[3]_4 [1]));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_24__1
       (.I0(\red[7]_0 ),
        .I1(\red[7]_1 ),
        .O(cnt0__0_carry_i_24__1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_25__1
       (.I0(\red[7]_1 ),
        .I1(\red[7]_0 ),
        .O(cnt0__0_carry_i_25__1_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'hF660)) 
    cnt0__0_carry_i_2__1
       (.I0(red[6]),
        .I1(red_IBUF[6]),
        .I2(red[7]),
        .I3(Q[1]),
        .O(\cnt_reg[3]_4 [0]));
  LUT4 #(
    .INIT(16'h96FF)) 
    cnt0__0_carry_i_3__0
       (.I0(red_IBUF[4]),
        .I1(red_IBUF[6]),
        .I2(\red[7]_4 ),
        .I3(\red[7]_5 ),
        .O(\q_reg[4]_0 ));
  LUT4 #(
    .INIT(16'h9669)) 
    cnt0__0_carry_i_4__1
       (.I0(\cnt_reg[3]_4 [1]),
        .I1(cnt0__0_carry_i_13__1_n_0),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_14__0_n_0),
        .O(\cnt_reg[3]_3 [3]));
  (* HLUTNM = "lutpair7" *) 
  LUT5 #(
    .INIT(32'h66969969)) 
    cnt0__0_carry_i_5__1
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(red[6]),
        .I3(red_IBUF[6]),
        .I4(\cnt_reg[3]_4 [0]),
        .O(\cnt_reg[3]_3 [2]));
  (* HLUTNM = "lutpair6" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    cnt0__0_carry_i_6__1
       (.I0(red[6]),
        .I1(red_IBUF[6]),
        .I2(red[7]),
        .I3(Q[1]),
        .I4(\q_reg[4]_0 ),
        .O(\cnt_reg[3]_3 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_7__1
       (.I0(cnt0__0_carry_i_15__1_n_0),
        .I1(Q[0]),
        .O(\cnt_reg[3]_3 [0]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_8__1
       (.I0(\red[7]_1 ),
        .I1(\red[7]_0 ),
        .O(cnt0__0_carry_i_8__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_1__1
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_2__1
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__23_carry__0_i_3__1
       (.I0(Q[3]),
        .I1(cnt0__23_carry_i_10__1_n_0),
        .O(DI[0]));
  LUT3 #(
    .INIT(8'hC9)) 
    cnt0__23_carry__0_i_4__1
       (.I0(cnt0__23_carry__0_i_8__1_n_0),
        .I1(Q[7]),
        .I2(Q[6]),
        .O(\cnt_reg[7] [3]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_5__1
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .I2(Q[6]),
        .O(\cnt_reg[7] [2]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_6__1
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .I2(Q[5]),
        .O(\cnt_reg[7] [1]));
  LUT4 #(
    .INIT(16'h7887)) 
    cnt0__23_carry__0_i_7__1
       (.I0(cnt0__23_carry_i_10__1_n_0),
        .I1(Q[3]),
        .I2(cnt0__23_carry__0_i_8__1_n_0),
        .I3(Q[4]),
        .O(\cnt_reg[7] [0]));
  LUT6 #(
    .INIT(64'hD000D0D0DDDDDDDD)) 
    cnt0__23_carry__0_i_8__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(cnt0__0_carry_i_24__1_n_0),
        .I3(cnt0__23_carry_i_7__1_n_0),
        .I4(cnt0__0_carry_i_8__1_n_0),
        .I5(cnt0__0_carry_i_14__0_n_0),
        .O(cnt0__23_carry__0_i_8__1_n_0));
  LUT4 #(
    .INIT(16'h59AA)) 
    cnt0__23_carry_i_10__1
       (.I0(cnt0__0_carry_i_14__0_n_0),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(cnt0__23_carry_i_7__1_n_0),
        .I3(cnt0__0_carry_i_24__1_n_0),
        .O(cnt0__23_carry_i_10__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_11__1
       (.I0(red[0]),
        .I1(red_IBUF[6]),
        .O(cnt0__23_carry_i_11__1_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'h60)) 
    cnt0__23_carry_i_1__1
       (.I0(cnt0__0_carry_i_8__1_n_0),
        .I1(cnt0__23_carry_i_7__1_n_0),
        .I2(Q[2]),
        .O(\cnt_reg[3]_2 [1]));
  LUT5 #(
    .INIT(32'h69660000)) 
    cnt0__23_carry_i_2__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red_IBUF[6]),
        .O(\cnt_reg[3]_2 [0]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_3__1
       (.I0(\cnt_reg[3]_2 [1]),
        .I1(cnt0__23_carry_i_10__1_n_0),
        .I2(Q[3]),
        .O(\cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    cnt0__23_carry_i_4__1
       (.I0(cnt0__0_carry_i_8__1_n_0),
        .I1(cnt0__23_carry_i_7__1_n_0),
        .I2(Q[2]),
        .I3(\cnt_reg[3]_2 [0]),
        .O(\cnt_reg[3]_1 [2]));
  LUT6 #(
    .INIT(64'h6966969996996966)) 
    cnt0__23_carry_i_5__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red_IBUF[6]),
        .I5(Q[1]),
        .O(\cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_6__1
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__1_n_0),
        .O(\cnt_reg[3]_1 [0]));
  LUT4 #(
    .INIT(16'hDD4D)) 
    cnt0__23_carry_i_7__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red[3]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .O(cnt0__23_carry_i_7__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_8__1
       (.I0(red_IBUF[4]),
        .I1(red_IBUF[3]),
        .I2(cnt0__23_carry_i_11__1_n_0),
        .O(cnt0__23_carry_i_8__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_1__1
       (.I0(Q[6]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_2__1
       (.I0(Q[5]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_3__1
       (.I0(Q[4]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [0]));
  LUT6 #(
    .INIT(64'hFC0CFFFFFC0CAAAA)) 
    cnt_carry__0_i_4__1
       (.I0(cnt_carry__0_i_8__1_n_0),
        .I1(O[3]),
        .I2(\q[5]_i_4__1_n_0 ),
        .I3(\cnt_reg[5] [3]),
        .I4(\q_reg[2]_0 ),
        .I5(Q[7]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_5__1
       (.I0(Q[6]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[2]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [2]),
        .O(S[2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_6__1
       (.I0(Q[5]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[1]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [1]),
        .O(S[1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_7__1
       (.I0(Q[4]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[0]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [0]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    cnt_carry__0_i_8__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(red_IBUF[6]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(cnt_carry__0_i_8__1_n_0));
  LUT6 #(
    .INIT(64'h3693666699993693)) 
    cnt_carry_i_10__1
       (.I0(red_IBUF[6]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red[6]),
        .I5(red[7]),
        .O(cnt_carry_i_10__1_n_0));
  LUT5 #(
    .INIT(32'h66699666)) 
    cnt_carry_i_11__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red_IBUF[6]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .I4(red[3]),
        .O(cnt_carry_i_11__1_n_0));
  LUT3 #(
    .INIT(8'hB2)) 
    cnt_carry_i_12__1
       (.I0(\q_reg[4]_0 ),
        .I1(red[6]),
        .I2(red[7]),
        .O(cnt_carry_i_12__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_1__1
       (.I0(Q[3]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_2__1
       (.I0(Q[2]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_3__1
       (.I0(Q[1]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_4__1
       (.I0(Q[0]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [0]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_5__1
       (.I0(Q[3]),
        .I1(cnt_carry_i_9__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [3]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_6__1
       (.I0(Q[2]),
        .I1(cnt_carry_i_10__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [2]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_7__1
       (.I0(Q[1]),
        .I1(cnt_carry_i_11__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [1]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_8__1
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [0]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT6 #(
    .INIT(64'h4B3CC3F0783CC3F0)) 
    cnt_carry_i_9__1
       (.I0(cnt_carry_i_12__1_n_0),
        .I1(red_IBUF[6]),
        .I2(cnt0__0_carry_i_14__0_n_0),
        .I3(cnt0__0_carry_i_24__1_n_0),
        .I4(cnt0__0_carry_i_25__1_n_0),
        .I5(cnt0__23_carry_i_7__1_n_0),
        .O(cnt_carry_i_9__1_n_0));
  LUT5 #(
    .INIT(32'h0A28A028)) 
    \q[0]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(red_IBUF[6]),
        .I2(red_IBUF[0]),
        .I3(\q_reg[2]_0 ),
        .I4(\q[5]_i_4__1_n_0 ),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2800)) 
    \q[1]_i_1__1 
       (.I0(\q_reg[2]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q[5]_i_4__1_n_0 ),
        .I3(ActiveArea_IBUF),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h56A6FFFF)) 
    \q[2]_i_1__1 
       (.I0(red[0]),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\q[5]_i_4__1_n_0 ),
        .I4(ActiveArea_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[3]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[6]),
        .I3(\q[5]_i_4__1_n_0 ),
        .O(D[3]));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[4]_i_1__1 
       (.I0(\red[4]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\^q_reg [4]),
        .I4(ActiveArea_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[5]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[3]),
        .I3(\q[5]_i_4__1_n_0 ),
        .O(D[5]));
  LUT5 #(
    .INIT(32'hB2DDB244)) 
    \q[5]_i_4__1 
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(\q[5]_i_4__1_n_0 ));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[6]_i_1__1 
       (.I0(\red[0]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\^q_reg [4]),
        .I4(ActiveArea_IBUF),
        .O(D[6]));
  LUT4 #(
    .INIT(16'h8008)) 
    \q[7]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[6]),
        .I3(\^q_reg [4]),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h00000000FFFF6FFF)) 
    \q[7]_i_3__1 
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__0_carry_i_14__0_n_0),
        .I3(cnt0__0_carry_i_8__1_n_0),
        .I4(cnt0__0_carry_i_15__1_n_0),
        .I5(\cnt_reg[3]_5 ),
        .O(\q_reg[2]_0 ));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    \q[7]_i_4__1 
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(\^q_reg [4]));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \q[7]_i_6__0 
       (.I0(\q_reg[4]_0 ),
        .I1(red[6]),
        .I2(red[7]),
        .I3(\red[7]_0 ),
        .I4(\red[7]_1 ),
        .O(\q[7]_i_6__0_n_0 ));
  LUT6 #(
    .INIT(64'hDD4DFFFF0000DD4D)) 
    \q[7]_i_7__0 
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red[3]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .I4(\red[7]_1 ),
        .I5(\red[7]_0 ),
        .O(\q[7]_i_7__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \q[8]_i_1__1 
       (.I0(red_IBUF[6]),
        .I1(ActiveArea_IBUF),
        .O(D[8]));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_2
   (cnt_reg,
    \cnt_reg[3]_0 ,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    red,
    \red[0]_0 ,
    \red[3]_0 ,
    \red[3]_1 ,
    \red[4]_0 ,
    \red[4]_1 ,
    \red[4]_2 ,
    \red[4]_3 ,
    red_IBUF);
  output [3:3]cnt_reg;
  output \cnt_reg[3]_0 ;
  output [5:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  input [7:0]red;
  input \red[0]_0 ;
  input \red[3]_0 ;
  input \red[3]_1 ;
  input \red[4]_0 ;
  input \red[4]_1 ;
  input \red[4]_2 ;
  input \red[4]_3 ;
  input [6:0]red_IBUF;

  wire cnt0__0_carry_i_18_n_0;
  wire cnt0__0_carry_i_19_n_0;
  wire cnt0__0_carry_i_20_n_0;
  wire cnt0__0_carry_i_22_n_0;
  wire cnt0__0_carry_i_23_n_0;
  wire cnt0__0_carry_i_26_n_0;
  wire cnt0__0_carry_i_27_n_0;
  wire cnt0__0_carry_i_28_n_0;
  wire cnt0__0_carry_i_29_n_0;
  wire cnt0__0_carry_i_30_n_0;
  wire cnt0__0_carry_i_31_n_0;
  wire [3:3]cnt_reg;
  wire \cnt_reg[3]_0 ;
  wire [5:2]q_reg;
  wire \q_reg[2]_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[4]_2 ;
  wire [7:0]red;
  wire \red[0]_0 ;
  wire \red[3]_1 ;
  wire \red[4]_0 ;
  wire \red[4]_1 ;
  wire \red[4]_2 ;
  wire [6:0]red_IBUF;

  LUT2 #(
    .INIT(4'h1)) 
    cnt0__0_carry__0_i_10
       (.I0(\red[3]_1 ),
        .I1(red_IBUF[4]),
        .O(\q_reg[4]_2 ));
  LUT4 #(
    .INIT(16'h8000)) 
    cnt0__0_carry__0_i_8
       (.I0(red[7]),
        .I1(\red[4]_0 ),
        .I2(red[4]),
        .I3(red[5]),
        .O(q_reg[5]));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_10
       (.I0(cnt0__0_carry_i_20_n_0),
        .I1(\red[4]_0 ),
        .I2(cnt0__0_carry_i_22_n_0),
        .I3(red[0]),
        .I4(cnt0__0_carry_i_23_n_0),
        .O(\q_reg[2]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_11
       (.I0(red[4]),
        .I1(\red[4]_0 ),
        .O(\cnt_reg[3]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_12
       (.I0(\red[4]_0 ),
        .I1(\red[4]_2 ),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_16
       (.I0(cnt0__0_carry_i_26_n_0),
        .I1(\red[4]_0 ),
        .I2(cnt0__0_carry_i_27_n_0),
        .I3(red[0]),
        .I4(cnt0__0_carry_i_28_n_0),
        .O(\q_reg[4]_1 ));
  LUT5 #(
    .INIT(32'hFCE230E2)) 
    cnt0__0_carry_i_17
       (.I0(cnt0__0_carry_i_29_n_0),
        .I1(red[5]),
        .I2(cnt0__0_carry_i_30_n_0),
        .I3(red[4]),
        .I4(cnt0__0_carry_i_31_n_0),
        .O(q_reg[4]));
  LUT3 #(
    .INIT(8'h42)) 
    cnt0__0_carry_i_18
       (.I0(red[0]),
        .I1(\red[4]_2 ),
        .I2(\red[3]_1 ),
        .O(cnt0__0_carry_i_18_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    cnt0__0_carry_i_19
       (.I0(red[0]),
        .I1(\red[4]_2 ),
        .I2(\red[3]_1 ),
        .O(cnt0__0_carry_i_19_n_0));
  LUT3 #(
    .INIT(8'h63)) 
    cnt0__0_carry_i_20
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_20_n_0));
  LUT3 #(
    .INIT(8'h9C)) 
    cnt0__0_carry_i_22
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_22_n_0));
  LUT3 #(
    .INIT(8'h39)) 
    cnt0__0_carry_i_23
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_23_n_0));
  LUT3 #(
    .INIT(8'h15)) 
    cnt0__0_carry_i_26
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_26_n_0));
  LUT3 #(
    .INIT(8'h76)) 
    cnt0__0_carry_i_27
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_27_n_0));
  LUT3 #(
    .INIT(8'h57)) 
    cnt0__0_carry_i_28
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_28_n_0));
  LUT4 #(
    .INIT(16'hCCC8)) 
    cnt0__0_carry_i_29
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_29_n_0));
  LUT4 #(
    .INIT(16'hECCC)) 
    cnt0__0_carry_i_30
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_30_n_0));
  LUT4 #(
    .INIT(16'h7EEC)) 
    cnt0__0_carry_i_31
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_31_n_0));
  LUT4 #(
    .INIT(16'h1EB4)) 
    cnt0__0_carry_i_9
       (.I0(red[4]),
        .I1(cnt0__0_carry_i_18_n_0),
        .I2(\red[3]_1 ),
        .I3(cnt0__0_carry_i_19_n_0),
        .O(q_reg[2]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_9
       (.I0(\red[3]_1 ),
        .I1(red_IBUF[1]),
        .I2(\cnt_reg[3]_0 ),
        .O(cnt_reg));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_3
   (ActiveArea_IBUF,
    \cnt_reg[3]_5 ,
    green,
    \green[0]_0 ,
    \green[3]_0 ,
    \green[3]_1 ,
    \green[4]_0 ,
    \green[7]_0 ,
    \green[7]_1 ,
    \green[7]_2 ,
    \green[7]_3 ,
    \green[7]_4 ,
    \green[7]_5 ,
    q_reg,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    \q_reg[4]_3 ,
    \q_reg[5]_0 ,
    \q_reg[5]_1 ,
    \q_reg[5]_2 ,
    D,
    DI,
    O,
    Q,
    S,
    \cnt_reg[0] ,
    \cnt_reg[1] ,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[5] ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    green_IBUF);
  input ActiveArea_IBUF;
  input \cnt_reg[3]_5 ;
  input [7:0]green;
  input \green[0]_0 ;
  input \green[3]_0 ;
  input \green[3]_1 ;
  input \green[4]_0 ;
  input \green[7]_0 ;
  input \green[7]_1 ;
  input \green[7]_2 ;
  input \green[7]_3 ;
  input \green[7]_4 ;
  input \green[7]_5 ;
  output [5:4]q_reg;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  output \q_reg[4]_3 ;
  output \q_reg[5]_0 ;
  output \q_reg[5]_1 ;
  output \q_reg[5]_2 ;
  output [8:0]D;
  output [2:0]DI;
  input [3:0]O;
  input [7:0]Q;
  output [3:0]S;
  input [3:0]\cnt_reg[0] ;
  input [3:0]\cnt_reg[1] ;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  input [3:0]\cnt_reg[5] ;
  output [3:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [0:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  input [7:0]green_IBUF;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [3:0]O;
  wire [7:0]Q;
  wire [3:0]S;
  wire cnt0__0_carry__0_i_7_n_0;
  wire cnt0__0_carry_i_13__0_n_0;
  wire cnt0__0_carry_i_14_n_0;
  wire cnt0__0_carry_i_15__0_n_0;
  wire cnt0__0_carry_i_24__0_n_0;
  wire cnt0__0_carry_i_25__0_n_0;
  wire cnt0__0_carry_i_8__0_n_0;
  wire cnt0__23_carry__0_i_8__0_n_0;
  wire cnt0__23_carry_i_10__0_n_0;
  wire cnt0__23_carry_i_11__0_n_0;
  wire cnt0__23_carry_i_7__0_n_0;
  wire cnt0__23_carry_i_8__0_n_0;
  wire cnt_carry__0_i_8__0_n_0;
  wire cnt_carry_i_10__0_n_0;
  wire cnt_carry_i_11__0_n_0;
  wire cnt_carry_i_12__0_n_0;
  wire cnt_carry_i_9__0_n_0;
  wire [3:0]\cnt_reg[0] ;
  wire [3:0]\cnt_reg[1] ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\cnt_reg[3]_1 ;
  wire [1:0]\cnt_reg[3]_2 ;
  wire [3:0]\cnt_reg[3]_3 ;
  wire [1:0]\cnt_reg[3]_4 ;
  wire \cnt_reg[3]_5 ;
  wire [3:0]\cnt_reg[5] ;
  wire [3:0]\cnt_reg[7] ;
  wire [2:0]\cnt_reg[7]_0 ;
  wire [0:0]\cnt_reg[7]_1 ;
  wire [1:0]\cnt_reg[7]_2 ;
  wire [7:0]green;
  wire \green[0]_0 ;
  wire \green[4]_0 ;
  wire \green[7]_0 ;
  wire \green[7]_1 ;
  wire \green[7]_2 ;
  wire \green[7]_3 ;
  wire \green[7]_4 ;
  wire \green[7]_5 ;
  wire [7:0]green_IBUF;
  wire \q[5]_i_4__0_n_0 ;
  wire \q[7]_i_6_n_0 ;
  wire \q[7]_i_7_n_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[4]_3 ;
  wire \q_reg[5]_0 ;

  assign q_reg[5] = green_IBUF[3];
  assign q_reg[4] = green_IBUF[6];
  assign \q_reg[4]_2  = green_IBUF[6];
  assign \q_reg[5]_1  = green_IBUF[6];
  assign \q_reg[5]_2  = green_IBUF[6];
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_11
       (.I0(green_IBUF[3]),
        .I1(green_IBUF[6]),
        .O(\q_reg[4]_3 ));
  LUT3 #(
    .INIT(8'h06)) 
    cnt0__0_carry__0_i_2__0
       (.I0(cnt0__0_carry_i_14_n_0),
        .I1(Q[3]),
        .I2(cnt0__0_carry_i_13__0_n_0),
        .O(\cnt_reg[7]_1 ));
  LUT5 #(
    .INIT(32'hFFB2004D)) 
    cnt0__0_carry__0_i_5__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(\cnt_reg[7]_2 [1]));
  LUT5 #(
    .INIT(32'hBD2B42D4)) 
    cnt0__0_carry__0_i_6__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(cnt0__0_carry_i_13__0_n_0),
        .I3(Q[3]),
        .I4(Q[4]),
        .O(\cnt_reg[7]_2 [0]));
  LUT4 #(
    .INIT(16'h0010)) 
    cnt0__0_carry__0_i_7
       (.I0(green[0]),
        .I1(green_IBUF[6]),
        .I2(\green[7]_3 ),
        .I3(green_IBUF[6]),
        .O(cnt0__0_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h8A)) 
    cnt0__0_carry_i_13__0
       (.I0(cnt0__0_carry_i_24__0_n_0),
        .I1(cnt0__0_carry_i_25__0_n_0),
        .I2(Q[2]),
        .O(cnt0__0_carry_i_13__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_14
       (.I0(\green[7]_2 ),
        .I1(cnt0__0_carry__0_i_7_n_0),
        .O(cnt0__0_carry_i_14_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_15__0
       (.I0(cnt0__23_carry_i_8__0_n_0),
        .I1(green[3]),
        .O(cnt0__0_carry_i_15__0_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6606)) 
    cnt0__0_carry_i_1__0
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(green[6]),
        .I3(green_IBUF[6]),
        .O(\cnt_reg[3]_4 [1]));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_24__0
       (.I0(\green[7]_0 ),
        .I1(\green[7]_1 ),
        .O(cnt0__0_carry_i_24__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__0_carry_i_25__0
       (.I0(\green[7]_0 ),
        .I1(\green[7]_1 ),
        .O(cnt0__0_carry_i_25__0_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'hF660)) 
    cnt0__0_carry_i_2__0
       (.I0(green[6]),
        .I1(green_IBUF[6]),
        .I2(green[7]),
        .I3(Q[1]),
        .O(\cnt_reg[3]_4 [0]));
  LUT4 #(
    .INIT(16'h96FF)) 
    cnt0__0_carry_i_3
       (.I0(green_IBUF[4]),
        .I1(green_IBUF[6]),
        .I2(\green[7]_4 ),
        .I3(\green[7]_5 ),
        .O(\q_reg[5]_0 ));
  LUT4 #(
    .INIT(16'h9669)) 
    cnt0__0_carry_i_4__0
       (.I0(\cnt_reg[3]_4 [1]),
        .I1(cnt0__0_carry_i_13__0_n_0),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_14_n_0),
        .O(\cnt_reg[3]_3 [3]));
  (* HLUTNM = "lutpair4" *) 
  LUT5 #(
    .INIT(32'h66969969)) 
    cnt0__0_carry_i_5__0
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(green[6]),
        .I3(green_IBUF[6]),
        .I4(\cnt_reg[3]_4 [0]),
        .O(\cnt_reg[3]_3 [2]));
  (* HLUTNM = "lutpair3" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    cnt0__0_carry_i_6__0
       (.I0(green[6]),
        .I1(green_IBUF[6]),
        .I2(green[7]),
        .I3(Q[1]),
        .I4(\q_reg[5]_0 ),
        .O(\cnt_reg[3]_3 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_7__0
       (.I0(cnt0__0_carry_i_15__0_n_0),
        .I1(Q[0]),
        .O(\cnt_reg[3]_3 [0]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_8__0
       (.I0(\green[7]_1 ),
        .I1(\green[7]_0 ),
        .O(cnt0__0_carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_1__0
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_2__0
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__23_carry__0_i_3__0
       (.I0(Q[3]),
        .I1(cnt0__23_carry_i_10__0_n_0),
        .O(DI[0]));
  LUT3 #(
    .INIT(8'hC9)) 
    cnt0__23_carry__0_i_4__0
       (.I0(cnt0__23_carry__0_i_8__0_n_0),
        .I1(Q[7]),
        .I2(Q[6]),
        .O(\cnt_reg[7] [3]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_5__0
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .I2(Q[6]),
        .O(\cnt_reg[7] [2]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_6__0
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .I2(Q[5]),
        .O(\cnt_reg[7] [1]));
  LUT4 #(
    .INIT(16'h7887)) 
    cnt0__23_carry__0_i_7__0
       (.I0(cnt0__23_carry_i_10__0_n_0),
        .I1(Q[3]),
        .I2(cnt0__23_carry__0_i_8__0_n_0),
        .I3(Q[4]),
        .O(\cnt_reg[7] [0]));
  LUT6 #(
    .INIT(64'hD000D0D0DDDDDDDD)) 
    cnt0__23_carry__0_i_8__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(cnt0__0_carry_i_24__0_n_0),
        .I3(cnt0__23_carry_i_7__0_n_0),
        .I4(cnt0__0_carry_i_8__0_n_0),
        .I5(cnt0__0_carry_i_14_n_0),
        .O(cnt0__23_carry__0_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h59AA)) 
    cnt0__23_carry_i_10__0
       (.I0(cnt0__0_carry_i_14_n_0),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(cnt0__23_carry_i_7__0_n_0),
        .I3(cnt0__0_carry_i_24__0_n_0),
        .O(cnt0__23_carry_i_10__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_11__0
       (.I0(\green[0]_0 ),
        .I1(green_IBUF[6]),
        .O(cnt0__23_carry_i_11__0_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'h60)) 
    cnt0__23_carry_i_1__0
       (.I0(cnt0__0_carry_i_8__0_n_0),
        .I1(cnt0__23_carry_i_7__0_n_0),
        .I2(Q[2]),
        .O(\cnt_reg[3]_2 [1]));
  LUT5 #(
    .INIT(32'h69660000)) 
    cnt0__23_carry_i_2__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green_IBUF[6]),
        .O(\cnt_reg[3]_2 [0]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_3__0
       (.I0(\cnt_reg[3]_2 [1]),
        .I1(cnt0__23_carry_i_10__0_n_0),
        .I2(Q[3]),
        .O(\cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    cnt0__23_carry_i_4__0
       (.I0(cnt0__0_carry_i_8__0_n_0),
        .I1(cnt0__23_carry_i_7__0_n_0),
        .I2(Q[2]),
        .I3(\cnt_reg[3]_2 [0]),
        .O(\cnt_reg[3]_1 [2]));
  LUT6 #(
    .INIT(64'h6966969996996966)) 
    cnt0__23_carry_i_5__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green_IBUF[6]),
        .I5(Q[1]),
        .O(\cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_6__0
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__0_n_0),
        .O(\cnt_reg[3]_1 [0]));
  LUT4 #(
    .INIT(16'hDD4D)) 
    cnt0__23_carry_i_7__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green[3]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .O(cnt0__23_carry_i_7__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_8__0
       (.I0(green_IBUF[4]),
        .I1(green_IBUF[3]),
        .I2(cnt0__23_carry_i_11__0_n_0),
        .O(cnt0__23_carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_1__0
       (.I0(Q[6]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_2__0
       (.I0(Q[5]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_3__0
       (.I0(Q[4]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [0]));
  LUT6 #(
    .INIT(64'hFC0CFFFFFC0CAAAA)) 
    cnt_carry__0_i_4__0
       (.I0(cnt_carry__0_i_8__0_n_0),
        .I1(O[3]),
        .I2(\q[5]_i_4__0_n_0 ),
        .I3(\cnt_reg[5] [3]),
        .I4(\q_reg[4]_0 ),
        .I5(Q[7]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_5__0
       (.I0(Q[6]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[2]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [2]),
        .O(S[2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_6__0
       (.I0(Q[5]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[1]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [1]),
        .O(S[1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_7__0
       (.I0(Q[4]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[0]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [0]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    cnt_carry__0_i_8__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(green_IBUF[6]),
        .I4(\q[7]_i_7_n_0 ),
        .O(cnt_carry__0_i_8__0_n_0));
  LUT6 #(
    .INIT(64'h3693666699993693)) 
    cnt_carry_i_10__0
       (.I0(green_IBUF[6]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green[6]),
        .I5(green[7]),
        .O(cnt_carry_i_10__0_n_0));
  LUT5 #(
    .INIT(32'h66699666)) 
    cnt_carry_i_11__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green_IBUF[6]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .I4(green[3]),
        .O(cnt_carry_i_11__0_n_0));
  LUT3 #(
    .INIT(8'hB2)) 
    cnt_carry_i_12__0
       (.I0(\q_reg[5]_0 ),
        .I1(green[6]),
        .I2(green[7]),
        .O(cnt_carry_i_12__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_1__0
       (.I0(Q[3]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_2__0
       (.I0(Q[2]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_3__0
       (.I0(Q[1]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_4__0
       (.I0(Q[0]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [0]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_5__0
       (.I0(Q[3]),
        .I1(cnt_carry_i_9__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [3]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_6__0
       (.I0(Q[2]),
        .I1(cnt_carry_i_10__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [2]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_7__0
       (.I0(Q[1]),
        .I1(cnt_carry_i_11__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [1]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_8__0
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [0]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT6 #(
    .INIT(64'hC34BF03CC378F03C)) 
    cnt_carry_i_9__0
       (.I0(cnt_carry_i_12__0_n_0),
        .I1(green_IBUF[6]),
        .I2(cnt0__0_carry_i_14_n_0),
        .I3(cnt0__0_carry_i_25__0_n_0),
        .I4(cnt0__0_carry_i_24__0_n_0),
        .I5(cnt0__23_carry_i_7__0_n_0),
        .O(cnt_carry_i_9__0_n_0));
  LUT5 #(
    .INIT(32'h0A28A028)) 
    \q[0]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(green_IBUF[6]),
        .I2(green_IBUF[0]),
        .I3(\q_reg[4]_0 ),
        .I4(\q[5]_i_4__0_n_0 ),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2800)) 
    \q[1]_i_1__0 
       (.I0(\q_reg[4]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q[5]_i_4__0_n_0 ),
        .I3(ActiveArea_IBUF),
        .O(D[1]));
  LUT5 #(
    .INIT(32'h56A6FFFF)) 
    \q[2]_i_1__0 
       (.I0(\green[0]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q[5]_i_4__0_n_0 ),
        .I4(ActiveArea_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[3]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[6]),
        .I3(\q[5]_i_4__0_n_0 ),
        .O(D[3]));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[4]_i_1__0 
       (.I0(\green[4]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[4]_1 ),
        .I4(ActiveArea_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[5]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[3]),
        .I3(\q[5]_i_4__0_n_0 ),
        .O(D[5]));
  LUT5 #(
    .INIT(32'hB2DDB244)) 
    \q[5]_i_4__0 
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7_n_0 ),
        .O(\q[5]_i_4__0_n_0 ));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[6]_i_1__0 
       (.I0(green[0]),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[4]_1 ),
        .I4(ActiveArea_IBUF),
        .O(D[6]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h8008)) 
    \q[7]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[6]),
        .I3(\q_reg[4]_1 ),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h00000000FFFF6FFF)) 
    \q[7]_i_3__0 
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__0_carry_i_14_n_0),
        .I3(cnt0__0_carry_i_8__0_n_0),
        .I4(cnt0__0_carry_i_15__0_n_0),
        .I5(\cnt_reg[3]_5 ),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    \q[7]_i_4__0 
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7_n_0 ),
        .O(\q_reg[4]_1 ));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \q[7]_i_6 
       (.I0(\q_reg[5]_0 ),
        .I1(green[6]),
        .I2(green[7]),
        .I3(\green[7]_0 ),
        .I4(\green[7]_1 ),
        .O(\q[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hDD4DFFFF0000DD4D)) 
    \q[7]_i_7 
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green[3]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .I4(\green[7]_1 ),
        .I5(\green[7]_0 ),
        .O(\q[7]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \q[8]_i_1__0 
       (.I0(green_IBUF[6]),
        .I1(ActiveArea_IBUF),
        .O(D[8]));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_4
   (cnt_reg,
    \cnt_reg[3]_0 ,
    green,
    \green[0]_0 ,
    \green[3]_0 ,
    \green[3]_1 ,
    \green[4]_0 ,
    \green[4]_1 ,
    \green[4]_2 ,
    \green[4]_3 ,
    q_reg,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[5]_0 ,
    \q_reg[5]_1 ,
    \q_reg[5]_2 ,
    green_IBUF);
  output [3:3]cnt_reg;
  output \cnt_reg[3]_0 ;
  input [7:0]green;
  input \green[0]_0 ;
  input \green[3]_0 ;
  input \green[3]_1 ;
  input \green[4]_0 ;
  input \green[4]_1 ;
  input \green[4]_2 ;
  input \green[4]_3 ;
  output [5:4]q_reg;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[5]_0 ;
  output \q_reg[5]_1 ;
  output \q_reg[5]_2 ;
  input [6:0]green_IBUF;

  wire cnt0__0_carry_i_18_n_0;
  wire cnt0__0_carry_i_19_n_0;
  wire cnt0__0_carry_i_20_n_0;
  wire cnt0__0_carry_i_22_n_0;
  wire cnt0__0_carry_i_23_n_0;
  wire cnt0__0_carry_i_26_n_0;
  wire cnt0__0_carry_i_27_n_0;
  wire cnt0__0_carry_i_28_n_0;
  wire cnt0__0_carry_i_29_n_0;
  wire cnt0__0_carry_i_30_n_0;
  wire cnt0__0_carry_i_31_n_0;
  wire [3:3]cnt_reg;
  wire \cnt_reg[3]_0 ;
  wire [7:0]green;
  wire \green[0]_0 ;
  wire \green[3]_1 ;
  wire \green[4]_0 ;
  wire \green[4]_1 ;
  wire \green[4]_2 ;
  wire [6:0]green_IBUF;
  wire [5:4]q_reg;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[5]_0 ;
  wire \q_reg[5]_1 ;
  wire \q_reg[5]_2 ;

  LUT2 #(
    .INIT(4'h1)) 
    cnt0__0_carry__0_i_10
       (.I0(\green[3]_1 ),
        .I1(green_IBUF[4]),
        .O(\q_reg[5]_2 ));
  LUT4 #(
    .INIT(16'h8000)) 
    cnt0__0_carry__0_i_8
       (.I0(green[7]),
        .I1(\green[4]_0 ),
        .I2(green[4]),
        .I3(green[5]),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_10
       (.I0(cnt0__0_carry_i_20_n_0),
        .I1(\green[4]_0 ),
        .I2(cnt0__0_carry_i_22_n_0),
        .I3(green[0]),
        .I4(cnt0__0_carry_i_23_n_0),
        .O(\q_reg[4]_1 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_11
       (.I0(green[4]),
        .I1(\green[4]_0 ),
        .O(\cnt_reg[3]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_12
       (.I0(\green[4]_0 ),
        .I1(\green[4]_2 ),
        .O(\q_reg[5]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_16
       (.I0(cnt0__0_carry_i_26_n_0),
        .I1(\green[4]_0 ),
        .I2(cnt0__0_carry_i_27_n_0),
        .I3(green[0]),
        .I4(cnt0__0_carry_i_28_n_0),
        .O(\q_reg[5]_1 ));
  LUT5 #(
    .INIT(32'hFCE230E2)) 
    cnt0__0_carry_i_17
       (.I0(cnt0__0_carry_i_29_n_0),
        .I1(green[5]),
        .I2(cnt0__0_carry_i_30_n_0),
        .I3(green[4]),
        .I4(cnt0__0_carry_i_31_n_0),
        .O(q_reg[5]));
  LUT3 #(
    .INIT(8'h42)) 
    cnt0__0_carry_i_18
       (.I0(green[0]),
        .I1(\green[4]_2 ),
        .I2(\green[3]_1 ),
        .O(cnt0__0_carry_i_18_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    cnt0__0_carry_i_19
       (.I0(green[0]),
        .I1(\green[4]_2 ),
        .I2(\green[3]_1 ),
        .O(cnt0__0_carry_i_19_n_0));
  LUT3 #(
    .INIT(8'h63)) 
    cnt0__0_carry_i_20
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_20_n_0));
  LUT3 #(
    .INIT(8'h9C)) 
    cnt0__0_carry_i_22
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_22_n_0));
  LUT3 #(
    .INIT(8'h39)) 
    cnt0__0_carry_i_23
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_23_n_0));
  LUT3 #(
    .INIT(8'h15)) 
    cnt0__0_carry_i_26
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_26_n_0));
  LUT3 #(
    .INIT(8'h76)) 
    cnt0__0_carry_i_27
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_27_n_0));
  LUT3 #(
    .INIT(8'h57)) 
    cnt0__0_carry_i_28
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_28_n_0));
  LUT4 #(
    .INIT(16'hCCC8)) 
    cnt0__0_carry_i_29
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_29_n_0));
  LUT4 #(
    .INIT(16'hECCC)) 
    cnt0__0_carry_i_30
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_30_n_0));
  LUT4 #(
    .INIT(16'h7EEC)) 
    cnt0__0_carry_i_31
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_31_n_0));
  LUT4 #(
    .INIT(16'h1EB4)) 
    cnt0__0_carry_i_9
       (.I0(green[4]),
        .I1(cnt0__0_carry_i_18_n_0),
        .I2(\green[3]_1 ),
        .I3(cnt0__0_carry_i_19_n_0),
        .O(q_reg[4]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_9
       (.I0(\green[3]_1 ),
        .I1(green_IBUF[1]),
        .I2(\cnt_reg[3]_0 ),
        .O(cnt_reg));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_5
   (ActiveArea_IBUF,
    blue,
    \blue[0]_0 ,
    \blue[3]_0 ,
    \blue[4]_0 ,
    \blue[7]_0 ,
    \blue[7]_1 ,
    \blue[7]_2 ,
    \blue[7]_3 ,
    \blue[7]_4 ,
    \cnt_reg[3]_5 ,
    hSync_IBUF,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[2]_1 ,
    \q_reg[2]_2 ,
    \q_reg[2]_3 ,
    \q_reg[2]_4 ,
    vSync_IBUF,
    D,
    DI,
    Q,
    S,
    blue_IBUF,
    cnt0,
    cnt00_in,
    cnt2,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    lopt);
  input ActiveArea_IBUF;
  input [7:0]blue;
  input \blue[0]_0 ;
  input \blue[3]_0 ;
  input \blue[4]_0 ;
  input \blue[7]_0 ;
  input \blue[7]_1 ;
  input \blue[7]_2 ;
  input \blue[7]_3 ;
  input \blue[7]_4 ;
  input \cnt_reg[3]_5 ;
  input hSync_IBUF;
  output [9:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[2]_1 ;
  output \q_reg[2]_2 ;
  output \q_reg[2]_3 ;
  output \q_reg[2]_4 ;
  input vSync_IBUF;
  output [8:0]D;
  output [2:0]DI;
  input [7:0]Q;
  output [3:0]S;
  input [7:0]blue_IBUF;
  input [7:0]cnt0;
  input [7:0]cnt00_in;
  output [0:0]cnt2;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  output [0:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [3:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  output lopt;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [7:0]\^Q ;
  wire [3:0]S;
  wire [7:0]cnt0;
  wire [7:0]cnt00_in;
  wire cnt0__0_carry__0_i_8_n_0;
  wire [0:0]\^cnt2 ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\^cnt_reg[3]_1 ;
  wire [1:0]\^cnt_reg[3]_2 ;
  wire [3:0]\^cnt_reg[3]_3 ;
  wire \cnt_reg[3]_5 ;
  wire [0:0]\cnt_reg[7] ;
  wire [3:0]\cnt_reg[7]_1 ;
  wire [1:0]\^cnt_reg[7]_2 ;
  wire hSync_IBUF;
  wire [9:2]\^q_reg ;
  wire \q_reg[2]_0 ;
  wire vSync_IBUF;

  assign \^Q [6:0] = Q[6:0];
  assign \cnt_reg[3]_1 [3] = \^cnt_reg[3]_1 [3];
  assign \cnt_reg[3]_1 [2] = \^Q [2];
  assign \cnt_reg[3]_1 [1] = \^cnt_reg[3]_1 [1];
  assign \cnt_reg[3]_1 [0] = \^Q [0];
  assign \cnt_reg[3]_2 [0] = \^cnt2 [0];
  assign \cnt_reg[3]_3 [3] = \^cnt_reg[3]_3 [3];
  assign \cnt_reg[3]_3 [2:0] = \^Q [2:0];
  assign \cnt_reg[3]_4 [1] = \^cnt2 [0];
  assign \cnt_reg[3]_4 [0] = \^cnt2 [0];
  assign \cnt_reg[7]_0 [2:0] = \^Q [5:3];
  assign \cnt_reg[7]_2 [1] = \^Q [5];
  assign \cnt_reg[7]_2 [0] = \^cnt_reg[7]_2 [0];
  assign lopt = \^cnt_reg[3]_2 [1];
  assign q_reg[9] = \^q_reg [9];
  assign q_reg[2] = \cnt_reg[3]_5 ;
  assign \q_reg[2]_0  = Q[7];
  assign \q_reg[2]_1  = cnt0__0_carry__0_i_8_n_0;
  GND GND
       (.G(\^cnt2 ));
  VCC VCC
       (.P(cnt0__0_carry__0_i_8_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_2
       (.I0(\^Q [3]),
        .I1(\^Q [2]),
        .O(\cnt_reg[7] ));
  LUT3 #(
    .INIT(8'h78)) 
    cnt0__0_carry__0_i_6
       (.I0(\^Q [2]),
        .I1(\^Q [3]),
        .I2(\^Q [4]),
        .O(\^cnt_reg[7]_2 [0]));
  (* HLUTNM = "lutpair1" *) 
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry_i_1
       (.I0(\^Q [2]),
        .O(\^cnt_reg[3]_2 [1]));
  LUT3 #(
    .INIT(8'h69)) 
    cnt0__0_carry_i_4
       (.I0(\^Q [2]),
        .I1(\^Q [2]),
        .I2(\^Q [3]),
        .O(\^cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair0" *) 
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry_i_6
       (.I0(\^Q [1]),
        .O(\^cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_4
       (.I0(\q_reg[2]_0 ),
        .I1(\^Q [6]),
        .O(\cnt_reg[7]_1 [3]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_5
       (.I0(\^Q [5]),
        .I1(\^Q [6]),
        .O(\cnt_reg[7]_1 [2]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_6
       (.I0(\^Q [4]),
        .I1(\^Q [5]),
        .O(\cnt_reg[7]_1 [1]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_7
       (.I0(\^Q [3]),
        .I1(\^Q [4]),
        .O(\cnt_reg[7]_1 [0]));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__23_carry_i_3
       (.I0(\^Q [3]),
        .O(\^cnt_reg[3]_3 [3]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_1
       (.I0(\^Q [6]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_2
       (.I0(\^Q [5]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_3
       (.I0(\^Q [4]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[0]));
  LUT4 #(
    .INIT(16'hFFE2)) 
    cnt_carry__0_i_4
       (.I0(cnt00_in[7]),
        .I1(\q_reg[2]_0 ),
        .I2(cnt0[7]),
        .I3(\cnt_reg[3]_5 ),
        .O(S[3]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_5
       (.I0(\^Q [6]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[6]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[6]),
        .O(S[2]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_6
       (.I0(\^Q [5]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[5]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[5]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_7
       (.I0(\^Q [4]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[4]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[4]),
        .O(S[0]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_1
       (.I0(\^Q [3]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_2
       (.I0(\^Q [2]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_3
       (.I0(\^Q [1]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_4
       (.I0(\^Q [0]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [0]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry_i_5
       (.I0(\^Q [3]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[3]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_6
       (.I0(\^Q [2]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[2]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_7
       (.I0(\^Q [1]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[1]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_8
       (.I0(\^Q [0]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[0]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[0]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2F20)) 
    \q[1]_i_1 
       (.I0(\q_reg[2]_0 ),
        .I1(\cnt_reg[3]_5 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[1]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[2]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[3]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[3]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[4]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[5]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[5]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[6]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[6]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[7]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[7]));
  LUT2 #(
    .INIT(4'h1)) 
    \q[8]_i_1 
       (.I0(ActiveArea_IBUF),
        .I1(hSync_IBUF),
        .O(D[8]));
  LUT3 #(
    .INIT(8'h14)) 
    \q[9]_i_2 
       (.I0(ActiveArea_IBUF),
        .I1(hSync_IBUF),
        .I2(vSync_IBUF),
        .O(\^q_reg [9]));
endmodule

(* ECO_CHECKSUM = "54ad8621" *) 
(* NotValidForBitStream *)
module PipelineCPUTest
   (clk,
    reset,
    step,
    run_mode,
    TMDSp,
    TMDSn,
    TMDSp_clk,
    TMDSn_clk);
  (* CLOCK_BUFFER_TYPE = "none" *) input clk;
  input reset;
  input step;
  input run_mode;
  output [2:0]TMDSp;
  output [2:0]TMDSn;
  output TMDSp_clk;
  output TMDSn_clk;

  wire [27:0]ALUResult;
  wire [31:12]ALU_A;
  wire ActiveArea;
  wire CPUInst_n_136;
  wire CPUInst_n_137;
  wire CPUInst_n_138;
  wire CPUInst_n_139;
  wire CPUInst_n_140;
  wire CPUInst_n_141;
  wire CPUInst_n_142;
  wire CPUInst_n_143;
  wire CPUInst_n_144;
  wire CPUInst_n_145;
  wire CPUInst_n_146;
  wire CPUInst_n_147;
  wire CPUInst_n_148;
  wire CPUInst_n_149;
  wire CPUInst_n_151;
  wire CPUInst_n_152;
  wire CPUInst_n_153;
  wire CPUInst_n_154;
  wire CPUInst_n_155;
  wire CPUInst_n_156;
  wire CPUInst_n_157;
  wire CPUInst_n_158;
  wire CPUInst_n_159;
  wire CPUInst_n_16;
  wire CPUInst_n_160;
  wire CPUInst_n_161;
  wire CPUInst_n_162;
  wire CPUInst_n_37;
  wire CPUInst_n_38;
  wire CPUInst_n_53;
  wire CPUInst_n_54;
  wire CPUInst_n_55;
  wire CPUInst_n_56;
  wire CPUInst_n_57;
  wire CPUInst_n_58;
  wire CPUInst_n_59;
  wire CPUInst_n_60;
  wire CPUInst_n_61;
  wire CPUInst_n_62;
  wire CPUInst_n_83;
  wire CPUInst_n_84;
  wire CPUInst_n_85;
  wire CPUInst_n_86;
  wire CPUInst_n_87;
  wire CPUInst_n_88;
  wire CPUInst_n_89;
  wire CPUInst_n_90;
  wire CPUInst_n_91;
  wire CPUInst_n_92;
  wire CPUInst_n_93;
  wire CPUInst_n_94;
  wire CPUInst_n_95;
  wire CPUInst_n_96;
  wire CPUInst_n_97;
  wire [30:2]Instruction_id;
  wire [27:12]MemDout_mem;
  wire [7:1]PC;
  wire [3:1]PosX_reg_reg__0;
  wire [4:1]PosY;
  wire [6:6]PosY__0;
  wire TMDSch0;
  wire TMDSch1;
  wire TMDSch2;
  wire [2:0]TMDSn;
  wire TMDSn_clk;
  wire [2:0]TMDSp;
  wire TMDSp_clk;
  wire char_pixel__6;
  wire [3:0]char_selection;
  (* IBUF_LOW_PWR *) wire clk;
  wire cpu_clk;
  wire cpu_clk_BUFG;
  wire [0:0]green;
  wire hSync;
  wire lopt;
  wire [4:4]p_0_in;
  wire [1:1]p_0_in__1;
  wire pixel_clk;
  wire r_RegWrite_wb;
  wire reset;
  wire reset_IBUF;
  wire run_mode;
  wire run_mode_IBUF;
  wire step;
  wire step_IBUF;
  wire step_pulse;
  wire step_pulse_reg;
  wire sync_inst_n_10;
  wire sync_inst_n_11;
  wire sync_inst_n_12;
  wire sync_inst_n_13;
  wire sync_inst_n_14;
  wire sync_inst_n_15;
  wire sync_inst_n_16;
  wire sync_inst_n_17;
  wire sync_inst_n_18;
  wire sync_inst_n_19;
  wire sync_inst_n_24;
  wire sync_inst_n_25;
  wire sync_inst_n_26;
  wire sync_inst_n_9;
  wire tmds_clk;
  wire [31:0]\u_ID/ReadData10 ;
  wire [31:0]\u_ID/ReadData20 ;
  wire vSync;
  wire [31:0]w_RegWriteData_wb;
  wire NLW_DCM_INST_locked_UNCONNECTED;
  wire NLW_TMDS_inst_pixel_clk_UNCONNECTED;
  wire [7:0]NLW_TMDS_inst_blue_UNCONNECTED;
  wire [7:5]NLW_TMDS_inst_green_UNCONNECTED;
  wire [7:5]NLW_TMDS_inst_red_UNCONNECTED;
  wire NLW_step_pulse_inst_clk_UNCONNECTED;
  wire NLW_step_pulse_inst_reset_UNCONNECTED;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_0_5_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_12_17_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_18_23_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_24_29_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOB_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOC_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r1_0_31_6_11_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_0_5_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_12_17_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_18_23_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_24_29_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOB_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOC_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOD_UNCONNECTED ;
  wire [1:0]\NLW_u_ID/u_Registers/regs_reg_r2_0_31_6_11_DOD_UNCONNECTED ;

initial begin
 $sdf_annotate("Risc5CPU_tb_v_time_impl.sdf",,,,"tool_control");
end
  Risc5CPU CPUInst
       (.D(MemDout_mem),
        .\PosX_reg_reg[2] (p_0_in),
        .\PosX_reg_reg[4] (sync_inst_n_16),
        .\PosX_reg_reg[4]_0 (sync_inst_n_25),
        .\PosX_reg_reg[4]_1 (sync_inst_n_12),
        .\PosX_reg_reg[4]_2 (sync_inst_n_26),
        .\PosX_reg_reg[4]_3 (sync_inst_n_13),
        .\PosX_reg_reg[4]_4 (sync_inst_n_14),
        .\PosX_reg_reg[4]_5 (sync_inst_n_11),
        .\PosX_reg_reg[4]_6 (sync_inst_n_15),
        .\PosX_reg_reg[4]_7 (sync_inst_n_10),
        .\PosX_reg_reg[5] (sync_inst_n_17),
        .\PosX_reg_reg[5]_0 (sync_inst_n_9),
        .\PosX_reg_reg[5]_1 (sync_inst_n_18),
        .\PosX_reg_reg[9] (sync_inst_n_24),
        .PosY__0(PosY__0),
        .Q({Instruction_id[30],Instruction_id[27:25],Instruction_id[23:19],Instruction_id[17:14],Instruction_id[11:10],Instruction_id[8:6],Instruction_id[3:2]}),
        .ReadData10(\u_ID/ReadData10 ),
        .ReadData20(\u_ID/ReadData20 ),
        .SR(reset_IBUF),
        .\TMDSn[2] (CPUInst_n_16),
        .\TMDSn[2]_0 (CPUInst_n_37),
        .\TMDSn[2]_1 (CPUInst_n_38),
        .\TMDSn[2]_10 (CPUInst_n_61),
        .\TMDSn[2]_11 (CPUInst_n_62),
        .\TMDSn[2]_12 (CPUInst_n_136),
        .\TMDSn[2]_13 (CPUInst_n_137),
        .\TMDSn[2]_14 (CPUInst_n_138),
        .\TMDSn[2]_15 (CPUInst_n_139),
        .\TMDSn[2]_16 (CPUInst_n_140),
        .\TMDSn[2]_17 (CPUInst_n_141),
        .\TMDSn[2]_18 (CPUInst_n_142),
        .\TMDSn[2]_19 (CPUInst_n_143),
        .\TMDSn[2]_2 (CPUInst_n_53),
        .\TMDSn[2]_20 (CPUInst_n_144),
        .\TMDSn[2]_21 (CPUInst_n_145),
        .\TMDSn[2]_22 (CPUInst_n_146),
        .\TMDSn[2]_23 (CPUInst_n_147),
        .\TMDSn[2]_24 (CPUInst_n_148),
        .\TMDSn[2]_25 (CPUInst_n_149),
        .\TMDSn[2]_3 (CPUInst_n_54),
        .\TMDSn[2]_4 (CPUInst_n_55),
        .\TMDSn[2]_5 (CPUInst_n_56),
        .\TMDSn[2]_6 (CPUInst_n_57),
        .\TMDSn[2]_7 (CPUInst_n_58),
        .\TMDSn[2]_8 (CPUInst_n_59),
        .\TMDSn[2]_9 (CPUInst_n_60),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .p_0_in__1(p_0_in__1),
        .\q_reg[147] (sync_inst_n_19),
        .\q_reg[39] ({PC[7:5],PC[3:1]}),
        .\q_reg[40] (CPUInst_n_83),
        .\q_reg[49] (CPUInst_n_96),
        .\q_reg[51] (CPUInst_n_97),
        .\q_reg[52] (CPUInst_n_162),
        .\q_reg[53] (CPUInst_n_161),
        .\q_reg[54] (CPUInst_n_95),
        .\q_reg[55] (CPUInst_n_94),
        .\q_reg[56] ({r_RegWrite_wb,CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .\q_reg[56]_0 (CPUInst_n_160),
        .\q_reg[57] (CPUInst_n_159),
        .\q_reg[58] (CPUInst_n_93),
        .\q_reg[59] (CPUInst_n_92),
        .\q_reg[60] (CPUInst_n_158),
        .\q_reg[61] (CPUInst_n_157),
        .\q_reg[62] (CPUInst_n_91),
        .\q_reg[63] (CPUInst_n_90),
        .\q_reg[64] (CPUInst_n_89),
        .\q_reg[65] (CPUInst_n_156),
        .\q_reg[66] (CPUInst_n_87),
        .\q_reg[67] ({ALUResult[27:26],ALUResult[23:22],ALUResult[19:18],ALUResult[15:14],ALUResult[9:8],ALUResult[5:4],ALUResult[1:0]}),
        .\q_reg[67]_0 (CPUInst_n_88),
        .\q_reg[68] (CPUInst_n_86),
        .\q_reg[69] (CPUInst_n_85),
        .\q_reg[70] (ALU_A),
        .\q_reg[70]_0 (CPUInst_n_84),
        .w_RegWriteData_wb(w_RegWriteData_wb));
  DCM_PLL DCM_INST
       (.clk_in1(clk),
        .clk_out1(pixel_clk),
        .clk_out2(tmds_clk),
        .locked(NLW_DCM_INST_locked_UNCONNECTED),
        .lopt(lopt),
        .reset(1'b0));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_blue
       (.I(TMDSch0),
        .O(TMDSp[0]),
        .OB(TMDSn[0]));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_clk
       (.I(pixel_clk),
        .O(TMDSp_clk),
        .OB(TMDSn_clk));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_green
       (.I(TMDSch1),
        .O(TMDSp[1]),
        .OB(TMDSn[1]));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_red
       (.I(TMDSch2),
        .O(TMDSp[2]),
        .OB(TMDSn[2]));
  TMDSencode TMDS_inst
       (.ActiveArea(ActiveArea),
        .TMDSch0(TMDSch0),
        .TMDSch1(TMDSch1),
        .TMDSch2(TMDSch2),
        .blue(NLW_TMDS_inst_blue_UNCONNECTED[7:0]),
        .green({NLW_TMDS_inst_green_UNCONNECTED[7],green,NLW_TMDS_inst_green_UNCONNECTED[5],green,green,green,green,green}),
        .hSync(hSync),
        .lopt(lopt),
        .pixel_clk(NLW_TMDS_inst_pixel_clk_UNCONNECTED),
        .red({NLW_TMDS_inst_red_UNCONNECTED[7],green,NLW_TMDS_inst_red_UNCONNECTED[5],green,green,green,green,green}),
        .reset(1'b0),
        .tmds_clk(tmds_clk),
        .vSync(vSync));
  vga_data VgaData
       (.CLK(pixel_clk),
        .Q(PosX_reg_reg__0),
        .a({char_selection,PosY}),
        .char_pixel__6(char_pixel__6));
  BUFG cpu_clk_BUFG_inst
       (.I(cpu_clk),
        .O(cpu_clk_BUFG));
  LUT3 #(
    .INIT(8'hB8)) 
    cpu_clk_BUFG_inst_i_1
       (.I0(pixel_clk),
        .I1(run_mode_IBUF),
        .I2(step_pulse_reg),
        .O(cpu_clk));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
  IBUF run_mode_IBUF_inst
       (.I(run_mode),
        .O(run_mode_IBUF));
  IBUF step_IBUF_inst
       (.I(step),
        .O(step_IBUF));
  button_process_unit step_pulse_inst
       (.ButtonIn(step_IBUF),
        .ButtonOut(step_pulse),
        .clk(NLW_step_pulse_inst_clk_UNCONNECTED),
        .lopt(lopt),
        .reset(NLW_step_pulse_inst_reset_UNCONNECTED));
  FDRE #(
    .INIT(1'b0)) 
    step_pulse_reg_reg
       (.C(pixel_clk),
        .CE(1'b1),
        .D(step_pulse),
        .Q(step_pulse_reg),
        .R(1'b0));
  syncGenarator sync_inst
       (.ActiveArea(ActiveArea),
        .CLK(pixel_clk),
        .D(p_0_in),
        .\PC_reg_reg[0] (CPUInst_n_136),
        .\PC_reg_reg[7] ({PC[7:5],PC[3:1]}),
        .\PosX_reg_reg[3]_0 (PosX_reg_reg__0),
        .\PosX_reg_reg[4]_0 (CPUInst_n_138),
        .\PosX_reg_reg[4]_1 (CPUInst_n_60),
        .\PosX_reg_reg[4]_10 (CPUInst_n_147),
        .\PosX_reg_reg[4]_11 (CPUInst_n_148),
        .\PosX_reg_reg[4]_12 (CPUInst_n_149),
        .\PosX_reg_reg[4]_2 (CPUInst_n_139),
        .\PosX_reg_reg[4]_3 (CPUInst_n_140),
        .\PosX_reg_reg[4]_4 (CPUInst_n_141),
        .\PosX_reg_reg[4]_5 (CPUInst_n_142),
        .\PosX_reg_reg[4]_6 (CPUInst_n_143),
        .\PosX_reg_reg[4]_7 (CPUInst_n_144),
        .\PosX_reg_reg[4]_8 (CPUInst_n_145),
        .\PosX_reg_reg[4]_9 (CPUInst_n_146),
        .\PosX_reg_reg[5]_0 (CPUInst_n_54),
        .Q({Instruction_id[30],Instruction_id[27:25],Instruction_id[23:22],Instruction_id[19],Instruction_id[16:14],Instruction_id[11:10],Instruction_id[8:6],Instruction_id[3:2]}),
        .\TMDSn[2] (PosY__0),
        .\TMDSn[2]_0 (sync_inst_n_9),
        .\TMDSn[2]_1 (sync_inst_n_10),
        .\TMDSn[2]_10 (sync_inst_n_19),
        .\TMDSn[2]_11 (sync_inst_n_24),
        .\TMDSn[2]_12 (sync_inst_n_25),
        .\TMDSn[2]_13 (sync_inst_n_26),
        .\TMDSn[2]_2 (sync_inst_n_11),
        .\TMDSn[2]_3 (sync_inst_n_12),
        .\TMDSn[2]_4 (sync_inst_n_13),
        .\TMDSn[2]_5 (sync_inst_n_14),
        .\TMDSn[2]_6 (sync_inst_n_15),
        .\TMDSn[2]_7 (sync_inst_n_16),
        .\TMDSn[2]_8 (sync_inst_n_17),
        .\TMDSn[2]_9 (sync_inst_n_18),
        .a({char_selection,PosY}),
        .\bbstub_spo[27] (MemDout_mem),
        .char_pixel__6(char_pixel__6),
        .green(green),
        .hSync(hSync),
        .p_0_in__1(p_0_in__1),
        .\q_reg[118] (CPUInst_n_96),
        .\q_reg[123] (CPUInst_n_162),
        .\q_reg[124] (CPUInst_n_161),
        .\q_reg[125] (CPUInst_n_95),
        .\q_reg[126] (CPUInst_n_94),
        .\q_reg[127] (CPUInst_n_160),
        .\q_reg[128] (CPUInst_n_159),
        .\q_reg[12] (CPUInst_n_61),
        .\q_reg[130] (CPUInst_n_92),
        .\q_reg[130]_0 (CPUInst_n_93),
        .\q_reg[131] (CPUInst_n_158),
        .\q_reg[132] (CPUInst_n_157),
        .\q_reg[133] (CPUInst_n_91),
        .\q_reg[134] (CPUInst_n_90),
        .\q_reg[134]_0 (CPUInst_n_89),
        .\q_reg[136] (CPUInst_n_156),
        .\q_reg[137] (CPUInst_n_87),
        .\q_reg[138] (CPUInst_n_83),
        .\q_reg[138]_0 (CPUInst_n_88),
        .\q_reg[138]_1 (CPUInst_n_85),
        .\q_reg[138]_2 (CPUInst_n_86),
        .\q_reg[141] (CPUInst_n_84),
        .\q_reg[143] (CPUInst_n_137),
        .\q_reg[146] (CPUInst_n_38),
        .\q_reg[146]_0 (CPUInst_n_55),
        .\q_reg[147] (CPUInst_n_58),
        .\q_reg[149] (CPUInst_n_53),
        .\q_reg[149]_0 (CPUInst_n_56),
        .\q_reg[149]_1 ({ALUResult[27:26],ALUResult[23:22],ALUResult[19:18],ALUResult[15:14],ALUResult[9:8],ALUResult[5:4],ALUResult[1:0]}),
        .\q_reg[149]_2 (CPUInst_n_59),
        .\q_reg[149]_3 (CPUInst_n_57),
        .\q_reg[17] (CPUInst_n_16),
        .\q_reg[20] (CPUInst_n_62),
        .\q_reg[31] (ALU_A),
        .\q_reg[48] (CPUInst_n_97),
        .\q_reg[4] (CPUInst_n_37),
        .vSync(vSync));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_UNIQ_BASE_ \u_ID/u_Registers/regs_reg_r1_0_31_0_5 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[1:0]),
        .DIB(w_RegWriteData_wb[3:2]),
        .DIC(w_RegWriteData_wb[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [1:0]),
        .DOB(\u_ID/ReadData10 [3:2]),
        .DOC(\u_ID/ReadData10 [5:4]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_0_5_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD32 \u_ID/u_Registers/regs_reg_r1_0_31_12_17 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[13:12]),
        .DIB(w_RegWriteData_wb[15:14]),
        .DIC(w_RegWriteData_wb[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [13:12]),
        .DOB(\u_ID/ReadData10 [15:14]),
        .DOC(\u_ID/ReadData10 [17:16]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_12_17_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD33 \u_ID/u_Registers/regs_reg_r1_0_31_18_23 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[19:18]),
        .DIB(w_RegWriteData_wb[21:20]),
        .DIC(w_RegWriteData_wb[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [19:18]),
        .DOB(\u_ID/ReadData10 [21:20]),
        .DOC(\u_ID/ReadData10 [23:22]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_18_23_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD34 \u_ID/u_Registers/regs_reg_r1_0_31_24_29 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[25:24]),
        .DIB(w_RegWriteData_wb[27:26]),
        .DIC(w_RegWriteData_wb[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [25:24]),
        .DOB(\u_ID/ReadData10 [27:26]),
        .DOC(\u_ID/ReadData10 [29:28]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_24_29_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD35 \u_ID/u_Registers/regs_reg_r1_0_31_30_31 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [31:30]),
        .DOB(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOB_UNCONNECTED [1:0]),
        .DOC(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOC_UNCONNECTED [1:0]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_30_31_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD36 \u_ID/u_Registers/regs_reg_r1_0_31_6_11 
       (.ADDRA({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRB({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRC({Instruction_id[19],Instruction_id[19],Instruction_id[17:15]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[7:6]),
        .DIB(w_RegWriteData_wb[9:8]),
        .DIC(w_RegWriteData_wb[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData10 [7:6]),
        .DOB(\u_ID/ReadData10 [9:8]),
        .DOC(\u_ID/ReadData10 [11:10]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r1_0_31_6_11_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD37 \u_ID/u_Registers/regs_reg_r2_0_31_0_5 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[1:0]),
        .DIB(w_RegWriteData_wb[3:2]),
        .DIC(w_RegWriteData_wb[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [1:0]),
        .DOB(\u_ID/ReadData20 [3:2]),
        .DOC(\u_ID/ReadData20 [5:4]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_0_5_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD38 \u_ID/u_Registers/regs_reg_r2_0_31_12_17 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[13:12]),
        .DIB(w_RegWriteData_wb[15:14]),
        .DIC(w_RegWriteData_wb[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [13:12]),
        .DOB(\u_ID/ReadData20 [15:14]),
        .DOC(\u_ID/ReadData20 [17:16]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_12_17_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD39 \u_ID/u_Registers/regs_reg_r2_0_31_18_23 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[19:18]),
        .DIB(w_RegWriteData_wb[21:20]),
        .DIC(w_RegWriteData_wb[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [19:18]),
        .DOB(\u_ID/ReadData20 [21:20]),
        .DOC(\u_ID/ReadData20 [23:22]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_18_23_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD40 \u_ID/u_Registers/regs_reg_r2_0_31_24_29 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[25:24]),
        .DIB(w_RegWriteData_wb[27:26]),
        .DIC(w_RegWriteData_wb[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [25:24]),
        .DOB(\u_ID/ReadData20 [27:26]),
        .DOC(\u_ID/ReadData20 [29:28]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_24_29_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD41 \u_ID/u_Registers/regs_reg_r2_0_31_30_31 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [31:30]),
        .DOB(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOB_UNCONNECTED [1:0]),
        .DOC(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOC_UNCONNECTED [1:0]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_30_31_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD42 \u_ID/u_Registers/regs_reg_r2_0_31_6_11 
       (.ADDRA({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRB({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRC({Instruction_id[23],Instruction_id[23:20]}),
        .ADDRD({CPUInst_n_151,CPUInst_n_152,CPUInst_n_153,CPUInst_n_154,CPUInst_n_155}),
        .DIA(w_RegWriteData_wb[7:6]),
        .DIB(w_RegWriteData_wb[9:8]),
        .DIC(w_RegWriteData_wb[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(\u_ID/ReadData20 [7:6]),
        .DOB(\u_ID/ReadData20 [9:8]),
        .DOC(\u_ID/ReadData20 [11:10]),
        .DOD(\NLW_u_ID/u_Registers/regs_reg_r2_0_31_6_11_DOD_UNCONNECTED [1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(r_RegWrite_wb));
endmodule

module Risc5CPU
   (D,
    \TMDSn[2] ,
    Q,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \q_reg[67] ,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    \TMDSn[2]_8 ,
    \TMDSn[2]_9 ,
    \TMDSn[2]_10 ,
    \TMDSn[2]_11 ,
    \q_reg[70] ,
    \q_reg[40] ,
    \q_reg[70]_0 ,
    \q_reg[69] ,
    \q_reg[68] ,
    \q_reg[66] ,
    \q_reg[67]_0 ,
    \q_reg[64] ,
    \q_reg[63] ,
    \q_reg[62] ,
    \q_reg[59] ,
    \q_reg[58] ,
    \q_reg[55] ,
    \q_reg[54] ,
    \q_reg[49] ,
    \q_reg[51] ,
    \q_reg[39] ,
    w_RegWriteData_wb,
    \TMDSn[2]_12 ,
    \TMDSn[2]_13 ,
    \TMDSn[2]_14 ,
    \TMDSn[2]_15 ,
    \TMDSn[2]_16 ,
    \TMDSn[2]_17 ,
    \TMDSn[2]_18 ,
    \TMDSn[2]_19 ,
    \TMDSn[2]_20 ,
    \TMDSn[2]_21 ,
    \TMDSn[2]_22 ,
    \TMDSn[2]_23 ,
    \TMDSn[2]_24 ,
    \TMDSn[2]_25 ,
    \q_reg[56] ,
    \q_reg[65] ,
    \q_reg[61] ,
    \q_reg[60] ,
    \q_reg[57] ,
    \q_reg[56]_0 ,
    \q_reg[53] ,
    \q_reg[52] ,
    cpu_clk_BUFG,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[5] ,
    \PosX_reg_reg[4]_2 ,
    \PosX_reg_reg[4]_3 ,
    \PosX_reg_reg[9] ,
    p_0_in__1,
    \PosX_reg_reg[2] ,
    \PosX_reg_reg[5]_0 ,
    PosY__0,
    \PosX_reg_reg[4]_4 ,
    \PosX_reg_reg[4]_5 ,
    \PosX_reg_reg[4]_6 ,
    \PosX_reg_reg[4]_7 ,
    \q_reg[147] ,
    \PosX_reg_reg[5]_1 ,
    ReadData20,
    SR,
    ReadData10);
  output [15:0]D;
  output \TMDSn[2] ;
  output [19:0]Q;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output [13:0]\q_reg[67] ;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output \TMDSn[2]_8 ;
  output \TMDSn[2]_9 ;
  output \TMDSn[2]_10 ;
  output \TMDSn[2]_11 ;
  output [19:0]\q_reg[70] ;
  output \q_reg[40] ;
  output \q_reg[70]_0 ;
  output \q_reg[69] ;
  output \q_reg[68] ;
  output \q_reg[66] ;
  output \q_reg[67]_0 ;
  output \q_reg[64] ;
  output \q_reg[63] ;
  output \q_reg[62] ;
  output \q_reg[59] ;
  output \q_reg[58] ;
  output \q_reg[55] ;
  output \q_reg[54] ;
  output \q_reg[49] ;
  output \q_reg[51] ;
  output [5:0]\q_reg[39] ;
  output [31:0]w_RegWriteData_wb;
  output \TMDSn[2]_12 ;
  output \TMDSn[2]_13 ;
  output \TMDSn[2]_14 ;
  output \TMDSn[2]_15 ;
  output \TMDSn[2]_16 ;
  output \TMDSn[2]_17 ;
  output \TMDSn[2]_18 ;
  output \TMDSn[2]_19 ;
  output \TMDSn[2]_20 ;
  output \TMDSn[2]_21 ;
  output \TMDSn[2]_22 ;
  output \TMDSn[2]_23 ;
  output \TMDSn[2]_24 ;
  output \TMDSn[2]_25 ;
  output [5:0]\q_reg[56] ;
  output \q_reg[65] ;
  output \q_reg[61] ;
  output \q_reg[60] ;
  output \q_reg[57] ;
  output \q_reg[56]_0 ;
  output \q_reg[53] ;
  output \q_reg[52] ;
  input cpu_clk_BUFG;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[5] ;
  input \PosX_reg_reg[4]_2 ;
  input \PosX_reg_reg[4]_3 ;
  input \PosX_reg_reg[9] ;
  input [0:0]p_0_in__1;
  input [0:0]\PosX_reg_reg[2] ;
  input \PosX_reg_reg[5]_0 ;
  input [0:0]PosY__0;
  input \PosX_reg_reg[4]_4 ;
  input \PosX_reg_reg[4]_5 ;
  input \PosX_reg_reg[4]_6 ;
  input \PosX_reg_reg[4]_7 ;
  input \q_reg[147] ;
  input \PosX_reg_reg[5]_1 ;
  input [31:0]ReadData20;
  input [0:0]SR;
  input [31:0]ReadData10;

  wire [31:2]ALUResult;
  wire [15:0]D;
  wire [9:9]Instruction_id;
  wire [31:0]MemDout_mem;
  wire [30:0]Next_PC;
  wire [4:0]PC;
  wire [0:0]\PosX_reg_reg[2] ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[4]_4 ;
  wire \PosX_reg_reg[4]_5 ;
  wire \PosX_reg_reg[4]_6 ;
  wire \PosX_reg_reg[4]_7 ;
  wire \PosX_reg_reg[5] ;
  wire \PosX_reg_reg[5]_0 ;
  wire \PosX_reg_reg[5]_1 ;
  wire \PosX_reg_reg[9] ;
  wire [0:0]PosY__0;
  wire [19:0]Q;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire [0:0]SR;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_10 ;
  wire \TMDSn[2]_11 ;
  wire \TMDSn[2]_12 ;
  wire \TMDSn[2]_13 ;
  wire \TMDSn[2]_14 ;
  wire \TMDSn[2]_15 ;
  wire \TMDSn[2]_16 ;
  wire \TMDSn[2]_17 ;
  wire \TMDSn[2]_18 ;
  wire \TMDSn[2]_19 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_20 ;
  wire \TMDSn[2]_21 ;
  wire \TMDSn[2]_22 ;
  wire \TMDSn[2]_23 ;
  wire \TMDSn[2]_24 ;
  wire \TMDSn[2]_25 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire \TMDSn[2]_9 ;
  wire cpu_clk_BUFG;
  wire [19:0]offset_w;
  wire [0:0]p_0_in__1;
  wire \q_reg[147] ;
  wire [5:0]\q_reg[39] ;
  wire \q_reg[40] ;
  wire \q_reg[49] ;
  wire \q_reg[51] ;
  wire \q_reg[52] ;
  wire \q_reg[53] ;
  wire \q_reg[54] ;
  wire \q_reg[55] ;
  wire [5:0]\q_reg[56] ;
  wire \q_reg[56]_0 ;
  wire \q_reg[57] ;
  wire \q_reg[58] ;
  wire \q_reg[59] ;
  wire \q_reg[60] ;
  wire \q_reg[61] ;
  wire \q_reg[62] ;
  wire \q_reg[63] ;
  wire \q_reg[64] ;
  wire \q_reg[65] ;
  wire \q_reg[66] ;
  wire [13:0]\q_reg[67] ;
  wire \q_reg[67]_0 ;
  wire \q_reg[68] ;
  wire \q_reg[69] ;
  wire [19:0]\q_reg[70] ;
  wire \q_reg[70]_0 ;
  wire [31:0]r_ALUResult_mem;
  wire r_ALUSrcA_ex;
  wire r_MemRead_ex;
  wire [31:0]r_MemWriteData_mem;
  wire r_MemWrite_mem;
  wire [31:0]r_PC_id;
  wire r_RegWrite_mem;
  wire [4:0]r_rdAddr_ex;
  wire [4:4]r_rs1Addr_ex;
  wire [4:4]r_rs2Addr_ex;
  wire [31:1]r_rs2Data_ex;
  wire u_IF1_n_0;
  wire u_IF1_n_1;
  wire u_IF1_n_10;
  wire u_IF1_n_11;
  wire u_IF1_n_12;
  wire u_IF1_n_13;
  wire u_IF1_n_14;
  wire u_IF1_n_15;
  wire u_IF1_n_16;
  wire u_IF1_n_17;
  wire u_IF1_n_18;
  wire u_IF1_n_19;
  wire u_IF1_n_2;
  wire u_IF1_n_20;
  wire u_IF1_n_21;
  wire u_IF1_n_22;
  wire u_IF1_n_23;
  wire u_IF1_n_3;
  wire u_IF1_n_33;
  wire u_IF1_n_36;
  wire u_IF1_n_4;
  wire u_IF1_n_5;
  wire u_IF1_n_57;
  wire u_IF1_n_58;
  wire u_IF1_n_59;
  wire u_IF1_n_6;
  wire u_IF1_n_60;
  wire u_IF1_n_61;
  wire u_IF1_n_62;
  wire u_IF1_n_63;
  wire u_IF1_n_64;
  wire u_IF1_n_65;
  wire u_IF1_n_66;
  wire u_IF1_n_67;
  wire u_IF1_n_68;
  wire u_IF1_n_69;
  wire u_IF1_n_7;
  wire u_IF1_n_70;
  wire u_IF1_n_8;
  wire u_IF1_n_9;
  wire u_reg_EX_MEM_n_0;
  wire u_reg_EX_MEM_n_67;
  wire u_reg_EX_MEM_n_68;
  wire u_reg_EX_MEM_n_69;
  wire u_reg_EX_MEM_n_70;
  wire u_reg_EX_MEM_n_71;
  wire u_reg_EX_MEM_n_72;
  wire u_reg_EX_MEM_n_73;
  wire u_reg_EX_MEM_n_74;
  wire u_reg_EX_MEM_n_75;
  wire u_reg_EX_MEM_n_76;
  wire u_reg_EX_MEM_n_77;
  wire u_reg_EX_MEM_n_78;
  wire u_reg_EX_MEM_n_79;
  wire u_reg_EX_MEM_n_80;
  wire u_reg_EX_MEM_n_81;
  wire u_reg_EX_MEM_n_82;
  wire u_reg_EX_MEM_n_83;
  wire u_reg_EX_MEM_n_84;
  wire u_reg_EX_MEM_n_85;
  wire u_reg_EX_MEM_n_86;
  wire u_reg_EX_MEM_n_87;
  wire u_reg_EX_MEM_n_88;
  wire u_reg_EX_MEM_n_89;
  wire u_reg_EX_MEM_n_90;
  wire u_reg_ID_EX_n_128;
  wire u_reg_ID_EX_n_138;
  wire u_reg_ID_EX_n_139;
  wire u_reg_ID_EX_n_140;
  wire u_reg_ID_EX_n_141;
  wire u_reg_ID_EX_n_35;
  wire u_reg_ID_EX_n_36;
  wire u_reg_IF_ID_n_11;
  wire u_reg_IF_ID_n_125;
  wire u_reg_IF_ID_n_126;
  wire u_reg_IF_ID_n_127;
  wire u_reg_IF_ID_n_128;
  wire u_reg_IF_ID_n_129;
  wire u_reg_IF_ID_n_13;
  wire u_reg_IF_ID_n_130;
  wire u_reg_IF_ID_n_131;
  wire u_reg_IF_ID_n_132;
  wire u_reg_IF_ID_n_133;
  wire u_reg_IF_ID_n_134;
  wire u_reg_IF_ID_n_135;
  wire u_reg_IF_ID_n_136;
  wire u_reg_IF_ID_n_137;
  wire u_reg_IF_ID_n_138;
  wire u_reg_IF_ID_n_139;
  wire u_reg_IF_ID_n_14;
  wire u_reg_IF_ID_n_140;
  wire u_reg_IF_ID_n_141;
  wire u_reg_IF_ID_n_142;
  wire u_reg_IF_ID_n_143;
  wire u_reg_IF_ID_n_144;
  wire u_reg_IF_ID_n_145;
  wire u_reg_IF_ID_n_146;
  wire u_reg_IF_ID_n_147;
  wire u_reg_IF_ID_n_148;
  wire u_reg_IF_ID_n_149;
  wire u_reg_IF_ID_n_15;
  wire u_reg_IF_ID_n_150;
  wire u_reg_IF_ID_n_151;
  wire u_reg_IF_ID_n_152;
  wire u_reg_IF_ID_n_153;
  wire u_reg_IF_ID_n_154;
  wire u_reg_IF_ID_n_155;
  wire u_reg_IF_ID_n_156;
  wire u_reg_IF_ID_n_157;
  wire u_reg_IF_ID_n_158;
  wire u_reg_IF_ID_n_159;
  wire u_reg_IF_ID_n_16;
  wire u_reg_IF_ID_n_160;
  wire u_reg_IF_ID_n_17;
  wire u_reg_IF_ID_n_18;
  wire u_reg_IF_ID_n_19;
  wire u_reg_IF_ID_n_20;
  wire u_reg_IF_ID_n_21;
  wire u_reg_IF_ID_n_22;
  wire u_reg_IF_ID_n_23;
  wire u_reg_IF_ID_n_24;
  wire u_reg_IF_ID_n_25;
  wire u_reg_IF_ID_n_9;
  wire u_reg_MEM_WB_n_65;
  wire u_reg_MEM_WB_n_67;
  wire u_reg_MEM_WB_n_68;
  wire u_reg_MEM_WB_n_69;
  wire u_reg_MEM_WB_n_71;
  wire u_reg_MEM_WB_n_72;
  wire u_reg_MEM_WB_n_74;
  wire u_reg_MEM_WB_n_76;
  wire u_reg_MEM_WB_n_78;
  wire u_reg_MEM_WB_n_80;
  wire u_reg_MEM_WB_n_81;
  wire u_reg_MEM_WB_n_82;
  wire u_reg_MEM_WB_n_90;
  wire u_reg_MEM_WB_n_99;
  wire [3:0]w_ALUCode_id;
  wire w_ALUSrcA_id;
  wire [0:0]w_ALUSrcB_id;
  wire w_IFWrite;
  wire [27:0]w_Imm_id;
  wire [30:2]w_Instruction_if;
  wire [31:0]w_JumpAddr;
  wire w_MemRead_id;
  wire [2:0]w_MemWriteData_ex;
  wire w_MemWrite_id;
  wire [31:0]w_RegWriteData_wb;
  wire w_RegWrite_id;
  wire [31:0]w_rs1Data_id;
  wire [31:0]w_rs2Data_id;

  LUT5 #(
    .INIT(32'hFEBA5410)) 
    char_tab_i_124
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(\PosX_reg_reg[4]_3 ),
        .I2(MemDout_mem[1]),
        .I3(MemDout_mem[5]),
        .I4(MemDout_mem[9]),
        .O(\TMDSn[2]_23 ));
  LUT5 #(
    .INIT(32'hFEBA5410)) 
    char_tab_i_130
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(\PosX_reg_reg[4]_3 ),
        .I2(MemDout_mem[0]),
        .I3(MemDout_mem[4]),
        .I4(MemDout_mem[8]),
        .O(\TMDSn[2]_22 ));
  LUT5 #(
    .INIT(32'hFEBA5410)) 
    char_tab_i_74
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(\PosX_reg_reg[4]_3 ),
        .I2(MemDout_mem[3]),
        .I3(MemDout_mem[7]),
        .I4(MemDout_mem[11]),
        .O(\TMDSn[2]_25 ));
  LUT5 #(
    .INIT(32'hFEBA5410)) 
    char_tab_i_81
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(\PosX_reg_reg[4]_3 ),
        .I2(MemDout_mem[2]),
        .I3(MemDout_mem[6]),
        .I4(MemDout_mem[10]),
        .O(\TMDSn[2]_24 ));
  (* x_core_info = "dist_mem_gen_v8_0_12,Vivado 2017.3" *) 
  DataRAM u_DataRAM
       (.a(r_ALUResult_mem[7:2]),
        .clk(cpu_clk_BUFG),
        .d(r_MemWriteData_mem),
        .spo({MemDout_mem[31:28],D,MemDout_mem[11:0]}),
        .we(r_MemWrite_mem));
  ID u_ID
       (.S({u_reg_IF_ID_n_133,u_reg_IF_ID_n_134,u_reg_IF_ID_n_135,u_reg_IF_ID_n_136}),
        .offset_w({offset_w[19],offset_w[17:10],offset_w[7:0]}),
        .\q_reg[39] ({u_reg_IF_ID_n_137,u_reg_IF_ID_n_138,u_reg_IF_ID_n_139,u_reg_IF_ID_n_140}),
        .\q_reg[43] ({u_reg_IF_ID_n_141,u_reg_IF_ID_n_142,u_reg_IF_ID_n_143,u_reg_IF_ID_n_144}),
        .\q_reg[47] ({u_reg_IF_ID_n_145,u_reg_IF_ID_n_146,u_reg_IF_ID_n_147,u_reg_IF_ID_n_148}),
        .\q_reg[51] ({u_reg_IF_ID_n_149,u_reg_IF_ID_n_150,u_reg_IF_ID_n_151,u_reg_IF_ID_n_152}),
        .\q_reg[55] ({u_reg_IF_ID_n_153,u_reg_IF_ID_n_154,u_reg_IF_ID_n_155,u_reg_IF_ID_n_156}),
        .\q_reg[59] ({u_reg_IF_ID_n_157,u_reg_IF_ID_n_158,u_reg_IF_ID_n_159,u_reg_IF_ID_n_160}),
        .\q_reg[63] ({u_reg_IF_ID_n_129,u_reg_IF_ID_n_130,u_reg_IF_ID_n_131,u_reg_IF_ID_n_132}),
        .w_JumpAddr(w_JumpAddr));
  IF1 u_IF1
       (.D({u_IF1_n_0,u_IF1_n_1,u_IF1_n_2,u_IF1_n_3,u_IF1_n_4,u_IF1_n_5,u_IF1_n_6,u_IF1_n_7,u_IF1_n_8,u_IF1_n_9,u_IF1_n_10,u_IF1_n_11,u_IF1_n_12,u_IF1_n_13,u_IF1_n_14,u_IF1_n_15,u_IF1_n_16,u_IF1_n_17,u_IF1_n_18,u_IF1_n_19,u_IF1_n_20,u_IF1_n_21,u_IF1_n_22,u_IF1_n_23,\q_reg[39] [5:3],PC[4],\q_reg[39] [2:0],PC[0],w_Instruction_if[30],u_IF1_n_33,w_Instruction_if[26:25],u_IF1_n_36,w_Instruction_if[22:19],w_Instruction_if[17:2],u_IF1_n_57}),
        .E(w_IFWrite),
        .\PC_reg_reg[11]_0 (u_IF1_n_69),
        .\PC_reg_reg[13]_0 (u_IF1_n_59),
        .\PC_reg_reg[15]_0 (u_IF1_n_68),
        .\PC_reg_reg[17]_0 (u_IF1_n_60),
        .\PC_reg_reg[19]_0 (u_IF1_n_67),
        .\PC_reg_reg[21]_0 (u_IF1_n_61),
        .\PC_reg_reg[23]_0 (u_IF1_n_66),
        .\PC_reg_reg[25]_0 (u_IF1_n_62),
        .\PC_reg_reg[27]_0 (u_IF1_n_65),
        .\PC_reg_reg[29]_0 (u_IF1_n_63),
        .\PC_reg_reg[30]_0 ({Next_PC[30],Next_PC[28:27],Next_PC[24:23],Next_PC[20:19],Next_PC[16:15],Next_PC[12:11],Next_PC[8:7],Next_PC[3:0]}),
        .\PC_reg_reg[31]_0 (u_IF1_n_64),
        .\PC_reg_reg[7]_0 (u_IF1_n_70),
        .\PC_reg_reg[9]_0 (u_IF1_n_58),
        .SR(SR),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[2] (u_reg_IF_ID_n_125),
        .w_JumpAddr({w_JumpAddr[31],w_JumpAddr[29],w_JumpAddr[26:25],w_JumpAddr[22:21],w_JumpAddr[18:17],w_JumpAddr[14:13],w_JumpAddr[10:9],w_JumpAddr[6:4]}));
  DFF__parameterized1 u_reg_EX_MEM
       (.D({ALUResult[31:28],\q_reg[67] [13:12],ALUResult[25:24],\q_reg[67] [11:10],ALUResult[21:20],\q_reg[67] [9:8],ALUResult[17:16],\q_reg[67] [7:6],ALUResult[13:10],\q_reg[67] [5:4],ALUResult[7:6],\q_reg[67] [3:2],ALUResult[3:2],\q_reg[67] [1:0],w_MemWriteData_ex[2],w_MemWriteData_ex[0],u_reg_ID_EX_n_35,u_reg_ID_EX_n_36,r_MemRead_ex,r_rdAddr_ex}),
        .Q({r_ALUResult_mem,r_MemWriteData_mem,r_MemWrite_mem,r_RegWrite_mem,u_reg_EX_MEM_n_67,u_reg_EX_MEM_n_68,u_reg_EX_MEM_n_69,u_reg_EX_MEM_n_70,u_reg_EX_MEM_n_71,u_reg_EX_MEM_n_72}),
        .SR(SR),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[10]_0 (u_reg_EX_MEM_n_74),
        .\q_reg[145] ({r_ALUSrcA_ex,r_rs2Data_ex[31:3],r_rs2Data_ex[1],r_rs1Addr_ex,r_rs2Addr_ex}),
        .\q_reg[2]_0 (u_reg_MEM_WB_n_67),
        .\q_reg[39]_0 (u_reg_EX_MEM_n_0),
        .\q_reg[39]_1 (u_reg_ID_EX_n_139),
        .\q_reg[39]_2 (u_reg_ID_EX_n_138),
        .\q_reg[40]_0 (w_RegWriteData_wb[1]),
        .\q_reg[41]_0 (u_reg_ID_EX_n_128),
        .\q_reg[41]_1 (u_reg_MEM_WB_n_68),
        .\q_reg[42]_0 (u_reg_EX_MEM_n_89),
        .\q_reg[42]_1 (w_RegWriteData_wb[3]),
        .\q_reg[43]_0 (u_reg_EX_MEM_n_79),
        .\q_reg[43]_1 (u_reg_EX_MEM_n_88),
        .\q_reg[43]_2 (w_RegWriteData_wb[4]),
        .\q_reg[44]_0 (u_reg_EX_MEM_n_78),
        .\q_reg[44]_1 (u_reg_EX_MEM_n_87),
        .\q_reg[44]_2 (w_RegWriteData_wb[5]),
        .\q_reg[44]_3 (u_reg_ID_EX_n_141),
        .\q_reg[44]_4 (u_reg_ID_EX_n_140),
        .\q_reg[45]_0 (u_reg_EX_MEM_n_86),
        .\q_reg[45]_1 (w_RegWriteData_wb[6]),
        .\q_reg[46]_0 (u_reg_EX_MEM_n_75),
        .\q_reg[46]_1 (u_reg_EX_MEM_n_76),
        .\q_reg[46]_2 (u_reg_EX_MEM_n_85),
        .\q_reg[46]_3 (w_RegWriteData_wb[7]),
        .\q_reg[46]_4 (u_reg_MEM_WB_n_80),
        .\q_reg[47]_0 (w_RegWriteData_wb[8]),
        .\q_reg[48]_0 (u_reg_EX_MEM_n_77),
        .\q_reg[48]_1 (u_reg_EX_MEM_n_84),
        .\q_reg[48]_2 (w_RegWriteData_wb[9]),
        .\q_reg[49]_0 (u_reg_EX_MEM_n_83),
        .\q_reg[49]_1 (w_RegWriteData_wb[10]),
        .\q_reg[50]_0 (w_RegWriteData_wb[11]),
        .\q_reg[51]_0 (u_reg_EX_MEM_n_73),
        .\q_reg[51]_1 (u_reg_EX_MEM_n_81),
        .\q_reg[51]_2 (u_reg_EX_MEM_n_82),
        .\q_reg[51]_3 (w_RegWriteData_wb[12]),
        .\q_reg[52]_0 (w_RegWriteData_wb[13]),
        .\q_reg[53]_0 (u_reg_EX_MEM_n_80),
        .\q_reg[53]_1 (w_RegWriteData_wb[14]),
        .\q_reg[54]_0 (w_RegWriteData_wb[15]),
        .\q_reg[55]_0 (w_RegWriteData_wb[16]),
        .\q_reg[56]_0 (w_RegWriteData_wb[17]),
        .\q_reg[57]_0 (w_RegWriteData_wb[18]),
        .\q_reg[58]_0 (w_RegWriteData_wb[19]),
        .\q_reg[59]_0 (w_RegWriteData_wb[20]),
        .\q_reg[60]_0 (w_RegWriteData_wb[21]),
        .\q_reg[61]_0 (w_RegWriteData_wb[22]),
        .\q_reg[62]_0 (w_RegWriteData_wb[23]),
        .\q_reg[63]_0 (w_RegWriteData_wb[24]),
        .\q_reg[64]_0 (w_RegWriteData_wb[25]),
        .\q_reg[65]_0 (w_RegWriteData_wb[26]),
        .\q_reg[66]_0 (w_RegWriteData_wb[27]),
        .\q_reg[67]_0 (w_RegWriteData_wb[28]),
        .\q_reg[68]_0 (w_RegWriteData_wb[29]),
        .\q_reg[69]_0 (w_RegWriteData_wb[30]),
        .\q_reg[70]_0 (u_reg_EX_MEM_n_90),
        .\q_reg[70]_1 (w_RegWriteData_wb[31]));
  DFF__parameterized0 u_reg_ID_EX
       (.D({MemDout_mem[31:28],r_ALUResult_mem[31:5],r_ALUResult_mem[2:0],u_reg_EX_MEM_n_70,u_reg_EX_MEM_n_71,u_reg_EX_MEM_n_72}),
        .E(w_IFWrite),
        .\PC_reg_reg[4] ({PC[4],PC[0]}),
        .\PosX_reg_reg[4] (\PosX_reg_reg[4]_4 ),
        .\PosX_reg_reg[4]_0 (\PosX_reg_reg[4]_5 ),
        .\PosX_reg_reg[4]_1 (\PosX_reg_reg[4]_6 ),
        .\PosX_reg_reg[4]_2 (\PosX_reg_reg[4]_7 ),
        .\PosX_reg_reg[4]_3 (\PosX_reg_reg[4] ),
        .\PosX_reg_reg[4]_4 (\PosX_reg_reg[4]_3 ),
        .\PosX_reg_reg[4]_5 (\PosX_reg_reg[4]_1 ),
        .\PosX_reg_reg[5] (\PosX_reg_reg[5]_0 ),
        .\PosX_reg_reg[5]_0 (\PosX_reg_reg[5]_1 ),
        .PosY__0(PosY__0),
        .Q({r_ALUSrcA_ex,r_rs2Data_ex[31:3],r_rs2Data_ex[1],r_rs1Addr_ex,r_rs2Addr_ex}),
        .SR(SR),
        .\TMDSn[2] (\TMDSn[2]_1 ),
        .\TMDSn[2]_0 (\TMDSn[2]_2 ),
        .\TMDSn[2]_1 (\TMDSn[2]_3 ),
        .\TMDSn[2]_10 (\TMDSn[2]_14 ),
        .\TMDSn[2]_11 (\TMDSn[2]_15 ),
        .\TMDSn[2]_12 (\TMDSn[2]_16 ),
        .\TMDSn[2]_13 (\TMDSn[2]_17 ),
        .\TMDSn[2]_14 (\TMDSn[2]_18 ),
        .\TMDSn[2]_15 (\TMDSn[2]_19 ),
        .\TMDSn[2]_16 (\TMDSn[2]_20 ),
        .\TMDSn[2]_17 (\TMDSn[2]_21 ),
        .\TMDSn[2]_2 (\TMDSn[2]_4 ),
        .\TMDSn[2]_3 (\TMDSn[2]_5 ),
        .\TMDSn[2]_4 (\TMDSn[2]_6 ),
        .\TMDSn[2]_5 (\TMDSn[2]_7 ),
        .\TMDSn[2]_6 (\TMDSn[2]_8 ),
        .\TMDSn[2]_7 (\TMDSn[2]_9 ),
        .\TMDSn[2]_8 (\TMDSn[2]_12 ),
        .\TMDSn[2]_9 (\TMDSn[2]_13 ),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[10]_0 (u_reg_ID_EX_n_128),
        .\q_reg[10]_1 (u_reg_ID_EX_n_138),
        .\q_reg[10]_2 (u_reg_ID_EX_n_139),
        .\q_reg[145]_0 (u_reg_EX_MEM_n_83),
        .\q_reg[145]_1 (u_reg_EX_MEM_n_84),
        .\q_reg[145]_2 (u_reg_EX_MEM_n_86),
        .\q_reg[145]_3 (u_reg_EX_MEM_n_87),
        .\q_reg[145]_4 (u_reg_EX_MEM_n_88),
        .\q_reg[145]_5 (u_reg_EX_MEM_n_89),
        .\q_reg[147]_0 (\q_reg[147] ),
        .\q_reg[2]_0 (u_reg_MEM_WB_n_67),
        .\q_reg[2]_1 ({w_RegWrite_id,w_MemWrite_id,w_MemRead_id,w_ALUCode_id,w_ALUSrcA_id,u_reg_IF_ID_n_9,w_ALUSrcB_id,u_reg_IF_ID_n_11,w_Imm_id[27],u_reg_IF_ID_n_13,u_reg_IF_ID_n_14,u_reg_IF_ID_n_15,u_reg_IF_ID_n_16,u_reg_IF_ID_n_17,u_reg_IF_ID_n_18,u_reg_IF_ID_n_19,u_reg_IF_ID_n_20,u_reg_IF_ID_n_21,u_reg_IF_ID_n_22,u_reg_IF_ID_n_23,u_reg_IF_ID_n_24,u_reg_IF_ID_n_25,w_Imm_id[10],w_Imm_id[7:0],w_rs1Data_id,w_rs2Data_id,Q[11:8],Q[15:12],Q[6:5],Instruction_id,Q[4:3],r_PC_id}),
        .\q_reg[2]_2 (\q_reg[56] [2:0]),
        .\q_reg[39]_0 (u_reg_MEM_WB_n_76),
        .\q_reg[39]_1 (w_RegWriteData_wb[0]),
        .\q_reg[40] (\q_reg[40] ),
        .\q_reg[40]_0 (u_reg_MEM_WB_n_74),
        .\q_reg[40]_1 (u_reg_EX_MEM_n_82),
        .\q_reg[40]_2 (w_RegWriteData_wb[1]),
        .\q_reg[41]_0 (u_reg_EX_MEM_n_0),
        .\q_reg[41]_1 (u_reg_MEM_WB_n_72),
        .\q_reg[41]_2 (w_RegWriteData_wb[2]),
        .\q_reg[41]_3 (u_reg_EX_MEM_n_81),
        .\q_reg[41]_4 (u_reg_EX_MEM_n_74),
        .\q_reg[41]_5 (u_reg_MEM_WB_n_68),
        .\q_reg[42]_0 (u_reg_ID_EX_n_140),
        .\q_reg[42]_1 (u_reg_ID_EX_n_141),
        .\q_reg[42]_2 (u_reg_MEM_WB_n_71),
        .\q_reg[42]_3 (u_reg_EX_MEM_n_80),
        .\q_reg[42]_4 (w_RegWriteData_wb[3]),
        .\q_reg[43]_0 (u_reg_MEM_WB_n_69),
        .\q_reg[43]_1 (u_reg_EX_MEM_n_79),
        .\q_reg[43]_2 (w_RegWriteData_wb[4]),
        .\q_reg[44]_0 (u_reg_MEM_WB_n_65),
        .\q_reg[44]_1 (w_RegWriteData_wb[5]),
        .\q_reg[44]_2 (u_reg_EX_MEM_n_78),
        .\q_reg[45] (w_RegWriteData_wb[6]),
        .\q_reg[45]_0 (u_reg_EX_MEM_n_77),
        .\q_reg[45]_1 (u_reg_MEM_WB_n_78),
        .\q_reg[46]_0 (w_RegWriteData_wb[7]),
        .\q_reg[46]_1 (u_reg_EX_MEM_n_90),
        .\q_reg[46]_2 (u_reg_EX_MEM_n_85),
        .\q_reg[46]_3 (u_reg_EX_MEM_n_76),
        .\q_reg[46]_4 (u_reg_MEM_WB_n_80),
        .\q_reg[47]_0 (w_RegWriteData_wb[8]),
        .\q_reg[48]_0 (w_RegWriteData_wb[9]),
        .\q_reg[49]_0 (\q_reg[49] ),
        .\q_reg[49]_1 (w_RegWriteData_wb[10]),
        .\q_reg[50]_0 (w_RegWriteData_wb[11]),
        .\q_reg[51]_0 (\q_reg[51] ),
        .\q_reg[51]_1 (w_RegWriteData_wb[12]),
        .\q_reg[52]_0 (\q_reg[70] [0]),
        .\q_reg[52]_1 (\q_reg[52] ),
        .\q_reg[52]_2 (w_RegWriteData_wb[13]),
        .\q_reg[53]_0 (\q_reg[70] [1]),
        .\q_reg[53]_1 (\q_reg[53] ),
        .\q_reg[53]_2 (w_RegWriteData_wb[14]),
        .\q_reg[54]_0 (\q_reg[70] [2]),
        .\q_reg[54]_1 (\q_reg[54] ),
        .\q_reg[54]_2 (w_RegWriteData_wb[15]),
        .\q_reg[55]_0 (\q_reg[70] [3]),
        .\q_reg[55]_1 (\q_reg[55] ),
        .\q_reg[55]_2 (w_RegWriteData_wb[16]),
        .\q_reg[56]_0 (\q_reg[70] [4]),
        .\q_reg[56]_1 (\q_reg[56]_0 ),
        .\q_reg[56]_2 (w_RegWriteData_wb[17]),
        .\q_reg[57]_0 (\q_reg[70] [5]),
        .\q_reg[57]_1 (\q_reg[57] ),
        .\q_reg[57]_2 (w_RegWriteData_wb[18]),
        .\q_reg[58]_0 (\q_reg[58] ),
        .\q_reg[58]_1 (\q_reg[70] [6]),
        .\q_reg[58]_2 (w_RegWriteData_wb[19]),
        .\q_reg[59]_0 (\q_reg[70] [7]),
        .\q_reg[59]_1 (\q_reg[59] ),
        .\q_reg[59]_2 (w_RegWriteData_wb[20]),
        .\q_reg[60]_0 (\q_reg[70] [8]),
        .\q_reg[60]_1 (\q_reg[60] ),
        .\q_reg[60]_2 (w_RegWriteData_wb[21]),
        .\q_reg[61]_0 (\q_reg[61] ),
        .\q_reg[61]_1 (\q_reg[70] [9]),
        .\q_reg[61]_2 (w_RegWriteData_wb[22]),
        .\q_reg[62]_0 (\q_reg[70] [10]),
        .\q_reg[62]_1 (\q_reg[62] ),
        .\q_reg[62]_2 (w_RegWriteData_wb[23]),
        .\q_reg[63]_0 (\q_reg[70] [11]),
        .\q_reg[63]_1 (\q_reg[63] ),
        .\q_reg[63]_2 (w_RegWriteData_wb[24]),
        .\q_reg[64]_0 (\q_reg[64] ),
        .\q_reg[64]_1 (\q_reg[70] [12]),
        .\q_reg[64]_2 (w_RegWriteData_wb[25]),
        .\q_reg[65]_0 (\q_reg[70] [13]),
        .\q_reg[65]_1 (\q_reg[70] [16]),
        .\q_reg[65]_2 (\q_reg[65] ),
        .\q_reg[65]_3 (w_RegWriteData_wb[26]),
        .\q_reg[66]_0 (\q_reg[70] [14]),
        .\q_reg[66]_1 (\q_reg[66] ),
        .\q_reg[66]_2 (w_RegWriteData_wb[27]),
        .\q_reg[67]_0 (\q_reg[70] [15]),
        .\q_reg[67]_1 (\q_reg[67]_0 ),
        .\q_reg[67]_2 (w_RegWriteData_wb[28]),
        .\q_reg[68]_0 (\q_reg[68] ),
        .\q_reg[68]_1 (\q_reg[70] [17]),
        .\q_reg[68]_2 (w_RegWriteData_wb[29]),
        .\q_reg[69]_0 (\q_reg[70] [18]),
        .\q_reg[69]_1 (\q_reg[69] ),
        .\q_reg[69]_2 (w_RegWriteData_wb[30]),
        .\q_reg[6]_0 (u_reg_EX_MEM_n_73),
        .\q_reg[6]_1 (u_reg_EX_MEM_n_75),
        .\q_reg[70]_0 (\q_reg[70] [19]),
        .\q_reg[70]_1 (\q_reg[70]_0 ),
        .\q_reg[70]_2 (w_RegWriteData_wb[31]),
        .\q_reg[71]_0 ({ALUResult[31:28],\q_reg[67] [13:12],ALUResult[25:24],\q_reg[67] [11:10],ALUResult[21:20],\q_reg[67] [9:8],ALUResult[17:16],\q_reg[67] [7:6],ALUResult[13:10],\q_reg[67] [5:4],ALUResult[7:6],\q_reg[67] [3:2],ALUResult[3:2],\q_reg[67] [1:0],w_MemWriteData_ex[2],w_MemWriteData_ex[0],u_reg_ID_EX_n_35,u_reg_ID_EX_n_36,r_MemRead_ex,r_rdAddr_ex}));
  DFF u_reg_IF_ID
       (.D({u_IF1_n_0,u_IF1_n_1,u_IF1_n_2,u_IF1_n_3,u_IF1_n_4,u_IF1_n_5,u_IF1_n_6,u_IF1_n_7,u_IF1_n_8,u_IF1_n_9,u_IF1_n_10,u_IF1_n_11,u_IF1_n_12,u_IF1_n_13,u_IF1_n_14,u_IF1_n_15,u_IF1_n_16,u_IF1_n_17,u_IF1_n_18,u_IF1_n_19,u_IF1_n_20,u_IF1_n_21,u_IF1_n_22,u_IF1_n_23,\q_reg[39] [5:3],PC[4],\q_reg[39] [2:0],PC[0],w_Instruction_if[30],u_IF1_n_33,w_Instruction_if[26:25],u_IF1_n_36,w_Instruction_if[22:19],w_Instruction_if[17:2],u_IF1_n_57}),
        .E(w_IFWrite),
        .\PC_reg_reg[0] (u_reg_IF_ID_n_125),
        .\PC_reg_reg[10] (u_IF1_n_59),
        .\PC_reg_reg[11] ({u_reg_IF_ID_n_141,u_reg_IF_ID_n_142,u_reg_IF_ID_n_143,u_reg_IF_ID_n_144}),
        .\PC_reg_reg[13] (u_IF1_n_68),
        .\PC_reg_reg[15] ({u_reg_IF_ID_n_145,u_reg_IF_ID_n_146,u_reg_IF_ID_n_147,u_reg_IF_ID_n_148}),
        .\PC_reg_reg[15]_0 (u_IF1_n_60),
        .\PC_reg_reg[17] (u_IF1_n_67),
        .\PC_reg_reg[19] ({u_reg_IF_ID_n_149,u_reg_IF_ID_n_150,u_reg_IF_ID_n_151,u_reg_IF_ID_n_152}),
        .\PC_reg_reg[19]_0 (u_IF1_n_61),
        .\PC_reg_reg[21] (u_IF1_n_66),
        .\PC_reg_reg[23] ({u_reg_IF_ID_n_153,u_reg_IF_ID_n_154,u_reg_IF_ID_n_155,u_reg_IF_ID_n_156}),
        .\PC_reg_reg[23]_0 (u_IF1_n_62),
        .\PC_reg_reg[25] (u_IF1_n_65),
        .\PC_reg_reg[27] ({u_reg_IF_ID_n_157,u_reg_IF_ID_n_158,u_reg_IF_ID_n_159,u_reg_IF_ID_n_160}),
        .\PC_reg_reg[27]_0 (u_IF1_n_63),
        .\PC_reg_reg[29] (u_IF1_n_64),
        .\PC_reg_reg[2] (u_IF1_n_70),
        .\PC_reg_reg[30] ({Next_PC[30],Next_PC[28:27],Next_PC[24:23],Next_PC[20:19],Next_PC[16:15],Next_PC[12:11],Next_PC[8:7],Next_PC[3:0]}),
        .\PC_reg_reg[31] ({u_reg_IF_ID_n_129,u_reg_IF_ID_n_130,u_reg_IF_ID_n_131,u_reg_IF_ID_n_132}),
        .\PC_reg_reg[6] (u_IF1_n_58),
        .\PC_reg_reg[7] ({u_reg_IF_ID_n_137,u_reg_IF_ID_n_138,u_reg_IF_ID_n_139,u_reg_IF_ID_n_140}),
        .\PC_reg_reg[9] (u_IF1_n_69),
        .\PosX_reg_reg[2] (\PosX_reg_reg[2] ),
        .\PosX_reg_reg[4] (\PosX_reg_reg[4] ),
        .\PosX_reg_reg[4]_0 (\PosX_reg_reg[4]_0 ),
        .\PosX_reg_reg[4]_1 (\PosX_reg_reg[4]_1 ),
        .\PosX_reg_reg[4]_2 (\PosX_reg_reg[4]_2 ),
        .\PosX_reg_reg[4]_3 (\PosX_reg_reg[4]_3 ),
        .\PosX_reg_reg[5] (\PosX_reg_reg[5] ),
        .\PosX_reg_reg[9] (\PosX_reg_reg[9] ),
        .Q({Q[19:16],Q[7],Q[2:0]}),
        .ReadData10(ReadData10[4:2]),
        .S({u_reg_IF_ID_n_133,u_reg_IF_ID_n_134,u_reg_IF_ID_n_135,u_reg_IF_ID_n_136}),
        .SR(SR),
        .\TMDSn[2] (\TMDSn[2] ),
        .\TMDSn[2]_0 (\TMDSn[2]_0 ),
        .\TMDSn[2]_1 (\TMDSn[2]_10 ),
        .\TMDSn[2]_2 (\TMDSn[2]_11 ),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .offset_w({offset_w[19],offset_w[17:10],offset_w[7:0]}),
        .p_0_in__1(p_0_in__1),
        .\q_reg[110] (u_reg_IF_ID_n_126),
        .\q_reg[152] ({w_RegWrite_id,w_MemWrite_id,w_MemRead_id,w_ALUCode_id,w_ALUSrcA_id,u_reg_IF_ID_n_9,w_ALUSrcB_id,u_reg_IF_ID_n_11,w_Imm_id[27],u_reg_IF_ID_n_13,u_reg_IF_ID_n_14,u_reg_IF_ID_n_15,u_reg_IF_ID_n_16,u_reg_IF_ID_n_17,u_reg_IF_ID_n_18,u_reg_IF_ID_n_19,u_reg_IF_ID_n_20,u_reg_IF_ID_n_21,u_reg_IF_ID_n_22,u_reg_IF_ID_n_23,u_reg_IF_ID_n_24,u_reg_IF_ID_n_25,w_Imm_id[10],w_Imm_id[7:0],Q[11:8],Q[15:12],Q[6:5],Instruction_id,Q[4:3],r_PC_id}),
        .\q_reg[19]_0 (u_reg_MEM_WB_n_99),
        .\q_reg[2]_0 (\q_reg[56] [2:0]),
        .\q_reg[41]_0 (w_RegWriteData_wb[2]),
        .\q_reg[42]_0 (w_RegWriteData_wb[3]),
        .\q_reg[43]_0 (w_RegWriteData_wb[4]),
        .\q_reg[54]_0 (u_reg_MEM_WB_n_90),
        .\q_reg[55]_0 (u_reg_MEM_WB_n_82),
        .\q_reg[56]_0 (u_reg_IF_ID_n_127),
        .\q_reg[69] (u_reg_MEM_WB_n_81),
        .\q_reg[70] ({w_rs1Data_id[31:5],w_rs1Data_id[1:0],w_rs2Data_id[31]}),
        .\q_reg[78] (u_reg_IF_ID_n_128),
        .w_JumpAddr({w_JumpAddr[30],w_JumpAddr[28:27],w_JumpAddr[24:23],w_JumpAddr[20:19],w_JumpAddr[16:15],w_JumpAddr[12:11],w_JumpAddr[8:7],w_JumpAddr[3:0]}));
  DFF__parameterized2 u_reg_MEM_WB
       (.D({MemDout_mem[31:28],D,MemDout_mem[11:0],r_ALUResult_mem,r_RegWrite_mem,u_reg_EX_MEM_n_67,u_reg_EX_MEM_n_68,u_reg_EX_MEM_n_69,u_reg_EX_MEM_n_70,u_reg_EX_MEM_n_71,u_reg_EX_MEM_n_72}),
        .\PC_reg_reg[0] (u_reg_MEM_WB_n_81),
        .\PC_reg_reg[0]_0 (u_reg_MEM_WB_n_82),
        .\PC_reg_reg[0]_1 (u_reg_MEM_WB_n_90),
        .Q(\q_reg[56] ),
        .ReadData10(ReadData10),
        .ReadData20(ReadData20),
        .SR(SR),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[10]_0 (u_reg_MEM_WB_n_68),
        .\q_reg[110] ({w_rs1Data_id,w_rs2Data_id}),
        .\q_reg[110]_0 (u_reg_MEM_WB_n_99),
        .\q_reg[19]_0 (w_RegWriteData_wb[11]),
        .\q_reg[19]_1 (u_reg_IF_ID_n_126),
        .\q_reg[19]_2 ({Q[11:8],Q[15]}),
        .\q_reg[20]_0 (w_RegWriteData_wb[12]),
        .\q_reg[21]_0 (w_RegWriteData_wb[13]),
        .\q_reg[22]_0 (w_RegWriteData_wb[14]),
        .\q_reg[22]_1 (u_reg_IF_ID_n_128),
        .\q_reg[22]_2 (u_reg_IF_ID_n_127),
        .\q_reg[23]_0 (w_RegWriteData_wb[15]),
        .\q_reg[27]_0 (w_RegWriteData_wb[19]),
        .\q_reg[28]_0 (w_RegWriteData_wb[20]),
        .\q_reg[29]_0 (w_RegWriteData_wb[21]),
        .\q_reg[30]_0 (w_RegWriteData_wb[22]),
        .\q_reg[31]_0 (w_RegWriteData_wb[23]),
        .\q_reg[35]_0 (w_RegWriteData_wb[27]),
        .\q_reg[39]_0 (w_RegWriteData_wb[31]),
        .\q_reg[39]_1 (u_reg_ID_EX_n_139),
        .\q_reg[39]_2 (u_reg_ID_EX_n_138),
        .\q_reg[41]_0 (u_reg_EX_MEM_n_74),
        .\q_reg[43]_0 (u_reg_MEM_WB_n_71),
        .\q_reg[44]_0 (u_reg_MEM_WB_n_69),
        .\q_reg[44]_1 (u_reg_ID_EX_n_141),
        .\q_reg[44]_2 (u_reg_ID_EX_n_140),
        .\q_reg[46]_0 (u_reg_MEM_WB_n_78),
        .\q_reg[46]_1 (u_reg_MEM_WB_n_80),
        .\q_reg[46]_2 (u_reg_EX_MEM_n_76),
        .\q_reg[46]_3 ({r_rs1Addr_ex,r_rs2Addr_ex}),
        .\q_reg[48]_0 (u_reg_MEM_WB_n_65),
        .\q_reg[51]_0 (u_reg_MEM_WB_n_74),
        .\q_reg[51]_1 (u_reg_MEM_WB_n_76),
        .\q_reg[53]_0 (u_reg_MEM_WB_n_72),
        .\q_reg[56]_0 (u_reg_MEM_WB_n_67),
        .\q_reg[79] (w_RegWriteData_wb[0]),
        .\q_reg[81] (w_RegWriteData_wb[2]),
        .\q_reg[82] (w_RegWriteData_wb[3]),
        .\q_reg[83] (w_RegWriteData_wb[4]),
        .\q_reg[84] (w_RegWriteData_wb[5]),
        .\q_reg[85] (w_RegWriteData_wb[6]),
        .\q_reg[86] (w_RegWriteData_wb[7]),
        .\q_reg[87] (w_RegWriteData_wb[8]),
        .\q_reg[88] (w_RegWriteData_wb[9]),
        .\q_reg[89] (w_RegWriteData_wb[10]),
        .\q_reg[9]_0 (w_RegWriteData_wb[1]),
        .w_RegWriteData_wb({w_RegWriteData_wb[30:28],w_RegWriteData_wb[26:24],w_RegWriteData_wb[18:16]}));
endmodule

module TMDSencode
   (ActiveArea,
    TMDSch0,
    TMDSch1,
    TMDSch2,
    hSync,
    pixel_clk,
    reset,
    tmds_clk,
    vSync,
    blue,
    green,
    red,
    lopt);
  input ActiveArea;
  output TMDSch0;
  output TMDSch1;
  output TMDSch2;
  input hSync;
  input pixel_clk;
  input reset;
  input tmds_clk;
  input vSync;
  input [7:0]blue;
  input [7:0]green;
  input [7:0]red;
  input lopt;

  wire ActiveArea;
  wire TMDSch0_OBUF;
  wire TMDSch0_i_1_n_0;
  wire TMDSch0_i_2_n_0;
  wire TMDSch0_i_4_n_0;
  wire TMDSch0_i_5_n_0;
  wire TMDSch0_reg_i_3_n_0;
  wire TMDSch1_OBUF;
  wire TMDSch1_i_1_n_0;
  wire TMDSch1_i_3_n_0;
  wire TMDSch1_i_4_n_0;
  wire TMDSch1_reg_i_2_n_0;
  wire TMDSch2_OBUF;
  wire TMDSch2_i_1_n_0;
  wire TMDSch2_i_3_n_0;
  wire TMDSch2_i_4_n_0;
  wire TMDSch2_reg_i_2_n_0;
  wire [9:0]TmdsBlue;
  wire [9:0]TmdsGreen;
  wire [9:0]TmdsRed;
  wire [3:0]bit_q_reg__0;
  wire [4:4]bit_q_reg__1;
  wire clear;
  wire encode_blue_n_0;
  wire encode_blue_n_1;
  wire encode_blue_n_10;
  wire encode_blue_n_2;
  wire encode_blue_n_3;
  wire encode_blue_n_4;
  wire encode_blue_n_5;
  wire encode_blue_n_6;
  wire encode_blue_n_7;
  wire encode_blue_n_8;
  wire encode_blue_n_9;
  wire encode_green_n_0;
  wire encode_green_n_1;
  wire encode_green_n_2;
  wire encode_green_n_3;
  wire encode_green_n_4;
  wire encode_green_n_5;
  wire encode_green_n_6;
  wire encode_green_n_7;
  wire encode_green_n_8;
  wire encode_green_n_9;
  wire encode_red_n_0;
  wire encode_red_n_1;
  wire encode_red_n_2;
  wire encode_red_n_3;
  wire encode_red_n_4;
  wire encode_red_n_5;
  wire encode_red_n_6;
  wire encode_red_n_7;
  wire encode_red_n_8;
  wire encode_red_n_9;
  wire [7:0]green;
  wire hSync;
  wire lopt;
  wire [4:0]p_0_in;
  wire [7:0]red;
  wire reset;
  wire tmds_clk;
  wire tmds_clk_IBUF_BUFG;
  wire vSync;
  wire [7:0]NLW_encode_blue_blue_IBUF_UNCONNECTED;
  wire [7:5]NLW_encode_green_green_IBUF_UNCONNECTED;
  wire [7:5]NLW_encode_red_red_IBUF_UNCONNECTED;

  assign TMDSch0 = TMDSch0_OBUF;
  assign TMDSch1 = TMDSch1_OBUF;
  assign TMDSch2 = TMDSch2_OBUF;
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch0_i_1
       (.I0(TmdsBlue[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsBlue[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch0_reg_i_3_n_0),
        .O(TMDSch0_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    TMDSch0_i_2
       (.I0(bit_q_reg__0[2]),
        .I1(bit_q_reg__0[1]),
        .O(TMDSch0_i_2_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch0_i_4
       (.I0(TmdsBlue[3]),
        .I1(TmdsBlue[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsBlue[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsBlue[0]),
        .O(TMDSch0_i_4_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch0_i_5
       (.I0(TmdsBlue[7]),
        .I1(TmdsBlue[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsBlue[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsBlue[4]),
        .O(TMDSch0_i_5_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch0_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch0_i_1_n_0),
        .Q(TMDSch0_OBUF),
        .R(1'b0));
  MUXF7 TMDSch0_reg_i_3
       (.I0(TMDSch0_i_4_n_0),
        .I1(TMDSch0_i_5_n_0),
        .O(TMDSch0_reg_i_3_n_0),
        .S(bit_q_reg__0[2]));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch1_i_1
       (.I0(TmdsGreen[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsGreen[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch1_reg_i_2_n_0),
        .O(TMDSch1_i_1_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch1_i_3
       (.I0(TmdsGreen[3]),
        .I1(TmdsGreen[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsGreen[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsGreen[0]),
        .O(TMDSch1_i_3_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch1_i_4
       (.I0(TmdsGreen[7]),
        .I1(TmdsGreen[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsGreen[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsGreen[4]),
        .O(TMDSch1_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch1_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch1_i_1_n_0),
        .Q(TMDSch1_OBUF),
        .R(1'b0));
  MUXF7 TMDSch1_reg_i_2
       (.I0(TMDSch1_i_3_n_0),
        .I1(TMDSch1_i_4_n_0),
        .O(TMDSch1_reg_i_2_n_0),
        .S(bit_q_reg__0[2]));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch2_i_1
       (.I0(TmdsRed[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsRed[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch2_reg_i_2_n_0),
        .O(TMDSch2_i_1_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch2_i_3
       (.I0(TmdsRed[3]),
        .I1(TmdsRed[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsRed[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsRed[0]),
        .O(TMDSch2_i_3_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch2_i_4
       (.I0(TmdsRed[7]),
        .I1(TmdsRed[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsRed[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsRed[4]),
        .O(TMDSch2_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch2_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch2_i_1_n_0),
        .Q(TMDSch2_OBUF),
        .R(1'b0));
  MUXF7 TMDSch2_reg_i_2
       (.I0(TMDSch2_i_3_n_0),
        .I1(TMDSch2_i_4_n_0),
        .O(TMDSch2_reg_i_2_n_0),
        .S(bit_q_reg__0[2]));
  LUT5 #(
    .INIT(32'h01000000)) 
    \TmdsBlue[9]_i_1 
       (.I0(bit_q_reg__1),
        .I1(bit_q_reg__0[2]),
        .I2(bit_q_reg__0[1]),
        .I3(bit_q_reg__0[0]),
        .I4(bit_q_reg__0[3]),
        .O(clear));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_10),
        .Q(TmdsBlue[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_9),
        .Q(TmdsBlue[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_8),
        .Q(TmdsBlue[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_7),
        .Q(TmdsBlue[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_6),
        .Q(TmdsBlue[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_5),
        .Q(TmdsBlue[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_4),
        .Q(TmdsBlue[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_3),
        .Q(TmdsBlue[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_2),
        .Q(TmdsBlue[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_1),
        .Q(TmdsBlue[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_9),
        .Q(TmdsGreen[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_8),
        .Q(TmdsGreen[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_7),
        .Q(TmdsGreen[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_6),
        .Q(TmdsGreen[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_5),
        .Q(TmdsGreen[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_4),
        .Q(TmdsGreen[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_3),
        .Q(TmdsGreen[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_2),
        .Q(TmdsGreen[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_1),
        .Q(TmdsGreen[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_0),
        .Q(TmdsGreen[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_9),
        .Q(TmdsRed[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_8),
        .Q(TmdsRed[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_7),
        .Q(TmdsRed[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_6),
        .Q(TmdsRed[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_5),
        .Q(TmdsRed[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_4),
        .Q(TmdsRed[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_3),
        .Q(TmdsRed[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_2),
        .Q(TmdsRed[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_1),
        .Q(TmdsRed[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_0),
        .Q(TmdsRed[9]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \bit_q[0]_i_1 
       (.I0(bit_q_reg__0[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bit_q[1]_i_1 
       (.I0(bit_q_reg__0[0]),
        .I1(bit_q_reg__0[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bit_q[2]_i_1 
       (.I0(bit_q_reg__0[0]),
        .I1(bit_q_reg__0[1]),
        .I2(bit_q_reg__0[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \bit_q[3]_i_1 
       (.I0(bit_q_reg__0[1]),
        .I1(bit_q_reg__0[0]),
        .I2(bit_q_reg__0[2]),
        .I3(bit_q_reg__0[3]),
        .O(p_0_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \bit_q[4]_i_1 
       (.I0(bit_q_reg__0[2]),
        .I1(bit_q_reg__0[0]),
        .I2(bit_q_reg__0[1]),
        .I3(bit_q_reg__0[3]),
        .I4(bit_q_reg__1),
        .O(p_0_in[4]));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(bit_q_reg__0[0]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(bit_q_reg__0[1]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(bit_q_reg__0[2]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(bit_q_reg__0[3]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(bit_q_reg__1),
        .R(clear));
  encode encode_blue
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_blue_n_1,encode_blue_n_2,encode_blue_n_3,encode_blue_n_4,encode_blue_n_5,encode_blue_n_6,encode_blue_n_7,encode_blue_n_8,encode_blue_n_9,encode_blue_n_10}),
        .SR(encode_blue_n_0),
        .blue_IBUF(NLW_encode_blue_blue_IBUF_UNCONNECTED[7:0]),
        .hSync_IBUF(hSync),
        .pixel_clk_IBUF_BUFG(lopt),
        .reset_IBUF(reset),
        .vSync_IBUF(vSync));
  encode_0 encode_green
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_green_n_0,encode_green_n_1,encode_green_n_2,encode_green_n_3,encode_green_n_4,encode_green_n_5,encode_green_n_6,encode_green_n_7,encode_green_n_8,encode_green_n_9}),
        .SR(encode_blue_n_0),
        .green_IBUF({NLW_encode_green_green_IBUF_UNCONNECTED[7],green[6],NLW_encode_green_green_IBUF_UNCONNECTED[5],green[4:0]}),
        .pixel_clk_IBUF_BUFG(lopt),
        .reset_IBUF(reset));
  encode_1 encode_red
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_red_n_0,encode_red_n_1,encode_red_n_2,encode_red_n_3,encode_red_n_4,encode_red_n_5,encode_red_n_6,encode_red_n_7,encode_red_n_8,encode_red_n_9}),
        .SR(encode_blue_n_0),
        .pixel_clk_IBUF_BUFG(lopt),
        .red_IBUF({NLW_encode_red_red_IBUF_UNCONNECTED[7],red[6],NLW_encode_red_red_IBUF_UNCONNECTED[5],red[4:0]}),
        .reset_IBUF(reset));
  BUFG tmds_clk_IBUF_BUFG_inst
       (.I(tmds_clk),
        .O(tmds_clk_IBUF_BUFG));
endmodule

module brute_force_synchronizer
   (ButtonIn_IBUF,
    button_sync,
    clk_IBUF_BUFG);
  input ButtonIn_IBUF;
  output button_sync;
  input clk_IBUF_BUFG;

  wire ButtonIn_IBUF;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire ff1_n_0;

  dff ff1
       (.ButtonIn_IBUF(ButtonIn_IBUF),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[0]_0 (ff1_n_0));
  dff_0 ff2
       (.button_sync(button_sync),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[0]_0 (ff1_n_0));
endmodule

(* sim = "0" *) 
module button_process_unit
   (ButtonIn,
    ButtonOut,
    clk,
    reset,
    lopt);
  input ButtonIn;
  output ButtonOut;
  input clk;
  input reset;
  input lopt;

  wire ButtonIn;
  wire ButtonOut_OBUF;
  wire button_debounced;
  wire button_sync;
  wire last_value;
  wire lopt;
  wire NLW_debounce_reset_IBUF_UNCONNECTED;

  assign ButtonOut = ButtonOut_OBUF;
  debouncer debounce
       (.ButtonOut_OBUF(ButtonOut_OBUF),
        .button_debounced(button_debounced),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(lopt),
        .last_value(last_value),
        .reset_IBUF(NLW_debounce_reset_IBUF_UNCONNECTED));
  one_pulse one_pulse_inst
       (.button_debounced(button_debounced),
        .clk_IBUF_BUFG(lopt),
        .last_value(last_value));
  brute_force_synchronizer sync
       (.ButtonIn_IBUF(ButtonIn),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(lopt));
endmodule

module counter_n
   (clk_IBUF_BUFG,
    E);
  input clk_IBUF_BUFG;
  output [0:0]E;

  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire [16:1]data0;
  wire [0:0]q;
  wire q0_carry__0_n_0;
  wire q0_carry__1_n_0;
  wire q0_carry_n_0;
  wire \q[16]_i_2_n_0 ;
  wire \q[16]_i_3_n_0 ;
  wire \q[16]_i_4_n_0 ;
  wire \q[16]_i_5_n_0 ;
  wire [16:0]q_reg_n_0_;
  wire [2:0]NLW_q0_carry_CO_UNCONNECTED;
  wire [2:0]NLW_q0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_q0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_q0_carry__2_CO_UNCONNECTED;

  CARRY4 q0_carry
       (.CI(1'b0),
        .CO({q0_carry_n_0,NLW_q0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(q_reg_n_0_[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(q_reg_n_0_[4:1]));
  CARRY4 q0_carry__0
       (.CI(q0_carry_n_0),
        .CO({q0_carry__0_n_0,NLW_q0_carry__0_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(q_reg_n_0_[8:5]));
  CARRY4 q0_carry__1
       (.CI(q0_carry__0_n_0),
        .CO({q0_carry__1_n_0,NLW_q0_carry__1_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(q_reg_n_0_[12:9]));
  CARRY4 q0_carry__2
       (.CI(q0_carry__1_n_0),
        .CO(NLW_q0_carry__2_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(q_reg_n_0_[16:13]));
  LUT1 #(
    .INIT(2'h1)) 
    \q[0]_i_1__1 
       (.I0(q_reg_n_0_[0]),
        .O(q));
  LUT4 #(
    .INIT(16'h0001)) 
    \q[16]_i_1 
       (.I0(\q[16]_i_2_n_0 ),
        .I1(\q[16]_i_3_n_0 ),
        .I2(\q[16]_i_4_n_0 ),
        .I3(\q[16]_i_5_n_0 ),
        .O(E));
  LUT4 #(
    .INIT(16'hFFF7)) 
    \q[16]_i_2 
       (.I0(q_reg_n_0_[4]),
        .I1(q_reg_n_0_[3]),
        .I2(q_reg_n_0_[6]),
        .I3(q_reg_n_0_[5]),
        .O(\q[16]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \q[16]_i_3 
       (.I0(q_reg_n_0_[0]),
        .I1(q_reg_n_0_[15]),
        .I2(q_reg_n_0_[16]),
        .I3(q_reg_n_0_[2]),
        .I4(q_reg_n_0_[1]),
        .O(\q[16]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[16]_i_4 
       (.I0(q_reg_n_0_[12]),
        .I1(q_reg_n_0_[11]),
        .I2(q_reg_n_0_[14]),
        .I3(q_reg_n_0_[13]),
        .O(\q[16]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hDFFF)) 
    \q[16]_i_5 
       (.I0(q_reg_n_0_[7]),
        .I1(q_reg_n_0_[8]),
        .I2(q_reg_n_0_[10]),
        .I3(q_reg_n_0_[9]),
        .O(\q[16]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q),
        .Q(q_reg_n_0_[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[10]),
        .Q(q_reg_n_0_[10]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[11]),
        .Q(q_reg_n_0_[11]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[12]),
        .Q(q_reg_n_0_[12]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[13]),
        .Q(q_reg_n_0_[13]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[14]),
        .Q(q_reg_n_0_[14]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[15]),
        .Q(q_reg_n_0_[15]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[16]),
        .Q(q_reg_n_0_[16]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[1]),
        .Q(q_reg_n_0_[1]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[2]),
        .Q(q_reg_n_0_[2]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[3]),
        .Q(q_reg_n_0_[3]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[4]),
        .Q(q_reg_n_0_[4]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[5]),
        .Q(q_reg_n_0_[5]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[6]),
        .Q(q_reg_n_0_[6]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[7]),
        .Q(q_reg_n_0_[7]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[8]),
        .Q(q_reg_n_0_[8]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[9]),
        .Q(q_reg_n_0_[9]),
        .R(E));
endmodule

module debouncer
   (ButtonOut_OBUF,
    button_debounced,
    button_sync,
    clk_IBUF_BUFG,
    last_value,
    reset_IBUF);
  output ButtonOut_OBUF;
  output button_debounced;
  input button_sync;
  input clk_IBUF_BUFG;
  input last_value;
  input reset_IBUF;

  wire ButtonOut_OBUF;
  wire button_debounced;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire counter_n_0;
  wire div_inst_n_0;
  wire last_value;
  wire state_n_0;
  wire NLW_state_reset_IBUF_UNCONNECTED;

  dffre counter
       (.E(div_inst_n_0),
        .SR(state_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[1]_0 (counter_n_0));
  counter_n div_inst
       (.E(div_inst_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG));
  dffre__parameterized0 state
       (.ButtonOut_OBUF(ButtonOut_OBUF),
        .SR(state_n_0),
        .button_debounced(button_debounced),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .last_value(last_value),
        .\q_reg[1]_0 (counter_n_0),
        .reset_IBUF(NLW_state_reset_IBUF_UNCONNECTED));
endmodule

module dff
   (ButtonIn_IBUF,
    clk_IBUF_BUFG,
    \q_reg[0]_0 );
  input ButtonIn_IBUF;
  input clk_IBUF_BUFG;
  output \q_reg[0]_0 ;

  wire ButtonIn_IBUF;
  wire clk_IBUF_BUFG;
  wire \q_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(ButtonIn_IBUF),
        .Q(\q_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module dff_0
   (button_sync,
    clk_IBUF_BUFG,
    \q_reg[0]_0 );
  output button_sync;
  input clk_IBUF_BUFG;
  input \q_reg[0]_0 ;

  wire button_sync;
  wire clk_IBUF_BUFG;
  wire \q_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q_reg[0]_0 ),
        .Q(button_sync),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module dff_1
   (button_debounced,
    clk_IBUF_BUFG,
    last_value);
  input button_debounced;
  input clk_IBUF_BUFG;
  output last_value;

  wire button_debounced;
  wire clk_IBUF_BUFG;
  wire last_value;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(button_debounced),
        .Q(last_value),
        .R(1'b0));
endmodule

module dffre
   (clk_IBUF_BUFG,
    \q_reg[1]_0 ,
    E,
    SR);
  input clk_IBUF_BUFG;
  output \q_reg[1]_0 ;
  input [0:0]E;
  input [0:0]SR;

  wire [0:0]E;
  wire [0:0]SR;
  wire clk_IBUF_BUFG;
  wire [3:0]d0;
  wire \q_reg[1]_0 ;
  wire [3:0]q_reg__0;

  LUT1 #(
    .INIT(2'h1)) 
    \q[0]_i_1 
       (.I0(q_reg__0[0]),
        .O(d0[0]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \q[1]_i_1 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .O(d0[1]));
  LUT4 #(
    .INIT(16'hFFDF)) 
    \q[1]_i_2 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .I2(q_reg__0[3]),
        .I3(q_reg__0[2]),
        .O(\q_reg[1]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \q[2]_i_1 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .I2(q_reg__0[2]),
        .O(d0[2]));
  LUT4 #(
    .INIT(16'h6CCC)) 
    \q[3]_i_2 
       (.I0(q_reg__0[2]),
        .I1(q_reg__0[3]),
        .I2(q_reg__0[0]),
        .I3(q_reg__0[1]),
        .O(d0[3]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[0]),
        .Q(q_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[1]),
        .Q(q_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[2]),
        .Q(q_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[3]),
        .Q(q_reg__0[3]),
        .R(SR));
endmodule

(* ORIG_REF_NAME = "dffre" *) 
module dffre__parameterized0
   (ButtonOut_OBUF,
    button_debounced,
    button_sync,
    clk_IBUF_BUFG,
    last_value,
    \q_reg[1]_0 ,
    reset_IBUF,
    SR);
  output ButtonOut_OBUF;
  output button_debounced;
  input button_sync;
  input clk_IBUF_BUFG;
  input last_value;
  input \q_reg[1]_0 ;
  input reset_IBUF;
  output [0:0]SR;

  wire ButtonOut_OBUF;
  wire [0:0]SR;
  wire button_debounced;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire [1:0]current_state_q;
  wire last_value;
  wire \q[0]_i_1_n_0 ;
  wire \q[1]_i_1_n_0 ;
  wire \q_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h04)) 
    ButtonOut_OBUF_inst_i_1
       (.I0(current_state_q[0]),
        .I1(current_state_q[1]),
        .I2(last_value),
        .O(ButtonOut_OBUF));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hBE14)) 
    \q[0]_i_1 
       (.I0(current_state_q[0]),
        .I1(current_state_q[1]),
        .I2(button_sync),
        .I3(\q_reg[1]_0 ),
        .O(\q[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \q[0]_i_1__0 
       (.I0(current_state_q[1]),
        .I1(current_state_q[0]),
        .O(button_debounced));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hA6)) 
    \q[1]_i_1 
       (.I0(current_state_q[1]),
        .I1(current_state_q[0]),
        .I2(\q_reg[1]_0 ),
        .O(\q[1]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \q[3]_i_1 
       (.I0(current_state_q[0]),
        .O(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[0]_i_1_n_0 ),
        .Q(current_state_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[1]_i_1_n_0 ),
        .Q(current_state_q[1]),
        .R(1'b0));
endmodule

module encode
   (ActiveArea_IBUF,
    hSync_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    vSync_IBUF,
    D,
    SR,
    blue_IBUF);
  input ActiveArea_IBUF;
  input hSync_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  input vSync_IBUF;
  output [9:0]D;
  output [0:0]SR;
  input [7:0]blue_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire [7:0]cnt0;
  wire [7:0]cnt00_in;
  wire cnt0__0_carry__0_i_1_n_0;
  wire cnt0__0_carry__0_i_3_n_0;
  wire cnt0__0_carry__0_i_4_n_0;
  wire cnt0__0_carry_n_0;
  wire cnt0__23_carry_n_0;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire hSync_IBUF;
  wire lopt;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire pixel_clk_IBUF_BUFG;
  wire [8:0]q1_in;
  wire \q[7]_i_10_n_0 ;
  wire \q[7]_i_7__1_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire reset_IBUF;
  wire vSync_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_blue[0]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[4]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_1_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_2_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_3_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_4_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_2_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_3_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_4_UNCONNECTED ;
  wire [7:0]NLW_numbercnt_d_inst_blue_UNCONNECTED;
  wire [7:0]NLW_numbercnt_d_inst_blue_IBUF_UNCONNECTED;
  wire [0:0]NLW_numbercnt_d_inst_cnt2_UNCONNECTED;
  wire [1:1]\NLW_numbercnt_d_inst_cnt_reg[3]_2_UNCONNECTED ;
  wire [8:3]NLW_numbercnt_d_inst_q_reg_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({lopt,numbercnt_d_inst_n_48,numbercnt_d_inst_n_33,cnt_reg__0[0]}),
        .O(cnt0[3:0]),
        .S({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,numbercnt_d_inst_n_45,numbercnt_d_inst_n_46}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1_n_0,numbercnt_d_inst_n_25}),
        .O(cnt0[7:4]),
        .S({cnt0__0_carry__0_i_3_n_0,cnt0__0_carry__0_i_4_n_0,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54,cnt_reg__0[1:0]}),
        .O(cnt00_in[3:0]),
        .S({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_51,numbercnt_d_inst_n_52}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27,numbercnt_d_inst_n_28}),
        .O(cnt00_in[7:4]),
        .S({numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31,numbercnt_d_inst_n_32}));
  LUT1 #(
    .INIT(2'h1)) 
    \cnt[7]_i_1 
       (.I0(ActiveArea_IBUF),
        .O(SR));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_37,numbercnt_d_inst_n_38,numbercnt_d_inst_n_39,numbercnt_d_inst_n_40}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_14,numbercnt_d_inst_n_15,numbercnt_d_inst_n_16,numbercnt_d_inst_n_17}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt_5 numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D(q1_in),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_14,numbercnt_d_inst_n_15,numbercnt_d_inst_n_16,numbercnt_d_inst_n_17}),
        .blue(NLW_numbercnt_d_inst_blue_UNCONNECTED[7:0]),
        .\blue[0]_0 (\NLW_numbercnt_d_inst_blue[0]_0_UNCONNECTED ),
        .\blue[3]_0 (\NLW_numbercnt_d_inst_blue[3]_0_UNCONNECTED ),
        .\blue[4]_0 (\NLW_numbercnt_d_inst_blue[4]_0_UNCONNECTED ),
        .\blue[7]_0 (\NLW_numbercnt_d_inst_blue[7]_0_UNCONNECTED ),
        .\blue[7]_1 (\NLW_numbercnt_d_inst_blue[7]_1_UNCONNECTED ),
        .\blue[7]_2 (\NLW_numbercnt_d_inst_blue[7]_2_UNCONNECTED ),
        .\blue[7]_3 (\NLW_numbercnt_d_inst_blue[7]_3_UNCONNECTED ),
        .\blue[7]_4 (\NLW_numbercnt_d_inst_blue[7]_4_UNCONNECTED ),
        .blue_IBUF(NLW_numbercnt_d_inst_blue_IBUF_UNCONNECTED[7:0]),
        .cnt0(cnt0),
        .cnt00_in(cnt00_in),
        .cnt2(NLW_numbercnt_d_inst_cnt2_UNCONNECTED[0]),
        .\cnt_reg[3] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_37,numbercnt_d_inst_n_38,numbercnt_d_inst_n_39,numbercnt_d_inst_n_40}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,numbercnt_d_inst_n_45,numbercnt_d_inst_n_46}),
        .\cnt_reg[3]_2 ({\NLW_numbercnt_d_inst_cnt_reg[3]_2_UNCONNECTED [1],numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_51,numbercnt_d_inst_n_52}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .\cnt_reg[3]_5 (\q[7]_i_7__1_n_0 ),
        .\cnt_reg[7] (numbercnt_d_inst_n_25),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_26,numbercnt_d_inst_n_27,numbercnt_d_inst_n_28}),
        .\cnt_reg[7]_1 ({numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31,numbercnt_d_inst_n_32}),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .hSync_IBUF(hSync_IBUF),
        .lopt(lopt),
        .q_reg({numbercnt_d_inst_n_36,NLW_numbercnt_d_inst_q_reg_UNCONNECTED[8:3],numbercnt_d_inst_n_10}),
        .\q_reg[2]_0 (numbercnt_d_inst_n_11),
        .\q_reg[2]_1 (numbercnt_d_inst_n_33),
        .\q_reg[2]_2 (\NLW_numbercnt_d_inst_q_reg[2]_2_UNCONNECTED ),
        .\q_reg[2]_3 (\NLW_numbercnt_d_inst_q_reg[2]_3_UNCONNECTED ),
        .\q_reg[2]_4 (\NLW_numbercnt_d_inst_q_reg[2]_4_UNCONNECTED ),
        .vSync_IBUF(vSync_IBUF));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_10 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_7__1 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_10_n_0 ),
        .O(\q[7]_i_7__1_n_0 ));
  LUT4 #(
    .INIT(16'h5355)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_36),
        .I1(numbercnt_d_inst_n_11),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[0]),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[1]),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[2]),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[3]),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[4]),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[5]),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[6]),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[7]),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[8]),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "encode" *) 
module encode_0
   (ActiveArea_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    D,
    SR,
    green_IBUF);
  input ActiveArea_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  output [9:0]D;
  input [0:0]SR;
  input [7:0]green_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire cnt0__0_carry__0_i_1__0_n_0;
  wire cnt0__0_carry__0_i_3__0_n_0;
  wire cnt0__0_carry__0_i_4__0_n_0;
  wire cnt0__0_carry__0_n_4;
  wire cnt0__0_carry__0_n_5;
  wire cnt0__0_carry__0_n_6;
  wire cnt0__0_carry__0_n_7;
  wire cnt0__0_carry_n_0;
  wire cnt0__0_carry_n_4;
  wire cnt0__0_carry_n_5;
  wire cnt0__0_carry_n_6;
  wire cnt0__0_carry_n_7;
  wire cnt0__23_carry__0_n_4;
  wire cnt0__23_carry__0_n_5;
  wire cnt0__23_carry__0_n_6;
  wire cnt0__23_carry__0_n_7;
  wire cnt0__23_carry_n_0;
  wire cnt0__23_carry_n_4;
  wire cnt0__23_carry_n_5;
  wire cnt0__23_carry_n_6;
  wire cnt0__23_carry_n_7;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire [7:0]green_IBUF;
  wire numbercnt_d_inst_n_0;
  wire numbercnt_d_inst_n_1;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_12;
  wire numbercnt_d_inst_n_13;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_2;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_3;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_34;
  wire numbercnt_d_inst_n_35;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_4;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_47;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_5;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire numbercnt_d_inst_n_6;
  wire numbercnt_d_inst_n_7;
  wire numbercnt_d_inst_n_8;
  wire numbercnt_d_inst_n_9;
  wire numbercnt_q_inst_n_0;
  wire numbercnt_q_inst_n_1;
  wire numbercnt_q_inst_n_2;
  wire numbercnt_q_inst_n_3;
  wire numbercnt_q_inst_n_4;
  wire numbercnt_q_inst_n_5;
  wire numbercnt_q_inst_n_6;
  wire numbercnt_q_inst_n_7;
  wire numbercnt_q_inst_n_8;
  wire pixel_clk_IBUF_BUFG;
  wire \q[7]_i_5_n_0 ;
  wire \q[7]_i_8__0_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire reset_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_green[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_green[3]_1_UNCONNECTED ;
  wire [5:1]NLW_numbercnt_d_inst_green_UNCONNECTED;
  wire [7:1]NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED;
  wire \NLW_numbercnt_q_inst_green[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_q_inst_green[4]_3_UNCONNECTED ;
  wire [6:1]NLW_numbercnt_q_inst_green_UNCONNECTED;
  wire [6:0]NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_17,cnt_reg__0[0]}),
        .O({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .S({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1__0_n_0,numbercnt_d_inst_n_32}),
        .O({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .S({cnt0__0_carry__0_i_3__0_n_0,cnt0__0_carry__0_i_4__0_n_0,numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1__0
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3__0
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4__0
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4__0_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,cnt_reg__0[1:0]}),
        .O({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .S({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .S({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt_3 numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D({numbercnt_d_inst_n_1,numbercnt_d_inst_n_2,numbercnt_d_inst_n_3,numbercnt_d_inst_n_4,numbercnt_d_inst_n_5,numbercnt_d_inst_n_6,numbercnt_d_inst_n_7,numbercnt_d_inst_n_8,numbercnt_d_inst_n_9}),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}),
        .\cnt_reg[0] ({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .\cnt_reg[1] ({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .\cnt_reg[3] ({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .\cnt_reg[3]_2 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50}),
        .\cnt_reg[3]_5 (\q[7]_i_5_n_0 ),
        .\cnt_reg[5] ({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .\cnt_reg[7] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .\cnt_reg[7]_1 (numbercnt_d_inst_n_32),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .green({numbercnt_q_inst_n_6,numbercnt_q_inst_n_0,NLW_numbercnt_d_inst_green_UNCONNECTED[5:4],numbercnt_q_inst_n_7,NLW_numbercnt_d_inst_green_UNCONNECTED[2:1],green_IBUF[2]}),
        .\green[0]_0 (green_IBUF[2]),
        .\green[3]_0 (\NLW_numbercnt_d_inst_green[3]_0_UNCONNECTED ),
        .\green[3]_1 (\NLW_numbercnt_d_inst_green[3]_1_UNCONNECTED ),
        .\green[4]_0 (green_IBUF[0]),
        .\green[7]_0 (numbercnt_q_inst_n_2),
        .\green[7]_1 (numbercnt_q_inst_n_4),
        .\green[7]_2 (numbercnt_q_inst_n_1),
        .\green[7]_3 (numbercnt_q_inst_n_5),
        .\green[7]_4 (numbercnt_q_inst_n_8),
        .\green[7]_5 (numbercnt_q_inst_n_3),
        .green_IBUF({NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[7],green_IBUF[6],NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[5],green_IBUF[4:3],NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[2:1],green_IBUF[0]}),
        .q_reg({numbercnt_d_inst_n_16,numbercnt_d_inst_n_0}),
        .\q_reg[4]_0 (numbercnt_d_inst_n_10),
        .\q_reg[4]_1 (numbercnt_d_inst_n_11),
        .\q_reg[4]_2 (numbercnt_d_inst_n_34),
        .\q_reg[4]_3 (numbercnt_d_inst_n_51),
        .\q_reg[5]_0 (numbercnt_d_inst_n_17),
        .\q_reg[5]_1 (numbercnt_d_inst_n_33),
        .\q_reg[5]_2 (numbercnt_d_inst_n_52));
  NumberCnt_4 numbercnt_q_inst
       (.cnt_reg(numbercnt_q_inst_n_7),
        .\cnt_reg[3]_0 (numbercnt_q_inst_n_8),
        .green({numbercnt_d_inst_n_51,NLW_numbercnt_q_inst_green_UNCONNECTED[6],numbercnt_d_inst_n_33,green_IBUF[0],NLW_numbercnt_q_inst_green_UNCONNECTED[3:1],green_IBUF[2]}),
        .\green[0]_0 (green_IBUF[2]),
        .\green[3]_0 (\NLW_numbercnt_q_inst_green[3]_0_UNCONNECTED ),
        .\green[3]_1 (numbercnt_d_inst_n_0),
        .\green[4]_0 (numbercnt_d_inst_n_52),
        .\green[4]_1 (numbercnt_d_inst_n_34),
        .\green[4]_2 (numbercnt_d_inst_n_16),
        .\green[4]_3 (\NLW_numbercnt_q_inst_green[4]_3_UNCONNECTED ),
        .green_IBUF({NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[6:5],green_IBUF[4],NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[3:2],green_IBUF[1],NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[0]}),
        .q_reg({numbercnt_q_inst_n_2,numbercnt_q_inst_n_0}),
        .\q_reg[4]_0 (numbercnt_q_inst_n_1),
        .\q_reg[4]_1 (numbercnt_q_inst_n_6),
        .\q_reg[5]_0 (numbercnt_q_inst_n_3),
        .\q_reg[5]_1 (numbercnt_q_inst_n_4),
        .\q_reg[5]_2 (numbercnt_q_inst_n_5));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_5 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_8__0_n_0 ),
        .O(\q[7]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_8__0 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_8__0_n_0 ));
  LUT4 #(
    .INIT(16'hC5FF)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_0),
        .I1(numbercnt_d_inst_n_11),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_9),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_8),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_7),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_6),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_5),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_4),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_3),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_2),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_1),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "encode" *) 
module encode_1
   (ActiveArea_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    D,
    SR,
    red_IBUF);
  input ActiveArea_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  output [9:0]D;
  input [0:0]SR;
  input [7:0]red_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire cnt0__0_carry__0_i_1__1_n_0;
  wire cnt0__0_carry__0_i_3__1_n_0;
  wire cnt0__0_carry__0_i_4__1_n_0;
  wire cnt0__0_carry__0_n_4;
  wire cnt0__0_carry__0_n_5;
  wire cnt0__0_carry__0_n_6;
  wire cnt0__0_carry__0_n_7;
  wire cnt0__0_carry_n_0;
  wire cnt0__0_carry_n_4;
  wire cnt0__0_carry_n_5;
  wire cnt0__0_carry_n_6;
  wire cnt0__0_carry_n_7;
  wire cnt0__23_carry__0_n_4;
  wire cnt0__23_carry__0_n_5;
  wire cnt0__23_carry__0_n_6;
  wire cnt0__23_carry__0_n_7;
  wire cnt0__23_carry_n_0;
  wire cnt0__23_carry_n_4;
  wire cnt0__23_carry_n_5;
  wire cnt0__23_carry_n_6;
  wire cnt0__23_carry_n_7;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire numbercnt_d_inst_n_0;
  wire numbercnt_d_inst_n_1;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_12;
  wire numbercnt_d_inst_n_13;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_2;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_3;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_34;
  wire numbercnt_d_inst_n_35;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_4;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_47;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_5;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire numbercnt_d_inst_n_6;
  wire numbercnt_d_inst_n_7;
  wire numbercnt_d_inst_n_8;
  wire numbercnt_d_inst_n_9;
  wire numbercnt_q_inst_n_0;
  wire numbercnt_q_inst_n_1;
  wire numbercnt_q_inst_n_2;
  wire numbercnt_q_inst_n_3;
  wire numbercnt_q_inst_n_4;
  wire numbercnt_q_inst_n_5;
  wire numbercnt_q_inst_n_6;
  wire numbercnt_q_inst_n_7;
  wire numbercnt_q_inst_n_8;
  wire pixel_clk_IBUF_BUFG;
  wire \q[7]_i_5__0_n_0 ;
  wire \q[7]_i_8__1_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire [7:0]red_IBUF;
  wire reset_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_red[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_red[3]_1_UNCONNECTED ;
  wire [3:3]NLW_numbercnt_d_inst_q_reg_UNCONNECTED;
  wire [5:1]NLW_numbercnt_d_inst_red_UNCONNECTED;
  wire [7:1]NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED;
  wire \NLW_numbercnt_q_inst_red[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_q_inst_red[4]_3_UNCONNECTED ;
  wire [3:3]NLW_numbercnt_q_inst_q_reg_UNCONNECTED;
  wire [6:1]NLW_numbercnt_q_inst_red_UNCONNECTED;
  wire [6:0]NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_17,cnt_reg__0[0]}),
        .O({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .S({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1__1_n_0,numbercnt_d_inst_n_32}),
        .O({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .S({cnt0__0_carry__0_i_3__1_n_0,cnt0__0_carry__0_i_4__1_n_0,numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1__1
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3__1
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4__1
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4__1_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,cnt_reg__0[1:0]}),
        .O({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .S({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .S({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D({numbercnt_d_inst_n_1,numbercnt_d_inst_n_2,numbercnt_d_inst_n_3,numbercnt_d_inst_n_4,numbercnt_d_inst_n_5,numbercnt_d_inst_n_6,numbercnt_d_inst_n_7,numbercnt_d_inst_n_8,numbercnt_d_inst_n_9}),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}),
        .\cnt_reg[0] ({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .\cnt_reg[1] ({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .\cnt_reg[3] ({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .\cnt_reg[3]_2 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50}),
        .\cnt_reg[3]_5 (\q[7]_i_5__0_n_0 ),
        .\cnt_reg[5] ({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .\cnt_reg[7] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .\cnt_reg[7]_1 (numbercnt_d_inst_n_32),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .q_reg({numbercnt_d_inst_n_11,numbercnt_d_inst_n_16,NLW_numbercnt_d_inst_q_reg_UNCONNECTED[3],numbercnt_d_inst_n_0}),
        .\q_reg[2]_0 (numbercnt_d_inst_n_10),
        .\q_reg[2]_1 (numbercnt_d_inst_n_34),
        .\q_reg[4]_0 (numbercnt_d_inst_n_17),
        .\q_reg[4]_1 (numbercnt_d_inst_n_33),
        .\q_reg[4]_2 (numbercnt_d_inst_n_52),
        .\q_reg[5]_0 (numbercnt_d_inst_n_51),
        .red({numbercnt_q_inst_n_6,numbercnt_q_inst_n_0,NLW_numbercnt_d_inst_red_UNCONNECTED[5:4],numbercnt_q_inst_n_7,NLW_numbercnt_d_inst_red_UNCONNECTED[2:1],red_IBUF[2]}),
        .\red[0]_0 (red_IBUF[2]),
        .\red[3]_0 (\NLW_numbercnt_d_inst_red[3]_0_UNCONNECTED ),
        .\red[3]_1 (\NLW_numbercnt_d_inst_red[3]_1_UNCONNECTED ),
        .\red[4]_0 (red_IBUF[0]),
        .\red[7]_0 (numbercnt_q_inst_n_2),
        .\red[7]_1 (numbercnt_q_inst_n_4),
        .\red[7]_2 (numbercnt_q_inst_n_1),
        .\red[7]_3 (numbercnt_q_inst_n_5),
        .\red[7]_4 (numbercnt_q_inst_n_8),
        .\red[7]_5 (numbercnt_q_inst_n_3),
        .red_IBUF({NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[7],red_IBUF[6],NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[5],red_IBUF[4:3],NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[2:1],red_IBUF[0]}));
  NumberCnt_2 numbercnt_q_inst
       (.cnt_reg(numbercnt_q_inst_n_7),
        .\cnt_reg[3]_0 (numbercnt_q_inst_n_8),
        .q_reg({numbercnt_q_inst_n_1,numbercnt_q_inst_n_2,NLW_numbercnt_q_inst_q_reg_UNCONNECTED[3],numbercnt_q_inst_n_0}),
        .\q_reg[2]_0 (numbercnt_q_inst_n_6),
        .\q_reg[4]_0 (numbercnt_q_inst_n_3),
        .\q_reg[4]_1 (numbercnt_q_inst_n_4),
        .\q_reg[4]_2 (numbercnt_q_inst_n_5),
        .red({numbercnt_d_inst_n_51,NLW_numbercnt_q_inst_red_UNCONNECTED[6],numbercnt_d_inst_n_33,red_IBUF[0],NLW_numbercnt_q_inst_red_UNCONNECTED[3:1],red_IBUF[2]}),
        .\red[0]_0 (red_IBUF[2]),
        .\red[3]_0 (\NLW_numbercnt_q_inst_red[3]_0_UNCONNECTED ),
        .\red[3]_1 (numbercnt_d_inst_n_0),
        .\red[4]_0 (numbercnt_d_inst_n_52),
        .\red[4]_1 (numbercnt_d_inst_n_34),
        .\red[4]_2 (numbercnt_d_inst_n_11),
        .\red[4]_3 (\NLW_numbercnt_q_inst_red[4]_3_UNCONNECTED ),
        .red_IBUF({NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[6:5],red_IBUF[4],NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[3:2],red_IBUF[1],NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[0]}));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_5__0 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_8__1_n_0 ),
        .O(\q[7]_i_5__0_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_8__1 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_8__1_n_0 ));
  LUT4 #(
    .INIT(16'hC5FF)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_0),
        .I1(numbercnt_d_inst_n_16),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_9),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_8),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_7),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_6),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_5),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_4),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_3),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_2),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_1),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

module one_pulse
   (button_debounced,
    clk_IBUF_BUFG,
    last_value);
  input button_debounced;
  input clk_IBUF_BUFG;
  output last_value;

  wire button_debounced;
  wire clk_IBUF_BUFG;
  wire last_value;

  dff_1 last_value_storage
       (.button_debounced(button_debounced),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .last_value(last_value));
endmodule

module syncGenarator
   (a,
    \TMDSn[2] ,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    \TMDSn[2]_8 ,
    \TMDSn[2]_9 ,
    \TMDSn[2]_10 ,
    D,
    \PosX_reg_reg[3]_0 ,
    \TMDSn[2]_11 ,
    \TMDSn[2]_12 ,
    \TMDSn[2]_13 ,
    p_0_in__1,
    vSync,
    ActiveArea,
    green,
    hSync,
    Q,
    \q_reg[17] ,
    \q_reg[12] ,
    \q_reg[4] ,
    \q_reg[20] ,
    \q_reg[146] ,
    \q_reg[138] ,
    \q_reg[149] ,
    \q_reg[147] ,
    \q_reg[149]_0 ,
    \q_reg[149]_1 ,
    \PosX_reg_reg[5]_0 ,
    \q_reg[141] ,
    \q_reg[149]_2 ,
    \q_reg[149]_3 ,
    \q_reg[146]_0 ,
    \q_reg[138]_0 ,
    \q_reg[134] ,
    \q_reg[137] ,
    \q_reg[133] ,
    \q_reg[136] ,
    \q_reg[132] ,
    \q_reg[134]_0 ,
    \q_reg[131] ,
    \q_reg[130] ,
    \q_reg[126] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[4]_2 ,
    \q_reg[130]_0 ,
    \q_reg[125] ,
    \PosX_reg_reg[4]_3 ,
    \q_reg[128] ,
    \q_reg[124] ,
    \q_reg[127] ,
    \q_reg[123] ,
    \PosX_reg_reg[4]_4 ,
    \q_reg[31] ,
    \PC_reg_reg[0] ,
    \PosX_reg_reg[4]_5 ,
    \PosX_reg_reg[4]_6 ,
    \PosX_reg_reg[4]_7 ,
    \PosX_reg_reg[4]_8 ,
    \bbstub_spo[27] ,
    \PosX_reg_reg[4]_9 ,
    \PosX_reg_reg[4]_10 ,
    \PosX_reg_reg[4]_11 ,
    \PosX_reg_reg[4]_12 ,
    \PC_reg_reg[7] ,
    char_pixel__6,
    \q_reg[138]_1 ,
    \q_reg[138]_2 ,
    \q_reg[118] ,
    \q_reg[143] ,
    \q_reg[48] ,
    CLK);
  output [7:0]a;
  output [0:0]\TMDSn[2] ;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output \TMDSn[2]_8 ;
  output \TMDSn[2]_9 ;
  output \TMDSn[2]_10 ;
  output [0:0]D;
  output [2:0]\PosX_reg_reg[3]_0 ;
  output \TMDSn[2]_11 ;
  output \TMDSn[2]_12 ;
  output \TMDSn[2]_13 ;
  output [0:0]p_0_in__1;
  output vSync;
  output ActiveArea;
  output [0:0]green;
  output hSync;
  input [16:0]Q;
  input \q_reg[17] ;
  input \q_reg[12] ;
  input \q_reg[4] ;
  input \q_reg[20] ;
  input \q_reg[146] ;
  input \q_reg[138] ;
  input \q_reg[149] ;
  input \q_reg[147] ;
  input \q_reg[149]_0 ;
  input [13:0]\q_reg[149]_1 ;
  input \PosX_reg_reg[5]_0 ;
  input \q_reg[141] ;
  input \q_reg[149]_2 ;
  input \q_reg[149]_3 ;
  input \q_reg[146]_0 ;
  input \q_reg[138]_0 ;
  input \q_reg[134] ;
  input \q_reg[137] ;
  input \q_reg[133] ;
  input \q_reg[136] ;
  input \q_reg[132] ;
  input \q_reg[134]_0 ;
  input \q_reg[131] ;
  input \q_reg[130] ;
  input \q_reg[126] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[4]_2 ;
  input \q_reg[130]_0 ;
  input \q_reg[125] ;
  input \PosX_reg_reg[4]_3 ;
  input \q_reg[128] ;
  input \q_reg[124] ;
  input \q_reg[127] ;
  input \q_reg[123] ;
  input \PosX_reg_reg[4]_4 ;
  input [19:0]\q_reg[31] ;
  input \PC_reg_reg[0] ;
  input \PosX_reg_reg[4]_5 ;
  input \PosX_reg_reg[4]_6 ;
  input \PosX_reg_reg[4]_7 ;
  input \PosX_reg_reg[4]_8 ;
  input [15:0]\bbstub_spo[27] ;
  input \PosX_reg_reg[4]_9 ;
  input \PosX_reg_reg[4]_10 ;
  input \PosX_reg_reg[4]_11 ;
  input \PosX_reg_reg[4]_12 ;
  input [5:0]\PC_reg_reg[7] ;
  input char_pixel__6;
  input \q_reg[138]_1 ;
  input \q_reg[138]_2 ;
  input \q_reg[118] ;
  input \q_reg[143] ;
  input \q_reg[48] ;
  input CLK;

  wire ActiveArea;
  wire CLK;
  wire [0:0]D;
  wire EndLine;
  wire \PC_reg_reg[0] ;
  wire [5:0]\PC_reg_reg[7] ;
  wire [7:7]PosX;
  wire \PosX_reg[8]_i_2_n_0 ;
  wire \PosX_reg[9]_i_3_n_0 ;
  wire \PosX_reg[9]_i_4_n_0 ;
  wire [2:0]\PosX_reg_reg[3]_0 ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_10 ;
  wire \PosX_reg_reg[4]_11 ;
  wire \PosX_reg_reg[4]_12 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[4]_4 ;
  wire \PosX_reg_reg[4]_5 ;
  wire \PosX_reg_reg[4]_6 ;
  wire \PosX_reg_reg[4]_7 ;
  wire \PosX_reg_reg[4]_8 ;
  wire \PosX_reg_reg[4]_9 ;
  wire \PosX_reg_reg[5]_0 ;
  wire [9:0]PosX_reg_reg__0;
  wire [7:5]PosY__0;
  wire PosY_reg;
  wire \PosY_reg[0]_i_1_n_0 ;
  wire \PosY_reg[9]_i_3_n_0 ;
  wire \PosY_reg[9]_i_4_n_0 ;
  wire [9:0]PosY_reg_reg__0;
  wire [16:0]Q;
  wire TMDS_inst_i_10_n_0;
  wire TMDS_inst_i_11_n_0;
  wire TMDS_inst_i_12_n_0;
  wire TMDS_inst_i_13_n_0;
  wire TMDS_inst_i_14_n_0;
  wire TMDS_inst_i_15_n_0;
  wire TMDS_inst_i_17_n_0;
  wire TMDS_inst_i_5_n_0;
  wire TMDS_inst_i_6_n_0;
  wire TMDS_inst_i_7_n_0;
  wire TMDS_inst_i_8_n_0;
  wire [0:0]\TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_10 ;
  wire \TMDSn[2]_11 ;
  wire \TMDSn[2]_12 ;
  wire \TMDSn[2]_13 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire \TMDSn[2]_9 ;
  wire [7:0]a;
  wire [15:0]\bbstub_spo[27] ;
  wire char_pixel__6;
  wire char_tab_i_101_n_0;
  wire char_tab_i_109_n_0;
  wire char_tab_i_10_n_0;
  wire char_tab_i_110_n_0;
  wire char_tab_i_111_n_0;
  wire char_tab_i_112_n_0;
  wire char_tab_i_113_n_0;
  wire char_tab_i_119_n_0;
  wire char_tab_i_11_n_0;
  wire char_tab_i_120_n_0;
  wire char_tab_i_121_n_0;
  wire char_tab_i_12_n_0;
  wire char_tab_i_133_n_0;
  wire char_tab_i_134_n_0;
  wire char_tab_i_136_n_0;
  wire char_tab_i_14_n_0;
  wire char_tab_i_15_n_0;
  wire char_tab_i_16_n_0;
  wire char_tab_i_17_n_0;
  wire char_tab_i_19_n_0;
  wire char_tab_i_20_n_0;
  wire char_tab_i_21_n_0;
  wire char_tab_i_22_n_0;
  wire char_tab_i_24_n_0;
  wire char_tab_i_25_n_0;
  wire char_tab_i_26_n_0;
  wire char_tab_i_27_n_0;
  wire char_tab_i_28_n_0;
  wire char_tab_i_29_n_0;
  wire char_tab_i_30_n_0;
  wire char_tab_i_32_n_0;
  wire char_tab_i_33_n_0;
  wire char_tab_i_34_n_0;
  wire char_tab_i_37_n_0;
  wire char_tab_i_38_n_0;
  wire char_tab_i_39_n_0;
  wire char_tab_i_41_n_0;
  wire char_tab_i_42_n_0;
  wire char_tab_i_43_n_0;
  wire char_tab_i_44_n_0;
  wire char_tab_i_45_n_0;
  wire char_tab_i_46_n_0;
  wire char_tab_i_47_n_0;
  wire char_tab_i_48_n_0;
  wire char_tab_i_49_n_0;
  wire char_tab_i_50_n_0;
  wire char_tab_i_52_n_0;
  wire char_tab_i_54_n_0;
  wire char_tab_i_58_n_0;
  wire char_tab_i_59_n_0;
  wire char_tab_i_61_n_0;
  wire char_tab_i_62_n_0;
  wire char_tab_i_66_n_0;
  wire char_tab_i_67_n_0;
  wire char_tab_i_68_n_0;
  wire char_tab_i_69_n_0;
  wire char_tab_i_70_n_0;
  wire char_tab_i_78_n_0;
  wire char_tab_i_79_n_0;
  wire char_tab_i_80_n_0;
  wire char_tab_i_84_n_0;
  wire char_tab_i_86_n_0;
  wire char_tab_i_93_n_0;
  wire char_tab_i_94_n_0;
  wire char_tab_i_95_n_0;
  wire char_tab_i_97_n_0;
  wire char_tab_i_99_n_0;
  wire char_tab_i_9_n_0;
  wire [0:0]green;
  wire hSync;
  wire [9:0]p_0_in;
  wire [9:1]p_0_in__0;
  wire [0:0]p_0_in__1;
  wire \q_reg[118] ;
  wire \q_reg[123] ;
  wire \q_reg[124] ;
  wire \q_reg[125] ;
  wire \q_reg[126] ;
  wire \q_reg[127] ;
  wire \q_reg[128] ;
  wire \q_reg[12] ;
  wire \q_reg[130] ;
  wire \q_reg[130]_0 ;
  wire \q_reg[131] ;
  wire \q_reg[132] ;
  wire \q_reg[133] ;
  wire \q_reg[134] ;
  wire \q_reg[134]_0 ;
  wire \q_reg[136] ;
  wire \q_reg[137] ;
  wire \q_reg[138] ;
  wire \q_reg[138]_0 ;
  wire \q_reg[138]_1 ;
  wire \q_reg[138]_2 ;
  wire \q_reg[141] ;
  wire \q_reg[143] ;
  wire \q_reg[146] ;
  wire \q_reg[146]_0 ;
  wire \q_reg[147] ;
  wire \q_reg[149] ;
  wire \q_reg[149]_0 ;
  wire [13:0]\q_reg[149]_1 ;
  wire \q_reg[149]_2 ;
  wire \q_reg[149]_3 ;
  wire \q_reg[17] ;
  wire \q_reg[20] ;
  wire [19:0]\q_reg[31] ;
  wire \q_reg[48] ;
  wire \q_reg[4] ;
  wire vSync;

  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \PosX_reg[0]_i_1 
       (.I0(PosX_reg_reg__0[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PosX_reg[1]_i_1 
       (.I0(PosX_reg_reg__0[0]),
        .I1(\PosX_reg_reg[3]_0 [0]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \PosX_reg[2]_i_1 
       (.I0(\PosX_reg_reg[3]_0 [0]),
        .I1(PosX_reg_reg__0[0]),
        .I2(\PosX_reg_reg[3]_0 [1]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \PosX_reg[3]_i_1 
       (.I0(PosX_reg_reg__0[0]),
        .I1(\PosX_reg_reg[3]_0 [0]),
        .I2(\PosX_reg_reg[3]_0 [1]),
        .I3(\PosX_reg_reg[3]_0 [2]),
        .O(p_0_in[3]));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosX_reg[4]_i_1 
       (.I0(\PosX_reg_reg[3]_0 [1]),
        .I1(\PosX_reg_reg[3]_0 [0]),
        .I2(PosX_reg_reg__0[0]),
        .I3(\PosX_reg_reg[3]_0 [2]),
        .I4(PosX_reg_reg__0[4]),
        .O(D));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \PosX_reg[5]_i_1 
       (.I0(\PosX_reg_reg[3]_0 [2]),
        .I1(PosX_reg_reg__0[0]),
        .I2(\PosX_reg_reg[3]_0 [0]),
        .I3(\PosX_reg_reg[3]_0 [1]),
        .I4(PosX_reg_reg__0[4]),
        .I5(PosX_reg_reg__0[5]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \PosX_reg[6]_i_1 
       (.I0(PosX_reg_reg__0[4]),
        .I1(\PosX_reg[8]_i_2_n_0 ),
        .I2(PosX_reg_reg__0[5]),
        .I3(PosX_reg_reg__0[6]),
        .O(p_0_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosX_reg[7]_i_1 
       (.I0(PosX_reg_reg__0[5]),
        .I1(\PosX_reg[8]_i_2_n_0 ),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosX_reg_reg__0[6]),
        .I4(PosX_reg_reg__0[7]),
        .O(p_0_in[7]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \PosX_reg[8]_i_1 
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[4]),
        .I2(\PosX_reg[8]_i_2_n_0 ),
        .I3(PosX_reg_reg__0[5]),
        .I4(PosX_reg_reg__0[7]),
        .I5(PosX_reg_reg__0[8]),
        .O(p_0_in[8]));
  LUT4 #(
    .INIT(16'h8000)) 
    \PosX_reg[8]_i_2 
       (.I0(\PosX_reg_reg[3]_0 [2]),
        .I1(PosX_reg_reg__0[0]),
        .I2(\PosX_reg_reg[3]_0 [0]),
        .I3(\PosX_reg_reg[3]_0 [1]),
        .O(\PosX_reg[8]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PosX_reg[9]_i_1 
       (.I0(\PosX_reg[9]_i_3_n_0 ),
        .I1(\PosX_reg_reg[3]_0 [1]),
        .I2(\PosX_reg_reg[3]_0 [2]),
        .I3(PosX_reg_reg__0[0]),
        .I4(\PosX_reg_reg[3]_0 [0]),
        .O(EndLine));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosX_reg[9]_i_2 
       (.I0(PosX_reg_reg__0[7]),
        .I1(\PosX_reg[9]_i_4_n_0 ),
        .I2(PosX_reg_reg__0[6]),
        .I3(PosX_reg_reg__0[8]),
        .I4(PosX_reg_reg__0[9]),
        .O(p_0_in[9]));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \PosX_reg[9]_i_3 
       (.I0(PosX_reg_reg__0[4]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[6]),
        .I3(PosX_reg_reg__0[7]),
        .I4(PosX_reg_reg__0[9]),
        .I5(PosX_reg_reg__0[8]),
        .O(\PosX_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \PosX_reg[9]_i_4 
       (.I0(PosX_reg_reg__0[5]),
        .I1(\PosX_reg_reg[3]_0 [2]),
        .I2(PosX_reg_reg__0[0]),
        .I3(\PosX_reg_reg[3]_0 [0]),
        .I4(\PosX_reg_reg[3]_0 [1]),
        .I5(PosX_reg_reg__0[4]),
        .O(\PosX_reg[9]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(PosX_reg_reg__0[0]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(\PosX_reg_reg[3]_0 [0]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(\PosX_reg_reg[3]_0 [1]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(\PosX_reg_reg[3]_0 [2]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(D),
        .Q(PosX_reg_reg__0[4]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(PosX_reg_reg__0[5]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(PosX_reg_reg__0[6]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(PosX_reg_reg__0[7]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(PosX_reg_reg__0[8]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(PosX_reg_reg__0[9]),
        .R(EndLine));
  LUT1 #(
    .INIT(2'h1)) 
    \PosY_reg[0]_i_1 
       (.I0(PosY_reg_reg__0[0]),
        .O(\PosY_reg[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \PosY_reg[1]_i_1 
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .O(p_0_in__0[1]));
  LUT3 #(
    .INIT(8'h78)) 
    \PosY_reg[2]_i_1 
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[2]),
        .O(p_0_in__0[2]));
  LUT4 #(
    .INIT(16'h7F80)) 
    \PosY_reg[3]_i_1 
       (.I0(PosY_reg_reg__0[1]),
        .I1(PosY_reg_reg__0[0]),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[3]),
        .O(p_0_in__0[3]));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosY_reg[4]_i_1 
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[0]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[3]),
        .I4(PosY_reg_reg__0[4]),
        .O(p_0_in__0[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \PosY_reg[5]_i_1 
       (.I0(PosY_reg_reg__0[3]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[2]),
        .I4(PosY_reg_reg__0[4]),
        .I5(PosY_reg_reg__0[5]),
        .O(p_0_in__0[5]));
  LUT2 #(
    .INIT(4'h6)) 
    \PosY_reg[6]_i_1 
       (.I0(\PosY_reg[9]_i_4_n_0 ),
        .I1(PosY_reg_reg__0[6]),
        .O(p_0_in__0[6]));
  LUT3 #(
    .INIT(8'h78)) 
    \PosY_reg[7]_i_1 
       (.I0(\PosY_reg[9]_i_4_n_0 ),
        .I1(PosY_reg_reg__0[6]),
        .I2(PosY_reg_reg__0[7]),
        .O(p_0_in__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \PosY_reg[8]_i_1 
       (.I0(PosY_reg_reg__0[6]),
        .I1(\PosY_reg[9]_i_4_n_0 ),
        .I2(PosY_reg_reg__0[7]),
        .I3(PosY_reg_reg__0[8]),
        .O(p_0_in__0[8]));
  LUT6 #(
    .INIT(64'h4000000000000000)) 
    \PosY_reg[9]_i_1 
       (.I0(TMDS_inst_i_12_n_0),
        .I1(\PosY_reg[9]_i_3_n_0 ),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[1]),
        .I4(PosY_reg_reg__0[3]),
        .I5(EndLine),
        .O(PosY_reg));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosY_reg[9]_i_2 
       (.I0(PosY_reg_reg__0[7]),
        .I1(\PosY_reg[9]_i_4_n_0 ),
        .I2(PosY_reg_reg__0[6]),
        .I3(PosY_reg_reg__0[8]),
        .I4(PosY_reg_reg__0[9]),
        .O(p_0_in__0[9]));
  LUT4 #(
    .INIT(16'h0004)) 
    \PosY_reg[9]_i_3 
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[9]),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[4]),
        .O(\PosY_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \PosY_reg[9]_i_4 
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[3]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[2]),
        .I5(PosY_reg_reg__0[4]),
        .O(\PosY_reg[9]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[0] 
       (.C(CLK),
        .CE(EndLine),
        .D(\PosY_reg[0]_i_1_n_0 ),
        .Q(PosY_reg_reg__0[0]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[1] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[1]),
        .Q(PosY_reg_reg__0[1]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[2] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[2]),
        .Q(PosY_reg_reg__0[2]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[3] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[3]),
        .Q(PosY_reg_reg__0[3]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[4] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[4]),
        .Q(PosY_reg_reg__0[4]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[5] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[5]),
        .Q(PosY_reg_reg__0[5]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[6] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[6]),
        .Q(PosY_reg_reg__0[6]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[7] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[7]),
        .Q(PosY_reg_reg__0[7]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[8] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[8]),
        .Q(PosY_reg_reg__0[8]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[9] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[9]),
        .Q(PosY_reg_reg__0[9]),
        .R(PosY_reg));
  LUT6 #(
    .INIT(64'h0555FF03FFFFFFFF)) 
    TMDS_inst_i_1
       (.I0(TMDS_inst_i_5_n_0),
        .I1(TMDS_inst_i_6_n_0),
        .I2(TMDS_inst_i_7_n_0),
        .I3(TMDS_inst_i_8_n_0),
        .I4(PosX),
        .I5(TMDS_inst_i_10_n_0),
        .O(green));
  LUT5 #(
    .INIT(32'h02222000)) 
    TMDS_inst_i_10
       (.I0(char_pixel__6),
        .I1(PosX_reg_reg__0[9]),
        .I2(TMDS_inst_i_17_n_0),
        .I3(PosX_reg_reg__0[7]),
        .I4(PosX_reg_reg__0[8]),
        .O(TMDS_inst_i_10_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    TMDS_inst_i_11
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[4]),
        .I2(PosY_reg_reg__0[3]),
        .O(TMDS_inst_i_11_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    TMDS_inst_i_12
       (.I0(PosY_reg_reg__0[6]),
        .I1(PosY_reg_reg__0[7]),
        .I2(PosY_reg_reg__0[8]),
        .O(TMDS_inst_i_12_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    TMDS_inst_i_13
       (.I0(PosY_reg_reg__0[1]),
        .I1(PosY_reg_reg__0[0]),
        .O(TMDS_inst_i_13_n_0));
  LUT6 #(
    .INIT(64'hFFFE000000000F1F)) 
    TMDS_inst_i_14
       (.I0(PosX_reg_reg__0[5]),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[7]),
        .I3(PosX_reg_reg__0[6]),
        .I4(PosX_reg_reg__0[8]),
        .I5(PosX_reg_reg__0[9]),
        .O(TMDS_inst_i_14_n_0));
  LUT5 #(
    .INIT(32'h00C20000)) 
    TMDS_inst_i_15
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosY__0[5]),
        .I4(char_tab_i_33_n_0),
        .O(TMDS_inst_i_15_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    TMDS_inst_i_17
       (.I0(PosX_reg_reg__0[4]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[6]),
        .O(TMDS_inst_i_17_n_0));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    TMDS_inst_i_2
       (.I0(PosX_reg_reg__0[7]),
        .I1(PosX_reg_reg__0[9]),
        .I2(PosX_reg_reg__0[8]),
        .I3(PosX_reg_reg__0[5]),
        .I4(PosX_reg_reg__0[6]),
        .O(hSync));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    TMDS_inst_i_3
       (.I0(PosY_reg_reg__0[9]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[5]),
        .I3(TMDS_inst_i_11_n_0),
        .I4(TMDS_inst_i_12_n_0),
        .O(vSync));
  LUT6 #(
    .INIT(64'h000000010000EEEC)) 
    TMDS_inst_i_4
       (.I0(PosY_reg_reg__0[5]),
        .I1(TMDS_inst_i_12_n_0),
        .I2(TMDS_inst_i_13_n_0),
        .I3(TMDS_inst_i_11_n_0),
        .I4(TMDS_inst_i_14_n_0),
        .I5(PosY_reg_reg__0[9]),
        .O(ActiveArea));
  LUT4 #(
    .INIT(16'h44C0)) 
    TMDS_inst_i_5
       (.I0(PosX_reg_reg__0[4]),
        .I1(TMDS_inst_i_15_n_0),
        .I2(PosY__0[7]),
        .I3(\TMDSn[2] ),
        .O(TMDS_inst_i_5_n_0));
  LUT5 #(
    .INIT(32'h00000028)) 
    TMDS_inst_i_6
       (.I0(\TMDSn[2] ),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosY__0[5]),
        .I4(PosY__0[7]),
        .O(TMDS_inst_i_6_n_0));
  LUT4 #(
    .INIT(16'hB003)) 
    TMDS_inst_i_7
       (.I0(\TMDSn[2] ),
        .I1(PosY__0[5]),
        .I2(PosY__0[7]),
        .I3(char_tab_i_33_n_0),
        .O(TMDS_inst_i_7_n_0));
  LUT3 #(
    .INIT(8'h1E)) 
    TMDS_inst_i_8
       (.I0(PosX_reg_reg__0[4]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[6]),
        .O(TMDS_inst_i_8_n_0));
  LUT4 #(
    .INIT(16'h01FE)) 
    TMDS_inst_i_9
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosX_reg_reg__0[7]),
        .O(PosX));
  LUT6 #(
    .INIT(64'hFFFFFFFFEEEEEEEA)) 
    char_tab_i_1
       (.I0(char_tab_i_9_n_0),
        .I1(char_tab_i_10_n_0),
        .I2(char_tab_i_11_n_0),
        .I3(char_tab_i_12_n_0),
        .I4(\q_reg[146] ),
        .I5(char_tab_i_14_n_0),
        .O(a[7]));
  LUT2 #(
    .INIT(4'h1)) 
    char_tab_i_10
       (.I0(char_tab_i_33_n_0),
        .I1(PosY__0[5]),
        .O(char_tab_i_10_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_101
       (.I0(\TMDSn[2]_6 ),
        .I1(\bbstub_spo[27] [4]),
        .I2(\TMDSn[2]_7 ),
        .I3(\bbstub_spo[27] [0]),
        .I4(\PosX_reg_reg[4]_9 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_101_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_102
       (.I0(char_tab_i_121_n_0),
        .I1(\q_reg[149]_1 [4]),
        .I2(\TMDSn[2]_3 ),
        .I3(\q_reg[149]_1 [2]),
        .I4(\q_reg[149]_1 [0]),
        .I5(\TMDSn[2]_4 ),
        .O(\TMDSn[2]_2 ));
  LUT2 #(
    .INIT(4'hE)) 
    char_tab_i_109
       (.I0(PosX_reg_reg__0[5]),
        .I1(PosX_reg_reg__0[4]),
        .O(char_tab_i_109_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_11
       (.I0(char_tab_i_34_n_0),
        .I1(\bbstub_spo[27] [15]),
        .I2(\TMDSn[2]_1 ),
        .I3(\bbstub_spo[27] [11]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_37_n_0),
        .O(char_tab_i_11_n_0));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    char_tab_i_110
       (.I0(\PosX_reg_reg[3]_0 [2]),
        .I1(PosX_reg_reg__0[0]),
        .I2(\PosX_reg_reg[3]_0 [0]),
        .I3(\PosX_reg_reg[3]_0 [1]),
        .I4(PosX_reg_reg__0[5]),
        .I5(PosX_reg_reg__0[4]),
        .O(char_tab_i_110_n_0));
  LUT6 #(
    .INIT(64'hFFF8F8F888888888)) 
    char_tab_i_111
       (.I0(Q[8]),
        .I1(\TMDSn[2]_9 ),
        .I2(char_tab_i_133_n_0),
        .I3(\TMDSn[2]_3 ),
        .I4(Q[6]),
        .I5(char_tab_i_121_n_0),
        .O(char_tab_i_111_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_112
       (.I0(\TMDSn[2]_6 ),
        .I1(char_tab_i_134_n_0),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[31] [11]),
        .I4(\TMDSn[2]_1 ),
        .I5(\q_reg[31] [15]),
        .O(char_tab_i_112_n_0));
  LUT5 #(
    .INIT(32'h0000ACA0)) 
    char_tab_i_113
       (.I0(\PC_reg_reg[7] [5]),
        .I1(\TMDSn[2]_1 ),
        .I2(\TMDSn[2]_0 ),
        .I3(\PC_reg_reg[7] [2]),
        .I4(PosY__0[7]),
        .O(char_tab_i_113_n_0));
  LUT4 #(
    .INIT(16'h1800)) 
    char_tab_i_114
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(\TMDSn[2]_11 ),
        .O(\TMDSn[2]_3 ));
  LUT4 #(
    .INIT(16'h6000)) 
    char_tab_i_115
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(\TMDSn[2]_11 ),
        .O(\TMDSn[2]_4 ));
  LUT6 #(
    .INIT(64'h1000000400000440)) 
    char_tab_i_116
       (.I0(PosX_reg_reg__0[9]),
        .I1(PosX_reg_reg__0[8]),
        .I2(PosX_reg_reg__0[6]),
        .I3(char_tab_i_109_n_0),
        .I4(PosX_reg_reg__0[7]),
        .I5(char_tab_i_110_n_0),
        .O(\TMDSn[2]_11 ));
  LUT6 #(
    .INIT(64'hFFF8F8F888888888)) 
    char_tab_i_119
       (.I0(Q[7]),
        .I1(\TMDSn[2]_9 ),
        .I2(char_tab_i_136_n_0),
        .I3(\TMDSn[2]_3 ),
        .I4(Q[5]),
        .I5(char_tab_i_121_n_0),
        .O(char_tab_i_119_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_12
       (.I0(char_tab_i_38_n_0),
        .I1(\q_reg[149]_1 [13]),
        .I2(\TMDSn[2]_1 ),
        .I3(\q_reg[149]_1 [11]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_39_n_0),
        .O(char_tab_i_12_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_120
       (.I0(char_tab_i_121_n_0),
        .I1(\PosX_reg_reg[4]_6 ),
        .I2(\TMDSn[2]_9 ),
        .I3(\q_reg[31] [2]),
        .I4(\TMDSn[2]_7 ),
        .I5(\q_reg[31] [6]),
        .O(char_tab_i_120_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    char_tab_i_121
       (.I0(\TMDSn[2]_7 ),
        .I1(\TMDSn[2]_8 ),
        .O(char_tab_i_121_n_0));
  LUT6 #(
    .INIT(64'hFFFF000080007FFF)) 
    char_tab_i_129
       (.I0(\PosX_reg_reg[3]_0 [2]),
        .I1(PosX_reg_reg__0[0]),
        .I2(\PosX_reg_reg[3]_0 [0]),
        .I3(\PosX_reg_reg[3]_0 [1]),
        .I4(PosX_reg_reg__0[5]),
        .I5(PosX_reg_reg__0[4]),
        .O(p_0_in__1));
  LUT5 #(
    .INIT(32'h51404040)) 
    char_tab_i_133
       (.I0(\TMDSn[2]_3 ),
        .I1(\TMDSn[2]_4 ),
        .I2(Q[3]),
        .I3(\TMDSn[2]_13 ),
        .I4(Q[1]),
        .O(char_tab_i_133_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_134
       (.I0(char_tab_i_121_n_0),
        .I1(\PosX_reg_reg[4]_5 ),
        .I2(\TMDSn[2]_9 ),
        .I3(\q_reg[31] [3]),
        .I4(\TMDSn[2]_7 ),
        .I5(\q_reg[31] [7]),
        .O(char_tab_i_134_n_0));
  LUT5 #(
    .INIT(32'h51404040)) 
    char_tab_i_136
       (.I0(\TMDSn[2]_3 ),
        .I1(\TMDSn[2]_4 ),
        .I2(Q[2]),
        .I3(\TMDSn[2]_13 ),
        .I4(Q[0]),
        .O(char_tab_i_136_n_0));
  LUT4 #(
    .INIT(16'h8100)) 
    char_tab_i_138
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(\TMDSn[2]_11 ),
        .O(\TMDSn[2]_13 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA08AA0808)) 
    char_tab_i_14
       (.I0(char_tab_i_41_n_0),
        .I1(\TMDSn[2]_1 ),
        .I2(\q_reg[138]_0 ),
        .I3(\q_reg[134] ),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_42_n_0),
        .O(char_tab_i_14_n_0));
  LUT6 #(
    .INIT(64'h44444444FFF00000)) 
    char_tab_i_15
       (.I0(\q_reg[141] ),
        .I1(\TMDSn[2]_0 ),
        .I2(char_tab_i_43_n_0),
        .I3(char_tab_i_44_n_0),
        .I4(char_tab_i_33_n_0),
        .I5(PosY__0[5]),
        .O(char_tab_i_15_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_16
       (.I0(char_tab_i_34_n_0),
        .I1(\bbstub_spo[27] [14]),
        .I2(\TMDSn[2]_1 ),
        .I3(\bbstub_spo[27] [10]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_45_n_0),
        .O(char_tab_i_16_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_17
       (.I0(char_tab_i_38_n_0),
        .I1(\q_reg[149]_1 [12]),
        .I2(\TMDSn[2]_1 ),
        .I3(\q_reg[149]_1 [10]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_46_n_0),
        .O(char_tab_i_17_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAA08AA0808)) 
    char_tab_i_19
       (.I0(char_tab_i_41_n_0),
        .I1(\TMDSn[2]_1 ),
        .I2(\q_reg[137] ),
        .I3(\q_reg[133] ),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_47_n_0),
        .O(char_tab_i_19_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFEEEEEEEA)) 
    char_tab_i_2
       (.I0(char_tab_i_15_n_0),
        .I1(char_tab_i_10_n_0),
        .I2(char_tab_i_16_n_0),
        .I3(char_tab_i_17_n_0),
        .I4(\PosX_reg_reg[5]_0 ),
        .I5(char_tab_i_19_n_0),
        .O(a[6]));
  LUT6 #(
    .INIT(64'hA8A88888AA888888)) 
    char_tab_i_20
       (.I0(char_tab_i_48_n_0),
        .I1(char_tab_i_49_n_0),
        .I2(\q_reg[31] [17]),
        .I3(char_tab_i_50_n_0),
        .I4(PosY__0[7]),
        .I5(\TMDSn[2]_0 ),
        .O(char_tab_i_20_n_0));
  LUT6 #(
    .INIT(64'hA280A280A2A28080)) 
    char_tab_i_21
       (.I0(char_tab_i_52_n_0),
        .I1(\TMDSn[2]_0 ),
        .I2(Q[15]),
        .I3(Q[13]),
        .I4(\q_reg[17] ),
        .I5(\TMDSn[2]_1 ),
        .O(char_tab_i_21_n_0));
  LUT6 #(
    .INIT(64'h00000000FFFFFEAA)) 
    char_tab_i_22
       (.I0(char_tab_i_54_n_0),
        .I1(\q_reg[149]_2 ),
        .I2(\q_reg[149]_3 ),
        .I3(char_tab_i_38_n_0),
        .I4(\q_reg[146]_0 ),
        .I5(char_tab_i_33_n_0),
        .O(char_tab_i_22_n_0));
  LUT6 #(
    .INIT(64'h00000001FFFFFFFE)) 
    char_tab_i_23
       (.I0(PosY_reg_reg__0[4]),
        .I1(PosY_reg_reg__0[2]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[3]),
        .I5(PosY_reg_reg__0[5]),
        .O(PosY__0[5]));
  LUT6 #(
    .INIT(64'hAAAAAAAA08AA0808)) 
    char_tab_i_24
       (.I0(char_tab_i_41_n_0),
        .I1(\TMDSn[2]_1 ),
        .I2(\q_reg[136] ),
        .I3(\q_reg[132] ),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_58_n_0),
        .O(char_tab_i_24_n_0));
  LUT3 #(
    .INIT(8'h08)) 
    char_tab_i_25
       (.I0(PosY__0[5]),
        .I1(\TMDSn[2]_0 ),
        .I2(\q_reg[138]_1 ),
        .O(char_tab_i_25_n_0));
  LUT6 #(
    .INIT(64'hAA8A2A0AA0802000)) 
    char_tab_i_26
       (.I0(char_tab_i_48_n_0),
        .I1(\TMDSn[2]_0 ),
        .I2(PosY__0[7]),
        .I3(char_tab_i_59_n_0),
        .I4(\q_reg[31] [16]),
        .I5(\PC_reg_reg[0] ),
        .O(char_tab_i_26_n_0));
  LUT6 #(
    .INIT(64'hA280A280A2A28080)) 
    char_tab_i_27
       (.I0(char_tab_i_52_n_0),
        .I1(\TMDSn[2]_0 ),
        .I2(Q[15]),
        .I3(Q[12]),
        .I4(char_tab_i_61_n_0),
        .I5(\TMDSn[2]_1 ),
        .O(char_tab_i_27_n_0));
  LUT6 #(
    .INIT(64'h00000000FFFFFEAA)) 
    char_tab_i_28
       (.I0(char_tab_i_62_n_0),
        .I1(\q_reg[149] ),
        .I2(\q_reg[147] ),
        .I3(char_tab_i_38_n_0),
        .I4(\q_reg[149]_0 ),
        .I5(char_tab_i_33_n_0),
        .O(char_tab_i_28_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAA08AA0808)) 
    char_tab_i_29
       (.I0(char_tab_i_41_n_0),
        .I1(\TMDSn[2]_1 ),
        .I2(\q_reg[134]_0 ),
        .I3(\q_reg[131] ),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_66_n_0),
        .O(char_tab_i_29_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF00FE)) 
    char_tab_i_3
       (.I0(char_tab_i_20_n_0),
        .I1(char_tab_i_21_n_0),
        .I2(char_tab_i_22_n_0),
        .I3(PosY__0[5]),
        .I4(char_tab_i_24_n_0),
        .I5(char_tab_i_25_n_0),
        .O(a[5]));
  LUT3 #(
    .INIT(8'h08)) 
    char_tab_i_30
       (.I0(PosY__0[5]),
        .I1(\TMDSn[2]_0 ),
        .I2(\q_reg[138]_2 ),
        .O(char_tab_i_30_n_0));
  LUT4 #(
    .INIT(16'h1200)) 
    char_tab_i_31
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .I3(char_tab_i_67_n_0),
        .O(\TMDSn[2]_0 ));
  LUT6 #(
    .INIT(64'hFFFFDDC80000DDC8)) 
    char_tab_i_32
       (.I0(\TMDSn[2]_0 ),
        .I1(Q[15]),
        .I2(\TMDSn[2]_1 ),
        .I3(char_tab_i_68_n_0),
        .I4(\TMDSn[2] ),
        .I5(char_tab_i_69_n_0),
        .O(char_tab_i_32_n_0));
  LUT4 #(
    .INIT(16'h01FE)) 
    char_tab_i_33
       (.I0(PosY_reg_reg__0[7]),
        .I1(char_tab_i_70_n_0),
        .I2(PosY_reg_reg__0[6]),
        .I3(PosY_reg_reg__0[8]),
        .O(char_tab_i_33_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_34
       (.I0(\TMDSn[2] ),
        .I1(\TMDSn[2]_0 ),
        .O(char_tab_i_34_n_0));
  LUT4 #(
    .INIT(16'h1800)) 
    char_tab_i_35
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(char_tab_i_67_n_0),
        .O(\TMDSn[2]_1 ));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_36
       (.I0(\TMDSn[2]_12 ),
        .I1(\TMDSn[2]_1 ),
        .O(\TMDSn[2]_5 ));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_37
       (.I0(\TMDSn[2]_6 ),
        .I1(\bbstub_spo[27] [7]),
        .I2(\TMDSn[2]_7 ),
        .I3(\bbstub_spo[27] [3]),
        .I4(\PosX_reg_reg[4]_12 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_37_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    char_tab_i_38
       (.I0(\TMDSn[2]_0 ),
        .I1(\TMDSn[2] ),
        .O(char_tab_i_38_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_39
       (.I0(\TMDSn[2]_6 ),
        .I1(\q_reg[149]_1 [9]),
        .I2(\TMDSn[2]_7 ),
        .I3(\q_reg[149]_1 [7]),
        .I4(\PosX_reg_reg[4]_1 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_39_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF00FE)) 
    char_tab_i_4
       (.I0(char_tab_i_26_n_0),
        .I1(char_tab_i_27_n_0),
        .I2(char_tab_i_28_n_0),
        .I3(PosY__0[5]),
        .I4(char_tab_i_29_n_0),
        .I5(char_tab_i_30_n_0),
        .O(a[4]));
  LUT6 #(
    .INIT(64'hFFFE00000001FFFF)) 
    char_tab_i_40
       (.I0(PosY_reg_reg__0[3]),
        .I1(TMDS_inst_i_13_n_0),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[4]),
        .I4(PosY_reg_reg__0[5]),
        .I5(PosY_reg_reg__0[6]),
        .O(\TMDSn[2] ));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_41
       (.I0(PosY__0[5]),
        .I1(\TMDSn[2]_0 ),
        .O(char_tab_i_41_n_0));
  LUT6 #(
    .INIT(64'h082A082A2A2A0808)) 
    char_tab_i_42
       (.I0(\TMDSn[2]_6 ),
        .I1(\TMDSn[2]_7 ),
        .I2(\q_reg[130] ),
        .I3(\q_reg[126] ),
        .I4(\PosX_reg_reg[4]_0 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_42_n_0));
  LUT6 #(
    .INIT(64'h00000000AAAAFCCC)) 
    char_tab_i_43
       (.I0(Q[16]),
        .I1(char_tab_i_78_n_0),
        .I2(\TMDSn[2]_1 ),
        .I3(Q[14]),
        .I4(\TMDSn[2]_0 ),
        .I5(\TMDSn[2] ),
        .O(char_tab_i_43_n_0));
  LUT6 #(
    .INIT(64'hEEAAFAAA00000000)) 
    char_tab_i_44
       (.I0(char_tab_i_79_n_0),
        .I1(\q_reg[31] [18]),
        .I2(char_tab_i_80_n_0),
        .I3(PosY__0[7]),
        .I4(\TMDSn[2]_0 ),
        .I5(\TMDSn[2] ),
        .O(char_tab_i_44_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_45
       (.I0(\TMDSn[2]_6 ),
        .I1(\bbstub_spo[27] [6]),
        .I2(\TMDSn[2]_7 ),
        .I3(\bbstub_spo[27] [2]),
        .I4(\PosX_reg_reg[4]_11 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_45_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_46
       (.I0(\TMDSn[2]_6 ),
        .I1(\q_reg[149]_1 [8]),
        .I2(\TMDSn[2]_7 ),
        .I3(\q_reg[149]_1 [6]),
        .I4(\PosX_reg_reg[4]_2 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_46_n_0));
  LUT6 #(
    .INIT(64'h082A082A2A2A0808)) 
    char_tab_i_47
       (.I0(\TMDSn[2]_6 ),
        .I1(\TMDSn[2]_7 ),
        .I2(\q_reg[130]_0 ),
        .I3(\q_reg[125] ),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_47_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    char_tab_i_48
       (.I0(char_tab_i_33_n_0),
        .I1(\TMDSn[2] ),
        .O(char_tab_i_48_n_0));
  LUT5 #(
    .INIT(32'h0000ACA0)) 
    char_tab_i_49
       (.I0(\PC_reg_reg[7] [3]),
        .I1(\TMDSn[2]_1 ),
        .I2(\TMDSn[2]_0 ),
        .I3(\PC_reg_reg[7] [0]),
        .I4(PosY__0[7]),
        .O(char_tab_i_49_n_0));
  LUT5 #(
    .INIT(32'hFFFE0001)) 
    char_tab_i_5
       (.I0(PosY_reg_reg__0[3]),
        .I1(PosY_reg_reg__0[0]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[2]),
        .I4(PosY_reg_reg__0[4]),
        .O(a[3]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_50
       (.I0(\TMDSn[2]_6 ),
        .I1(char_tab_i_84_n_0),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[31] [9]),
        .I4(\TMDSn[2]_1 ),
        .I5(\q_reg[31] [13]),
        .O(char_tab_i_50_n_0));
  LUT3 #(
    .INIT(8'hE1)) 
    char_tab_i_51
       (.I0(PosY_reg_reg__0[6]),
        .I1(char_tab_i_70_n_0),
        .I2(PosY_reg_reg__0[7]),
        .O(PosY__0[7]));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_52
       (.I0(char_tab_i_33_n_0),
        .I1(\TMDSn[2] ),
        .O(char_tab_i_52_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_54
       (.I0(char_tab_i_34_n_0),
        .I1(\bbstub_spo[27] [13]),
        .I2(\TMDSn[2]_1 ),
        .I3(\bbstub_spo[27] [9]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_86_n_0),
        .O(char_tab_i_54_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAA08AA0808)) 
    char_tab_i_58
       (.I0(\TMDSn[2]_6 ),
        .I1(\TMDSn[2]_7 ),
        .I2(\q_reg[128] ),
        .I3(\q_reg[124] ),
        .I4(\TMDSn[2]_9 ),
        .I5(char_tab_i_93_n_0),
        .O(char_tab_i_58_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_59
       (.I0(\TMDSn[2]_6 ),
        .I1(char_tab_i_94_n_0),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[31] [8]),
        .I4(\TMDSn[2]_1 ),
        .I5(\q_reg[31] [12]),
        .O(char_tab_i_59_n_0));
  LUT4 #(
    .INIT(16'hFE01)) 
    char_tab_i_6
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[3]),
        .O(a[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFAAA8)) 
    char_tab_i_61
       (.I0(char_tab_i_95_n_0),
        .I1(\q_reg[12] ),
        .I2(char_tab_i_97_n_0),
        .I3(\q_reg[4] ),
        .I4(char_tab_i_99_n_0),
        .I5(\q_reg[20] ),
        .O(char_tab_i_61_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA808080)) 
    char_tab_i_62
       (.I0(char_tab_i_34_n_0),
        .I1(\bbstub_spo[27] [12]),
        .I2(\TMDSn[2]_1 ),
        .I3(\bbstub_spo[27] [8]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_101_n_0),
        .O(char_tab_i_62_n_0));
  LUT6 #(
    .INIT(64'h082A082A2A2A0808)) 
    char_tab_i_66
       (.I0(\TMDSn[2]_6 ),
        .I1(\TMDSn[2]_7 ),
        .I2(\q_reg[127] ),
        .I3(\q_reg[123] ),
        .I4(\PosX_reg_reg[4]_4 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_66_n_0));
  LUT6 #(
    .INIT(64'h0004040004000010)) 
    char_tab_i_67
       (.I0(PosX_reg_reg__0[9]),
        .I1(PosX_reg_reg__0[7]),
        .I2(PosX_reg_reg__0[8]),
        .I3(char_tab_i_109_n_0),
        .I4(PosX_reg_reg__0[6]),
        .I5(char_tab_i_110_n_0),
        .O(char_tab_i_67_n_0));
  LUT6 #(
    .INIT(64'hFFF8F8F888888888)) 
    char_tab_i_68
       (.I0(Q[12]),
        .I1(\TMDSn[2]_5 ),
        .I2(char_tab_i_111_n_0),
        .I3(\TMDSn[2]_7 ),
        .I4(Q[10]),
        .I5(\TMDSn[2]_6 ),
        .O(char_tab_i_68_n_0));
  LUT5 #(
    .INIT(32'hFFFFC840)) 
    char_tab_i_69
       (.I0(\TMDSn[2]_0 ),
        .I1(PosY__0[7]),
        .I2(char_tab_i_112_n_0),
        .I3(\q_reg[31] [19]),
        .I4(char_tab_i_113_n_0),
        .O(char_tab_i_69_n_0));
  LUT3 #(
    .INIT(8'hE1)) 
    char_tab_i_7
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[2]),
        .O(a[1]));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    char_tab_i_70
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[4]),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[1]),
        .I4(PosY_reg_reg__0[0]),
        .I5(PosY_reg_reg__0[3]),
        .O(char_tab_i_70_n_0));
  LUT4 #(
    .INIT(16'h6000)) 
    char_tab_i_71
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(char_tab_i_67_n_0),
        .O(\TMDSn[2]_12 ));
  LUT2 #(
    .INIT(4'h1)) 
    char_tab_i_72
       (.I0(\TMDSn[2]_1 ),
        .I1(\TMDSn[2]_12 ),
        .O(\TMDSn[2]_6 ));
  LUT4 #(
    .INIT(16'h8100)) 
    char_tab_i_73
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(char_tab_i_67_n_0),
        .O(\TMDSn[2]_7 ));
  LUT4 #(
    .INIT(16'h1200)) 
    char_tab_i_75
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .I3(\TMDSn[2]_11 ),
        .O(\TMDSn[2]_8 ));
  LUT6 #(
    .INIT(64'hFFF8F8F888888888)) 
    char_tab_i_78
       (.I0(Q[11]),
        .I1(\TMDSn[2]_5 ),
        .I2(char_tab_i_119_n_0),
        .I3(\TMDSn[2]_7 ),
        .I4(Q[10]),
        .I5(\TMDSn[2]_6 ),
        .O(char_tab_i_78_n_0));
  LUT5 #(
    .INIT(32'h0000ACA0)) 
    char_tab_i_79
       (.I0(\PC_reg_reg[7] [4]),
        .I1(\TMDSn[2]_1 ),
        .I2(\TMDSn[2]_0 ),
        .I3(\PC_reg_reg[7] [1]),
        .I4(PosY__0[7]),
        .O(char_tab_i_79_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    char_tab_i_8
       (.I0(PosY_reg_reg__0[1]),
        .I1(PosY_reg_reg__0[0]),
        .O(a[0]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_80
       (.I0(\TMDSn[2]_6 ),
        .I1(char_tab_i_120_n_0),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[31] [10]),
        .I4(\TMDSn[2]_1 ),
        .I5(\q_reg[31] [14]),
        .O(char_tab_i_80_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_84
       (.I0(char_tab_i_121_n_0),
        .I1(\PosX_reg_reg[4]_7 ),
        .I2(\TMDSn[2]_9 ),
        .I3(\q_reg[31] [1]),
        .I4(\TMDSn[2]_7 ),
        .I5(\q_reg[31] [5]),
        .O(char_tab_i_84_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_86
       (.I0(\TMDSn[2]_6 ),
        .I1(\bbstub_spo[27] [5]),
        .I2(\TMDSn[2]_7 ),
        .I3(\bbstub_spo[27] [1]),
        .I4(\PosX_reg_reg[4]_10 ),
        .I5(\TMDSn[2]_8 ),
        .O(char_tab_i_86_n_0));
  LUT6 #(
    .INIT(64'h8A808A808A8A8080)) 
    char_tab_i_88
       (.I0(char_tab_i_121_n_0),
        .I1(\q_reg[149]_1 [5]),
        .I2(\TMDSn[2]_3 ),
        .I3(\q_reg[149]_1 [3]),
        .I4(\q_reg[149]_1 [1]),
        .I5(\TMDSn[2]_4 ),
        .O(\TMDSn[2]_10 ));
  LUT5 #(
    .INIT(32'h4444F000)) 
    char_tab_i_9
       (.I0(\q_reg[138] ),
        .I1(\TMDSn[2]_0 ),
        .I2(char_tab_i_32_n_0),
        .I3(char_tab_i_33_n_0),
        .I4(PosY__0[5]),
        .O(char_tab_i_9_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_92
       (.I0(\TMDSn[2]_8 ),
        .I1(\TMDSn[2]_7 ),
        .O(\TMDSn[2]_9 ));
  LUT6 #(
    .INIT(64'hF0F000A0F0F010B0)) 
    char_tab_i_93
       (.I0(\TMDSn[2]_3 ),
        .I1(\TMDSn[2]_4 ),
        .I2(char_tab_i_121_n_0),
        .I3(\q_reg[118] ),
        .I4(\q_reg[143] ),
        .I5(\q_reg[48] ),
        .O(char_tab_i_93_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_94
       (.I0(char_tab_i_121_n_0),
        .I1(\PosX_reg_reg[4]_8 ),
        .I2(\TMDSn[2]_9 ),
        .I3(\q_reg[31] [0]),
        .I4(\TMDSn[2]_7 ),
        .I5(\q_reg[31] [4]),
        .O(char_tab_i_94_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    char_tab_i_95
       (.I0(\TMDSn[2]_12 ),
        .I1(\TMDSn[2]_7 ),
        .O(char_tab_i_95_n_0));
  LUT3 #(
    .INIT(8'h08)) 
    char_tab_i_97
       (.I0(Q[4]),
        .I1(\TMDSn[2]_3 ),
        .I2(\TMDSn[2]_8 ),
        .O(char_tab_i_97_n_0));
  LUT3 #(
    .INIT(8'h08)) 
    char_tab_i_99
       (.I0(Q[9]),
        .I1(\TMDSn[2]_7 ),
        .I2(\TMDSn[2]_12 ),
        .O(char_tab_i_99_n_0));
endmodule

module vga_data
   (char_pixel__6,
    a,
    CLK,
    Q);
  output char_pixel__6;
  input [7:0]a;
  input CLK;
  input [2:0]Q;

  wire CLK;
  wire [2:0]Q;
  wire TMDS_inst_i_18_n_0;
  wire TMDS_inst_i_19_n_0;
  wire [7:0]a;
  wire char_pixel__6;
  wire [7:0]rom_dout;

  MUXF7 TMDS_inst_i_16
       (.I0(TMDS_inst_i_18_n_0),
        .I1(TMDS_inst_i_19_n_0),
        .O(char_pixel__6),
        .S(Q[2]));
  LUT6 #(
    .INIT(64'hCACAFFF0CACA0F00)) 
    TMDS_inst_i_18
       (.I0(rom_dout[6]),
        .I1(rom_dout[4]),
        .I2(Q[1]),
        .I3(rom_dout[7]),
        .I4(Q[0]),
        .I5(rom_dout[5]),
        .O(TMDS_inst_i_18_n_0));
  LUT6 #(
    .INIT(64'hCACAFFF0CACA0F00)) 
    TMDS_inst_i_19
       (.I0(rom_dout[2]),
        .I1(rom_dout[0]),
        .I2(Q[1]),
        .I3(rom_dout[3]),
        .I4(Q[0]),
        .I5(rom_dout[1]),
        .O(TMDS_inst_i_19_n_0));
  (* x_core_info = "dist_mem_gen_v8_0_11,Vivado 2017.1" *) 
  DisplayROM char_tab
       (.a(a),
        .clk(CLK),
        .qspo(rom_dout));
endmodule

(* C_ADDR_WIDTH = "6" *) (* C_DEFAULT_DATA = "0" *) (* C_DEPTH = "64" *) 
(* C_ELABORATION_DIR = "./" *) (* C_FAMILY = "artix7" *) (* C_HAS_CLK = "1" *) 
(* C_HAS_D = "1" *) (* C_HAS_DPO = "0" *) (* C_HAS_DPRA = "0" *) 
(* C_HAS_I_CE = "0" *) (* C_HAS_QDPO = "0" *) (* C_HAS_QDPO_CE = "0" *) 
(* C_HAS_QDPO_CLK = "0" *) (* C_HAS_QDPO_RST = "0" *) (* C_HAS_QDPO_SRST = "0" *) 
(* C_HAS_QSPO = "0" *) (* C_HAS_QSPO_CE = "0" *) (* C_HAS_QSPO_RST = "0" *) 
(* C_HAS_QSPO_SRST = "0" *) (* C_HAS_SPO = "1" *) (* C_HAS_WE = "1" *) 
(* C_MEM_INIT_FILE = "no_coe_file_loaded" *) (* C_MEM_TYPE = "1" *) (* C_PARSER_TYPE = "1" *) 
(* C_PIPELINE_STAGES = "0" *) (* C_QCE_JOINED = "0" *) (* C_QUALIFY_WE = "0" *) 
(* C_READ_MIF = "0" *) (* C_REG_A_D_INPUTS = "0" *) (* C_REG_DPRA_INPUT = "0" *) 
(* C_SYNC_ENABLE = "1" *) (* C_WIDTH = "32" *) (* ORIG_REF_NAME = "dist_mem_gen_v8_0_12" *) 
module DataRAM_dist_mem_gen_v8_0_12
   (a,
    d,
    dpra,
    clk,
    we,
    i_ce,
    qspo_ce,
    qdpo_ce,
    qdpo_clk,
    qspo_rst,
    qdpo_rst,
    qspo_srst,
    qdpo_srst,
    spo,
    dpo,
    qspo,
    qdpo);
  input [5:0]a;
  input [31:0]d;
  input [5:0]dpra;
  input clk;
  input we;
  input i_ce;
  input qspo_ce;
  input qdpo_ce;
  input qdpo_clk;
  input qspo_rst;
  input qdpo_rst;
  input qspo_srst;
  input qdpo_srst;
  output [31:0]spo;
  output [31:0]dpo;
  output [31:0]qspo;
  output [31:0]qdpo;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  DataRAM_dist_mem_gen_v8_0_12_synth \synth_options.dist_mem_inst 
       (.a(a),
        .clk(clk),
        .d(d),
        .spo(spo),
        .we(we));
endmodule

(* ORIG_REF_NAME = "dist_mem_gen_v8_0_12_synth" *) 
module DataRAM_dist_mem_gen_v8_0_12_synth
   (spo,
    clk,
    d,
    we,
    a);
  output [31:0]spo;
  input clk;
  input [31:0]d;
  input we;
  input [5:0]a;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  DataRAM_spram \gen_sp_ram.spram_inst 
       (.a(a),
        .clk(clk),
        .d(d),
        .spo(spo),
        .we(we));
endmodule

(* ORIG_REF_NAME = "spram" *) 
module DataRAM_spram
   (spo,
    clk,
    d,
    we,
    a);
  output [31:0]spo;
  input clk;
  input [31:0]d;
  input we;
  input [5:0]a;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_UNIQ_BASE_ ram_reg_0_63_0_0
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[0]),
        .O(spo[0]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD1 ram_reg_0_63_10_10
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[10]),
        .O(spo[10]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD2 ram_reg_0_63_11_11
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[11]),
        .O(spo[11]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD3 ram_reg_0_63_12_12
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[12]),
        .O(spo[12]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD4 ram_reg_0_63_13_13
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[13]),
        .O(spo[13]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD5 ram_reg_0_63_14_14
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[14]),
        .O(spo[14]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD6 ram_reg_0_63_15_15
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[15]),
        .O(spo[15]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD7 ram_reg_0_63_16_16
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[16]),
        .O(spo[16]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD8 ram_reg_0_63_17_17
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[17]),
        .O(spo[17]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD9 ram_reg_0_63_18_18
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[18]),
        .O(spo[18]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD10 ram_reg_0_63_19_19
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[19]),
        .O(spo[19]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD11 ram_reg_0_63_1_1
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[1]),
        .O(spo[1]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD12 ram_reg_0_63_20_20
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[20]),
        .O(spo[20]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD13 ram_reg_0_63_21_21
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[21]),
        .O(spo[21]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD14 ram_reg_0_63_22_22
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[22]),
        .O(spo[22]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD15 ram_reg_0_63_23_23
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[23]),
        .O(spo[23]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD16 ram_reg_0_63_24_24
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[24]),
        .O(spo[24]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD17 ram_reg_0_63_25_25
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[25]),
        .O(spo[25]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD18 ram_reg_0_63_26_26
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[26]),
        .O(spo[26]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD19 ram_reg_0_63_27_27
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[27]),
        .O(spo[27]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD20 ram_reg_0_63_28_28
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[28]),
        .O(spo[28]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD21 ram_reg_0_63_29_29
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[29]),
        .O(spo[29]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD22 ram_reg_0_63_2_2
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[2]),
        .O(spo[2]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD23 ram_reg_0_63_30_30
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[30]),
        .O(spo[30]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD24 ram_reg_0_63_31_31
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[31]),
        .O(spo[31]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD25 ram_reg_0_63_3_3
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[3]),
        .O(spo[3]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD26 ram_reg_0_63_4_4
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[4]),
        .O(spo[4]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD27 ram_reg_0_63_5_5
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[5]),
        .O(spo[5]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD28 ram_reg_0_63_6_6
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[6]),
        .O(spo[6]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD29 ram_reg_0_63_7_7
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[7]),
        .O(spo[7]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD30 ram_reg_0_63_8_8
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[8]),
        .O(spo[8]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD31 ram_reg_0_63_9_9
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[9]),
        .O(spo[9]),
        .WCLK(clk),
        .WE(we));
endmodule

(* C_ADDR_WIDTH = "8" *) (* C_DEFAULT_DATA = "0" *) (* C_DEPTH = "256" *) 
(* C_ELABORATION_DIR = "./" *) (* C_FAMILY = "artix7" *) (* C_HAS_CLK = "1" *) 
(* C_HAS_D = "0" *) (* C_HAS_DPO = "0" *) (* C_HAS_DPRA = "0" *) 
(* C_HAS_I_CE = "0" *) (* C_HAS_QDPO = "0" *) (* C_HAS_QDPO_CE = "0" *) 
(* C_HAS_QDPO_CLK = "0" *) (* C_HAS_QDPO_RST = "0" *) (* C_HAS_QDPO_SRST = "0" *) 
(* C_HAS_QSPO = "1" *) (* C_HAS_QSPO_CE = "0" *) (* C_HAS_QSPO_RST = "0" *) 
(* C_HAS_QSPO_SRST = "0" *) (* C_HAS_SPO = "0" *) (* C_HAS_WE = "0" *) 
(* C_MEM_INIT_FILE = "DisplayROM.mif" *) (* C_MEM_TYPE = "0" *) (* C_PARSER_TYPE = "1" *) 
(* C_PIPELINE_STAGES = "0" *) (* C_QCE_JOINED = "0" *) (* C_QUALIFY_WE = "0" *) 
(* C_READ_MIF = "1" *) (* C_REG_A_D_INPUTS = "0" *) (* C_REG_DPRA_INPUT = "0" *) 
(* C_SYNC_ENABLE = "1" *) (* C_WIDTH = "8" *) (* ORIG_REF_NAME = "dist_mem_gen_v8_0_11" *) 
module DisplayROM_dist_mem_gen_v8_0_11
   (a,
    d,
    dpra,
    clk,
    we,
    i_ce,
    qspo_ce,
    qdpo_ce,
    qdpo_clk,
    qspo_rst,
    qdpo_rst,
    qspo_srst,
    qdpo_srst,
    spo,
    dpo,
    qspo,
    qdpo);
  input [7:0]a;
  input [7:0]d;
  input [7:0]dpra;
  input clk;
  input we;
  input i_ce;
  input qspo_ce;
  input qdpo_ce;
  input qdpo_clk;
  input qspo_rst;
  input qdpo_rst;
  input qspo_srst;
  input qdpo_srst;
  output [7:0]spo;
  output [7:0]dpo;
  output [7:0]qspo;
  output [7:0]qdpo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;

  DisplayROM_dist_mem_gen_v8_0_11_synth \synth_options.dist_mem_inst 
       (.a(a),
        .clk(clk),
        .qspo(qspo));
endmodule

(* ORIG_REF_NAME = "dist_mem_gen_v8_0_11_synth" *) 
module DisplayROM_dist_mem_gen_v8_0_11_synth
   (qspo,
    a,
    clk);
  output [7:0]qspo;
  input [7:0]a;
  input clk;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;

  DisplayROM_rom \gen_rom.rom_inst 
       (.a(a),
        .clk(clk),
        .qspo(qspo));
endmodule

(* ORIG_REF_NAME = "rom" *) 
module DisplayROM_rom
   (qspo,
    a,
    clk);
  output [7:0]qspo;
  input [7:0]a;
  input clk;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire \qspo_int[0]_i_1_n_0 ;
  wire \qspo_int[0]_i_2_n_0 ;
  wire \qspo_int[1]_i_4_n_0 ;
  wire \qspo_int[1]_i_5_n_0 ;
  wire \qspo_int[1]_i_6_n_0 ;
  wire \qspo_int[1]_i_7_n_0 ;
  wire \qspo_int[2]_i_4_n_0 ;
  wire \qspo_int[2]_i_5_n_0 ;
  wire \qspo_int[2]_i_6_n_0 ;
  wire \qspo_int[2]_i_7_n_0 ;
  wire \qspo_int[3]_i_1_n_0 ;
  wire \qspo_int[3]_i_2_n_0 ;
  wire \qspo_int[3]_i_3_n_0 ;
  wire \qspo_int[3]_i_4_n_0 ;
  wire \qspo_int[4]_i_1_n_0 ;
  wire \qspo_int[4]_i_2_n_0 ;
  wire \qspo_int[4]_i_3_n_0 ;
  wire \qspo_int[4]_i_4_n_0 ;
  wire \qspo_int[4]_i_5_n_0 ;
  wire \qspo_int[5]_i_4_n_0 ;
  wire \qspo_int[5]_i_5_n_0 ;
  wire \qspo_int[5]_i_6_n_0 ;
  wire \qspo_int[5]_i_7_n_0 ;
  wire \qspo_int[6]_i_4_n_0 ;
  wire \qspo_int[6]_i_5_n_0 ;
  wire \qspo_int[6]_i_6_n_0 ;
  wire \qspo_int[6]_i_7_n_0 ;
  wire \qspo_int[7]_i_1_n_0 ;
  wire \qspo_int[7]_i_2_n_0 ;
  wire \qspo_int[7]_i_3_n_0 ;
  wire \qspo_int_reg[1]_i_1_n_0 ;
  wire \qspo_int_reg[1]_i_2_n_0 ;
  wire \qspo_int_reg[1]_i_3_n_0 ;
  wire \qspo_int_reg[2]_i_1_n_0 ;
  wire \qspo_int_reg[2]_i_2_n_0 ;
  wire \qspo_int_reg[2]_i_3_n_0 ;
  wire \qspo_int_reg[5]_i_1_n_0 ;
  wire \qspo_int_reg[5]_i_2_n_0 ;
  wire \qspo_int_reg[5]_i_3_n_0 ;
  wire \qspo_int_reg[6]_i_1_n_0 ;
  wire \qspo_int_reg[6]_i_2_n_0 ;
  wire \qspo_int_reg[6]_i_3_n_0 ;

  LUT6 #(
    .INIT(64'h0000200000000000)) 
    \qspo_int[0]_i_1 
       (.I0(a[5]),
        .I1(a[4]),
        .I2(\qspo_int[0]_i_2_n_0 ),
        .I3(a[2]),
        .I4(a[6]),
        .I5(a[7]),
        .O(\qspo_int[0]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h40)) 
    \qspo_int[0]_i_2 
       (.I0(a[1]),
        .I1(a[3]),
        .I2(a[0]),
        .O(\qspo_int[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0A08080014941C04)) 
    \qspo_int[1]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[0]),
        .I5(a[4]),
        .O(\qspo_int[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0105011566806000)) 
    \qspo_int[1]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[1]),
        .I3(a[3]),
        .I4(a[0]),
        .I5(a[2]),
        .O(\qspo_int[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00FD01CCCD20F300)) 
    \qspo_int[1]_i_6 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h07001400040030A0)) 
    \qspo_int[1]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[1]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h02024A8F2A080888)) 
    \qspo_int[2]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[4]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00001F40106780A0)) 
    \qspo_int[2]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000705000000D8C0)) 
    \qspo_int[2]_i_6 
       (.I0(a[6]),
        .I1(a[2]),
        .I2(a[4]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h003101450A404040)) 
    \qspo_int[2]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[0]),
        .I5(a[3]),
        .O(\qspo_int[2]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \qspo_int[3]_i_1 
       (.I0(\qspo_int[3]_i_2_n_0 ),
        .I1(\qspo_int[4]_i_3_n_0 ),
        .I2(a[7]),
        .I3(\qspo_int[3]_i_3_n_0 ),
        .I4(a[5]),
        .I5(\qspo_int[3]_i_4_n_0 ),
        .O(\qspo_int[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h006BFEB0000AB000)) 
    \qspo_int[3]_i_2 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[3]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00EF710000800000)) 
    \qspo_int[3]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0089F00002000020)) 
    \qspo_int[3]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \qspo_int[4]_i_1 
       (.I0(\qspo_int[4]_i_2_n_0 ),
        .I1(\qspo_int[4]_i_3_n_0 ),
        .I2(a[7]),
        .I3(\qspo_int[4]_i_4_n_0 ),
        .I4(a[5]),
        .I5(\qspo_int[4]_i_5_n_0 ),
        .O(\qspo_int[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00EF611000000010)) 
    \qspo_int[4]_i_2 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000F00F4010000)) 
    \qspo_int[4]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0809F8886F000000)) 
    \qspo_int[4]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h04CDF46006404440)) 
    \qspo_int[4]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0202C01520080080)) 
    \qspo_int[5]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[4]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h001D500000002220)) 
    \qspo_int[5]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[3]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0027CD0000005040)) 
    \qspo_int[5]_i_6 
       (.I0(a[6]),
        .I1(a[2]),
        .I2(a[4]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000F1E0F0110000)) 
    \qspo_int[5]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[5]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0048933B999C8000)) 
    \qspo_int[6]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[1]),
        .I4(a[2]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h012F053D62802200)) 
    \qspo_int[6]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[1]),
        .I3(a[3]),
        .I4(a[0]),
        .I5(a[2]),
        .O(\qspo_int[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00B98B88CD80FB00)) 
    \qspo_int[6]_i_6 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00FFFFFAFAC8FA00)) 
    \qspo_int[6]_i_7 
       (.I0(a[6]),
        .I1(a[0]),
        .I2(a[4]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hE200)) 
    \qspo_int[7]_i_1 
       (.I0(\qspo_int[7]_i_2_n_0 ),
        .I1(a[5]),
        .I2(\qspo_int[7]_i_3_n_0 ),
        .I3(a[7]),
        .O(\qspo_int[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0840502A00000000)) 
    \qspo_int[7]_i_2 
       (.I0(a[3]),
        .I1(a[0]),
        .I2(a[1]),
        .I3(a[2]),
        .I4(a[4]),
        .I5(a[6]),
        .O(\qspo_int[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000F00000E00000)) 
    \qspo_int[7]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[7]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[0]_i_1_n_0 ),
        .Q(qspo[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[1]_i_1_n_0 ),
        .Q(qspo[1]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[1]_i_1 
       (.I0(\qspo_int_reg[1]_i_2_n_0 ),
        .I1(\qspo_int_reg[1]_i_3_n_0 ),
        .O(\qspo_int_reg[1]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[1]_i_2 
       (.I0(\qspo_int[1]_i_4_n_0 ),
        .I1(\qspo_int[1]_i_5_n_0 ),
        .O(\qspo_int_reg[1]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[1]_i_3 
       (.I0(\qspo_int[1]_i_6_n_0 ),
        .I1(\qspo_int[1]_i_7_n_0 ),
        .O(\qspo_int_reg[1]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[2]_i_1_n_0 ),
        .Q(qspo[2]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[2]_i_1 
       (.I0(\qspo_int_reg[2]_i_2_n_0 ),
        .I1(\qspo_int_reg[2]_i_3_n_0 ),
        .O(\qspo_int_reg[2]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[2]_i_2 
       (.I0(\qspo_int[2]_i_4_n_0 ),
        .I1(\qspo_int[2]_i_5_n_0 ),
        .O(\qspo_int_reg[2]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[2]_i_3 
       (.I0(\qspo_int[2]_i_6_n_0 ),
        .I1(\qspo_int[2]_i_7_n_0 ),
        .O(\qspo_int_reg[2]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[3]_i_1_n_0 ),
        .Q(qspo[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[4]_i_1_n_0 ),
        .Q(qspo[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[5]_i_1_n_0 ),
        .Q(qspo[5]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[5]_i_1 
       (.I0(\qspo_int_reg[5]_i_2_n_0 ),
        .I1(\qspo_int_reg[5]_i_3_n_0 ),
        .O(\qspo_int_reg[5]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[5]_i_2 
       (.I0(\qspo_int[5]_i_4_n_0 ),
        .I1(\qspo_int[5]_i_5_n_0 ),
        .O(\qspo_int_reg[5]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[5]_i_3 
       (.I0(\qspo_int[5]_i_6_n_0 ),
        .I1(\qspo_int[5]_i_7_n_0 ),
        .O(\qspo_int_reg[5]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[6]_i_1_n_0 ),
        .Q(qspo[6]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[6]_i_1 
       (.I0(\qspo_int_reg[6]_i_2_n_0 ),
        .I1(\qspo_int_reg[6]_i_3_n_0 ),
        .O(\qspo_int_reg[6]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[6]_i_2 
       (.I0(\qspo_int[6]_i_4_n_0 ),
        .I1(\qspo_int[6]_i_5_n_0 ),
        .O(\qspo_int_reg[6]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[6]_i_3 
       (.I0(\qspo_int[6]_i_6_n_0 ),
        .I1(\qspo_int[6]_i_7_n_0 ),
        .O(\qspo_int_reg[6]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[7]_i_1_n_0 ),
        .Q(qspo[7]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
