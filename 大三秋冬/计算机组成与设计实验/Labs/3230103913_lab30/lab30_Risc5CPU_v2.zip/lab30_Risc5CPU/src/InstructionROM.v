module InstructionROM(addr,dout);
	input [5 : 0] addr;
	output [31 : 0] dout;
	reg [31 : 0] dout;
	always @(*)
		case (addr)
			// Initialization
			6'd0:  dout=32'h00000093; // addi x1, x0, 0      (Base Addr = 0)
			6'd1:  dout=32'h07800113; // addi x2, x0, 0x78   (x2 = 0x78)
			6'd2:  dout=32'h0000D1B7; // lui x3, 13          (x3 = 0xD000)
			6'd3:  dout=32'hCDD18193; // addi x3, x3, 0xCDD  (x3 = 0xCCDD)
			
			// Store Tests
			6'd4:  dout=32'h00208023; // sb x2, 0(x1)        (Mem[0] = 0x78)
			6'd5:  dout=32'h002080A3; // sb x2, 1(x1)        (Mem[1] = 0x78)
			6'd6:  dout=32'h00309123; // sh x3, 2(x1)        (Mem[2,3] = 0xCCDD)
			
			// Load Tests
			6'd7:  dout=32'h00008203; // lb x4, 0(x1)        (x4 = 0x00000078)
			6'd8:  dout=32'h00208283; // lb x5, 2(x1)        (x5 = 0xFFFFFFDD)
			6'd9:  dout=32'h0020C303; // lbu x6, 2(x1)       (x6 = 0x000000DD)
			6'd10: dout=32'h00209383; // lh x7, 2(x1)        (x7 = 0xFFFFCCDD)
			6'd11: dout=32'h0020D403; // lhu x8, 2(x1)       (x8 = 0x0000CCDD)
			6'd12: dout=32'h0000A483; // lw x9, 0(x1)        (x9 = 0xCCDD7878)
			
			// Halt
			6'd13: dout=32'h00000063; // beq x0, x0, 0       (Infinite Loop)
			
			default: dout=32'h00000000; // nop
		endcase	
endmodule
