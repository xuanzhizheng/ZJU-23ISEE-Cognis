`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: ID (Instruction Decode Stage)
// Function: Integrates Registers, Decode, Branch_test, Hazard_Detector modules
//////////////////////////////////////////////////////////////////////////////////
module ID(clk,Instruction_id, PC_id, RegWrite_wb, rdAddr_wb, RegWriteData_wb, MemRead_ex, 
          rdAddr_ex, MemtoReg_id, RegWrite_id, MemWrite_id, MemRead_id, ALUCode_id, 
			 ALUSrcA_id, ALUSrcB_id,  Stall, Branch, Jump, IFWrite,  JumpAddr, Imm_id,
			 rs1Data_id, rs2Data_id,rs1Addr_id,rs2Addr_id,rdAddr_id,funct3_id);
    input clk;
    input [31:0] Instruction_id;
    input [31:0] PC_id;
    input RegWrite_wb;
    input [4:0] rdAddr_wb;
    input [31:0] RegWriteData_wb;
    input MemRead_ex;
    input [4:0] rdAddr_ex;
    output MemtoReg_id;
    output RegWrite_id;
    output MemWrite_id;
    output MemRead_id;
    output [3:0] ALUCode_id;
    output ALUSrcA_id;
    output [1:0]ALUSrcB_id;
    output Stall;
    output Branch;
    output Jump;
    output IFWrite;
    output [31:0] JumpAddr;
    output [31:0] Imm_id;
    output [31:0] rs1Data_id;
    output [31:0] rs2Data_id;
	output[4:0] rs1Addr_id,rs2Addr_id,rdAddr_id;
	output [2:0] funct3_id;

//Internal wires
	wire JALR_w;
	wire [31:0] offset_w;

//Extract register addresses from instruction
	assign rs1Addr_id = Instruction_id[19:15];
	assign rs2Addr_id = Instruction_id[24:20];
	assign rdAddr_id  = Instruction_id[11:7];
	
//******************************************************************************
//  Module Instantiation
//******************************************************************************

//Registers module: Register file with RAW hazard forwarding
	Registers u_Registers (
		.clk(clk),
		.RegWrite_wb(RegWrite_wb),
		.rdAddr_wb(rdAddr_wb),
		.RegWriteData_wb(RegWriteData_wb),
		.rs1Addr_id(rs1Addr_id),
		.rs2Addr_id(rs2Addr_id),
		.rs1Data_id(rs1Data_id),
		.rs2Data_id(rs2Data_id)
	);

//Decode module: Instruction decode and control signal generation
	Decode u_Decode (
		.Instruction(Instruction_id),
		.MemtoReg(MemtoReg_id),
		.RegWrite(RegWrite_id),
		.MemWrite(MemWrite_id),
		.MemRead(MemRead_id),
		.ALUCode(ALUCode_id),
		.ALUSrcA(ALUSrcA_id),
		.ALUSrcB(ALUSrcB_id),
		.Jump(Jump),
		.JALR(JALR_w),
		.Imm(Imm_id),
		.offset(offset_w)
	);

    // Extract funct3 directly from instruction for load/store width handling
    assign funct3_id = Instruction_id[14:12];

//Branch_test module: Branch condition evaluation
	Branch_test u_Branch_test (
		.rs1Data_id(rs1Data_id),
		.rs2Data_id(rs2Data_id),
		.Instruction_id(Instruction_id),
		.Branch(Branch)
	);

//Hazard_Detector module: Load-use hazard detection and stall generation
	Hazard_Detector u_Hazard_Detector (
		.MemRead_ex(MemRead_ex),
		.rdAddr_ex(rdAddr_ex),
		.rs1Addr_id(rs1Addr_id),
		.rs2Addr_id(rs2Addr_id),
		.Stall(Stall),
		.IFWrite(IFWrite)
	);
	
//******************************************************************************
//  Jump address calculation
//******************************************************************************
	assign JumpAddr = (JALR_w==1) ? (rs1Data_id + offset_w) : (PC_id + offset_w);

endmodule
