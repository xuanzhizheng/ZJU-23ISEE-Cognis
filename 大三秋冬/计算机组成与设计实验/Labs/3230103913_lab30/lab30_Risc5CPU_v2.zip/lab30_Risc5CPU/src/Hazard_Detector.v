`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: Hazard_Detector
// Function: Load-use hazard detection (ID/EX hazard)
//////////////////////////////////////////////////////////////////////////////////
module Hazard_Detector(
    input MemRead_ex,
    input [4:0] rdAddr_ex,
    input [4:0] rs1Addr_id,
    input [4:0] rs2Addr_id,
    output Stall,
    output IFWrite
);

//Load-use hazard detection logic
    assign Stall = MemRead_ex && (rdAddr_ex != 5'b0) && 
                   ( (rdAddr_ex == rs1Addr_id) || (rdAddr_ex == rs2Addr_id) );
    
//Pipeline stall control signal
    assign IFWrite = ~Stall;

endmodule

