// Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
// Date        : Sat Nov 22 20:21:15 2025
// Host        : LAPTOP-V15JOVGD running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               C:/Users/zzx/Desktop/SourceProgram/lab30_Risc5CPU/vivado201701/Risc5CPU.sim/sim_1/impl/timing/xsim/Risc5CPU_tb_v_time_impl.v
// Design      : PipelineCPUTest
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module RAM32M_UNIQ_BASE_
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD32
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD33
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD34
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD35
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD36
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD37
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD38
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD39
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD40
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD41
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM32M_HD42
   (DOA,
    DOB,
    DOC,
    DOD,
    ADDRA,
    ADDRB,
    ADDRC,
    ADDRD,
    DIA,
    DIB,
    DIC,
    DID,
    WCLK,
    WE);
  output [1:0]DOA;
  output [1:0]DOB;
  output [1:0]DOC;
  output [1:0]DOD;
  input [4:0]ADDRA;
  input [4:0]ADDRB;
  input [4:0]ADDRC;
  input [4:0]ADDRD;
  input [1:0]DIA;
  input [1:0]DIB;
  input [1:0]DIC;
  input [1:0]DID;
  input WCLK;
  input WE;

  wire ADDRA0;
  wire ADDRA1;
  wire ADDRA2;
  wire ADDRA3;
  wire ADDRA4;
  wire ADDRB0;
  wire ADDRB1;
  wire ADDRB2;
  wire ADDRB3;
  wire ADDRB4;
  wire ADDRC0;
  wire ADDRC1;
  wire ADDRC2;
  wire ADDRC3;
  wire ADDRC4;
  wire ADDRD0;
  wire ADDRD1;
  wire ADDRD2;
  wire ADDRD3;
  wire ADDRD4;
  wire DIA0;
  wire DIA1;
  wire DIB0;
  wire DIB1;
  wire DIC0;
  wire DIC1;
  wire DID0;
  wire DID1;
  wire DOA0;
  wire DOA1;
  wire DOB0;
  wire DOB1;
  wire DOC0;
  wire DOC1;
  wire DOD0;
  wire DOD1;
  wire WCLK;
  wire WE;

  assign ADDRA0 = ADDRA[0];
  assign ADDRA1 = ADDRA[1];
  assign ADDRA2 = ADDRA[2];
  assign ADDRA3 = ADDRA[3];
  assign ADDRA4 = ADDRA[4];
  assign ADDRB0 = ADDRB[0];
  assign ADDRB1 = ADDRB[1];
  assign ADDRB2 = ADDRB[2];
  assign ADDRB3 = ADDRB[3];
  assign ADDRB4 = ADDRB[4];
  assign ADDRC0 = ADDRC[0];
  assign ADDRC1 = ADDRC[1];
  assign ADDRC2 = ADDRC[2];
  assign ADDRC3 = ADDRC[3];
  assign ADDRC4 = ADDRC[4];
  assign ADDRD0 = ADDRD[0];
  assign ADDRD1 = ADDRD[1];
  assign ADDRD2 = ADDRD[2];
  assign ADDRD3 = ADDRD[3];
  assign ADDRD4 = ADDRD[4];
  assign DIA0 = DIA[0];
  assign DIA1 = DIA[1];
  assign DIB0 = DIB[0];
  assign DIB1 = DIB[1];
  assign DIC0 = DIC[0];
  assign DIC1 = DIC[1];
  assign DID0 = DID[0];
  assign DID1 = DID[1];
  assign DOA[1] = DOA1;
  assign DOA[0] = DOA0;
  assign DOB[1] = DOB1;
  assign DOB[0] = DOB0;
  assign DOC[1] = DOC1;
  assign DOC[0] = DOC0;
  assign DOD[1] = DOD1;
  assign DOD[0] = DOD0;
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA
       (.CLK(WCLK),
        .I(DIA0),
        .O(DOA0),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMA_D1
       (.CLK(WCLK),
        .I(DIA1),
        .O(DOA1),
        .RADR0(ADDRA0),
        .RADR1(ADDRA1),
        .RADR2(ADDRA2),
        .RADR3(ADDRA3),
        .RADR4(ADDRA4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB
       (.CLK(WCLK),
        .I(DIB0),
        .O(DOB0),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMB_D1
       (.CLK(WCLK),
        .I(DIB1),
        .O(DOB1),
        .RADR0(ADDRB0),
        .RADR1(ADDRB1),
        .RADR2(ADDRB2),
        .RADR3(ADDRB3),
        .RADR4(ADDRB4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC
       (.CLK(WCLK),
        .I(DIC0),
        .O(DOC0),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMD32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMC_D1
       (.CLK(WCLK),
        .I(DIC1),
        .O(DOC1),
        .RADR0(ADDRC0),
        .RADR1(ADDRC1),
        .RADR2(ADDRC2),
        .RADR3(ADDRC3),
        .RADR4(ADDRC4),
        .WADR0(ADDRD0),
        .WADR1(ADDRD1),
        .WADR2(ADDRD2),
        .WADR3(ADDRD3),
        .WADR4(ADDRD4),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID0),
        .O(DOD0),
        .WE(WE));
  RAMS32 #(
    .INIT(32'h00000000),
    .IS_CLK_INVERTED(1'b0)) 
    RAMD_D1
       (.ADR0(ADDRD0),
        .ADR1(ADDRD1),
        .ADR2(ADDRD2),
        .ADR3(ADDRD3),
        .ADR4(ADDRD4),
        .CLK(WCLK),
        .I(DID1),
        .O(DOD1),
        .WE(WE));
endmodule

module RAM64X1S_UNIQ_BASE_
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD1
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD10
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD11
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD12
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD13
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD14
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD15
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD16
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD17
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD18
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD19
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD2
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD20
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD21
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD22
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD23
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD24
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD25
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD26
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD27
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD28
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD29
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD3
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD30
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD31
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD4
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD5
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD6
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD7
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD8
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD9
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module DCM_PLL
   (clk_out1,
    clk_out2,
    reset,
    locked,
    clk_in1,
    lopt);
  output clk_out1;
  output clk_out2;
  input reset;
  output locked;
  input clk_in1;
  output lopt;

  wire clk_in1;
  wire clk_out1;
  wire clk_out2;
  wire lopt;
  wire reset;
  wire NLW_inst_locked_UNCONNECTED;

  DCM_PLL_DCM_PLL_clk_wiz inst
       (.clk_in1(clk_in1),
        .clk_out1(clk_out1),
        .clk_out2(clk_out2),
        .locked(NLW_inst_locked_UNCONNECTED),
        .lopt(lopt),
        .reset(reset));
endmodule

(* ORIG_REF_NAME = "DCM_PLL_clk_wiz" *) 
module DCM_PLL_DCM_PLL_clk_wiz
   (clk_out1,
    clk_out2,
    reset,
    locked,
    clk_in1,
    lopt);
  output clk_out1;
  output clk_out2;
  input reset;
  output locked;
  input clk_in1;
  output lopt;

  wire clk_in1;
  wire clk_in1_DCM_PLL;
  wire clk_out1;
  wire clk_out1_DCM_PLL;
  wire clk_out2_DCM_PLL;
  wire clkfbout_DCM_PLL;
  wire clkfbout_buf_DCM_PLL;
  wire reset;
  wire NLW_mmcm_adv_inst_CLKFBOUTB_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKFBSTOPPED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKINSTOPPED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT0B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT1B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT2_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT2B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT3_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT3B_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT4_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT5_UNCONNECTED;
  wire NLW_mmcm_adv_inst_CLKOUT6_UNCONNECTED;
  wire NLW_mmcm_adv_inst_DRDY_UNCONNECTED;
  wire NLW_mmcm_adv_inst_LOCKED_UNCONNECTED;
  wire NLW_mmcm_adv_inst_PSDONE_UNCONNECTED;
  wire [15:0]NLW_mmcm_adv_inst_DO_UNCONNECTED;

  assign clk_out2 = clk_out2_DCM_PLL;
  assign lopt = clk_out1;
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG clkf_buf
       (.I(clkfbout_DCM_PLL),
        .O(clkfbout_buf_DCM_PLL));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* IBUF_DELAY_VALUE = "0" *) 
  (* IFD_DELAY_VALUE = "AUTO" *) 
  IBUF #(
    .IOSTANDARD("DEFAULT")) 
    clkin1_ibufg
       (.I(clk_in1),
        .O(clk_in1_DCM_PLL));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG clkout1_buf
       (.I(clk_out1_DCM_PLL),
        .O(clk_out1));
  (* BOX_TYPE = "PRIMITIVE" *) 
  MMCME2_ADV #(
    .BANDWIDTH("OPTIMIZED"),
    .CLKFBOUT_MULT_F(10.000000),
    .CLKFBOUT_PHASE(0.000000),
    .CLKFBOUT_USE_FINE_PS("FALSE"),
    .CLKIN1_PERIOD(10.000000),
    .CLKIN2_PERIOD(0.000000),
    .CLKOUT0_DIVIDE_F(40.000000),
    .CLKOUT0_DUTY_CYCLE(0.500000),
    .CLKOUT0_PHASE(0.000000),
    .CLKOUT0_USE_FINE_PS("FALSE"),
    .CLKOUT1_DIVIDE(4),
    .CLKOUT1_DUTY_CYCLE(0.500000),
    .CLKOUT1_PHASE(0.000000),
    .CLKOUT1_USE_FINE_PS("FALSE"),
    .CLKOUT2_DIVIDE(1),
    .CLKOUT2_DUTY_CYCLE(0.500000),
    .CLKOUT2_PHASE(0.000000),
    .CLKOUT2_USE_FINE_PS("FALSE"),
    .CLKOUT3_DIVIDE(1),
    .CLKOUT3_DUTY_CYCLE(0.500000),
    .CLKOUT3_PHASE(0.000000),
    .CLKOUT3_USE_FINE_PS("FALSE"),
    .CLKOUT4_CASCADE("FALSE"),
    .CLKOUT4_DIVIDE(1),
    .CLKOUT4_DUTY_CYCLE(0.500000),
    .CLKOUT4_PHASE(0.000000),
    .CLKOUT4_USE_FINE_PS("FALSE"),
    .CLKOUT5_DIVIDE(1),
    .CLKOUT5_DUTY_CYCLE(0.500000),
    .CLKOUT5_PHASE(0.000000),
    .CLKOUT5_USE_FINE_PS("FALSE"),
    .CLKOUT6_DIVIDE(1),
    .CLKOUT6_DUTY_CYCLE(0.500000),
    .CLKOUT6_PHASE(0.000000),
    .CLKOUT6_USE_FINE_PS("FALSE"),
    .COMPENSATION("ZHOLD"),
    .DIVCLK_DIVIDE(1),
    .IS_CLKINSEL_INVERTED(1'b0),
    .IS_PSEN_INVERTED(1'b0),
    .IS_PSINCDEC_INVERTED(1'b0),
    .IS_PWRDWN_INVERTED(1'b0),
    .IS_RST_INVERTED(1'b0),
    .REF_JITTER1(0.010000),
    .REF_JITTER2(0.010000),
    .SS_EN("FALSE"),
    .SS_MODE("CENTER_HIGH"),
    .SS_MOD_PERIOD(10000),
    .STARTUP_WAIT("FALSE")) 
    mmcm_adv_inst
       (.CLKFBIN(clkfbout_buf_DCM_PLL),
        .CLKFBOUT(clkfbout_DCM_PLL),
        .CLKFBOUTB(NLW_mmcm_adv_inst_CLKFBOUTB_UNCONNECTED),
        .CLKFBSTOPPED(NLW_mmcm_adv_inst_CLKFBSTOPPED_UNCONNECTED),
        .CLKIN1(clk_in1_DCM_PLL),
        .CLKIN2(1'b0),
        .CLKINSEL(1'b1),
        .CLKINSTOPPED(NLW_mmcm_adv_inst_CLKINSTOPPED_UNCONNECTED),
        .CLKOUT0(clk_out1_DCM_PLL),
        .CLKOUT0B(NLW_mmcm_adv_inst_CLKOUT0B_UNCONNECTED),
        .CLKOUT1(clk_out2_DCM_PLL),
        .CLKOUT1B(NLW_mmcm_adv_inst_CLKOUT1B_UNCONNECTED),
        .CLKOUT2(NLW_mmcm_adv_inst_CLKOUT2_UNCONNECTED),
        .CLKOUT2B(NLW_mmcm_adv_inst_CLKOUT2B_UNCONNECTED),
        .CLKOUT3(NLW_mmcm_adv_inst_CLKOUT3_UNCONNECTED),
        .CLKOUT3B(NLW_mmcm_adv_inst_CLKOUT3B_UNCONNECTED),
        .CLKOUT4(NLW_mmcm_adv_inst_CLKOUT4_UNCONNECTED),
        .CLKOUT5(NLW_mmcm_adv_inst_CLKOUT5_UNCONNECTED),
        .CLKOUT6(NLW_mmcm_adv_inst_CLKOUT6_UNCONNECTED),
        .DADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DCLK(1'b0),
        .DEN(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DO(NLW_mmcm_adv_inst_DO_UNCONNECTED[15:0]),
        .DRDY(NLW_mmcm_adv_inst_DRDY_UNCONNECTED),
        .DWE(1'b0),
        .LOCKED(NLW_mmcm_adv_inst_LOCKED_UNCONNECTED),
        .PSCLK(1'b0),
        .PSDONE(NLW_mmcm_adv_inst_PSDONE_UNCONNECTED),
        .PSEN(1'b0),
        .PSINCDEC(1'b0),
        .PWRDWN(1'b0),
        .RST(reset));
endmodule

module DFF
   (\TMDSn[2] ,
    \q_reg[155] ,
    Q,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \PC_reg_reg[28] ,
    JumpAddr,
    w_IF_flush,
    \PC_reg_reg[8] ,
    \q_reg[85] ,
    \q_reg[78] ,
    \PosX_reg_reg[5] ,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[6] ,
    \q_reg[23]_0 ,
    \PosX_reg_reg[4]_2 ,
    c2__0,
    D,
    c3__0,
    c4__0,
    c5__0,
    c6__0,
    c7__0,
    \q_reg[68] ,
    \q_reg[70] ,
    w_RegWriteData_wb,
    \q_reg[15]_0 ,
    ReadData10,
    \q_reg[69] ,
    SR,
    E,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [70:0]\q_reg[155] ;
  output [2:0]Q;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output [9:0]\PC_reg_reg[28] ;
  output [21:0]JumpAddr;
  output w_IF_flush;
  output [0:0]\PC_reg_reg[8] ;
  output \q_reg[85] ;
  output \q_reg[78] ;
  input \PosX_reg_reg[5] ;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[6] ;
  input \q_reg[23]_0 ;
  input \PosX_reg_reg[4]_2 ;
  input c2__0;
  input [49:0]D;
  input c3__0;
  input c4__0;
  input c5__0;
  input c6__0;
  input c7__0;
  input \q_reg[68] ;
  input [30:0]\q_reg[70] ;
  input [1:0]w_RegWriteData_wb;
  input \q_reg[15]_0 ;
  input [1:0]ReadData10;
  input \q_reg[69] ;
  input [0:0]SR;
  input [0:0]E;
  input cpu_clk_BUFG;

  wire [49:0]D;
  wire [0:0]E;
  wire [6:2]Instruction_id;
  wire [21:0]JumpAddr;
  wire \PC_reg[11]_i_10_n_0 ;
  wire \PC_reg[11]_i_6_n_0 ;
  wire \PC_reg[11]_i_7_n_0 ;
  wire \PC_reg[15]_i_5_n_0 ;
  wire \PC_reg[15]_i_6_n_0 ;
  wire \PC_reg[15]_i_7_n_0 ;
  wire \PC_reg[15]_i_8_n_0 ;
  wire \PC_reg[19]_i_5_n_0 ;
  wire \PC_reg[19]_i_6_n_0 ;
  wire \PC_reg[19]_i_7_n_0 ;
  wire \PC_reg[19]_i_8_n_0 ;
  wire \PC_reg[23]_i_5_n_0 ;
  wire \PC_reg[23]_i_6_n_0 ;
  wire \PC_reg[23]_i_7_n_0 ;
  wire \PC_reg[23]_i_8_n_0 ;
  wire \PC_reg[27]_i_5_n_0 ;
  wire \PC_reg[27]_i_6_n_0 ;
  wire \PC_reg[27]_i_7_n_0 ;
  wire \PC_reg[27]_i_8_n_0 ;
  wire \PC_reg[31]_i_12_n_0 ;
  wire \PC_reg[31]_i_13_n_0 ;
  wire \PC_reg[31]_i_14_n_0 ;
  wire \PC_reg[31]_i_15_n_0 ;
  wire \PC_reg[31]_i_17_n_0 ;
  wire \PC_reg[31]_i_18_n_0 ;
  wire \PC_reg[3]_i_10_n_0 ;
  wire \PC_reg[3]_i_7_n_0 ;
  wire \PC_reg[3]_i_8_n_0 ;
  wire \PC_reg[3]_i_9_n_0 ;
  wire \PC_reg[7]_i_10_n_0 ;
  wire \PC_reg[7]_i_11_n_0 ;
  wire \PC_reg[7]_i_7_n_0 ;
  wire \PC_reg[7]_i_8_n_0 ;
  wire \PC_reg[7]_i_9_n_0 ;
  wire \PC_reg_reg[11]_i_2_n_0 ;
  wire \PC_reg_reg[15]_i_2_n_0 ;
  wire \PC_reg_reg[19]_i_2_n_0 ;
  wire \PC_reg_reg[23]_i_2_n_0 ;
  wire \PC_reg_reg[27]_i_2_n_0 ;
  wire [9:0]\PC_reg_reg[28] ;
  wire \PC_reg_reg[3]_i_2_n_0 ;
  wire \PC_reg_reg[7]_i_2_n_0 ;
  wire [0:0]\PC_reg_reg[8] ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[5] ;
  wire \PosX_reg_reg[6] ;
  wire [2:0]Q;
  wire [1:0]ReadData10;
  wire [0:0]SR;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire c2__0;
  wire c3__0;
  wire c4__0;
  wire c5__0;
  wire c6__0;
  wire c7__0;
  wire char_tab_i_43_n_0;
  wire char_tab_i_79_n_0;
  wire cpu_clk_BUFG;
  wire \q[120]_i_2_n_0 ;
  wire \q[130]_i_2_n_0 ;
  wire \q[139]_i_2_n_0 ;
  wire \q[139]_i_3_n_0 ;
  wire \q[139]_i_4_n_0 ;
  wire \q[149]_i_2_n_0 ;
  wire \q[150]_i_2_n_0 ;
  wire \q[152]_i_2_n_0 ;
  wire \q[63]_i_1__1_n_0 ;
  wire [70:0]\q_reg[155] ;
  wire \q_reg[15]_0 ;
  wire \q_reg[23]_0 ;
  wire \q_reg[68] ;
  wire \q_reg[69] ;
  wire [30:0]\q_reg[70] ;
  wire \q_reg[78] ;
  wire \q_reg[85] ;
  wire [11:0]\u_ID/offset_w ;
  wire [9:8]\u_ID/p_0_in ;
  wire w_IF_flush;
  wire [28:0]w_JumpAddr;
  wire [1:0]w_RegWriteData_wb;
  wire [2:0]\NLW_PC_reg_reg[11]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[15]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[19]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[23]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[27]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_PC_reg_reg[31]_i_4_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[3]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_PC_reg_reg[7]_i_2_CO_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \PC_reg[0]_i_1 
       (.I0(w_JumpAddr[0]),
        .I1(w_IF_flush),
        .I2(D[18]),
        .O(\PC_reg_reg[28] [0]));
  LUT4 #(
    .INIT(16'hFF7F)) 
    \PC_reg[11]_i_10 
       (.I0(Instruction_id[5]),
        .I1(Q[0]),
        .I2(Instruction_id[6]),
        .I3(Q[1]),
        .O(\PC_reg[11]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h0B08)) 
    \PC_reg[11]_i_5 
       (.I0(\q_reg[155] [43]),
        .I1(Instruction_id[2]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(\q_reg[155] [35]),
        .O(\u_ID/offset_w [11]));
  LUT6 #(
    .INIT(64'hF033F05AF0CCF05A)) 
    \PC_reg[11]_i_6 
       (.I0(\q_reg[155] [35]),
        .I1(\q_reg[155] [43]),
        .I2(\q_reg[155] [14]),
        .I3(\PC_reg[11]_i_10_n_0 ),
        .I4(Instruction_id[2]),
        .I5(\q_reg[70] [10]),
        .O(\PC_reg[11]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[11]_i_7 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [13]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [9]),
        .O(\PC_reg[11]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h88B8FFFF88B80000)) 
    \PC_reg[11]_i_8 
       (.I0(w_RegWriteData_wb[1]),
        .I1(\q_reg[15]_0 ),
        .I2(ReadData10[1]),
        .I3(\q_reg[85] ),
        .I4(\q_reg[155] [62]),
        .I5(\q_reg[155] [12]),
        .O(\u_ID/p_0_in [9]));
  LUT6 #(
    .INIT(64'h88B8FFFF88B80000)) 
    \PC_reg[11]_i_9 
       (.I0(w_RegWriteData_wb[0]),
        .I1(\q_reg[15]_0 ),
        .I2(ReadData10[0]),
        .I3(\q_reg[85] ),
        .I4(\q_reg[155] [62]),
        .I5(\q_reg[155] [11]),
        .O(\u_ID/p_0_in [8]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[12]_i_1 
       (.I0(w_JumpAddr[12]),
        .I1(w_IF_flush),
        .I2(c3__0),
        .I3(D[30]),
        .O(\PC_reg_reg[28] [5]));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[15]_i_5 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [18]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [14]),
        .O(\PC_reg[15]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[15]_i_6 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [17]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [13]),
        .O(\PC_reg[15]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[15]_i_7 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [16]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [12]),
        .O(\PC_reg[15]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[15]_i_8 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [15]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [11]),
        .O(\PC_reg[15]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[16]_i_1 
       (.I0(w_JumpAddr[16]),
        .I1(w_IF_flush),
        .I2(c4__0),
        .I3(D[34]),
        .O(\PC_reg_reg[28] [6]));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[19]_i_5 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [22]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [18]),
        .O(\PC_reg[19]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[19]_i_6 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [21]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [17]),
        .O(\PC_reg[19]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[19]_i_7 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [20]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [16]),
        .O(\PC_reg[19]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[19]_i_8 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [19]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [15]),
        .O(\PC_reg[19]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \PC_reg[1]_i_1 
       (.I0(w_JumpAddr[1]),
        .I1(w_IF_flush),
        .I2(D[19]),
        .O(\PC_reg_reg[28] [1]));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[20]_i_1 
       (.I0(w_JumpAddr[20]),
        .I1(w_IF_flush),
        .I2(c5__0),
        .I3(D[38]),
        .O(\PC_reg_reg[28] [7]));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[23]_i_5 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [26]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [22]),
        .O(\PC_reg[23]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[23]_i_6 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [25]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [21]),
        .O(\PC_reg[23]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[23]_i_7 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [24]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [20]),
        .O(\PC_reg[23]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[23]_i_8 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [23]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [19]),
        .O(\PC_reg[23]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[24]_i_1 
       (.I0(w_JumpAddr[24]),
        .I1(w_IF_flush),
        .I2(c6__0),
        .I3(D[42]),
        .O(\PC_reg_reg[28] [8]));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[27]_i_5 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [30]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [26]),
        .O(\PC_reg[27]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[27]_i_6 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [29]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [25]),
        .O(\PC_reg[27]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[27]_i_7 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [28]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [24]),
        .O(\PC_reg[27]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[27]_i_8 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [27]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [23]),
        .O(\PC_reg[27]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[28]_i_1 
       (.I0(w_JumpAddr[28]),
        .I1(w_IF_flush),
        .I2(c7__0),
        .I3(D[46]),
        .O(\PC_reg_reg[28] [9]));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT3 #(
    .INIT(8'h8B)) 
    \PC_reg[2]_i_1 
       (.I0(w_JumpAddr[2]),
        .I1(w_IF_flush),
        .I2(D[20]),
        .O(\PC_reg_reg[28] [2]));
  LUT5 #(
    .INIT(32'h20000000)) 
    \PC_reg[31]_i_11 
       (.I0(\q_reg[155] [43]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Q[0]),
        .I4(Instruction_id[5]),
        .O(\u_ID/offset_w [7]));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[31]_i_12 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [34]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [30]),
        .O(\PC_reg[31]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[31]_i_13 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [33]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [29]),
        .O(\PC_reg[31]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[31]_i_14 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [32]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [28]),
        .O(\PC_reg[31]_i_14_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[31]_i_15 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [31]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [27]),
        .O(\PC_reg[31]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h222222A22222222A)) 
    \PC_reg[31]_i_16 
       (.I0(\PC_reg[31]_i_17_n_0 ),
        .I1(\PC_reg[31]_i_18_n_0 ),
        .I2(\q_reg[155] [0]),
        .I3(\q_reg[155] [1]),
        .I4(\q_reg[155] [2]),
        .I5(\q_reg[68] ),
        .O(\PC_reg_reg[8] ));
  LUT5 #(
    .INIT(32'h10000000)) 
    \PC_reg[31]_i_17 
       (.I0(Instruction_id[2]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Q[0]),
        .I4(Instruction_id[5]),
        .O(\PC_reg[31]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h99A9FFFF9A99FFFF)) 
    \PC_reg[31]_i_18 
       (.I0(\q_reg[155] [0]),
        .I1(\q_reg[69] ),
        .I2(\q_reg[70] [0]),
        .I3(\q_reg[70] [30]),
        .I4(\q_reg[155] [2]),
        .I5(\q_reg[155] [1]),
        .O(\PC_reg[31]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAEAAAAAAAAAAA)) 
    \PC_reg[31]_i_5 
       (.I0(\PC_reg_reg[8] ),
        .I1(Instruction_id[5]),
        .I2(Q[0]),
        .I3(Instruction_id[6]),
        .I4(Q[1]),
        .I5(Instruction_id[2]),
        .O(w_IF_flush));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[3]_i_1 
       (.I0(w_JumpAddr[3]),
        .I1(w_IF_flush),
        .I2(D[21]),
        .I3(D[20]),
        .O(\PC_reg_reg[28] [3]));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \PC_reg[3]_i_10 
       (.I0(\q_reg[155] [39]),
        .I1(\q_reg[155] [3]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [1]),
        .O(\PC_reg[3]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h0B08)) 
    \PC_reg[3]_i_3 
       (.I0(\q_reg[155] [41]),
        .I1(Instruction_id[2]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(\q_reg[155] [38]),
        .O(\u_ID/offset_w [3]));
  LUT4 #(
    .INIT(16'h0B08)) 
    \PC_reg[3]_i_4 
       (.I0(\q_reg[155] [43]),
        .I1(Instruction_id[2]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(\q_reg[155] [37]),
        .O(\u_ID/offset_w [2]));
  LUT4 #(
    .INIT(16'h0E02)) 
    \PC_reg[3]_i_5 
       (.I0(\q_reg[155] [36]),
        .I1(Instruction_id[2]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(\q_reg[155] [40]),
        .O(\u_ID/offset_w [1]));
  LUT6 #(
    .INIT(64'h0000800000000000)) 
    \PC_reg[3]_i_6 
       (.I0(\q_reg[155] [39]),
        .I1(Instruction_id[5]),
        .I2(Q[0]),
        .I3(Instruction_id[6]),
        .I4(Q[1]),
        .I5(Instruction_id[2]),
        .O(\u_ID/offset_w [0]));
  LUT6 #(
    .INIT(64'hF033F05AF0CCF05A)) 
    \PC_reg[3]_i_7 
       (.I0(\q_reg[155] [38]),
        .I1(\q_reg[155] [41]),
        .I2(\q_reg[155] [6]),
        .I3(\PC_reg[11]_i_10_n_0 ),
        .I4(Instruction_id[2]),
        .I5(\q_reg[70] [4]),
        .O(\PC_reg[3]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hF033F05AF0CCF05A)) 
    \PC_reg[3]_i_8 
       (.I0(\q_reg[155] [37]),
        .I1(\q_reg[155] [43]),
        .I2(\q_reg[155] [5]),
        .I3(\PC_reg[11]_i_10_n_0 ),
        .I4(Instruction_id[2]),
        .I5(\q_reg[70] [3]),
        .O(\PC_reg[3]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hF055F03CF0AAF03C)) 
    \PC_reg[3]_i_9 
       (.I0(\q_reg[155] [40]),
        .I1(\q_reg[155] [36]),
        .I2(\q_reg[155] [4]),
        .I3(\PC_reg[11]_i_10_n_0 ),
        .I4(Instruction_id[2]),
        .I5(\q_reg[70] [2]),
        .O(\PC_reg[3]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hC5C6CAC6)) 
    \PC_reg[7]_i_10 
       (.I0(Q[2]),
        .I1(\q_reg[155] [8]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(Instruction_id[2]),
        .I4(\q_reg[70] [6]),
        .O(\PC_reg[7]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \PC_reg[7]_i_11 
       (.I0(\q_reg[155] [41]),
        .I1(\q_reg[155] [7]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [5]),
        .O(\PC_reg[7]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h20000000)) 
    \PC_reg[7]_i_5 
       (.I0(\q_reg[155] [41]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Q[0]),
        .I4(Instruction_id[5]),
        .O(\u_ID/offset_w [6]));
  LUT5 #(
    .INIT(32'h20000000)) 
    \PC_reg[7]_i_6 
       (.I0(Q[2]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Q[0]),
        .I4(Instruction_id[5]),
        .O(\u_ID/offset_w [5]));
  LUT6 #(
    .INIT(64'h0080000000000000)) 
    \PC_reg[7]_i_7 
       (.I0(Instruction_id[5]),
        .I1(Q[0]),
        .I2(Instruction_id[6]),
        .I3(Q[1]),
        .I4(Instruction_id[2]),
        .I5(\q_reg[155] [41]),
        .O(\PC_reg[7]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \PC_reg[7]_i_8 
       (.I0(\u_ID/offset_w [7]),
        .I1(\q_reg[155] [10]),
        .I2(\q_reg[155] [62]),
        .I3(\q_reg[70] [8]),
        .O(\PC_reg[7]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hC5C6CAC6)) 
    \PC_reg[7]_i_9 
       (.I0(\q_reg[155] [41]),
        .I1(\q_reg[155] [9]),
        .I2(\PC_reg[11]_i_10_n_0 ),
        .I3(Instruction_id[2]),
        .I4(\q_reg[70] [7]),
        .O(\PC_reg[7]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'h8BB8)) 
    \PC_reg[8]_i_1 
       (.I0(w_JumpAddr[8]),
        .I1(w_IF_flush),
        .I2(c2__0),
        .I3(D[26]),
        .O(\PC_reg_reg[28] [4]));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[11]_i_2 
       (.CI(\PC_reg_reg[7]_i_2_n_0 ),
        .CO({\PC_reg_reg[11]_i_2_n_0 ,\NLW_PC_reg_reg[11]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [11],\u_ID/offset_w [7],1'b0,1'b0}),
        .O({JumpAddr[6:4],w_JumpAddr[8]}),
        .S({\PC_reg[11]_i_6_n_0 ,\PC_reg[11]_i_7_n_0 ,\u_ID/p_0_in }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[15]_i_2 
       (.CI(\PC_reg_reg[11]_i_2_n_0 ),
        .CO({\PC_reg_reg[15]_i_2_n_0 ,\NLW_PC_reg_reg[15]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7]}),
        .O({JumpAddr[9:7],w_JumpAddr[12]}),
        .S({\PC_reg[15]_i_5_n_0 ,\PC_reg[15]_i_6_n_0 ,\PC_reg[15]_i_7_n_0 ,\PC_reg[15]_i_8_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[19]_i_2 
       (.CI(\PC_reg_reg[15]_i_2_n_0 ),
        .CO({\PC_reg_reg[19]_i_2_n_0 ,\NLW_PC_reg_reg[19]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7]}),
        .O({JumpAddr[12:10],w_JumpAddr[16]}),
        .S({\PC_reg[19]_i_5_n_0 ,\PC_reg[19]_i_6_n_0 ,\PC_reg[19]_i_7_n_0 ,\PC_reg[19]_i_8_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[23]_i_2 
       (.CI(\PC_reg_reg[19]_i_2_n_0 ),
        .CO({\PC_reg_reg[23]_i_2_n_0 ,\NLW_PC_reg_reg[23]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7]}),
        .O({JumpAddr[15:13],w_JumpAddr[20]}),
        .S({\PC_reg[23]_i_5_n_0 ,\PC_reg[23]_i_6_n_0 ,\PC_reg[23]_i_7_n_0 ,\PC_reg[23]_i_8_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[27]_i_2 
       (.CI(\PC_reg_reg[23]_i_2_n_0 ),
        .CO({\PC_reg_reg[27]_i_2_n_0 ,\NLW_PC_reg_reg[27]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7]}),
        .O({JumpAddr[18:16],w_JumpAddr[24]}),
        .S({\PC_reg[27]_i_5_n_0 ,\PC_reg[27]_i_6_n_0 ,\PC_reg[27]_i_7_n_0 ,\PC_reg[27]_i_8_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[31]_i_4 
       (.CI(\PC_reg_reg[27]_i_2_n_0 ),
        .CO(\NLW_PC_reg_reg[31]_i_4_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,\u_ID/offset_w [7],\u_ID/offset_w [7],\u_ID/offset_w [7]}),
        .O({JumpAddr[21:19],w_JumpAddr[28]}),
        .S({\PC_reg[31]_i_12_n_0 ,\PC_reg[31]_i_13_n_0 ,\PC_reg[31]_i_14_n_0 ,\PC_reg[31]_i_15_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[3]_i_2 
       (.CI(1'b0),
        .CO({\PC_reg_reg[3]_i_2_n_0 ,\NLW_PC_reg_reg[3]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(\u_ID/offset_w [3:0]),
        .O(w_JumpAddr[3:0]),
        .S({\PC_reg[3]_i_7_n_0 ,\PC_reg[3]_i_8_n_0 ,\PC_reg[3]_i_9_n_0 ,\PC_reg[3]_i_10_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \PC_reg_reg[7]_i_2 
       (.CI(\PC_reg_reg[3]_i_2_n_0 ),
        .CO({\PC_reg_reg[7]_i_2_n_0 ,\NLW_PC_reg_reg[7]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\u_ID/offset_w [7:5],\PC_reg[7]_i_7_n_0 }),
        .O(JumpAddr[3:0]),
        .S({\PC_reg[7]_i_8_n_0 ,\PC_reg[7]_i_9_n_0 ,\PC_reg[7]_i_10_n_0 ,\PC_reg[7]_i_11_n_0 }));
  LUT6 #(
    .INIT(64'h0000000000151515)) 
    char_tab_i_16
       (.I0(char_tab_i_43_n_0),
        .I1(\PosX_reg_reg[4]_1 ),
        .I2(\q_reg[155] [2]),
        .I3(\q_reg[155] [43]),
        .I4(\PosX_reg_reg[6] ),
        .I5(\q_reg[23]_0 ),
        .O(\TMDSn[2]_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    char_tab_i_40
       (.I0(\q_reg[155] [43]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_79_n_0),
        .O(\TMDSn[2]_1 ));
  LUT6 #(
    .INIT(64'h88F8FFFF88F888F8)) 
    char_tab_i_43
       (.I0(Instruction_id[6]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(Instruction_id[2]),
        .I3(\PosX_reg_reg[5] ),
        .I4(\PosX_reg_reg[4] ),
        .I5(\q_reg[155] [38]),
        .O(char_tab_i_43_n_0));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    char_tab_i_79
       (.I0(\q_reg[155] [42]),
        .I1(\PosX_reg_reg[4]_1 ),
        .I2(\q_reg[155] [35]),
        .I3(\PosX_reg_reg[4]_0 ),
        .I4(\q_reg[155] [41]),
        .I5(\PosX_reg_reg[6] ),
        .O(char_tab_i_79_n_0));
  LUT6 #(
    .INIT(64'h00FF47FFFFFF47FF)) 
    char_tab_i_95
       (.I0(\q_reg[155] [62]),
        .I1(\PosX_reg_reg[5] ),
        .I2(Q[0]),
        .I3(\PosX_reg_reg[4] ),
        .I4(\PosX_reg_reg[4]_0 ),
        .I5(Instruction_id[5]),
        .O(\TMDSn[2] ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[113]_i_3 
       (.I0(\q_reg[155] [43]),
        .I1(\q_reg[155] [42]),
        .O(\q_reg[85] ));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[114]_i_1 
       (.I0(\q_reg[155] [69]),
        .I1(\q_reg[155] [35]),
        .I2(\q[120]_i_2_n_0 ),
        .I3(\q_reg[155] [39]),
        .O(\q_reg[155] [44]));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[115]_i_1 
       (.I0(\q[120]_i_2_n_0 ),
        .I1(\q_reg[155] [40]),
        .I2(\q_reg[155] [69]),
        .I3(\q_reg[155] [36]),
        .O(\q_reg[155] [45]));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[116]_i_1 
       (.I0(\q[120]_i_2_n_0 ),
        .I1(\q_reg[155] [43]),
        .I2(\q_reg[155] [69]),
        .I3(\q_reg[155] [37]),
        .O(\q_reg[155] [46]));
  LUT4 #(
    .INIT(16'hF888)) 
    \q[117]_i_1 
       (.I0(\q_reg[155] [41]),
        .I1(\q[120]_i_2_n_0 ),
        .I2(\q_reg[155] [69]),
        .I3(\q_reg[155] [38]),
        .O(\q_reg[155] [47]));
  LUT5 #(
    .INIT(32'h00100000)) 
    \q[118]_i_1 
       (.I0(Instruction_id[2]),
        .I1(Instruction_id[5]),
        .I2(Q[0]),
        .I3(Instruction_id[6]),
        .I4(\q_reg[155] [41]),
        .O(\q_reg[155] [48]));
  LUT6 #(
    .INIT(64'hC0CCCCCC88888888)) 
    \q[119]_i_1 
       (.I0(\q_reg[155] [69]),
        .I1(Q[2]),
        .I2(\q_reg[155] [1]),
        .I3(\q_reg[155] [0]),
        .I4(Q[1]),
        .I5(\q[120]_i_2_n_0 ),
        .O(\q_reg[155] [49]));
  LUT6 #(
    .INIT(64'hC0CCCCCC88888888)) 
    \q[120]_i_1 
       (.I0(\q_reg[155] [69]),
        .I1(\q_reg[155] [41]),
        .I2(\q_reg[155] [1]),
        .I3(\q_reg[155] [0]),
        .I4(Q[1]),
        .I5(\q[120]_i_2_n_0 ),
        .O(\q_reg[155] [50]));
  LUT4 #(
    .INIT(16'h0004)) 
    \q[120]_i_2 
       (.I0(Instruction_id[6]),
        .I1(Q[0]),
        .I2(Instruction_id[5]),
        .I3(Instruction_id[2]),
        .O(\q[120]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[121]_i_1 
       (.I0(\q[139]_i_2_n_0 ),
        .I1(\q[139]_i_4_n_0 ),
        .O(\q_reg[155] [51]));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[126]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [0]),
        .O(\q_reg[155] [52]));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[127]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [1]),
        .O(\q_reg[155] [53]));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[128]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [2]),
        .O(\q_reg[155] [54]));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[129]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [42]),
        .O(\q_reg[155] [55]));
  LUT4 #(
    .INIT(16'h002A)) 
    \q[130]_i_1 
       (.I0(\q_reg[155] [43]),
        .I1(\q[139]_i_3_n_0 ),
        .I2(\q[130]_i_2_n_0 ),
        .I3(\q[139]_i_4_n_0 ),
        .O(\q_reg[155] [56]));
  LUT5 #(
    .INIT(32'hFFFFECFF)) 
    \q[130]_i_2 
       (.I0(Q[1]),
        .I1(Instruction_id[2]),
        .I2(Instruction_id[5]),
        .I3(Q[0]),
        .I4(Instruction_id[6]),
        .O(\q[130]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[134]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [39]),
        .O(\q_reg[155] [57]));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[135]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [40]),
        .O(\q_reg[155] [58]));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT4 #(
    .INIT(16'h4544)) 
    \q[137]_i_1 
       (.I0(\q[139]_i_4_n_0 ),
        .I1(\q[139]_i_2_n_0 ),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q_reg[155] [41]),
        .O(\q_reg[155] [59]));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT4 #(
    .INIT(16'h00AE)) 
    \q[139]_i_1 
       (.I0(\q[139]_i_2_n_0 ),
        .I1(Q[2]),
        .I2(\q[139]_i_3_n_0 ),
        .I3(\q[139]_i_4_n_0 ),
        .O(\q_reg[155] [60]));
  LUT6 #(
    .INIT(64'h0000002000002020)) 
    \q[139]_i_2 
       (.I0(\q_reg[155] [43]),
        .I1(Instruction_id[6]),
        .I2(Q[0]),
        .I3(Instruction_id[5]),
        .I4(Instruction_id[2]),
        .I5(Q[1]),
        .O(\q[139]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hBFFF)) 
    \q[139]_i_3 
       (.I0(Instruction_id[6]),
        .I1(Q[0]),
        .I2(Instruction_id[2]),
        .I3(Q[1]),
        .O(\q[139]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0080)) 
    \q[139]_i_4 
       (.I0(\q[120]_i_2_n_0 ),
        .I1(Q[1]),
        .I2(\q_reg[155] [0]),
        .I3(\q_reg[155] [1]),
        .O(\q[139]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hDBFFFFFF)) 
    \q[146]_i_1 
       (.I0(Instruction_id[2]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Instruction_id[5]),
        .I4(Q[0]),
        .O(\q_reg[155] [61]));
  LUT5 #(
    .INIT(32'h20000000)) 
    \q[147]_i_1 
       (.I0(Instruction_id[2]),
        .I1(Q[1]),
        .I2(Instruction_id[6]),
        .I3(Q[0]),
        .I4(Instruction_id[5]),
        .O(\q_reg[155] [62]));
  LUT5 #(
    .INIT(32'h20000800)) 
    \q[148]_i_1 
       (.I0(Instruction_id[2]),
        .I1(Q[1]),
        .I2(Instruction_id[5]),
        .I3(Q[0]),
        .I4(Instruction_id[6]),
        .O(\q_reg[155] [63]));
  LUT6 #(
    .INIT(64'h88AA88880000A888)) 
    \q[149]_i_1 
       (.I0(\q[152]_i_2_n_0 ),
        .I1(\q_reg[155] [1]),
        .I2(\q[149]_i_2_n_0 ),
        .I3(\q_reg[155] [43]),
        .I4(\q_reg[155] [0]),
        .I5(\q_reg[155] [2]),
        .O(\q_reg[155] [64]));
  LUT5 #(
    .INIT(32'h00000800)) 
    \q[149]_i_2 
       (.I0(Q[0]),
        .I1(Instruction_id[5]),
        .I2(Instruction_id[6]),
        .I3(Q[1]),
        .I4(Instruction_id[2]),
        .O(\q[149]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFBFFAAAAAAAAAAAA)) 
    \q[150]_i_1 
       (.I0(\q[150]_i_2_n_0 ),
        .I1(\q_reg[155] [2]),
        .I2(\q_reg[155] [1]),
        .I3(\q_reg[155] [43]),
        .I4(\q_reg[155] [0]),
        .I5(\q[152]_i_2_n_0 ),
        .O(\q_reg[155] [65]));
  LUT5 #(
    .INIT(32'h00008000)) 
    \q[150]_i_2 
       (.I0(Q[1]),
        .I1(Instruction_id[2]),
        .I2(Q[0]),
        .I3(Instruction_id[5]),
        .I4(Instruction_id[6]),
        .O(\q[150]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT5 #(
    .INIT(32'h0A202A20)) 
    \q[151]_i_1 
       (.I0(\q[152]_i_2_n_0 ),
        .I1(\q_reg[155] [1]),
        .I2(\q_reg[155] [0]),
        .I3(\q_reg[155] [2]),
        .I4(\q_reg[155] [43]),
        .O(\q_reg[155] [66]));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT5 #(
    .INIT(32'h0A0A8000)) 
    \q[152]_i_1 
       (.I0(\q[152]_i_2_n_0 ),
        .I1(\q_reg[155] [43]),
        .I2(\q_reg[155] [2]),
        .I3(\q_reg[155] [0]),
        .I4(\q_reg[155] [1]),
        .O(\q_reg[155] [67]));
  LUT4 #(
    .INIT(16'h0400)) 
    \q[152]_i_2 
       (.I0(Instruction_id[6]),
        .I1(Q[0]),
        .I2(Instruction_id[2]),
        .I3(Q[1]),
        .O(\q[152]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000004)) 
    \q[153]_i_1 
       (.I0(Instruction_id[6]),
        .I1(Q[0]),
        .I2(Instruction_id[5]),
        .I3(Q[1]),
        .I4(Instruction_id[2]),
        .O(\q_reg[155] [68]));
  LUT5 #(
    .INIT(32'h00000008)) 
    \q[154]_i_1 
       (.I0(Q[0]),
        .I1(Instruction_id[5]),
        .I2(Instruction_id[6]),
        .I3(Q[1]),
        .I4(Instruction_id[2]),
        .O(\q_reg[155] [69]));
  LUT5 #(
    .INIT(32'h44448004)) 
    \q[155]_i_2 
       (.I0(Instruction_id[6]),
        .I1(Q[0]),
        .I2(Instruction_id[5]),
        .I3(Instruction_id[2]),
        .I4(Q[1]),
        .O(\q_reg[155] [70]));
  LUT2 #(
    .INIT(4'hE)) 
    \q[63]_i_1__1 
       (.I0(SR),
        .I1(w_IF_flush),
        .O(\q[63]_i_1__1_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \q[81]_i_3 
       (.I0(\q_reg[155] [40]),
        .I1(\q_reg[155] [43]),
        .I2(\q_reg[155] [39]),
        .I3(\q_reg[155] [41]),
        .O(\q_reg[78] ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(Q[0]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[8]),
        .Q(\q_reg[155] [38]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[9]),
        .Q(\q_reg[155] [0]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[10]),
        .Q(\q_reg[155] [1]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[11]),
        .Q(\q_reg[155] [2]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[12]),
        .Q(\q_reg[155] [42]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[13]),
        .Q(\q_reg[155] [39]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[14]),
        .Q(\q_reg[155] [40]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[15]),
        .Q(\q_reg[155] [41]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[16]),
        .Q(Q[2]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[17]),
        .Q(\q_reg[155] [43]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(Instruction_id[2]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[18]),
        .Q(\q_reg[155] [3]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[19]),
        .Q(\q_reg[155] [4]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[20]),
        .Q(\q_reg[155] [5]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[21]),
        .Q(\q_reg[155] [6]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[22]),
        .Q(\q_reg[155] [7]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[23]),
        .Q(\q_reg[155] [8]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[24]),
        .Q(\q_reg[155] [9]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[25]),
        .Q(\q_reg[155] [10]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[26]),
        .Q(\q_reg[155] [11]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[27]),
        .Q(\q_reg[155] [12]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[28]),
        .Q(\q_reg[155] [13]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[29]),
        .Q(\q_reg[155] [14]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[30]),
        .Q(\q_reg[155] [15]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[31]),
        .Q(\q_reg[155] [16]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[32]),
        .Q(\q_reg[155] [17]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[33]),
        .Q(\q_reg[155] [18]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[34]),
        .Q(\q_reg[155] [19]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[35]),
        .Q(\q_reg[155] [20]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[2]),
        .Q(Q[1]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[36]),
        .Q(\q_reg[155] [21]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[37]),
        .Q(\q_reg[155] [22]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[38]),
        .Q(\q_reg[155] [23]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[39]),
        .Q(\q_reg[155] [24]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[40]),
        .Q(\q_reg[155] [25]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[41]),
        .Q(\q_reg[155] [26]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[42]),
        .Q(\q_reg[155] [27]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[43]),
        .Q(\q_reg[155] [28]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[44]),
        .Q(\q_reg[155] [29]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[45]),
        .Q(\q_reg[155] [30]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[3]),
        .Q(Instruction_id[5]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[46]),
        .Q(\q_reg[155] [31]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[47]),
        .Q(\q_reg[155] [32]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[48]),
        .Q(\q_reg[155] [33]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[49]),
        .Q(\q_reg[155] [34]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[4]),
        .Q(Instruction_id[6]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[5]),
        .Q(\q_reg[155] [35]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[6]),
        .Q(\q_reg[155] [36]),
        .R(\q[63]_i_1__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(D[7]),
        .Q(\q_reg[155] [37]),
        .R(\q[63]_i_1__1_n_0 ));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized0
   (\TMDSn[2] ,
    D,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    \TMDSn[2]_8 ,
    \TMDSn[2]_9 ,
    \TMDSn[2]_10 ,
    \TMDSn[2]_11 ,
    \TMDSn[2]_12 ,
    \TMDSn[2]_13 ,
    \q_reg[74]_0 ,
    \q_reg[72]_0 ,
    \q_reg[68]_0 ,
    \q_reg[70]_0 ,
    \q_reg[63]_0 ,
    \q_reg[64]_0 ,
    \q_reg[65]_0 ,
    \q_reg[66]_0 ,
    \q_reg[67]_0 ,
    \q_reg[69]_0 ,
    \q_reg[71]_0 ,
    \q_reg[67]_1 ,
    \q_reg[73]_0 ,
    \q_reg[71]_1 ,
    Q,
    E,
    Stall,
    \q_reg[11]_0 ,
    \q_reg[11]_1 ,
    \q_reg[11]_2 ,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[4]_2 ,
    \PosX_reg_reg[4]_3 ,
    \PosX_reg_reg[6] ,
    \PosX_reg_reg[6]_0 ,
    \q_reg[4]_0 ,
    \q_reg[6]_0 ,
    \q_reg[44]_0 ,
    \q_reg[6]_1 ,
    w_RegWriteData_wb,
    \q_reg[44]_1 ,
    \q_reg[74]_1 ,
    \q_reg[6]_2 ,
    \q_reg[43] ,
    \q_reg[39] ,
    \q_reg[40]_0 ,
    \q_reg[44]_2 ,
    \q_reg[49] ,
    \q_reg[45]_0 ,
    \q_reg[148]_0 ,
    \q_reg[148]_1 ,
    \q_reg[148]_2 ,
    \q_reg[148]_3 ,
    \q_reg[148]_4 ,
    \q_reg[148]_5 ,
    \q_reg[148]_6 ,
    \q_reg[148]_7 ,
    \q_reg[148]_8 ,
    \q_reg[148]_9 ,
    \q_reg[54]_0 ,
    \q_reg[148]_10 ,
    \q_reg[148]_11 ,
    \q_reg[148]_12 ,
    \q_reg[148]_13 ,
    \q_reg[148]_14 ,
    \q_reg[148]_15 ,
    \q_reg[148]_16 ,
    \q_reg[148]_17 ,
    \q_reg[148]_18 ,
    \q_reg[148]_19 ,
    \q_reg[5]_0 ,
    \q_reg[2]_0 ,
    \q_reg[6]_3 ,
    \q_reg[1]_0 ,
    SR,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [62:0]D;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output \TMDSn[2]_8 ;
  output \TMDSn[2]_9 ;
  output \TMDSn[2]_10 ;
  output \TMDSn[2]_11 ;
  output \TMDSn[2]_12 ;
  output \TMDSn[2]_13 ;
  output \q_reg[74]_0 ;
  output \q_reg[72]_0 ;
  output \q_reg[68]_0 ;
  output \q_reg[70]_0 ;
  output \q_reg[63]_0 ;
  output \q_reg[64]_0 ;
  output \q_reg[65]_0 ;
  output \q_reg[66]_0 ;
  output \q_reg[67]_0 ;
  output \q_reg[69]_0 ;
  output \q_reg[71]_0 ;
  output \q_reg[67]_1 ;
  output \q_reg[73]_0 ;
  output \q_reg[71]_1 ;
  output [31:0]Q;
  output [0:0]E;
  output Stall;
  output \q_reg[11]_0 ;
  output \q_reg[11]_1 ;
  output \q_reg[11]_2 ;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[4]_2 ;
  input \PosX_reg_reg[4]_3 ;
  input \PosX_reg_reg[6] ;
  input \PosX_reg_reg[6]_0 ;
  input \q_reg[4]_0 ;
  input \q_reg[6]_0 ;
  input \q_reg[44]_0 ;
  input [134:0]\q_reg[6]_1 ;
  input [31:0]w_RegWriteData_wb;
  input \q_reg[44]_1 ;
  input [31:0]\q_reg[74]_1 ;
  input \q_reg[6]_2 ;
  input \q_reg[43] ;
  input \q_reg[39] ;
  input \q_reg[40]_0 ;
  input \q_reg[44]_2 ;
  input \q_reg[49] ;
  input \q_reg[45]_0 ;
  input \q_reg[148]_0 ;
  input \q_reg[148]_1 ;
  input \q_reg[148]_2 ;
  input \q_reg[148]_3 ;
  input \q_reg[148]_4 ;
  input \q_reg[148]_5 ;
  input \q_reg[148]_6 ;
  input \q_reg[148]_7 ;
  input \q_reg[148]_8 ;
  input \q_reg[148]_9 ;
  input \q_reg[54]_0 ;
  input \q_reg[148]_10 ;
  input \q_reg[148]_11 ;
  input \q_reg[148]_12 ;
  input \q_reg[148]_13 ;
  input \q_reg[148]_14 ;
  input \q_reg[148]_15 ;
  input \q_reg[148]_16 ;
  input \q_reg[148]_17 ;
  input \q_reg[148]_18 ;
  input \q_reg[148]_19 ;
  input \q_reg[5]_0 ;
  input \q_reg[2]_0 ;
  input \q_reg[6]_3 ;
  input [0:0]\q_reg[1]_0 ;
  input [0:0]SR;
  input cpu_clk_BUFG;

  wire [19:1]ALU_A;
  wire [30:0]ALU_B;
  wire [62:0]D;
  wire [0:0]E;
  wire \PC_reg[31]_i_10_n_0 ;
  wire \PC_reg[31]_i_8_n_0 ;
  wire \PC_reg[31]_i_9_n_0 ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[6] ;
  wire \PosX_reg_reg[6]_0 ;
  wire [31:0]Q;
  wire [0:0]SR;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_10 ;
  wire \TMDSn[2]_11 ;
  wire \TMDSn[2]_12 ;
  wire \TMDSn[2]_13 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire \TMDSn[2]_9 ;
  wire char_tab_i_103_n_0;
  wire char_tab_i_104_n_0;
  wire char_tab_i_105_n_0;
  wire char_tab_i_110_n_0;
  wire char_tab_i_111_n_0;
  wire char_tab_i_112_n_0;
  wire char_tab_i_113_n_0;
  wire char_tab_i_114_n_0;
  wire char_tab_i_115_n_0;
  wire char_tab_i_117_n_0;
  wire char_tab_i_118_n_0;
  wire char_tab_i_121_n_0;
  wire char_tab_i_122_n_0;
  wire char_tab_i_123_n_0;
  wire char_tab_i_124_n_0;
  wire char_tab_i_125_n_0;
  wire char_tab_i_126_n_0;
  wire char_tab_i_127_n_0;
  wire char_tab_i_128_n_0;
  wire char_tab_i_129_n_0;
  wire char_tab_i_130_n_0;
  wire char_tab_i_131_n_0;
  wire char_tab_i_41_n_0;
  wire char_tab_i_42_n_0;
  wire char_tab_i_52_n_0;
  wire char_tab_i_76_n_0;
  wire char_tab_i_80_n_0;
  wire char_tab_i_81_n_0;
  wire char_tab_i_89_n_0;
  wire char_tab_i_90_n_0;
  wire char_tab_i_93_n_0;
  wire char_tab_i_94_n_0;
  wire char_tab_i_98_n_0;
  wire cpu_clk_BUFG;
  wire \q[155]_i_1_n_0 ;
  wire \q[43]_i_10_n_0 ;
  wire \q[43]_i_11_n_0 ;
  wire \q[43]_i_12_n_0 ;
  wire \q[43]_i_13_n_0 ;
  wire \q[43]_i_14_n_0 ;
  wire \q[43]_i_15_n_0 ;
  wire \q[43]_i_16_n_0 ;
  wire \q[43]_i_17_n_0 ;
  wire \q[43]_i_18_n_0 ;
  wire \q[43]_i_19_n_0 ;
  wire \q[43]_i_20_n_0 ;
  wire \q[43]_i_21_n_0 ;
  wire \q[43]_i_2_n_0 ;
  wire \q[43]_i_3_n_0 ;
  wire \q[43]_i_4_n_0 ;
  wire \q[43]_i_5_n_0 ;
  wire \q[43]_i_6_n_0 ;
  wire \q[43]_i_7_n_0 ;
  wire \q[43]_i_8_n_0 ;
  wire \q[43]_i_9_n_0 ;
  wire \q[44]_i_10_n_0 ;
  wire \q[44]_i_11_n_0 ;
  wire \q[44]_i_13_n_0 ;
  wire \q[44]_i_14_n_0 ;
  wire \q[44]_i_15_n_0 ;
  wire \q[44]_i_2_n_0 ;
  wire \q[44]_i_3_n_0 ;
  wire \q[44]_i_4_n_0 ;
  wire \q[44]_i_5_n_0 ;
  wire \q[44]_i_6_n_0 ;
  wire \q[44]_i_8_n_0 ;
  wire \q[44]_i_9_n_0 ;
  wire \q[45]_i_10_n_0 ;
  wire \q[45]_i_11_n_0 ;
  wire \q[45]_i_13_n_0 ;
  wire \q[45]_i_14_n_0 ;
  wire \q[45]_i_15_n_0 ;
  wire \q[45]_i_16_n_0 ;
  wire \q[45]_i_17_n_0 ;
  wire \q[45]_i_2_n_0 ;
  wire \q[45]_i_3_n_0 ;
  wire \q[45]_i_4_n_0 ;
  wire \q[45]_i_5_n_0 ;
  wire \q[45]_i_6_n_0 ;
  wire \q[45]_i_7_n_0 ;
  wire \q[45]_i_8_n_0 ;
  wire \q[45]_i_9_n_0 ;
  wire \q[46]_i_10_n_0 ;
  wire \q[46]_i_11_n_0 ;
  wire \q[46]_i_12_n_0 ;
  wire \q[46]_i_13_n_0 ;
  wire \q[46]_i_14_n_0 ;
  wire \q[46]_i_15_n_0 ;
  wire \q[46]_i_2_n_0 ;
  wire \q[46]_i_3_n_0 ;
  wire \q[46]_i_4_n_0 ;
  wire \q[46]_i_7_n_0 ;
  wire \q[46]_i_8_n_0 ;
  wire \q[46]_i_9_n_0 ;
  wire \q[47]_i_10_n_0 ;
  wire \q[47]_i_2_n_0 ;
  wire \q[47]_i_3_n_0 ;
  wire \q[47]_i_4_n_0 ;
  wire \q[47]_i_5_n_0 ;
  wire \q[47]_i_6_n_0 ;
  wire \q[47]_i_7_n_0 ;
  wire \q[47]_i_8_n_0 ;
  wire \q[47]_i_9_n_0 ;
  wire \q[48]_i_10_n_0 ;
  wire \q[48]_i_2_n_0 ;
  wire \q[48]_i_3_n_0 ;
  wire \q[48]_i_4_n_0 ;
  wire \q[48]_i_5_n_0 ;
  wire \q[48]_i_6_n_0 ;
  wire \q[48]_i_7_n_0 ;
  wire \q[48]_i_8_n_0 ;
  wire \q[48]_i_9_n_0 ;
  wire \q[49]_i_10_n_0 ;
  wire \q[49]_i_11_n_0 ;
  wire \q[49]_i_12_n_0 ;
  wire \q[49]_i_13_n_0 ;
  wire \q[49]_i_14_n_0 ;
  wire \q[49]_i_15_n_0 ;
  wire \q[49]_i_16_n_0 ;
  wire \q[49]_i_17_n_0 ;
  wire \q[49]_i_2_n_0 ;
  wire \q[49]_i_3_n_0 ;
  wire \q[49]_i_4_n_0 ;
  wire \q[49]_i_5_n_0 ;
  wire \q[49]_i_6_n_0 ;
  wire \q[49]_i_7_n_0 ;
  wire \q[49]_i_8_n_0 ;
  wire \q[49]_i_9_n_0 ;
  wire \q[50]_i_10_n_0 ;
  wire \q[50]_i_11_n_0 ;
  wire \q[50]_i_13_n_0 ;
  wire \q[50]_i_15_n_0 ;
  wire \q[50]_i_16_n_0 ;
  wire \q[50]_i_18_n_0 ;
  wire \q[50]_i_19_n_0 ;
  wire \q[50]_i_20_n_0 ;
  wire \q[50]_i_21_n_0 ;
  wire \q[50]_i_22_n_0 ;
  wire \q[50]_i_2_n_0 ;
  wire \q[50]_i_3_n_0 ;
  wire \q[50]_i_4_n_0 ;
  wire \q[50]_i_5_n_0 ;
  wire \q[50]_i_6_n_0 ;
  wire \q[50]_i_7_n_0 ;
  wire \q[50]_i_8_n_0 ;
  wire \q[50]_i_9_n_0 ;
  wire \q[51]_i_2_n_0 ;
  wire \q[51]_i_3_n_0 ;
  wire \q[51]_i_4_n_0 ;
  wire \q[51]_i_5_n_0 ;
  wire \q[51]_i_6_n_0 ;
  wire \q[51]_i_7_n_0 ;
  wire \q[52]_i_10_n_0 ;
  wire \q[52]_i_11_n_0 ;
  wire \q[52]_i_12_n_0 ;
  wire \q[52]_i_13_n_0 ;
  wire \q[52]_i_14_n_0 ;
  wire \q[52]_i_15_n_0 ;
  wire \q[52]_i_16_n_0 ;
  wire \q[52]_i_17_n_0 ;
  wire \q[52]_i_18_n_0 ;
  wire \q[52]_i_19_n_0 ;
  wire \q[52]_i_20_n_0 ;
  wire \q[52]_i_2_n_0 ;
  wire \q[52]_i_3_n_0 ;
  wire \q[52]_i_4_n_0 ;
  wire \q[52]_i_5_n_0 ;
  wire \q[52]_i_6_n_0 ;
  wire \q[52]_i_7_n_0 ;
  wire \q[52]_i_8_n_0 ;
  wire \q[52]_i_9_n_0 ;
  wire \q[53]_i_13_n_0 ;
  wire \q[53]_i_14_n_0 ;
  wire \q[53]_i_15_n_0 ;
  wire \q[53]_i_16_n_0 ;
  wire \q[53]_i_17_n_0 ;
  wire \q[53]_i_19_n_0 ;
  wire \q[53]_i_21_n_0 ;
  wire \q[53]_i_2_n_0 ;
  wire \q[53]_i_3_n_0 ;
  wire \q[53]_i_4_n_0 ;
  wire \q[53]_i_5_n_0 ;
  wire \q[53]_i_6_n_0 ;
  wire \q[53]_i_8_n_0 ;
  wire \q[53]_i_9_n_0 ;
  wire \q[54]_i_10_n_0 ;
  wire \q[54]_i_11_n_0 ;
  wire \q[54]_i_12_n_0 ;
  wire \q[54]_i_13_n_0 ;
  wire \q[54]_i_15_n_0 ;
  wire \q[54]_i_16_n_0 ;
  wire \q[54]_i_18_n_0 ;
  wire \q[54]_i_19_n_0 ;
  wire \q[54]_i_20_n_0 ;
  wire \q[54]_i_21_n_0 ;
  wire \q[54]_i_22_n_0 ;
  wire \q[54]_i_23_n_0 ;
  wire \q[54]_i_24_n_0 ;
  wire \q[54]_i_25_n_0 ;
  wire \q[54]_i_26_n_0 ;
  wire \q[54]_i_27_n_0 ;
  wire \q[54]_i_28_n_0 ;
  wire \q[54]_i_2__0_n_0 ;
  wire \q[54]_i_3_n_0 ;
  wire \q[54]_i_4_n_0 ;
  wire \q[54]_i_5_n_0 ;
  wire \q[54]_i_6_n_0 ;
  wire \q[54]_i_9_n_0 ;
  wire \q[55]_i_10_n_0 ;
  wire \q[55]_i_11_n_0 ;
  wire \q[55]_i_12_n_0 ;
  wire \q[55]_i_13_n_0 ;
  wire \q[55]_i_14_n_0 ;
  wire \q[55]_i_15_n_0 ;
  wire \q[55]_i_16_n_0 ;
  wire \q[55]_i_19_n_0 ;
  wire \q[55]_i_20_n_0 ;
  wire \q[55]_i_21_n_0 ;
  wire \q[55]_i_22_n_0 ;
  wire \q[55]_i_23_n_0 ;
  wire \q[55]_i_25_n_0 ;
  wire \q[55]_i_27_n_0 ;
  wire \q[55]_i_28_n_0 ;
  wire \q[55]_i_2_n_0 ;
  wire \q[55]_i_31_n_0 ;
  wire \q[55]_i_3_n_0 ;
  wire \q[55]_i_4_n_0 ;
  wire \q[55]_i_5_n_0 ;
  wire \q[55]_i_6_n_0 ;
  wire \q[55]_i_7_n_0 ;
  wire \q[55]_i_8_n_0 ;
  wire \q[55]_i_9_n_0 ;
  wire \q[56]_i_10_n_0 ;
  wire \q[56]_i_11_n_0 ;
  wire \q[56]_i_12_n_0 ;
  wire \q[56]_i_13_n_0 ;
  wire \q[56]_i_14_n_0 ;
  wire \q[56]_i_15_n_0 ;
  wire \q[56]_i_16_n_0 ;
  wire \q[56]_i_17_n_0 ;
  wire \q[56]_i_2_n_0 ;
  wire \q[56]_i_3_n_0 ;
  wire \q[56]_i_4_n_0 ;
  wire \q[56]_i_5_n_0 ;
  wire \q[56]_i_6_n_0 ;
  wire \q[56]_i_7_n_0 ;
  wire \q[56]_i_8_n_0 ;
  wire \q[56]_i_9_n_0 ;
  wire \q[57]_i_12_n_0 ;
  wire \q[57]_i_13_n_0 ;
  wire \q[57]_i_14_n_0 ;
  wire \q[57]_i_15_n_0 ;
  wire \q[57]_i_17_n_0 ;
  wire \q[57]_i_18_n_0 ;
  wire \q[57]_i_19_n_0 ;
  wire \q[57]_i_20_n_0 ;
  wire \q[57]_i_21_n_0 ;
  wire \q[57]_i_22_n_0 ;
  wire \q[57]_i_23_n_0 ;
  wire \q[57]_i_24_n_0 ;
  wire \q[57]_i_2_n_0 ;
  wire \q[57]_i_3_n_0 ;
  wire \q[57]_i_4_n_0 ;
  wire \q[57]_i_5_n_0 ;
  wire \q[57]_i_6_n_0 ;
  wire \q[58]_i_10_n_0 ;
  wire \q[58]_i_11_n_0 ;
  wire \q[58]_i_12_n_0 ;
  wire \q[58]_i_15_n_0 ;
  wire \q[58]_i_16_n_0 ;
  wire \q[58]_i_17_n_0 ;
  wire \q[58]_i_18_n_0 ;
  wire \q[58]_i_19_n_0 ;
  wire \q[58]_i_20_n_0 ;
  wire \q[58]_i_21_n_0 ;
  wire \q[58]_i_22_n_0 ;
  wire \q[58]_i_23_n_0 ;
  wire \q[58]_i_2__0_n_0 ;
  wire \q[58]_i_3__0_n_0 ;
  wire \q[58]_i_4__0_n_0 ;
  wire \q[58]_i_5_n_0 ;
  wire \q[58]_i_6_n_0 ;
  wire \q[58]_i_9_n_0 ;
  wire \q[59]_i_10_n_0 ;
  wire \q[59]_i_11_n_0 ;
  wire \q[59]_i_2_n_0 ;
  wire \q[59]_i_3_n_0 ;
  wire \q[59]_i_4_n_0 ;
  wire \q[59]_i_5_n_0 ;
  wire \q[59]_i_6_n_0 ;
  wire \q[59]_i_7_n_0 ;
  wire \q[59]_i_8_n_0 ;
  wire \q[59]_i_9_n_0 ;
  wire \q[60]_i_10_n_0 ;
  wire \q[60]_i_11_n_0 ;
  wire \q[60]_i_2_n_0 ;
  wire \q[60]_i_3_n_0 ;
  wire \q[60]_i_4_n_0 ;
  wire \q[60]_i_5_n_0 ;
  wire \q[60]_i_6_n_0 ;
  wire \q[60]_i_7_n_0 ;
  wire \q[60]_i_8_n_0 ;
  wire \q[60]_i_9_n_0 ;
  wire \q[61]_i_10_n_0 ;
  wire \q[61]_i_13_n_0 ;
  wire \q[61]_i_14_n_0 ;
  wire \q[61]_i_15_n_0 ;
  wire \q[61]_i_16_n_0 ;
  wire \q[61]_i_17_n_0 ;
  wire \q[61]_i_18_n_0 ;
  wire \q[61]_i_20_n_0 ;
  wire \q[61]_i_22_n_0 ;
  wire \q[61]_i_23_n_0 ;
  wire \q[61]_i_24_n_0 ;
  wire \q[61]_i_25_n_0 ;
  wire \q[61]_i_26_n_0 ;
  wire \q[61]_i_27_n_0 ;
  wire \q[61]_i_28_n_0 ;
  wire \q[61]_i_2_n_0 ;
  wire \q[61]_i_3_n_0 ;
  wire \q[61]_i_4_n_0 ;
  wire \q[61]_i_5_n_0 ;
  wire \q[61]_i_6_n_0 ;
  wire \q[61]_i_7_n_0 ;
  wire \q[61]_i_8_n_0 ;
  wire \q[62]_i_10_n_0 ;
  wire \q[62]_i_11_n_0 ;
  wire \q[62]_i_12_n_0 ;
  wire \q[62]_i_13_n_0 ;
  wire \q[62]_i_14_n_0 ;
  wire \q[62]_i_15_n_0 ;
  wire \q[62]_i_16_n_0 ;
  wire \q[62]_i_17_n_0 ;
  wire \q[62]_i_18_n_0 ;
  wire \q[62]_i_19_n_0 ;
  wire \q[62]_i_20_n_0 ;
  wire \q[62]_i_2__0_n_0 ;
  wire \q[62]_i_3_n_0 ;
  wire \q[62]_i_4_n_0 ;
  wire \q[62]_i_5_n_0 ;
  wire \q[62]_i_6_n_0 ;
  wire \q[62]_i_9_n_0 ;
  wire \q[63]_i_10_n_0 ;
  wire \q[63]_i_11_n_0 ;
  wire \q[63]_i_12_n_0 ;
  wire \q[63]_i_13_n_0 ;
  wire \q[63]_i_14_n_0 ;
  wire \q[63]_i_15_n_0 ;
  wire \q[63]_i_16_n_0 ;
  wire \q[63]_i_17_n_0 ;
  wire \q[63]_i_18_n_0 ;
  wire \q[63]_i_19_n_0 ;
  wire \q[63]_i_20_n_0 ;
  wire \q[63]_i_21_n_0 ;
  wire \q[63]_i_22_n_0 ;
  wire \q[63]_i_2_n_0 ;
  wire \q[63]_i_3_n_0 ;
  wire \q[63]_i_4_n_0 ;
  wire \q[63]_i_5_n_0 ;
  wire \q[63]_i_6_n_0 ;
  wire \q[63]_i_7_n_0 ;
  wire \q[63]_i_8_n_0 ;
  wire \q[63]_i_9_n_0 ;
  wire \q[64]_i_10_n_0 ;
  wire \q[64]_i_11_n_0 ;
  wire \q[64]_i_12_n_0 ;
  wire \q[64]_i_13_n_0 ;
  wire \q[64]_i_14_n_0 ;
  wire \q[64]_i_2_n_0 ;
  wire \q[64]_i_3_n_0 ;
  wire \q[64]_i_4_n_0 ;
  wire \q[64]_i_5_n_0 ;
  wire \q[64]_i_6_n_0 ;
  wire \q[64]_i_7_n_0 ;
  wire \q[64]_i_8_n_0 ;
  wire \q[64]_i_9_n_0 ;
  wire \q[65]_i_12_n_0 ;
  wire \q[65]_i_13_n_0 ;
  wire \q[65]_i_14_n_0 ;
  wire \q[65]_i_15_n_0 ;
  wire \q[65]_i_18_n_0 ;
  wire \q[65]_i_20_n_0 ;
  wire \q[65]_i_21_n_0 ;
  wire \q[65]_i_22_n_0 ;
  wire \q[65]_i_23_n_0 ;
  wire \q[65]_i_24_n_0 ;
  wire \q[65]_i_25_n_0 ;
  wire \q[65]_i_26_n_0 ;
  wire \q[65]_i_27_n_0 ;
  wire \q[65]_i_28_n_0 ;
  wire \q[65]_i_29_n_0 ;
  wire \q[65]_i_2_n_0 ;
  wire \q[65]_i_30_n_0 ;
  wire \q[65]_i_31_n_0 ;
  wire \q[65]_i_32_n_0 ;
  wire \q[65]_i_3_n_0 ;
  wire \q[65]_i_4_n_0 ;
  wire \q[65]_i_5_n_0 ;
  wire \q[65]_i_6_n_0 ;
  wire \q[66]_i_10_n_0 ;
  wire \q[66]_i_11_n_0 ;
  wire \q[66]_i_12_n_0 ;
  wire \q[66]_i_13_n_0 ;
  wire \q[66]_i_14_n_0 ;
  wire \q[66]_i_2_n_0 ;
  wire \q[66]_i_3_n_0 ;
  wire \q[66]_i_4_n_0 ;
  wire \q[66]_i_5_n_0 ;
  wire \q[66]_i_6_n_0 ;
  wire \q[66]_i_7_n_0 ;
  wire \q[66]_i_9_n_0 ;
  wire \q[67]_i_10_n_0 ;
  wire \q[67]_i_11_n_0 ;
  wire \q[67]_i_12_n_0 ;
  wire \q[67]_i_13_n_0 ;
  wire \q[67]_i_14_n_0 ;
  wire \q[67]_i_15_n_0 ;
  wire \q[67]_i_16_n_0 ;
  wire \q[67]_i_17_n_0 ;
  wire \q[67]_i_18_n_0 ;
  wire \q[67]_i_19_n_0 ;
  wire \q[67]_i_20_n_0 ;
  wire \q[67]_i_21_n_0 ;
  wire \q[67]_i_22_n_0 ;
  wire \q[67]_i_23_n_0 ;
  wire \q[67]_i_24_n_0 ;
  wire \q[67]_i_25_n_0 ;
  wire \q[67]_i_2_n_0 ;
  wire \q[67]_i_3_n_0 ;
  wire \q[67]_i_4_n_0 ;
  wire \q[67]_i_5_n_0 ;
  wire \q[67]_i_6_n_0 ;
  wire \q[67]_i_7_n_0 ;
  wire \q[68]_i_10_n_0 ;
  wire \q[68]_i_11_n_0 ;
  wire \q[68]_i_12_n_0 ;
  wire \q[68]_i_13_n_0 ;
  wire \q[68]_i_2_n_0 ;
  wire \q[68]_i_3_n_0 ;
  wire \q[68]_i_4_n_0 ;
  wire \q[68]_i_5_n_0 ;
  wire \q[68]_i_6_n_0 ;
  wire \q[68]_i_8_n_0 ;
  wire \q[68]_i_9_n_0 ;
  wire \q[69]_i_10_n_0 ;
  wire \q[69]_i_11_n_0 ;
  wire \q[69]_i_12_n_0 ;
  wire \q[69]_i_13_n_0 ;
  wire \q[69]_i_2_n_0 ;
  wire \q[69]_i_3_n_0 ;
  wire \q[69]_i_4_n_0 ;
  wire \q[69]_i_5_n_0 ;
  wire \q[69]_i_7_n_0 ;
  wire \q[69]_i_8_n_0 ;
  wire \q[69]_i_9_n_0 ;
  wire \q[70]_i_11_n_0 ;
  wire \q[70]_i_12_n_0 ;
  wire \q[70]_i_13_n_0 ;
  wire \q[70]_i_16_n_0 ;
  wire \q[70]_i_17_n_0 ;
  wire \q[70]_i_18_n_0 ;
  wire \q[70]_i_19_n_0 ;
  wire \q[70]_i_2__0_n_0 ;
  wire \q[70]_i_3_n_0 ;
  wire \q[70]_i_4_n_0 ;
  wire \q[70]_i_5_n_0 ;
  wire \q[70]_i_6_n_0 ;
  wire \q[70]_i_7_n_0 ;
  wire \q[70]_i_8_n_0 ;
  wire \q[71]_i_10_n_0 ;
  wire \q[71]_i_11_n_0 ;
  wire \q[71]_i_12_n_0 ;
  wire \q[71]_i_13_n_0 ;
  wire \q[71]_i_14_n_0 ;
  wire \q[71]_i_15_n_0 ;
  wire \q[71]_i_16_n_0 ;
  wire \q[71]_i_17_n_0 ;
  wire \q[71]_i_18_n_0 ;
  wire \q[71]_i_19_n_0 ;
  wire \q[71]_i_20_n_0 ;
  wire \q[71]_i_21_n_0 ;
  wire \q[71]_i_22_n_0 ;
  wire \q[71]_i_23_n_0 ;
  wire \q[71]_i_24_n_0 ;
  wire \q[71]_i_25_n_0 ;
  wire \q[71]_i_26_n_0 ;
  wire \q[71]_i_27_n_0 ;
  wire \q[71]_i_28_n_0 ;
  wire \q[71]_i_29_n_0 ;
  wire \q[71]_i_2_n_0 ;
  wire \q[71]_i_30_n_0 ;
  wire \q[71]_i_31_n_0 ;
  wire \q[71]_i_3_n_0 ;
  wire \q[71]_i_4_n_0 ;
  wire \q[71]_i_5_n_0 ;
  wire \q[71]_i_6_n_0 ;
  wire \q[71]_i_9_n_0 ;
  wire \q[72]_i_10_n_0 ;
  wire \q[72]_i_11_n_0 ;
  wire \q[72]_i_12_n_0 ;
  wire \q[72]_i_14_n_0 ;
  wire \q[72]_i_2_n_0 ;
  wire \q[72]_i_3_n_0 ;
  wire \q[72]_i_4_n_0 ;
  wire \q[72]_i_5_n_0 ;
  wire \q[72]_i_6_n_0 ;
  wire \q[72]_i_7_n_0 ;
  wire \q[72]_i_8_n_0 ;
  wire \q[73]_i_13_n_0 ;
  wire \q[73]_i_15_n_0 ;
  wire \q[73]_i_17_n_0 ;
  wire \q[73]_i_21_n_0 ;
  wire \q[73]_i_22_n_0 ;
  wire \q[73]_i_26_n_0 ;
  wire \q[73]_i_27_n_0 ;
  wire \q[73]_i_28_n_0 ;
  wire \q[73]_i_29_n_0 ;
  wire \q[73]_i_2_n_0 ;
  wire \q[73]_i_3_n_0 ;
  wire \q[73]_i_4_n_0 ;
  wire \q[73]_i_5_n_0 ;
  wire \q[73]_i_6_n_0 ;
  wire \q[73]_i_7_n_0 ;
  wire \q[73]_i_9_n_0 ;
  wire \q[74]_i_10_n_0 ;
  wire \q[74]_i_11_n_0 ;
  wire \q[74]_i_12_n_0 ;
  wire \q[74]_i_15_n_0 ;
  wire \q[74]_i_16_n_0 ;
  wire \q[74]_i_17_n_0 ;
  wire \q[74]_i_18_n_0 ;
  wire \q[74]_i_2_n_0 ;
  wire \q[74]_i_4_n_0 ;
  wire \q[74]_i_5_n_0 ;
  wire \q[74]_i_6_n_0 ;
  wire \q[74]_i_7_n_0 ;
  wire \q_reg[11]_0 ;
  wire \q_reg[11]_1 ;
  wire \q_reg[11]_2 ;
  wire \q_reg[148]_0 ;
  wire \q_reg[148]_1 ;
  wire \q_reg[148]_10 ;
  wire \q_reg[148]_11 ;
  wire \q_reg[148]_12 ;
  wire \q_reg[148]_13 ;
  wire \q_reg[148]_14 ;
  wire \q_reg[148]_15 ;
  wire \q_reg[148]_16 ;
  wire \q_reg[148]_17 ;
  wire \q_reg[148]_18 ;
  wire \q_reg[148]_19 ;
  wire \q_reg[148]_2 ;
  wire \q_reg[148]_3 ;
  wire \q_reg[148]_4 ;
  wire \q_reg[148]_5 ;
  wire \q_reg[148]_6 ;
  wire \q_reg[148]_7 ;
  wire \q_reg[148]_8 ;
  wire \q_reg[148]_9 ;
  wire [0:0]\q_reg[1]_0 ;
  wire \q_reg[2]_0 ;
  wire \q_reg[39] ;
  wire \q_reg[40]_0 ;
  wire \q_reg[43] ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[45]_0 ;
  wire \q_reg[49] ;
  wire \q_reg[4]_0 ;
  wire \q_reg[54]_0 ;
  wire \q_reg[5]_0 ;
  wire \q_reg[63]_0 ;
  wire \q_reg[64]_0 ;
  wire \q_reg[65]_0 ;
  wire \q_reg[66]_0 ;
  wire \q_reg[67]_0 ;
  wire \q_reg[67]_1 ;
  wire \q_reg[68]_0 ;
  wire \q_reg[69]_0 ;
  wire \q_reg[6]_0 ;
  wire [134:0]\q_reg[6]_1 ;
  wire \q_reg[6]_2 ;
  wire \q_reg[6]_3 ;
  wire \q_reg[70]_0 ;
  wire \q_reg[71]_0 ;
  wire \q_reg[71]_1 ;
  wire \q_reg[72]_0 ;
  wire \q_reg[73]_0 ;
  wire \q_reg[74]_0 ;
  wire [31:0]\q_reg[74]_1 ;
  wire [3:0]r_ALUCode_ex;
  wire [1:0]r_ALUSrcB_ex;
  wire [25:0]r_Imm_ex;
  wire [31:0]r_PC_ex;
  wire [31:0]r_rs1Data_ex;
  wire [31:0]r_rs2Data_ex;
  wire [31:0]w_RegWriteData_wb;

  assign Stall = E;
  LUT5 #(
    .INIT(32'h55555557)) 
    \PC_reg[31]_i_10 
       (.I0(Q[29]),
        .I1(Q[5]),
        .I2(Q[6]),
        .I3(Q[3]),
        .I4(Q[4]),
        .O(\PC_reg[31]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF5554)) 
    \PC_reg[31]_i_3 
       (.I0(\PC_reg[31]_i_8_n_0 ),
        .I1(\PC_reg[31]_i_9_n_0 ),
        .I2(Q[6]),
        .I3(\q_reg[6]_1 [41]),
        .I4(\PC_reg[31]_i_10_n_0 ),
        .O(E));
  LUT6 #(
    .INIT(64'h0009000000000009)) 
    \PC_reg[31]_i_8 
       (.I0(\q_reg[6]_1 [43]),
        .I1(Q[4]),
        .I2(Q[5]),
        .I3(Q[6]),
        .I4(\q_reg[6]_1 [42]),
        .I5(Q[3]),
        .O(\PC_reg[31]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \PC_reg[31]_i_9 
       (.I0(Q[3]),
        .I1(\q_reg[6]_1 [39]),
        .I2(\q_reg[6]_1 [40]),
        .I3(Q[4]),
        .I4(\q_reg[6]_1 [43]),
        .I5(Q[5]),
        .O(\PC_reg[31]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8BBBBBBB88888)) 
    char_tab_i_103
       (.I0(D[35]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_121_n_0),
        .I3(\q[43]_i_2_n_0 ),
        .I4(\q[43]_i_3_n_0 ),
        .I5(char_tab_i_122_n_0),
        .O(char_tab_i_103_n_0));
  LUT5 #(
    .INIT(32'h28828228)) 
    char_tab_i_104
       (.I0(\q[67]_i_5_n_0 ),
        .I1(ALU_A[16]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[61]_i_10_n_0 ),
        .I4(\q[61]_i_8_n_0 ),
        .O(char_tab_i_104_n_0));
  LUT4 #(
    .INIT(16'h4F44)) 
    char_tab_i_105
       (.I0(\q[59]_i_5_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[59]_i_4_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(char_tab_i_105_n_0));
  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_107
       (.I0(ALU_A[12]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_123_n_0),
        .I3(ALU_A[16]),
        .I4(\PosX_reg_reg[4]_1 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_10 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    char_tab_i_110
       (.I0(ALU_B[12]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_124_n_0),
        .I3(\PosX_reg_reg[4] ),
        .I4(ALU_B[8]),
        .O(char_tab_i_110_n_0));
  LUT5 #(
    .INIT(32'h2EFF2E00)) 
    char_tab_i_111
       (.I0(ALU_A[3]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(\q[50]_i_6_n_0 ),
        .I3(\PosX_reg_reg[4] ),
        .I4(ALU_A[11]),
        .O(char_tab_i_111_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    char_tab_i_112
       (.I0(ALU_B[7]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(ALU_B[3]),
        .I3(\PosX_reg_reg[4] ),
        .I4(ALU_B[11]),
        .O(char_tab_i_112_n_0));
  LUT6 #(
    .INIT(64'hF011FFFFF0110000)) 
    char_tab_i_113
       (.I0(\q[50]_i_18_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[6]),
        .I3(r_ALUSrcB_ex[0]),
        .I4(\PosX_reg_reg[4]_2 ),
        .I5(ALU_B[2]),
        .O(char_tab_i_113_n_0));
  LUT6 #(
    .INIT(64'h00000000B8B800FF)) 
    char_tab_i_114
       (.I0(\q[50]_i_9_n_0 ),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(\q[45]_i_6_n_0 ),
        .I3(ALU_A[10]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_0 ),
        .O(char_tab_i_114_n_0));
  LUT6 #(
    .INIT(64'hFF0DFFFFFF0D0000)) 
    char_tab_i_115
       (.I0(char_tab_i_125_n_0),
        .I1(\q[49]_i_7_n_0 ),
        .I2(r_ALUCode_ex[3]),
        .I3(char_tab_i_126_n_0),
        .I4(\PosX_reg_reg[4]_2 ),
        .I5(D[33]),
        .O(char_tab_i_115_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    char_tab_i_117
       (.I0(ALU_B[5]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(ALU_B[1]),
        .I3(\PosX_reg_reg[4] ),
        .I4(ALU_B[9]),
        .O(char_tab_i_117_n_0));
  LUT5 #(
    .INIT(32'hF1FFF100)) 
    char_tab_i_118
       (.I0(\q[48]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(char_tab_i_127_n_0),
        .I3(\PosX_reg_reg[4]_2 ),
        .I4(D[32]),
        .O(char_tab_i_118_n_0));
  LUT6 #(
    .INIT(64'h656A000000000000)) 
    char_tab_i_121
       (.I0(\q[69]_i_7_n_0 ),
        .I1(char_tab_i_128_n_0),
        .I2(\q[71]_i_10_n_0 ),
        .I3(char_tab_i_129_n_0),
        .I4(\q[43]_i_4_n_0 ),
        .I5(\q[43]_i_5_n_0 ),
        .O(char_tab_i_121_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFF01515404)) 
    char_tab_i_122
       (.I0(char_tab_i_130_n_0),
        .I1(char_tab_i_129_n_0),
        .I2(\q[71]_i_10_n_0 ),
        .I3(char_tab_i_128_n_0),
        .I4(\q[43]_i_15_n_0 ),
        .I5(\q[43]_i_7_n_0 ),
        .O(char_tab_i_122_n_0));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    char_tab_i_123
       (.I0(\q[55]_i_19_n_0 ),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(\q[45]_i_16_n_0 ),
        .I3(\q[53]_i_9_n_0 ),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_0 ),
        .O(char_tab_i_123_n_0));
  LUT6 #(
    .INIT(64'hBBBB8888888B888B)) 
    char_tab_i_124
       (.I0(ALU_B[4]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(\q[54]_i_20_n_0 ),
        .I3(r_ALUSrcB_ex[1]),
        .I4(r_Imm_ex[0]),
        .I5(r_ALUSrcB_ex[0]),
        .O(char_tab_i_124_n_0));
  LUT5 #(
    .INIT(32'h54F504F5)) 
    char_tab_i_125
       (.I0(char_tab_i_131_n_0),
        .I1(\q[49]_i_14_n_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[49]_i_5_n_0 ),
        .O(char_tab_i_125_n_0));
  LUT4 #(
    .INIT(16'h4F44)) 
    char_tab_i_126
       (.I0(\q[49]_i_4_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[49]_i_3_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(char_tab_i_126_n_0));
  LUT4 #(
    .INIT(16'h4F44)) 
    char_tab_i_127
       (.I0(\q[48]_i_3_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[49]_i_4_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(char_tab_i_127_n_0));
  LUT4 #(
    .INIT(16'h2BB2)) 
    char_tab_i_128
       (.I0(\q[43]_i_14_n_0 ),
        .I1(\q_reg[73]_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[30]),
        .O(char_tab_i_128_n_0));
  LUT4 #(
    .INIT(16'h2BB2)) 
    char_tab_i_129
       (.I0(\q[43]_i_13_n_0 ),
        .I1(\q_reg[73]_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[30]),
        .O(char_tab_i_129_n_0));
  LUT3 #(
    .INIT(8'h8B)) 
    char_tab_i_13
       (.I0(char_tab_i_41_n_0),
        .I1(\PosX_reg_reg[6] ),
        .I2(\q[43]_i_12_n_0 ),
        .O(\TMDSn[2]_9 ));
  LUT4 #(
    .INIT(16'hD0FF)) 
    char_tab_i_130
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[43]_i_5_n_0 ),
        .O(char_tab_i_130_n_0));
  LUT6 #(
    .INIT(64'h0700000700070700)) 
    char_tab_i_131
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[50]_i_9_n_0 ),
        .I4(\q[50]_i_10_n_0 ),
        .I5(\q[50]_i_8_n_0 ),
        .O(char_tab_i_131_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    char_tab_i_15
       (.I0(char_tab_i_42_n_0),
        .I1(\PosX_reg_reg[4]_3 ),
        .I2(ALU_B[26]),
        .I3(\PosX_reg_reg[6] ),
        .I4(ALU_B[30]),
        .O(\TMDSn[2]_8 ));
  LUT3 #(
    .INIT(8'h8B)) 
    char_tab_i_20
       (.I0(char_tab_i_52_n_0),
        .I1(\PosX_reg_reg[6] ),
        .I2(\q[72]_i_8_n_0 ),
        .O(\TMDSn[2]_7 ));
  LUT3 #(
    .INIT(8'hB8)) 
    char_tab_i_34
       (.I0(D[46]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_76_n_0),
        .O(\TMDSn[2]_5 ));
  LUT5 #(
    .INIT(32'h740074FF)) 
    char_tab_i_41
       (.I0(\q[66]_i_7_n_0 ),
        .I1(\PosX_reg_reg[6]_0 ),
        .I2(char_tab_i_80_n_0),
        .I3(\PosX_reg_reg[4]_3 ),
        .I4(\q[70]_i_13_n_0 ),
        .O(char_tab_i_41_n_0));
  LUT5 #(
    .INIT(32'h8B8BBB88)) 
    char_tab_i_42
       (.I0(ALU_B[22]),
        .I1(\PosX_reg_reg[6]_0 ),
        .I2(\q[61]_i_7_n_0 ),
        .I3(char_tab_i_81_n_0),
        .I4(\PosX_reg_reg[4]_1 ),
        .O(char_tab_i_42_n_0));
  LUT6 #(
    .INIT(64'h00000000BABABABB)) 
    char_tab_i_50
       (.I0(char_tab_i_89_n_0),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[73]_i_3_n_0 ),
        .I3(\q[70]_i_4_n_0 ),
        .I4(char_tab_i_90_n_0),
        .I5(\PosX_reg_reg[6] ),
        .O(\TMDSn[2]_1 ));
  LUT5 #(
    .INIT(32'h740074FF)) 
    char_tab_i_52
       (.I0(\q[65]_i_12_n_0 ),
        .I1(\PosX_reg_reg[6]_0 ),
        .I2(char_tab_i_93_n_0),
        .I3(\PosX_reg_reg[4]_3 ),
        .I4(\q[68]_i_6_n_0 ),
        .O(char_tab_i_52_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFF00B0B0)) 
    char_tab_i_54
       (.I0(ALU_A[13]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_94_n_0),
        .I3(ALU_A[17]),
        .I4(\PosX_reg_reg[4]_1 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_11 ));
  LUT4 #(
    .INIT(16'h00AB)) 
    char_tab_i_59
       (.I0(char_tab_i_98_n_0),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[68]_i_2_n_0 ),
        .I3(\PosX_reg_reg[4]_3 ),
        .O(\TMDSn[2]_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    char_tab_i_63
       (.I0(D[39]),
        .I1(\PosX_reg_reg[4] ),
        .I2(char_tab_i_103_n_0),
        .I3(\PosX_reg_reg[4]_0 ),
        .I4(D[43]),
        .I5(\PosX_reg_reg[4]_1 ),
        .O(\TMDSn[2] ));
  LUT6 #(
    .INIT(64'hEEEEEEEEAEAEAEAA)) 
    char_tab_i_64
       (.I0(\PosX_reg_reg[6]_0 ),
        .I1(\PosX_reg_reg[4]_1 ),
        .I2(\q[59]_i_2_n_0 ),
        .I3(char_tab_i_104_n_0),
        .I4(\q[59]_i_6_n_0 ),
        .I5(char_tab_i_105_n_0),
        .O(\TMDSn[2]_2 ));
  LUT5 #(
    .INIT(32'h8B8BBB88)) 
    char_tab_i_71
       (.I0(ALU_B[20]),
        .I1(\PosX_reg_reg[6]_0 ),
        .I2(\q[61]_i_10_n_0 ),
        .I3(char_tab_i_110_n_0),
        .I4(\PosX_reg_reg[4]_1 ),
        .O(\TMDSn[2]_6 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    char_tab_i_76
       (.I0(D[38]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(D[34]),
        .I3(\PosX_reg_reg[4] ),
        .I4(D[42]),
        .O(char_tab_i_76_n_0));
  LUT6 #(
    .INIT(64'h0000000000FF4747)) 
    char_tab_i_78
       (.I0(ALU_A[15]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_111_n_0),
        .I3(ALU_A[19]),
        .I4(\PosX_reg_reg[4]_1 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_13 ));
  LUT5 #(
    .INIT(32'h55553F30)) 
    char_tab_i_80
       (.I0(\q[62]_i_11_n_0 ),
        .I1(\q[58]_i_11_n_0 ),
        .I2(\PosX_reg_reg[4]_0 ),
        .I3(char_tab_i_112_n_0),
        .I4(\PosX_reg_reg[4]_1 ),
        .O(char_tab_i_80_n_0));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    char_tab_i_81
       (.I0(ALU_B[14]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_113_n_0),
        .I3(\PosX_reg_reg[4] ),
        .I4(ALU_B[10]),
        .O(char_tab_i_81_n_0));
  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_87
       (.I0(ALU_A[14]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_114_n_0),
        .I3(ALU_A[18]),
        .I4(\PosX_reg_reg[4]_1 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_12 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    char_tab_i_88
       (.I0(D[45]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_115_n_0),
        .I3(\PosX_reg_reg[4] ),
        .I4(D[41]),
        .O(\TMDSn[2]_4 ));
  LUT4 #(
    .INIT(16'hF888)) 
    char_tab_i_89
       (.I0(\q[72]_i_4_n_0 ),
        .I1(\q[72]_i_3_n_0 ),
        .I2(\q_reg[74]_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(char_tab_i_89_n_0));
  LUT6 #(
    .INIT(64'h00000000D77D7DD7)) 
    char_tab_i_90
       (.I0(\q[67]_i_5_n_0 ),
        .I1(ALU_B[30]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q_reg[73]_0 ),
        .I4(\q[73]_i_7_n_0 ),
        .I5(\q[73]_i_6_n_0 ),
        .O(char_tab_i_90_n_0));
  LUT5 #(
    .INIT(32'hAAAACFC0)) 
    char_tab_i_93
       (.I0(ALU_B[17]),
        .I1(ALU_B[13]),
        .I2(\PosX_reg_reg[4]_0 ),
        .I3(char_tab_i_117_n_0),
        .I4(\PosX_reg_reg[4]_1 ),
        .O(char_tab_i_93_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFB8B8FF00)) 
    char_tab_i_94
       (.I0(ALU_A[5]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(ALU_A[1]),
        .I3(ALU_A[9]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_0 ),
        .O(char_tab_i_94_n_0));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    char_tab_i_97
       (.I0(D[44]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(char_tab_i_118_n_0),
        .I3(\PosX_reg_reg[4] ),
        .I4(D[40]),
        .O(\TMDSn[2]_3 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    char_tab_i_98
       (.I0(\q[68]_i_3_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[69]_i_5_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(char_tab_i_98_n_0));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[11]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[0]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [1]),
        .I4(r_rs2Data_ex[0]),
        .O(D[0]));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[13]_i_1__0 
       (.I0(r_rs2Data_ex[2]),
        .I1(\q_reg[74]_1 [2]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[2]),
        .I4(\q_reg[11]_0 ),
        .O(D[1]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[14]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[3]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [3]),
        .I4(r_rs2Data_ex[3]),
        .O(D[2]));
  LUT2 #(
    .INIT(4'hB)) 
    \q[155]_i_1 
       (.I0(SR),
        .I1(E),
        .O(\q[155]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[15]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[4]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [4]),
        .I4(r_rs2Data_ex[4]),
        .O(D[3]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[16]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[5]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [5]),
        .I4(r_rs2Data_ex[5]),
        .O(D[4]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[17]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[6]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [6]),
        .I4(r_rs2Data_ex[6]),
        .O(D[5]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[18]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[7]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [7]),
        .I4(r_rs2Data_ex[7]),
        .O(D[6]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[19]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[8]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [8]),
        .I4(r_rs2Data_ex[8]),
        .O(D[7]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[20]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[9]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [9]),
        .I4(r_rs2Data_ex[9]),
        .O(D[8]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[21]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[10]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [10]),
        .I4(r_rs2Data_ex[10]),
        .O(D[9]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[22]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[11]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [11]),
        .I4(r_rs2Data_ex[11]),
        .O(D[10]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[23]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[12]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [12]),
        .I4(r_rs2Data_ex[12]),
        .O(D[11]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[24]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[13]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [13]),
        .I4(r_rs2Data_ex[13]),
        .O(D[12]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[25]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[14]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [14]),
        .I4(r_rs2Data_ex[14]),
        .O(D[13]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[26]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[15]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [15]),
        .I4(r_rs2Data_ex[15]),
        .O(D[14]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[27]_i_1__0 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[16]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [16]),
        .I4(r_rs2Data_ex[16]),
        .O(D[15]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[28]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[17]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [17]),
        .I4(r_rs2Data_ex[17]),
        .O(D[16]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[29]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[18]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [18]),
        .I4(r_rs2Data_ex[18]),
        .O(D[17]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[30]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[19]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [19]),
        .I4(r_rs2Data_ex[19]),
        .O(D[18]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[31]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[20]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [20]),
        .I4(r_rs2Data_ex[20]),
        .O(D[19]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[32]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[21]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [21]),
        .I4(r_rs2Data_ex[21]),
        .O(D[20]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[33]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[22]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [22]),
        .I4(r_rs2Data_ex[22]),
        .O(D[21]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[34]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[23]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [23]),
        .I4(r_rs2Data_ex[23]),
        .O(D[22]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[35]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[24]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [24]),
        .I4(r_rs2Data_ex[24]),
        .O(D[23]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[36]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[25]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [25]),
        .I4(r_rs2Data_ex[25]),
        .O(D[24]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[37]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[26]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [26]),
        .I4(r_rs2Data_ex[26]),
        .O(D[25]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[38]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[27]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [27]),
        .I4(r_rs2Data_ex[27]),
        .O(D[26]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[39]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[28]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [28]),
        .I4(r_rs2Data_ex[28]),
        .O(D[27]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[40]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[29]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [29]),
        .I4(r_rs2Data_ex[29]),
        .O(D[28]));
  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[41]_i_1 
       (.I0(\q_reg[11]_0 ),
        .I1(w_RegWriteData_wb[30]),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[74]_1 [30]),
        .I4(r_rs2Data_ex[30]),
        .O(D[29]));
  LUT5 #(
    .INIT(32'hACACFF0C)) 
    \q[42]_i_1 
       (.I0(r_rs2Data_ex[31]),
        .I1(\q_reg[74]_1 [31]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[31]),
        .I4(\q_reg[11]_0 ),
        .O(D[30]));
  LUT5 #(
    .INIT(32'hFFFFFFF2)) 
    \q[42]_i_3 
       (.I0(\q_reg[11]_1 ),
        .I1(\q_reg[5]_0 ),
        .I2(\q_reg[11]_2 ),
        .I3(\q_reg[2]_0 ),
        .I4(\q_reg[6]_3 ),
        .O(\q_reg[11]_0 ));
  LUT3 #(
    .INIT(8'h41)) 
    \q[42]_i_6 
       (.I0(Q[9]),
        .I1(Q[7]),
        .I2(\q_reg[74]_1 [0]),
        .O(\q_reg[11]_1 ));
  LUT3 #(
    .INIT(8'hBE)) 
    \q[42]_i_7 
       (.I0(Q[9]),
        .I1(Q[8]),
        .I2(\q_reg[1]_0 ),
        .O(\q_reg[11]_2 ));
  LUT6 #(
    .INIT(64'hFBBBBBBBCB888888)) 
    \q[43]_i_1 
       (.I0(\q[43]_i_2_n_0 ),
        .I1(\q[43]_i_3_n_0 ),
        .I2(\q[43]_i_4_n_0 ),
        .I3(\q[43]_i_5_n_0 ),
        .I4(\q[43]_i_6_n_0 ),
        .I5(\q[43]_i_7_n_0 ),
        .O(D[31]));
  LUT5 #(
    .INIT(32'h959595A6)) 
    \q[43]_i_10 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(r_ALUSrcB_ex[0]),
        .I2(r_Imm_ex[0]),
        .I3(r_ALUSrcB_ex[1]),
        .I4(\q[54]_i_20_n_0 ),
        .O(\q[43]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFBFBB)) 
    \q[43]_i_11 
       (.I0(\q[43]_i_12_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[74]_0 ),
        .O(\q[43]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h5C5F)) 
    \q[43]_i_12 
       (.I0(r_Imm_ex[16]),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_ALUSrcB_ex[0]),
        .I3(D[30]),
        .O(\q[43]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hC413DFF7)) 
    \q[43]_i_13 
       (.I0(\q_reg[71]_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q_reg[71]_1 ),
        .I3(\q[72]_i_8_n_0 ),
        .I4(\q_reg[72]_0 ),
        .O(\q[43]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h0801AB5D)) 
    \q[43]_i_14 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(\q_reg[71]_1 ),
        .I2(\q_reg[71]_0 ),
        .I3(\q[72]_i_8_n_0 ),
        .I4(\q_reg[72]_0 ),
        .O(\q[43]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hEEBF1140)) 
    \q[43]_i_15 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[43]_i_5_n_0 ),
        .O(\q[43]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h8888BB8B)) 
    \q[43]_i_16 
       (.I0(\q[44]_i_8_n_0 ),
        .I1(ALU_B[0]),
        .I2(ALU_B[1]),
        .I3(\q[43]_i_19_n_0 ),
        .I4(\q[43]_i_20_n_0 ),
        .O(\q[43]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hAFCFA0CFAFC0A0C0)) 
    \q[43]_i_17 
       (.I0(\q[49]_i_17_n_0 ),
        .I1(\q[45]_i_15_n_0 ),
        .I2(ALU_B[1]),
        .I3(ALU_B[2]),
        .I4(\q[47]_i_10_n_0 ),
        .I5(\q[43]_i_21_n_0 ),
        .O(\q[43]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h4444444451515351)) 
    \q[43]_i_18 
       (.I0(r_ALUCode_ex[1]),
        .I1(ALU_B[0]),
        .I2(r_ALUCode_ex[0]),
        .I3(\q[45]_i_14_n_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .I5(\q[45]_i_16_n_0 ),
        .O(\q[43]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[43]_i_19 
       (.I0(\q[49]_i_17_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[45]_i_15_n_0 ),
        .O(\q[43]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h55544454FFFFFFFF)) 
    \q[43]_i_2 
       (.I0(\q[43]_i_8_n_0 ),
        .I1(\q[70]_i_4_n_0 ),
        .I2(\q[43]_i_9_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[43]_i_10_n_0 ),
        .I5(\q[43]_i_11_n_0 ),
        .O(\q[43]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h0035)) 
    \q[43]_i_20 
       (.I0(\q[43]_i_21_n_0 ),
        .I1(\q[47]_i_10_n_0 ),
        .I2(ALU_B[2]),
        .I3(ALU_B[1]),
        .O(\q[43]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h5500CCF055FFCCF0)) 
    \q[43]_i_21 
       (.I0(\q_reg[67]_0 ),
        .I1(\q[53]_i_9_n_0 ),
        .I2(\q[45]_i_16_n_0 ),
        .I3(ALU_B[3]),
        .I4(ALU_B[4]),
        .I5(ALU_A[16]),
        .O(\q[43]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \q[43]_i_3 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[3]),
        .O(\q[43]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h8A)) 
    \q[43]_i_4 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .O(\q[43]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \q[43]_i_5 
       (.I0(\q_reg[74]_0 ),
        .I1(\q[43]_i_12_n_0 ),
        .O(\q[43]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h444DDD4DBBB222B2)) 
    \q[43]_i_6 
       (.I0(\q[73]_i_9_n_0 ),
        .I1(\q_reg[73]_0 ),
        .I2(\q[43]_i_13_n_0 ),
        .I3(\q[71]_i_10_n_0 ),
        .I4(\q[43]_i_14_n_0 ),
        .I5(\q[43]_i_15_n_0 ),
        .O(\q[43]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h5DFF510051005100)) 
    \q[43]_i_7 
       (.I0(\q[43]_i_16_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(\q_reg[74]_0 ),
        .I5(\q[43]_i_12_n_0 ),
        .O(\q[43]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAAFB0000AABBAAAA)) 
    \q[43]_i_8 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[0]),
        .I2(\q[45]_i_16_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[43]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF47000000)) 
    \q[43]_i_9 
       (.I0(\q[44]_i_8_n_0 ),
        .I1(ALU_B[0]),
        .I2(\q[43]_i_17_n_0 ),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[43]_i_18_n_0 ),
        .O(\q[43]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF5454FF54)) 
    \q[44]_i_1 
       (.I0(\q[44]_i_2_n_0 ),
        .I1(\q[44]_i_3_n_0 ),
        .I2(\q[44]_i_4_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q[44]_i_5_n_0 ),
        .I5(\q[44]_i_6_n_0 ),
        .O(D[32]));
  LUT6 #(
    .INIT(64'hAAFFFEFEAA000202)) 
    \q[44]_i_10 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(\q[54]_i_20_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_Imm_ex[0]),
        .I4(r_ALUSrcB_ex[0]),
        .I5(\q[69]_i_7_n_0 ),
        .O(\q[44]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00DAFF00)) 
    \q[44]_i_11 
       (.I0(ALU_A[1]),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[1]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[44]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[44]_i_13 
       (.I0(Q[28]),
        .I1(r_PC_ex[1]),
        .O(\q[44]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h5030503F5F305F3F)) 
    \q[44]_i_14 
       (.I0(\q_reg[68]_0 ),
        .I1(ALU_A[9]),
        .I2(ALU_B[3]),
        .I3(ALU_B[4]),
        .I4(ALU_A[1]),
        .I5(ALU_A[17]),
        .O(\q[44]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \q[44]_i_15 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_B[4]),
        .O(\q[44]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[44]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[1]),
        .I2(ALU_A[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[44]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \q[44]_i_3 
       (.I0(\q[52]_i_8_n_0 ),
        .I1(\q[44]_i_8_n_0 ),
        .I2(\q[45]_i_9_n_0 ),
        .I3(\q[44]_i_9_n_0 ),
        .I4(\q[45]_i_8_n_0 ),
        .I5(\q[54]_i_10_n_0 ),
        .O(\q[44]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69009600)) 
    \q[44]_i_4 
       (.I0(ALU_A[1]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[44]_i_10_n_0 ),
        .I5(\q[44]_i_11_n_0 ),
        .O(\q[44]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h2AAA)) 
    \q[44]_i_5 
       (.I0(\q[45]_i_8_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[52]_i_14_n_0 ),
        .I3(ALU_B[1]),
        .O(\q[44]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[44]_i_6 
       (.I0(\q[72]_i_4_n_0 ),
        .I1(\q[44]_i_8_n_0 ),
        .O(\q[44]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B3FF80FF)) 
    \q[44]_i_7 
       (.I0(r_rs1Data_ex[1]),
        .I1(\q_reg[6]_0 ),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[148]_1 ),
        .I4(w_RegWriteData_wb[1]),
        .I5(\q[44]_i_13_n_0 ),
        .O(ALU_A[1]));
  LUT6 #(
    .INIT(64'hAFCFA0CFAFC0A0C0)) 
    \q[44]_i_8 
       (.I0(\q[49]_i_16_n_0 ),
        .I1(\q[46]_i_14_n_0 ),
        .I2(ALU_B[1]),
        .I3(ALU_B[2]),
        .I4(\q[48]_i_10_n_0 ),
        .I5(\q[44]_i_14_n_0 ),
        .O(\q[44]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h2F002200)) 
    \q[44]_i_9 
       (.I0(\q[54]_i_24_n_0 ),
        .I1(\q[44]_i_15_n_0 ),
        .I2(\q[45]_i_13_n_0 ),
        .I3(\q[45]_i_14_n_0 ),
        .I4(\q[54]_i_26_n_0 ),
        .O(\q[44]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF5454FF54)) 
    \q[45]_i_1 
       (.I0(\q[45]_i_2_n_0 ),
        .I1(\q[45]_i_3_n_0 ),
        .I2(\q[45]_i_4_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q[46]_i_4_n_0 ),
        .I5(\q[45]_i_5_n_0 ),
        .O(D[33]));
  LUT5 #(
    .INIT(32'hF7404F07)) 
    \q[45]_i_10 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(ALU_B[0]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_A[1]),
        .I4(ALU_B[1]),
        .O(\q[45]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00CBFF00)) 
    \q[45]_i_11 
       (.I0(r_ALUCode_ex[0]),
        .I1(ALU_B[2]),
        .I2(\q[45]_i_6_n_0 ),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[45]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \q[45]_i_13 
       (.I0(ALU_B[3]),
        .I1(ALU_B[4]),
        .I2(ALU_A[1]),
        .O(\q[45]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[45]_i_14 
       (.I0(ALU_B[2]),
        .I1(ALU_B[1]),
        .O(\q[45]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h55330FFF55330F00)) 
    \q[45]_i_15 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_A[10]),
        .I2(ALU_A[18]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q[45]_i_6_n_0 ),
        .O(\q[45]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[45]_i_16 
       (.I0(\q[45]_i_17_n_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(w_RegWriteData_wb[0]),
        .I3(\q_reg[148]_0 ),
        .I4(\q_reg[4]_0 ),
        .I5(r_rs1Data_ex[0]),
        .O(\q[45]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[45]_i_17 
       (.I0(Q[28]),
        .I1(r_PC_ex[0]),
        .O(\q[45]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hAFABAAAAABABAAAA)) 
    \q[45]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[2]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[45]_i_6_n_0 ),
        .O(\q[45]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \q[45]_i_3 
       (.I0(\q[52]_i_8_n_0 ),
        .I1(\q[46]_i_9_n_0 ),
        .I2(\q[54]_i_10_n_0 ),
        .I3(\q[45]_i_7_n_0 ),
        .I4(\q[45]_i_8_n_0 ),
        .I5(\q[45]_i_9_n_0 ),
        .O(\q[45]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF28828228)) 
    \q[45]_i_4 
       (.I0(\q[67]_i_5_n_0 ),
        .I1(\q[45]_i_6_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[45]_i_10_n_0 ),
        .I5(\q[45]_i_11_n_0 ),
        .O(\q[45]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h8000AAAA)) 
    \q[45]_i_5 
       (.I0(\q[72]_i_4_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[52]_i_14_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[45]_i_8_n_0 ),
        .O(\q[45]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'hF4)) 
    \q[45]_i_6 
       (.I0(r_PC_ex[2]),
        .I1(Q[28]),
        .I2(\q_reg[148]_2 ),
        .O(\q[45]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h40FF4040)) 
    \q[45]_i_7 
       (.I0(\q[45]_i_13_n_0 ),
        .I1(\q[45]_i_14_n_0 ),
        .I2(\q[54]_i_24_n_0 ),
        .I3(\q[46]_i_12_n_0 ),
        .I4(\q[54]_i_26_n_0 ),
        .O(\q[45]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[45]_i_8 
       (.I0(\q[49]_i_10_n_0 ),
        .I1(\q[47]_i_10_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[49]_i_17_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[45]_i_15_n_0 ),
        .O(\q[45]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h2A2A2A08)) 
    \q[45]_i_9 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUSrcB_ex[0]),
        .I2(r_Imm_ex[0]),
        .I3(r_ALUSrcB_ex[1]),
        .I4(\q[54]_i_20_n_0 ),
        .O(\q[45]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[46]_i_1 
       (.I0(\q[46]_i_2_n_0 ),
        .I1(\q[46]_i_3_n_0 ),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[47]_i_3_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[46]_i_4_n_0 ),
        .O(D[34]));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[46]_i_10 
       (.I0(r_rs2Data_ex[3]),
        .I1(\q_reg[74]_1 [3]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[3]),
        .I4(\q_reg[11]_0 ),
        .O(\q[46]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[46]_i_11 
       (.I0(r_rs1Data_ex[3]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [3]),
        .I4(w_RegWriteData_wb[3]),
        .I5(\q_reg[6]_0 ),
        .O(\q[46]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFCFFFA)) 
    \q[46]_i_12 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(\q[45]_i_16_n_0 ),
        .I2(ALU_B[3]),
        .I3(ALU_B[4]),
        .I4(ALU_B[1]),
        .I5(ALU_B[2]),
        .O(\q[46]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h60F600009F090000)) 
    \q[46]_i_13 
       (.I0(ALU_B[2]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q[45]_i_6_n_0 ),
        .I3(\q[45]_i_10_n_0 ),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[46]_i_15_n_0 ),
        .O(\q[46]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h55330F0055330FFF)) 
    \q[46]_i_14 
       (.I0(\q_reg[70]_0 ),
        .I1(ALU_A[11]),
        .I2(ALU_A[19]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[3]),
        .O(\q[46]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h55556599AAAA9A66)) 
    \q[46]_i_15 
       (.I0(ALU_A[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[3]),
        .O(\q[46]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[46]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[3]),
        .I2(ALU_A[3]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[46]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000F200)) 
    \q[46]_i_3 
       (.I0(\q[54]_i_10_n_0 ),
        .I1(\q[47]_i_7_n_0 ),
        .I2(\q[46]_i_7_n_0 ),
        .I3(r_ALUCode_ex[1]),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[46]_i_8_n_0 ),
        .O(\q[46]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h2AAA)) 
    \q[46]_i_4 
       (.I0(\q[46]_i_9_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[52]_i_14_n_0 ),
        .I3(ALU_B[1]),
        .O(\q[46]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[46]_i_5 
       (.I0(\q[46]_i_10_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[3]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[3]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[46]_i_6 
       (.I0(\q[46]_i_11_n_0 ),
        .I1(r_PC_ex[3]),
        .I2(Q[28]),
        .O(ALU_A[3]));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[46]_i_7 
       (.I0(\q[46]_i_9_n_0 ),
        .I1(\q[45]_i_9_n_0 ),
        .I2(\q[54]_i_26_n_0 ),
        .I3(\q[47]_i_8_n_0 ),
        .I4(\q[54]_i_24_n_0 ),
        .I5(\q[46]_i_12_n_0 ),
        .O(\q[46]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hBEBEBEBABABEBEBA)) 
    \q[46]_i_8 
       (.I0(\q[46]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(ALU_A[3]),
        .I4(ALU_B[3]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[46]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[46]_i_9 
       (.I0(\q[52]_i_20_n_0 ),
        .I1(\q[48]_i_10_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[49]_i_16_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[46]_i_14_n_0 ),
        .O(\q[46]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h11F111F1FFFF11F1)) 
    \q[47]_i_1 
       (.I0(\q[47]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[48]_i_3_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[47]_i_3_n_0 ),
        .O(D[35]));
  LUT6 #(
    .INIT(64'h33550FFF33550F00)) 
    \q[47]_i_10 
       (.I0(ALU_A[12]),
        .I1(\q_reg[71]_0 ),
        .I2(\q_reg[63]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q[55]_i_19_n_0 ),
        .O(\q[47]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h000022F7)) 
    \q[47]_i_2 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .I2(\q[47]_i_4_n_0 ),
        .I3(\q[47]_i_5_n_0 ),
        .I4(\q[47]_i_6_n_0 ),
        .O(\q[47]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \q[47]_i_3 
       (.I0(\q[52]_i_14_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[47]_i_7_n_0 ),
        .O(\q[47]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFCAF0CA0FCA00CA)) 
    \q[47]_i_4 
       (.I0(\q[48]_i_8_n_0 ),
        .I1(\q[47]_i_7_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[47]_i_8_n_0 ),
        .I5(\q[48]_i_7_n_0 ),
        .O(\q[47]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000055CF55C355)) 
    \q[47]_i_5 
       (.I0(\q[47]_i_9_n_0 ),
        .I1(ALU_B[4]),
        .I2(\q[55]_i_19_n_0 ),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[0]),
        .I5(r_ALUCode_ex[1]),
        .O(\q[47]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h00080808)) 
    \q[47]_i_6 
       (.I0(ALU_B[4]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[55]_i_19_n_0 ),
        .I4(r_ALUCode_ex[0]),
        .O(\q[47]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[47]_i_7 
       (.I0(\q[52]_i_12_n_0 ),
        .I1(\q[49]_i_17_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[49]_i_10_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[47]_i_10_n_0 ),
        .O(\q[47]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFF0DD)) 
    \q[47]_i_8 
       (.I0(ALU_A[3]),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q[45]_i_13_n_0 ),
        .I3(ALU_B[1]),
        .I4(ALU_B[2]),
        .O(\q[47]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \q[47]_i_9 
       (.I0(\q[55]_i_9_n_0 ),
        .I1(ALU_B[4]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[55]_i_19_n_0 ),
        .O(\q[47]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h11F111F1FFFF11F1)) 
    \q[48]_i_1 
       (.I0(\q[48]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[49]_i_4_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[48]_i_3_n_0 ),
        .O(D[36]));
  LUT6 #(
    .INIT(64'h55330F0055330FFF)) 
    \q[48]_i_10 
       (.I0(\q_reg[72]_0 ),
        .I1(ALU_A[13]),
        .I2(\q_reg[64]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[5]),
        .O(\q[48]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h000022F7)) 
    \q[48]_i_2 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .I2(\q[48]_i_4_n_0 ),
        .I3(\q[48]_i_5_n_0 ),
        .I4(\q[48]_i_6_n_0 ),
        .O(\q[48]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \q[48]_i_3 
       (.I0(\q[52]_i_14_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[48]_i_7_n_0 ),
        .O(\q[48]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFCCAAF000CCAA)) 
    \q[48]_i_4 
       (.I0(\q[49]_i_13_n_0 ),
        .I1(\q[48]_i_7_n_0 ),
        .I2(\q[49]_i_12_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[48]_i_8_n_0 ),
        .O(\q[48]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000E060000FEF6F)) 
    \q[48]_i_5 
       (.I0(ALU_B[5]),
        .I1(ALU_A[5]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[48]_i_9_n_0 ),
        .O(\q[48]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h08080008)) 
    \q[48]_i_6 
       (.I0(ALU_B[5]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[5]),
        .O(\q[48]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[48]_i_7 
       (.I0(\q[54]_i_27_n_0 ),
        .I1(\q[49]_i_16_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[52]_i_20_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[48]_i_10_n_0 ),
        .O(\q[48]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFAFFFAFFFAFCFA0C)) 
    \q[48]_i_8 
       (.I0(\q[44]_i_15_n_0 ),
        .I1(\q[55]_i_19_n_0 ),
        .I2(ALU_B[1]),
        .I3(ALU_B[2]),
        .I4(\q[45]_i_6_n_0 ),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[48]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h9666996966699699)) 
    \q[48]_i_9 
       (.I0(ALU_B[5]),
        .I1(ALU_A[5]),
        .I2(\q[55]_i_19_n_0 ),
        .I3(\q[69]_i_7_n_0 ),
        .I4(ALU_B[4]),
        .I5(\q[55]_i_9_n_0 ),
        .O(\q[48]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h11F111F1FFFF11F1)) 
    \q[49]_i_1 
       (.I0(\q[49]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[49]_i_3_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[49]_i_4_n_0 ),
        .O(D[37]));
  LUT5 #(
    .INIT(32'hF05CFF5C)) 
    \q[49]_i_10 
       (.I0(\q_reg[67]_0 ),
        .I1(\q[53]_i_9_n_0 ),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(ALU_A[16]),
        .O(\q[49]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[49]_i_11 
       (.I0(\q[52]_i_12_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[49]_i_17_n_0 ),
        .O(\q[49]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[49]_i_12 
       (.I0(\q[49]_i_9_n_0 ),
        .I1(\q[49]_i_10_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[52]_i_12_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[49]_i_17_n_0 ),
        .O(\q[49]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFAFFFAFFFA03FAF3)) 
    \q[49]_i_13 
       (.I0(\q[45]_i_13_n_0 ),
        .I1(ALU_A[5]),
        .I2(ALU_B[1]),
        .I3(ALU_B[2]),
        .I4(ALU_A[3]),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[49]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h00FFFCFC55000101)) 
    \q[49]_i_14 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q[50]_i_18_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_Imm_ex[6]),
        .I4(r_ALUSrcB_ex[0]),
        .I5(\q[50]_i_9_n_0 ),
        .O(\q[49]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[49]_i_15 
       (.I0(\q[73]_i_21_n_0 ),
        .I1(\q_reg[11]_0 ),
        .I2(w_RegWriteData_wb[6]),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[74]_1 [6]),
        .I5(r_rs2Data_ex[6]),
        .O(\q[49]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h33550FFF33550F00)) 
    \q[49]_i_16 
       (.I0(ALU_A[15]),
        .I1(\q_reg[74]_0 ),
        .I2(\q_reg[66]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q[50]_i_6_n_0 ),
        .O(\q[49]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h55330FFF55330F00)) 
    \q[49]_i_17 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_A[14]),
        .I2(\q_reg[65]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q[50]_i_9_n_0 ),
        .O(\q[49]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h000022F7)) 
    \q[49]_i_2 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .I2(\q[49]_i_5_n_0 ),
        .I3(\q[49]_i_6_n_0 ),
        .I4(\q[49]_i_7_n_0 ),
        .O(\q[49]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[49]_i_3 
       (.I0(\q[49]_i_8_n_0 ),
        .I1(\q[52]_i_14_n_0 ),
        .O(\q[49]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00330000B8FFB800)) 
    \q[49]_i_4 
       (.I0(\q[49]_i_9_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[49]_i_10_n_0 ),
        .I3(ALU_B[1]),
        .I4(\q[49]_i_11_n_0 ),
        .I5(\q[52]_i_14_n_0 ),
        .O(\q[49]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFCCAAF000CCAA)) 
    \q[49]_i_5 
       (.I0(\q[50]_i_19_n_0 ),
        .I1(\q[49]_i_12_n_0 ),
        .I2(\q[49]_i_8_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[49]_i_13_n_0 ),
        .O(\q[49]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h96969696000000FF)) 
    \q[49]_i_6 
       (.I0(\q[50]_i_8_n_0 ),
        .I1(\q[50]_i_10_n_0 ),
        .I2(\q[50]_i_9_n_0 ),
        .I3(\q[49]_i_14_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[49]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000F800F800F800)) 
    \q[49]_i_7 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[6]),
        .I2(\q[49]_i_15_n_0 ),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q[50]_i_9_n_0 ),
        .I5(r_ALUCode_ex[0]),
        .O(\q[49]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[49]_i_8 
       (.I0(\q[56]_i_16_n_0 ),
        .I1(\q[52]_i_20_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[54]_i_27_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[49]_i_16_n_0 ),
        .O(\q[49]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hF035FF35)) 
    \q[49]_i_9 
       (.I0(ALU_A[12]),
        .I1(\q_reg[71]_0 ),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q_reg[63]_0 ),
        .O(\q[49]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h7772888D)) 
    \q[50]_i_10 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[6]),
        .I2(r_ALUSrcB_ex[1]),
        .I3(\q[50]_i_18_n_0 ),
        .I4(\q[69]_i_7_n_0 ),
        .O(\q[50]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFCCAAF000CCAAF0)) 
    \q[50]_i_11 
       (.I0(\q[49]_i_8_n_0 ),
        .I1(\q[50]_i_19_n_0 ),
        .I2(\q[50]_i_20_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[51]_i_6_n_0 ),
        .O(\q[50]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[50]_i_12 
       (.I0(r_Imm_ex[7]),
        .I1(\q[50]_i_15_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[7]));
  LUT2 #(
    .INIT(4'h2)) 
    \q[50]_i_13 
       (.I0(Q[28]),
        .I1(r_PC_ex[7]),
        .O(\q[50]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[50]_i_15 
       (.I0(r_rs2Data_ex[7]),
        .I1(\q_reg[74]_1 [7]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[7]),
        .I4(\q_reg[11]_0 ),
        .O(\q[50]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[50]_i_16 
       (.I0(Q[28]),
        .I1(r_PC_ex[6]),
        .O(\q[50]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[50]_i_18 
       (.I0(r_rs2Data_ex[6]),
        .I1(\q_reg[74]_1 [6]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[6]),
        .I4(\q_reg[11]_0 ),
        .O(\q[50]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBB8BBB888)) 
    \q[50]_i_19 
       (.I0(\q[50]_i_21_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[45]_i_6_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[50]_i_9_n_0 ),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[50]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[50]_i_1__0 
       (.I0(\q[50]_i_2_n_0 ),
        .I1(\q[50]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[50]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[50]_i_5_n_0 ),
        .O(D[38]));
  LUT6 #(
    .INIT(64'h99696966FFFFFFFF)) 
    \q[50]_i_2 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(\q[50]_i_7_n_0 ),
        .I2(\q[50]_i_8_n_0 ),
        .I3(\q[50]_i_9_n_0 ),
        .I4(\q[50]_i_10_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[50]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBB8BBB8B88)) 
    \q[50]_i_20 
       (.I0(\q[50]_i_22_n_0 ),
        .I1(ALU_B[1]),
        .I2(ALU_A[3]),
        .I3(ALU_B[2]),
        .I4(\q[50]_i_6_n_0 ),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[50]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hFFFBFFF8)) 
    \q[50]_i_21 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(ALU_B[2]),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q[55]_i_19_n_0 ),
        .O(\q[50]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hFFF4FFF7)) 
    \q[50]_i_22 
       (.I0(ALU_A[1]),
        .I1(ALU_B[2]),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(ALU_A[5]),
        .O(\q[50]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h5555F0CF44440000)) 
    \q[50]_i_3 
       (.I0(\q[50]_i_11_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[7]),
        .I3(\q[50]_i_6_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[50]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00080808)) 
    \q[50]_i_4 
       (.I0(ALU_B[7]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q[50]_i_6_n_0 ),
        .I4(r_ALUCode_ex[0]),
        .O(\q[50]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[50]_i_5 
       (.I0(\q[49]_i_3_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[51]_i_4_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[50]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[50]_i_6 
       (.I0(\q[50]_i_13_n_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(w_RegWriteData_wb[7]),
        .I3(\q_reg[148]_4 ),
        .I4(\q_reg[4]_0 ),
        .I5(r_rs1Data_ex[7]),
        .O(\q[50]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h54FEAB01)) 
    \q[50]_i_7 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_ALUSrcB_ex[1]),
        .I2(\q[50]_i_15_n_0 ),
        .I3(r_Imm_ex[7]),
        .I4(\q[69]_i_7_n_0 ),
        .O(\q[50]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hF1F770107F1F0107)) 
    \q[50]_i_8 
       (.I0(\q[55]_i_9_n_0 ),
        .I1(\q[55]_i_19_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_A[5]),
        .I5(ALU_B[5]),
        .O(\q[50]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[50]_i_9 
       (.I0(\q[50]_i_16_n_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(w_RegWriteData_wb[6]),
        .I3(\q_reg[148]_3 ),
        .I4(\q_reg[4]_0 ),
        .I5(r_rs1Data_ex[6]),
        .O(\q[50]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[51]_i_1__0 
       (.I0(\q[51]_i_2_n_0 ),
        .I1(\q[51]_i_3_n_0 ),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[52]_i_5_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[51]_i_4_n_0 ),
        .O(D[39]));
  LUT6 #(
    .INIT(64'hAFABAAAAABABAAAA)) 
    \q[51]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[8]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(\q[53]_i_9_n_0 ),
        .O(\q[51]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF96690000)) 
    \q[51]_i_3 
       (.I0(\q[53]_i_8_n_0 ),
        .I1(ALU_B[8]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[53]_i_9_n_0 ),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[51]_i_5_n_0 ),
        .O(\q[51]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[51]_i_4 
       (.I0(\q[51]_i_6_n_0 ),
        .I1(\q[52]_i_14_n_0 ),
        .O(\q[51]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C707C707C7C707C)) 
    \q[51]_i_5 
       (.I0(\q[51]_i_7_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(ALU_B[8]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[53]_i_9_n_0 ),
        .O(\q[51]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[51]_i_6 
       (.I0(\q[52]_i_11_n_0 ),
        .I1(\q[52]_i_12_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[49]_i_9_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[49]_i_10_n_0 ),
        .O(\q[51]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFCAF0CA0FCA00CA)) 
    \q[51]_i_7 
       (.I0(\q[52]_i_18_n_0 ),
        .I1(\q[51]_i_6_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[50]_i_20_n_0 ),
        .I5(\q[52]_i_15_n_0 ),
        .O(\q[51]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[52]_i_10 
       (.I0(\q[52]_i_19_n_0 ),
        .I1(\q[49]_i_9_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[52]_i_11_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[52]_i_12_n_0 ),
        .O(\q[52]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hF053FF53)) 
    \q[52]_i_11 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_A[14]),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q_reg[65]_0 ),
        .O(\q[52]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hF5F503F3)) 
    \q[52]_i_12 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_A[10]),
        .I2(ALU_B[3]),
        .I3(ALU_A[18]),
        .I4(ALU_B[4]),
        .O(\q[52]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h00307474)) 
    \q[52]_i_13 
       (.I0(\q[52]_i_19_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[49]_i_9_n_0 ),
        .I3(ALU_B[3]),
        .I4(\q[59]_i_7_n_0 ),
        .O(\q[52]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h80)) 
    \q[52]_i_14 
       (.I0(\q_reg[74]_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .O(\q[52]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[52]_i_15 
       (.I0(\q[56]_i_14_n_0 ),
        .I1(\q[54]_i_27_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[56]_i_16_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[52]_i_20_n_0 ),
        .O(\q[52]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[52]_i_16 
       (.I0(ALU_B[8]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[52]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[52]_i_17 
       (.I0(ALU_B[9]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[52]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFB8FFFFFFB80000)) 
    \q[52]_i_18 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[50]_i_9_n_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[54]_i_28_n_0 ),
        .O(\q[52]_i_18_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[52]_i_19 
       (.I0(\q_reg[67]_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_A[16]),
        .I3(ALU_B[4]),
        .O(\q[52]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[52]_i_1__0 
       (.I0(\q[52]_i_2_n_0 ),
        .I1(\q[52]_i_3_n_0 ),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[52]_i_4_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[52]_i_5_n_0 ),
        .O(D[40]));
  LUT6 #(
    .INIT(64'hAABFAABBAAAAAAAA)) 
    \q[52]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[9]),
        .I2(ALU_A[9]),
        .I3(r_ALUCode_ex[2]),
        .I4(r_ALUCode_ex[0]),
        .I5(r_ALUCode_ex[1]),
        .O(\q[52]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF053FF53)) 
    \q[52]_i_20 
       (.I0(\q_reg[68]_0 ),
        .I1(ALU_A[9]),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(ALU_A[17]),
        .O(\q[52]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hFEEEFEFEFEEEFEEE)) 
    \q[52]_i_3 
       (.I0(\q[52]_i_6_n_0 ),
        .I1(\q[52]_i_7_n_0 ),
        .I2(\q[52]_i_8_n_0 ),
        .I3(\q[52]_i_9_n_0 ),
        .I4(\q[52]_i_10_n_0 ),
        .I5(\q[54]_i_10_n_0 ),
        .O(\q[52]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF000000FF00B8B8)) 
    \q[52]_i_4 
       (.I0(\q[52]_i_11_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[52]_i_12_n_0 ),
        .I3(\q[52]_i_13_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[52]_i_14_n_0 ),
        .O(\q[52]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[52]_i_5 
       (.I0(\q[52]_i_15_n_0 ),
        .I1(\q[52]_i_14_n_0 ),
        .O(\q[52]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hA880022A022AA880)) 
    \q[52]_i_6 
       (.I0(\q[67]_i_5_n_0 ),
        .I1(\q[53]_i_9_n_0 ),
        .I2(\q[52]_i_16_n_0 ),
        .I3(\q[53]_i_8_n_0 ),
        .I4(ALU_A[9]),
        .I5(\q[52]_i_17_n_0 ),
        .O(\q[52]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h00DAFF00)) 
    \q[52]_i_7 
       (.I0(ALU_A[9]),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[9]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .O(\q[52]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'hA8)) 
    \q[52]_i_8 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[2]),
        .O(\q[52]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h44F4FFFF44F444F4)) 
    \q[52]_i_9 
       (.I0(\q[52]_i_15_n_0 ),
        .I1(\q[45]_i_9_n_0 ),
        .I2(\q[54]_i_26_n_0 ),
        .I3(\q[53]_i_21_n_0 ),
        .I4(\q[52]_i_18_n_0 ),
        .I5(\q[54]_i_24_n_0 ),
        .O(\q[52]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[53]_i_10 
       (.I0(\q[73]_i_21_n_0 ),
        .I1(\q_reg[11]_0 ),
        .I2(w_RegWriteData_wb[8]),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[74]_1 [8]),
        .I5(r_rs2Data_ex[8]),
        .O(ALU_B[8]));
  LUT6 #(
    .INIT(64'h5554551055105510)) 
    \q[53]_i_11 
       (.I0(\q[53]_i_19_n_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(w_RegWriteData_wb[9]),
        .I3(\q_reg[148]_6 ),
        .I4(\q_reg[4]_0 ),
        .I5(r_rs1Data_ex[9]),
        .O(ALU_A[9]));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[53]_i_12 
       (.I0(\q[73]_i_21_n_0 ),
        .I1(\q_reg[11]_0 ),
        .I2(w_RegWriteData_wb[9]),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[74]_1 [9]),
        .I5(r_rs2Data_ex[9]),
        .O(ALU_B[9]));
  LUT6 #(
    .INIT(64'hFFCAF0CA0FCA00CA)) 
    \q[53]_i_13 
       (.I0(\q[54]_i_25_n_0 ),
        .I1(\q[52]_i_10_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[53]_i_21_n_0 ),
        .I5(\q[54]_i_23_n_0 ),
        .O(\q[53]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h0000E00D)) 
    \q[53]_i_14 
       (.I0(ALU_B[5]),
        .I1(ALU_A[5]),
        .I2(ALU_B[4]),
        .I3(\q[69]_i_7_n_0 ),
        .I4(\q[55]_i_19_n_0 ),
        .O(\q[53]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hE00DEEDD)) 
    \q[53]_i_15 
       (.I0(ALU_B[5]),
        .I1(ALU_A[5]),
        .I2(ALU_B[4]),
        .I3(\q[69]_i_7_n_0 ),
        .I4(\q[55]_i_19_n_0 ),
        .O(\q[53]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA8A2200002088)) 
    \q[53]_i_16 
       (.I0(ALU_A[5]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[5]),
        .O(\q[53]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[53]_i_17 
       (.I0(Q[28]),
        .I1(r_PC_ex[8]),
        .O(\q[53]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[53]_i_19 
       (.I0(Q[28]),
        .I1(r_PC_ex[9]),
        .O(\q[53]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[53]_i_1__0 
       (.I0(\q[53]_i_2_n_0 ),
        .I1(\q[53]_i_3_n_0 ),
        .I2(\q[53]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[53]_i_5_n_0 ),
        .I5(\q[53]_i_6_n_0 ),
        .O(D[41]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[53]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[10]),
        .I2(ALU_A[10]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[53]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF74FFFFFF740000)) 
    \q[53]_i_21 
       (.I0(ALU_A[3]),
        .I1(ALU_B[2]),
        .I2(\q[50]_i_6_n_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[55]_i_28_n_0 ),
        .O(\q[53]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h0E088FEF80E0FEF8)) 
    \q[53]_i_3 
       (.I0(\q[53]_i_8_n_0 ),
        .I1(\q[53]_i_9_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[8]),
        .I4(ALU_A[9]),
        .I5(ALU_B[9]),
        .O(\q[53]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h55556599AAAA9A66)) 
    \q[53]_i_4 
       (.I0(ALU_A[10]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[10]),
        .O(\q[53]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C707C7C707C70)) 
    \q[53]_i_5 
       (.I0(\q[53]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(ALU_B[10]),
        .I4(r_ALUCode_ex[0]),
        .I5(ALU_A[10]),
        .O(\q[53]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[53]_i_6 
       (.I0(\q[52]_i_4_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[54]_i_15_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[53]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[53]_i_7 
       (.I0(r_Imm_ex[7]),
        .I1(\q[54]_i_16_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[10]));
  LUT6 #(
    .INIT(64'hF0F00000F0F04070)) 
    \q[53]_i_8 
       (.I0(\q[53]_i_14_n_0 ),
        .I1(\q[55]_i_9_n_0 ),
        .I2(\q[55]_i_10_n_0 ),
        .I3(\q[53]_i_15_n_0 ),
        .I4(\q[55]_i_16_n_0 ),
        .I5(\q[53]_i_16_n_0 ),
        .O(\q[53]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAEFAAEFAAEF)) 
    \q[53]_i_9 
       (.I0(\q[53]_i_17_n_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(w_RegWriteData_wb[8]),
        .I3(\q_reg[148]_5 ),
        .I4(\q_reg[4]_0 ),
        .I5(r_rs1Data_ex[8]),
        .O(\q[53]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h888D0000)) 
    \q[54]_i_10 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[0]),
        .I2(r_ALUSrcB_ex[1]),
        .I3(\q[54]_i_20_n_0 ),
        .I4(r_ALUCode_ex[0]),
        .O(\q[54]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \q[54]_i_11 
       (.I0(\q[54]_i_21_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[54]_i_22_n_0 ),
        .O(\q[54]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h44F4FFFF44F444F4)) 
    \q[54]_i_12 
       (.I0(\q[54]_i_23_n_0 ),
        .I1(\q[45]_i_9_n_0 ),
        .I2(\q[54]_i_24_n_0 ),
        .I3(\q[54]_i_25_n_0 ),
        .I4(\q[55]_i_21_n_0 ),
        .I5(\q[54]_i_26_n_0 ),
        .O(\q[54]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h22022020)) 
    \q[54]_i_13 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[1]),
        .I2(ALU_B[11]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[11]),
        .O(\q[54]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[54]_i_14 
       (.I0(r_Imm_ex[7]),
        .I1(\q[54]_i_19_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[11]));
  LUT6 #(
    .INIT(64'hFF000000FF00B8B8)) 
    \q[54]_i_15 
       (.I0(\q[56]_i_14_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[54]_i_27_n_0 ),
        .I3(\q[56]_i_10_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[52]_i_14_n_0 ),
        .O(\q[54]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[54]_i_16 
       (.I0(r_rs2Data_ex[10]),
        .I1(\q_reg[74]_1 [10]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[10]),
        .I4(\q_reg[11]_0 ),
        .O(\q[54]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[54]_i_18 
       (.I0(r_rs1Data_ex[11]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [11]),
        .I4(w_RegWriteData_wb[11]),
        .I5(\q_reg[6]_0 ),
        .O(\q[54]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[54]_i_19 
       (.I0(r_rs2Data_ex[11]),
        .I1(\q_reg[74]_1 [11]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[11]),
        .I4(\q_reg[11]_0 ),
        .O(\q[54]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[54]_i_1__0 
       (.I0(\q[54]_i_2__0_n_0 ),
        .I1(\q[54]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[54]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[54]_i_5_n_0 ),
        .O(D[42]));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[54]_i_20 
       (.I0(r_rs2Data_ex[0]),
        .I1(\q_reg[74]_1 [1]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[0]),
        .I4(\q_reg[11]_0 ),
        .O(\q[54]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h00B8000000B8FFFF)) 
    \q[54]_i_21 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_A[18]),
        .I3(ALU_B[4]),
        .I4(ALU_B[2]),
        .I5(\q[52]_i_11_n_0 ),
        .O(\q[54]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hFF47FFFFFF470000)) 
    \q[54]_i_22 
       (.I0(\q_reg[67]_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_A[16]),
        .I3(ALU_B[4]),
        .I4(ALU_B[2]),
        .I5(\q[49]_i_9_n_0 ),
        .O(\q[54]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h5F50CFCF5F50C0C0)) 
    \q[54]_i_23 
       (.I0(\q[56]_i_15_n_0 ),
        .I1(\q[56]_i_16_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[56]_i_14_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[54]_i_27_n_0 ),
        .O(\q[54]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'h0000888D)) 
    \q[54]_i_24 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[0]),
        .I2(r_ALUSrcB_ex[1]),
        .I3(\q[54]_i_20_n_0 ),
        .I4(r_ALUCode_ex[0]),
        .O(\q[54]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[54]_i_25 
       (.I0(\q[54]_i_28_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[56]_i_17_n_0 ),
        .O(\q[54]_i_25_n_0 ));
  LUT5 #(
    .INIT(32'h15151504)) 
    \q[54]_i_26 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUSrcB_ex[0]),
        .I2(r_Imm_ex[0]),
        .I3(r_ALUSrcB_ex[1]),
        .I4(\q[54]_i_20_n_0 ),
        .O(\q[54]_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hF5F503F3)) 
    \q[54]_i_27 
       (.I0(\q_reg[70]_0 ),
        .I1(ALU_A[11]),
        .I2(ALU_B[3]),
        .I3(ALU_A[19]),
        .I4(ALU_B[4]),
        .O(\q[54]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hFFFCFFBBFFFCFF88)) 
    \q[54]_i_28 
       (.I0(\q[55]_i_19_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[45]_i_16_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q[53]_i_9_n_0 ),
        .O(\q[54]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h718E8E71FFFFFFFF)) 
    \q[54]_i_2__0 
       (.I0(\q[53]_i_3_n_0 ),
        .I1(\q[54]_i_6_n_0 ),
        .I2(ALU_A[10]),
        .I3(ALU_A[11]),
        .I4(\q[54]_i_9_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[54]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000F200)) 
    \q[54]_i_3 
       (.I0(\q[54]_i_10_n_0 ),
        .I1(\q[54]_i_11_n_0 ),
        .I2(\q[54]_i_12_n_0 ),
        .I3(r_ALUCode_ex[1]),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[54]_i_13_n_0 ),
        .O(\q[54]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h08080008)) 
    \q[54]_i_4 
       (.I0(ALU_B[11]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[11]),
        .O(\q[54]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[54]_i_5 
       (.I0(\q[54]_i_15_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[55]_i_14_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[54]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h54FEAB01)) 
    \q[54]_i_6 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_ALUSrcB_ex[1]),
        .I2(\q[54]_i_16_n_0 ),
        .I3(r_Imm_ex[7]),
        .I4(\q[69]_i_7_n_0 ),
        .O(\q[54]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[54]_i_7 
       (.I0(\q_reg[148]_7 ),
        .I1(r_PC_ex[10]),
        .I2(Q[28]),
        .O(ALU_A[10]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[54]_i_8 
       (.I0(\q[54]_i_18_n_0 ),
        .I1(r_PC_ex[11]),
        .I2(Q[28]),
        .O(ALU_A[11]));
  LUT5 #(
    .INIT(32'h54FEAB01)) 
    \q[54]_i_9 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_ALUSrcB_ex[1]),
        .I2(\q[54]_i_19_n_0 ),
        .I3(r_Imm_ex[7]),
        .I4(\q[69]_i_7_n_0 ),
        .O(\q[54]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hF6F6F660)) 
    \q[55]_i_10 
       (.I0(ALU_B[7]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q[50]_i_6_n_0 ),
        .I3(\q[50]_i_10_n_0 ),
        .I4(\q[50]_i_9_n_0 ),
        .O(\q[55]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h5440105154545151)) 
    \q[55]_i_11 
       (.I0(\q[55]_i_16_n_0 ),
        .I1(ALU_B[5]),
        .I2(ALU_A[5]),
        .I3(ALU_B[4]),
        .I4(\q[69]_i_7_n_0 ),
        .I5(\q[55]_i_19_n_0 ),
        .O(\q[55]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hDCFD80C8B3FB1031)) 
    \q[55]_i_12 
       (.I0(ALU_B[10]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_A[10]),
        .I3(\q[55]_i_20_n_0 ),
        .I4(ALU_A[11]),
        .I5(ALU_B[11]),
        .O(\q[55]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hCFAFCFA0C0AFC0A0)) 
    \q[55]_i_13 
       (.I0(\q[55]_i_21_n_0 ),
        .I1(\q[56]_i_12_n_0 ),
        .I2(ALU_B[0]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[56]_i_11_n_0 ),
        .I5(\q[54]_i_11_n_0 ),
        .O(\q[55]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[55]_i_14 
       (.I0(\q[57]_i_21_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[52]_i_13_n_0 ),
        .O(\q[55]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h32BF8CFE)) 
    \q[55]_i_15 
       (.I0(\q[53]_i_9_n_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_B[8]),
        .I3(ALU_A[9]),
        .I4(ALU_B[9]),
        .O(\q[55]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h10FFFFE01010E0E0)) 
    \q[55]_i_16 
       (.I0(\q[55]_i_22_n_0 ),
        .I1(\q[55]_i_23_n_0 ),
        .I2(\q[50]_i_6_n_0 ),
        .I3(ALU_B[6]),
        .I4(\q[69]_i_7_n_0 ),
        .I5(\q[50]_i_9_n_0 ),
        .O(\q[55]_i_16_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[55]_i_17 
       (.I0(\q[55]_i_25_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[5]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[5]));
  LUT6 #(
    .INIT(64'hF0FFF0FFF088F000)) 
    \q[55]_i_18 
       (.I0(\q_reg[4]_0 ),
        .I1(\q_reg[6]_0 ),
        .I2(r_PC_ex[5]),
        .I3(Q[28]),
        .I4(r_rs1Data_ex[5]),
        .I5(\q_reg[44]_0 ),
        .O(ALU_A[5]));
  LUT3 #(
    .INIT(8'hBA)) 
    \q[55]_i_19 
       (.I0(\q[55]_i_27_n_0 ),
        .I1(r_PC_ex[4]),
        .I2(Q[28]),
        .O(\q[55]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[55]_i_1__0 
       (.I0(\q[55]_i_2_n_0 ),
        .I1(\q[55]_i_3_n_0 ),
        .I2(\q[55]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[55]_i_5_n_0 ),
        .I5(\q[55]_i_6_n_0 ),
        .O(D[43]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[55]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[12]),
        .I2(ALU_A[12]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[55]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h203B08EC)) 
    \q[55]_i_20 
       (.I0(\q[53]_i_9_n_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_B[8]),
        .I3(ALU_A[9]),
        .I4(ALU_B[9]),
        .O(\q[55]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[55]_i_21 
       (.I0(\q[55]_i_28_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[57]_i_22_n_0 ),
        .O(\q[55]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA82020AA2020)) 
    \q[55]_i_22 
       (.I0(\q[73]_i_21_n_0 ),
        .I1(\q_reg[11]_0 ),
        .I2(w_RegWriteData_wb[7]),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[74]_1 [7]),
        .I5(r_rs2Data_ex[7]),
        .O(\q[55]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[55]_i_23 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[7]),
        .O(\q[55]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFF20000)) 
    \q[55]_i_24 
       (.I0(r_rs2Data_ex[6]),
        .I1(\q_reg[6]_2 ),
        .I2(\q_reg[49] ),
        .I3(\q_reg[45]_0 ),
        .I4(\q[73]_i_21_n_0 ),
        .I5(\q[55]_i_31_n_0 ),
        .O(ALU_B[6]));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[55]_i_25 
       (.I0(r_rs2Data_ex[5]),
        .I1(\q_reg[74]_1 [5]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[5]),
        .I4(\q_reg[11]_0 ),
        .O(\q[55]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[55]_i_27 
       (.I0(r_rs1Data_ex[4]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [4]),
        .I4(w_RegWriteData_wb[4]),
        .I5(\q_reg[6]_0 ),
        .O(\q[55]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hFFCFFF44FFCFFF77)) 
    \q[55]_i_28 
       (.I0(ALU_A[5]),
        .I1(ALU_B[2]),
        .I2(ALU_A[1]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[9]),
        .O(\q[55]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'hEFFFEAFF20002A00)) 
    \q[55]_i_3 
       (.I0(\q[55]_i_7_n_0 ),
        .I1(\q[55]_i_8_n_0 ),
        .I2(\q[55]_i_9_n_0 ),
        .I3(\q[55]_i_10_n_0 ),
        .I4(\q[55]_i_11_n_0 ),
        .I5(\q[55]_i_12_n_0 ),
        .O(\q[55]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[55]_i_31 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[6]),
        .O(\q[55]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA9A6655556599)) 
    \q[55]_i_4 
       (.I0(ALU_A[12]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[12]),
        .O(\q[55]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C70707C7C70)) 
    \q[55]_i_5 
       (.I0(\q[55]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(ALU_A[12]),
        .I4(ALU_B[12]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[55]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h47FF474700FF0000)) 
    \q[55]_i_6 
       (.I0(\q[56]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[56]_i_10_n_0 ),
        .I3(\q[55]_i_14_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[73]_i_4_n_0 ),
        .O(\q[55]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hDCFD80C8B3FB1031)) 
    \q[55]_i_7 
       (.I0(ALU_B[10]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_A[10]),
        .I3(\q[55]_i_15_n_0 ),
        .I4(ALU_A[11]),
        .I5(ALU_B[11]),
        .O(\q[55]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h4040101054401051)) 
    \q[55]_i_8 
       (.I0(\q[55]_i_16_n_0 ),
        .I1(ALU_B[5]),
        .I2(ALU_A[5]),
        .I3(ALU_B[4]),
        .I4(\q[69]_i_7_n_0 ),
        .I5(\q[55]_i_19_n_0 ),
        .O(\q[55]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h17D4114477DD17D4)) 
    \q[55]_i_9 
       (.I0(ALU_A[3]),
        .I1(ALU_B[3]),
        .I2(ALU_B[2]),
        .I3(\q[69]_i_7_n_0 ),
        .I4(\q[45]_i_6_n_0 ),
        .I5(\q[45]_i_10_n_0 ),
        .O(\q[55]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h00307474)) 
    \q[56]_i_10 
       (.I0(\q[56]_i_15_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[56]_i_16_n_0 ),
        .I3(ALU_B[3]),
        .I4(\q[59]_i_7_n_0 ),
        .O(\q[56]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \q[56]_i_11 
       (.I0(\q[56]_i_17_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[58]_i_20_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[58]_i_21_n_0 ),
        .O(\q[56]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h505FCFCF505FC0C0)) 
    \q[56]_i_12 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(\q[56]_i_14_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[56]_i_15_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[56]_i_16_n_0 ),
        .O(\q[56]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[56]_i_13 
       (.I0(\q_reg[70]_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_A[19]),
        .I3(ALU_B[4]),
        .O(\q[56]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hFF550F33)) 
    \q[56]_i_14 
       (.I0(\q_reg[66]_0 ),
        .I1(ALU_A[15]),
        .I2(\q_reg[74]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .O(\q[56]_i_14_n_0 ));
  LUT4 #(
    .INIT(16'h2320)) 
    \q[56]_i_15 
       (.I0(\q_reg[68]_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[17]),
        .O(\q[56]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hF053FF53)) 
    \q[56]_i_16 
       (.I0(\q_reg[72]_0 ),
        .I1(ALU_A[13]),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q_reg[64]_0 ),
        .O(\q[56]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hFFFCFF88FFFCFFBB)) 
    \q[56]_i_17 
       (.I0(\q[50]_i_9_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[45]_i_6_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[10]),
        .O(\q[56]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[56]_i_1__0 
       (.I0(\q[56]_i_2_n_0 ),
        .I1(\q[56]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[56]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[56]_i_5_n_0 ),
        .O(D[44]));
  LUT6 #(
    .INIT(64'hB24D4DB2FFFFFFFF)) 
    \q[56]_i_2 
       (.I0(\q[55]_i_3_n_0 ),
        .I1(\q[56]_i_6_n_0 ),
        .I2(ALU_A[12]),
        .I3(ALU_A[13]),
        .I4(\q[56]_i_7_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[56]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFF044440000)) 
    \q[56]_i_3 
       (.I0(\q[56]_i_8_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[13]),
        .I3(ALU_A[13]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[56]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h08080008)) 
    \q[56]_i_4 
       (.I0(ALU_B[13]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[13]),
        .O(\q[56]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4700FFFF47004700)) 
    \q[56]_i_5 
       (.I0(\q[56]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[56]_i_10_n_0 ),
        .I3(\q[72]_i_4_n_0 ),
        .I4(\q[57]_i_13_n_0 ),
        .I5(\q[73]_i_4_n_0 ),
        .O(\q[56]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[56]_i_6 
       (.I0(ALU_B[12]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[56]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[56]_i_7 
       (.I0(ALU_B[13]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[56]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAACCFFF0AACC00F0)) 
    \q[56]_i_8 
       (.I0(\q[57]_i_19_n_0 ),
        .I1(\q[56]_i_11_n_0 ),
        .I2(\q[57]_i_20_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[56]_i_12_n_0 ),
        .O(\q[56]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h00307474)) 
    \q[56]_i_9 
       (.I0(\q[56]_i_13_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[56]_i_14_n_0 ),
        .I3(ALU_B[3]),
        .I4(\q[59]_i_7_n_0 ),
        .O(\q[56]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[57]_i_10 
       (.I0(r_PC_ex[13]),
        .I1(Q[28]),
        .I2(\q[57]_i_17_n_0 ),
        .O(ALU_A[13]));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[57]_i_11 
       (.I0(\q[57]_i_18_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[13]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[13]));
  LUT6 #(
    .INIT(64'hFFCCAAF000CCAAF0)) 
    \q[57]_i_12 
       (.I0(\q[57]_i_19_n_0 ),
        .I1(\q[57]_i_20_n_0 ),
        .I2(\q[58]_i_16_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[58]_i_17_n_0 ),
        .O(\q[57]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h1F10)) 
    \q[57]_i_13 
       (.I0(\q[59]_i_7_n_0 ),
        .I1(\q[59]_i_11_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[57]_i_21_n_0 ),
        .O(\q[57]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[57]_i_14 
       (.I0(r_rs2Data_ex[14]),
        .I1(\q_reg[74]_1 [14]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[14]),
        .I4(\q_reg[11]_0 ),
        .O(\q[57]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[57]_i_15 
       (.I0(r_rs2Data_ex[12]),
        .I1(\q_reg[74]_1 [12]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[12]),
        .I4(\q_reg[11]_0 ),
        .O(\q[57]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[57]_i_17 
       (.I0(r_rs1Data_ex[13]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [13]),
        .I4(w_RegWriteData_wb[13]),
        .I5(\q_reg[6]_0 ),
        .O(\q[57]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[57]_i_18 
       (.I0(r_rs2Data_ex[13]),
        .I1(\q_reg[74]_1 [13]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[13]),
        .I4(\q_reg[11]_0 ),
        .O(\q[57]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h553355330FFF0F00)) 
    \q[57]_i_19 
       (.I0(\q[63]_i_22_n_0 ),
        .I1(\q[52]_i_19_n_0 ),
        .I2(\q[61]_i_27_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[52]_i_11_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[57]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[57]_i_1__0 
       (.I0(\q[57]_i_2_n_0 ),
        .I1(\q[57]_i_3_n_0 ),
        .I2(\q[57]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[57]_i_5_n_0 ),
        .I5(\q[57]_i_6_n_0 ),
        .O(D[45]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[57]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[14]),
        .I2(ALU_A[14]),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[57]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \q[57]_i_20 
       (.I0(\q[57]_i_22_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[57]_i_23_n_0 ),
        .I3(ALU_B[2]),
        .I4(\q[57]_i_24_n_0 ),
        .O(\q[57]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'h00307474)) 
    \q[57]_i_21 
       (.I0(\q[61]_i_27_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[52]_i_11_n_0 ),
        .I3(ALU_B[3]),
        .I4(\q[59]_i_7_n_0 ),
        .O(\q[57]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hFFCFFF88FFCFFFBB)) 
    \q[57]_i_22 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(ALU_B[2]),
        .I2(ALU_A[3]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[11]),
        .O(\q[57]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'hDCDF)) 
    \q[57]_i_23 
       (.I0(ALU_A[1]),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[9]),
        .O(\q[57]_i_23_n_0 ));
  LUT4 #(
    .INIT(16'hDCDF)) 
    \q[57]_i_24 
       (.I0(ALU_A[5]),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[13]),
        .O(\q[57]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h1031377F044CDCFD)) 
    \q[57]_i_3 
       (.I0(\q[55]_i_3_n_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_B[12]),
        .I3(ALU_A[12]),
        .I4(ALU_A[13]),
        .I5(ALU_B[13]),
        .O(\q[57]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h55556599AAAA9A66)) 
    \q[57]_i_4 
       (.I0(ALU_A[14]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[14]),
        .O(\q[57]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C70707C7C70)) 
    \q[57]_i_5 
       (.I0(\q[57]_i_12_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(ALU_A[14]),
        .I4(ALU_B[14]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[57]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[57]_i_6 
       (.I0(\q[57]_i_13_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[58]_i_12_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[57]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[57]_i_7 
       (.I0(\q[57]_i_14_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[14]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[14]));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[57]_i_8 
       (.I0(\q[57]_i_15_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[12]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[12]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[57]_i_9 
       (.I0(\q_reg[148]_8 ),
        .I1(r_PC_ex[12]),
        .I2(Q[28]),
        .O(ALU_A[12]));
  LUT6 #(
    .INIT(64'h0FCCFFAA0FCC00AA)) 
    \q[58]_i_10 
       (.I0(\q[58]_i_15_n_0 ),
        .I1(\q[58]_i_16_n_0 ),
        .I2(\q[59]_i_9_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[58]_i_17_n_0 ),
        .O(\q[58]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h0FEE)) 
    \q[58]_i_11 
       (.I0(\q[58]_i_18_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[15]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[58]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h1F10)) 
    \q[58]_i_12 
       (.I0(\q[59]_i_7_n_0 ),
        .I1(\q[59]_i_8_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[56]_i_9_n_0 ),
        .O(\q[58]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[58]_i_15 
       (.I0(\q[58]_i_19_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[61]_i_26_n_0 ),
        .O(\q[58]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \q[58]_i_16 
       (.I0(\q[58]_i_20_n_0 ),
        .I1(\q[58]_i_21_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[58]_i_22_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[58]_i_23_n_0 ),
        .O(\q[58]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h303F5F5F303F5050)) 
    \q[58]_i_17 
       (.I0(\q[56]_i_15_n_0 ),
        .I1(\q[64]_i_12_n_0 ),
        .I2(ALU_B[1]),
        .I3(\q[56]_i_13_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[56]_i_14_n_0 ),
        .O(\q[58]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[58]_i_18 
       (.I0(r_rs2Data_ex[15]),
        .I1(\q_reg[74]_1 [15]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[15]),
        .I4(\q_reg[11]_0 ),
        .O(\q[58]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hBB8BBB88BB8BBBBB)) 
    \q[58]_i_19 
       (.I0(\q[57]_i_23_n_0 ),
        .I1(ALU_B[2]),
        .I2(ALU_A[5]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[13]),
        .O(\q[58]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[58]_i_1__0 
       (.I0(\q[58]_i_2__0_n_0 ),
        .I1(\q[58]_i_3__0_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[58]_i_4__0_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[58]_i_5_n_0 ),
        .O(D[46]));
  LUT4 #(
    .INIT(16'hEFEC)) 
    \q[58]_i_20 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(\q[53]_i_9_n_0 ),
        .O(\q[58]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'hECEF)) 
    \q[58]_i_21 
       (.I0(\q[55]_i_19_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[12]),
        .O(\q[58]_i_21_n_0 ));
  LUT4 #(
    .INIT(16'hECEF)) 
    \q[58]_i_22 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[10]),
        .O(\q[58]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'hECEF)) 
    \q[58]_i_23 
       (.I0(\q[50]_i_9_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[14]),
        .O(\q[58]_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h718E8E71FFFFFFFF)) 
    \q[58]_i_2__0 
       (.I0(\q[57]_i_3_n_0 ),
        .I1(\q[58]_i_6_n_0 ),
        .I2(ALU_A[14]),
        .I3(ALU_A[15]),
        .I4(\q[58]_i_9_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[58]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[58]_i_3__0 
       (.I0(\q[58]_i_10_n_0 ),
        .I1(ALU_A[15]),
        .I2(\q[58]_i_11_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[58]_i_3__0_n_0 ));
  LUT5 #(
    .INIT(32'h04040004)) 
    \q[58]_i_4__0 
       (.I0(\q[58]_i_11_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[15]),
        .O(\q[58]_i_4__0_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[58]_i_5 
       (.I0(\q[58]_i_12_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[59]_i_5_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[58]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[58]_i_6 
       (.I0(ALU_B[14]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[58]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[58]_i_7 
       (.I0(r_PC_ex[14]),
        .I1(Q[28]),
        .I2(\q_reg[148]_9 ),
        .O(ALU_A[14]));
  LUT5 #(
    .INIT(32'hBBBB8B88)) 
    \q[58]_i_8 
       (.I0(r_PC_ex[15]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [15]),
        .I4(\q_reg[54]_0 ),
        .O(ALU_A[15]));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[58]_i_9 
       (.I0(\q[58]_i_11_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[58]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAA0FCCFFAA0FCC00)) 
    \q[59]_i_10 
       (.I0(\q[60]_i_9_n_0 ),
        .I1(\q[58]_i_15_n_0 ),
        .I2(\q[59]_i_9_n_0 ),
        .I3(ALU_B[0]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[60]_i_10_n_0 ),
        .O(\q[59]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \q[59]_i_11 
       (.I0(\q_reg[71]_0 ),
        .I1(ALU_B[3]),
        .I2(\q_reg[63]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[2]),
        .I5(\q[52]_i_19_n_0 ),
        .O(\q[59]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[59]_i_1__0 
       (.I0(\q[59]_i_2_n_0 ),
        .I1(\q[59]_i_3_n_0 ),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[59]_i_4_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[59]_i_5_n_0 ),
        .O(D[47]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[59]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_A[16]),
        .I3(\q[61]_i_10_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[59]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69960000)) 
    \q[59]_i_3 
       (.I0(\q[61]_i_8_n_0 ),
        .I1(\q[61]_i_10_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_A[16]),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[59]_i_6_n_0 ),
        .O(\q[59]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[59]_i_4 
       (.I0(\q[59]_i_7_n_0 ),
        .I1(\q[59]_i_8_n_0 ),
        .I2(\q[62]_i_12_n_0 ),
        .I3(ALU_B[1]),
        .O(\q[59]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[59]_i_5 
       (.I0(\q[59]_i_7_n_0 ),
        .I1(\q[59]_i_9_n_0 ),
        .O(\q[59]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C7070707C7C)) 
    \q[59]_i_6 
       (.I0(\q[59]_i_10_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[61]_i_10_n_0 ),
        .I5(ALU_A[16]),
        .O(\q[59]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[59]_i_7 
       (.I0(ALU_B[4]),
        .I1(\q_reg[74]_0 ),
        .O(\q[59]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h88B888BB88B88888)) 
    \q[59]_i_8 
       (.I0(\q[64]_i_12_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q_reg[68]_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(ALU_A[17]),
        .O(\q[59]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[59]_i_9 
       (.I0(\q[61]_i_25_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[59]_i_11_n_0 ),
        .O(\q[59]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[60]_i_10 
       (.I0(\q[60]_i_11_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[62]_i_20_n_0 ),
        .O(\q[60]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hECEFFFFFECEF0000)) 
    \q[60]_i_11 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[10]),
        .I4(ALU_B[2]),
        .I5(\q[58]_i_23_n_0 ),
        .O(\q[60]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[60]_i_1__0 
       (.I0(\q[60]_i_2_n_0 ),
        .I1(\q[60]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[60]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[60]_i_5_n_0 ),
        .O(D[48]));
  LUT6 #(
    .INIT(64'h8E71718EFFFFFFFF)) 
    \q[60]_i_2 
       (.I0(\q[61]_i_8_n_0 ),
        .I1(ALU_A[16]),
        .I2(\q[60]_i_6_n_0 ),
        .I3(ALU_A[17]),
        .I4(\q[60]_i_7_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[60]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFF044440000)) 
    \q[60]_i_3 
       (.I0(\q[60]_i_8_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[17]),
        .I3(ALU_A[17]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[60]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h08080008)) 
    \q[60]_i_4 
       (.I0(ALU_B[17]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[17]),
        .O(\q[60]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[60]_i_5 
       (.I0(\q[59]_i_4_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[61]_i_14_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[60]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[60]_i_6 
       (.I0(\q[61]_i_10_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[60]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[60]_i_7 
       (.I0(ALU_B[17]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[60]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFAC0FACF0AC00AC)) 
    \q[60]_i_8 
       (.I0(\q[60]_i_9_n_0 ),
        .I1(\q[61]_i_23_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[61]_i_24_n_0 ),
        .I5(\q[60]_i_10_n_0 ),
        .O(\q[60]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h8B)) 
    \q[60]_i_9 
       (.I0(\q[62]_i_19_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[59]_i_8_n_0 ),
        .O(\q[60]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[61]_i_10 
       (.I0(r_Imm_ex[16]),
        .I1(\q[61]_i_20_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[61]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[61]_i_11 
       (.I0(r_PC_ex[17]),
        .I1(Q[28]),
        .I2(\q_reg[148]_11 ),
        .O(ALU_A[17]));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[61]_i_12 
       (.I0(r_Imm_ex[7]),
        .I1(\q[61]_i_22_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[17]));
  LUT6 #(
    .INIT(64'hAFCFA0CFAFC0A0C0)) 
    \q[61]_i_13 
       (.I0(\q[62]_i_15_n_0 ),
        .I1(\q[61]_i_23_n_0 ),
        .I2(ALU_B[0]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q[61]_i_24_n_0 ),
        .I5(\q[62]_i_16_n_0 ),
        .O(\q[61]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h888B)) 
    \q[61]_i_14 
       (.I0(\q[63]_i_19_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[59]_i_7_n_0 ),
        .I3(\q[61]_i_25_n_0 ),
        .O(\q[61]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[61]_i_15 
       (.I0(r_rs2Data_ex[18]),
        .I1(\q_reg[74]_1 [18]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[18]),
        .I4(\q_reg[11]_0 ),
        .O(\q[61]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB5004A)) 
    \q[61]_i_16 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[58]_i_11_n_0 ),
        .I5(ALU_A[15]),
        .O(\q[61]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h00000000004AFFB5)) 
    \q[61]_i_17 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(ALU_B[14]),
        .I5(ALU_A[14]),
        .O(\q[61]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h0D70DD77)) 
    \q[61]_i_18 
       (.I0(ALU_A[15]),
        .I1(\q[58]_i_11_n_0 ),
        .I2(ALU_B[14]),
        .I3(\q[69]_i_7_n_0 ),
        .I4(ALU_A[14]),
        .O(\q[61]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[61]_i_1__0 
       (.I0(\q[61]_i_2_n_0 ),
        .I1(\q[61]_i_3_n_0 ),
        .I2(\q[61]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[61]_i_5_n_0 ),
        .I5(\q[61]_i_6_n_0 ),
        .O(D[49]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[61]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_A[18]),
        .I3(\q[61]_i_7_n_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[61]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[61]_i_20 
       (.I0(r_rs2Data_ex[16]),
        .I1(\q_reg[74]_1 [16]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[16]),
        .I4(\q_reg[11]_0 ),
        .O(\q[61]_i_20_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[61]_i_22 
       (.I0(r_rs2Data_ex[17]),
        .I1(\q_reg[74]_1 [17]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[17]),
        .I4(\q_reg[11]_0 ),
        .O(\q[61]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[61]_i_23 
       (.I0(\q[61]_i_26_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[63]_i_21_n_0 ),
        .O(\q[61]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'hD1)) 
    \q[61]_i_24 
       (.I0(\q[61]_i_25_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[63]_i_20_n_0 ),
        .O(\q[61]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h2320FFFF23200000)) 
    \q[61]_i_25 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(\q_reg[65]_0 ),
        .I4(ALU_B[2]),
        .I5(\q[61]_i_27_n_0 ),
        .O(\q[61]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'hDCDFFFFFDCDF0000)) 
    \q[61]_i_26 
       (.I0(ALU_A[3]),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[11]),
        .I4(ALU_B[2]),
        .I5(\q[61]_i_28_n_0 ),
        .O(\q[61]_i_26_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[61]_i_27 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_B[3]),
        .I2(ALU_A[18]),
        .I3(ALU_B[4]),
        .O(\q[61]_i_27_n_0 ));
  LUT4 #(
    .INIT(16'hECEF)) 
    \q[61]_i_28 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[15]),
        .O(\q[61]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h01077F1F7010F1F7)) 
    \q[61]_i_3 
       (.I0(\q[61]_i_8_n_0 ),
        .I1(ALU_A[16]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[61]_i_10_n_0 ),
        .I4(ALU_A[17]),
        .I5(ALU_B[17]),
        .O(\q[61]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA9A6655556599)) 
    \q[61]_i_4 
       (.I0(ALU_A[18]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(\q[61]_i_7_n_0 ),
        .O(\q[61]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C70707C707C7C)) 
    \q[61]_i_5 
       (.I0(\q[61]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_A[18]),
        .I5(\q[61]_i_7_n_0 ),
        .O(\q[61]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4700FFFF47004700)) 
    \q[61]_i_6 
       (.I0(\q[64]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[62]_i_12_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q[61]_i_14_n_0 ),
        .I5(\q[72]_i_4_n_0 ),
        .O(\q[61]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[61]_i_7 
       (.I0(r_Imm_ex[7]),
        .I1(\q[61]_i_15_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[61]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h000400070F0F0F0F)) 
    \q[61]_i_8 
       (.I0(\q[63]_i_14_n_0 ),
        .I1(\q[55]_i_3_n_0 ),
        .I2(\q[61]_i_16_n_0 ),
        .I3(\q[61]_i_17_n_0 ),
        .I4(\q[63]_i_15_n_0 ),
        .I5(\q[61]_i_18_n_0 ),
        .O(\q[61]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[61]_i_9 
       (.I0(\q_reg[148]_10 ),
        .I1(r_PC_ex[16]),
        .I2(Q[28]),
        .O(ALU_A[16]));
  LUT6 #(
    .INIT(64'hFFAC0FACF0AC00AC)) 
    \q[62]_i_10 
       (.I0(\q[62]_i_15_n_0 ),
        .I1(\q[63]_i_18_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[63]_i_17_n_0 ),
        .I5(\q[62]_i_16_n_0 ),
        .O(\q[62]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[62]_i_11 
       (.I0(r_Imm_ex[7]),
        .I1(\q[62]_i_17_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[62]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h45FF4500)) 
    \q[62]_i_12 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[66]_0 ),
        .I3(ALU_B[2]),
        .I4(\q[62]_i_18_n_0 ),
        .O(\q[62]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[62]_i_13 
       (.I0(r_rs1Data_ex[18]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [18]),
        .I4(w_RegWriteData_wb[18]),
        .I5(\q_reg[6]_0 ),
        .O(\q[62]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[62]_i_14 
       (.I0(r_rs1Data_ex[19]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [19]),
        .I4(w_RegWriteData_wb[19]),
        .I5(\q_reg[6]_0 ),
        .O(\q[62]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[62]_i_15 
       (.I0(\q[64]_i_13_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[62]_i_19_n_0 ),
        .O(\q[62]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[62]_i_16 
       (.I0(\q[62]_i_20_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[64]_i_14_n_0 ),
        .O(\q[62]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[62]_i_17 
       (.I0(r_rs2Data_ex[19]),
        .I1(\q_reg[74]_1 [19]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[19]),
        .I4(\q_reg[11]_0 ),
        .O(\q[62]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h44455545)) 
    \q[62]_i_18 
       (.I0(\q[59]_i_7_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_A[19]),
        .I3(ALU_B[3]),
        .I4(\q_reg[70]_0 ),
        .O(\q[62]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hDCDF0000DCDFFFFF)) 
    \q[62]_i_19 
       (.I0(\q_reg[74]_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(\q_reg[66]_0 ),
        .I4(ALU_B[2]),
        .I5(\q[56]_i_13_n_0 ),
        .O(\q[62]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[62]_i_1__0 
       (.I0(\q[62]_i_2__0_n_0 ),
        .I1(\q[62]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[62]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[62]_i_5_n_0 ),
        .O(D[50]));
  LUT6 #(
    .INIT(64'hECEFFFFFECEF0000)) 
    \q[62]_i_20 
       (.I0(\q[55]_i_19_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[12]),
        .I4(ALU_B[2]),
        .I5(\q[65]_i_29_n_0 ),
        .O(\q[62]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h718E8E71FFFFFFFF)) 
    \q[62]_i_2__0 
       (.I0(\q[61]_i_3_n_0 ),
        .I1(\q[62]_i_6_n_0 ),
        .I2(ALU_A[18]),
        .I3(ALU_A[19]),
        .I4(\q[62]_i_9_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[62]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[62]_i_3 
       (.I0(\q[62]_i_10_n_0 ),
        .I1(ALU_A[19]),
        .I2(\q[62]_i_11_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[62]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h000000D0)) 
    \q[62]_i_4 
       (.I0(r_ALUCode_ex[0]),
        .I1(ALU_A[19]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[62]_i_11_n_0 ),
        .O(\q[62]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4700FFFF47004700)) 
    \q[62]_i_5 
       (.I0(\q[64]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[62]_i_12_n_0 ),
        .I3(\q[72]_i_4_n_0 ),
        .I4(\q[63]_i_12_n_0 ),
        .I5(\q[73]_i_4_n_0 ),
        .O(\q[62]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[62]_i_6 
       (.I0(\q[61]_i_7_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[62]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[62]_i_7 
       (.I0(\q[62]_i_13_n_0 ),
        .I1(r_PC_ex[18]),
        .I2(Q[28]),
        .O(ALU_A[18]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[62]_i_8 
       (.I0(\q[62]_i_14_n_0 ),
        .I1(r_PC_ex[19]),
        .I2(Q[28]),
        .O(ALU_A[19]));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[62]_i_9 
       (.I0(\q[62]_i_11_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[62]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h2FBF080EF8FE20B0)) 
    \q[63]_i_10 
       (.I0(ALU_A[18]),
        .I1(\q[61]_i_7_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[63]_i_16_n_0 ),
        .I4(ALU_A[19]),
        .I5(\q[62]_i_11_n_0 ),
        .O(\q[63]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFAC0FACF0AC00AC)) 
    \q[63]_i_11 
       (.I0(\q[63]_i_17_n_0 ),
        .I1(\q[64]_i_11_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[64]_i_10_n_0 ),
        .I5(\q[63]_i_18_n_0 ),
        .O(\q[63]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[63]_i_12 
       (.I0(\q[65]_i_27_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[63]_i_19_n_0 ),
        .O(\q[63]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h015D08AB)) 
    \q[63]_i_13 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(\q[61]_i_10_n_0 ),
        .I2(ALU_A[16]),
        .I3(ALU_A[17]),
        .I4(ALU_B[17]),
        .O(\q[63]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h045702AE)) 
    \q[63]_i_14 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(ALU_B[12]),
        .I2(ALU_A[12]),
        .I3(ALU_A[13]),
        .I4(ALU_B[13]),
        .O(\q[63]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h457F2AEF)) 
    \q[63]_i_15 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(ALU_B[12]),
        .I2(ALU_A[12]),
        .I3(ALU_A[13]),
        .I4(ALU_B[13]),
        .O(\q[63]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h13F7C4DF)) 
    \q[63]_i_16 
       (.I0(ALU_A[16]),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q[61]_i_10_n_0 ),
        .I3(ALU_A[17]),
        .I4(ALU_B[17]),
        .O(\q[63]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[63]_i_17 
       (.I0(\q[65]_i_28_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[63]_i_20_n_0 ),
        .O(\q[63]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[63]_i_18 
       (.I0(\q[63]_i_21_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[65]_i_31_n_0 ),
        .O(\q[63]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h45450000454500FF)) 
    \q[63]_i_19 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[67]_0 ),
        .I3(\q[59]_i_7_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[63]_i_22_n_0 ),
        .O(\q[63]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[63]_i_1__0 
       (.I0(\q[63]_i_2_n_0 ),
        .I1(\q[63]_i_3_n_0 ),
        .I2(\q[63]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[63]_i_5_n_0 ),
        .I5(\q[63]_i_6_n_0 ),
        .O(D[51]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[63]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[20]),
        .I2(\q_reg[63]_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[63]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF5F5FFFF303F)) 
    \q[63]_i_20 
       (.I0(\q_reg[67]_0 ),
        .I1(\q_reg[71]_0 ),
        .I2(ALU_B[3]),
        .I3(\q_reg[63]_0 ),
        .I4(ALU_B[4]),
        .I5(ALU_B[2]),
        .O(\q[63]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hDCDFFFFFDCDF0000)) 
    \q[63]_i_21 
       (.I0(ALU_A[5]),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[13]),
        .I4(ALU_B[2]),
        .I5(\q[67]_i_23_n_0 ),
        .O(\q[63]_i_21_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[63]_i_22 
       (.I0(\q_reg[71]_0 ),
        .I1(ALU_B[3]),
        .I2(\q_reg[63]_0 ),
        .I3(ALU_B[4]),
        .O(\q[63]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \q[63]_i_3 
       (.I0(\q[63]_i_7_n_0 ),
        .I1(\q[63]_i_8_n_0 ),
        .I2(\q[55]_i_3_n_0 ),
        .I3(\q[63]_i_9_n_0 ),
        .I4(\q[63]_i_10_n_0 ),
        .O(\q[63]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA9A6655556599)) 
    \q[63]_i_4 
       (.I0(\q_reg[63]_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[20]),
        .O(\q[63]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C70707C7C70)) 
    \q[63]_i_5 
       (.I0(\q[63]_i_11_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[63]_0 ),
        .I4(ALU_B[20]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[63]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4700FFFF47004700)) 
    \q[63]_i_6 
       (.I0(\q[66]_i_10_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[64]_i_9_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q[63]_i_12_n_0 ),
        .I5(\q[72]_i_4_n_0 ),
        .O(\q[63]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h2FBF080EF8FE20B0)) 
    \q[63]_i_7 
       (.I0(ALU_A[18]),
        .I1(\q[61]_i_7_n_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[63]_i_13_n_0 ),
        .I4(ALU_A[19]),
        .I5(\q[62]_i_11_n_0 ),
        .O(\q[63]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[63]_i_8 
       (.I0(ALU_A[14]),
        .I1(ALU_B[14]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[63]_i_14_n_0 ),
        .I4(ALU_A[15]),
        .I5(\q[58]_i_11_n_0 ),
        .O(\q[63]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[63]_i_9 
       (.I0(ALU_A[14]),
        .I1(ALU_B[14]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[63]_i_15_n_0 ),
        .I4(ALU_A[15]),
        .I5(\q[58]_i_11_n_0 ),
        .O(\q[63]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[64]_i_10 
       (.I0(\q[65]_i_30_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[64]_i_13_n_0 ),
        .O(\q[64]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFF00B8B8)) 
    \q[64]_i_11 
       (.I0(\q[65]_i_29_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[70]_i_19_n_0 ),
        .I3(\q[64]_i_14_n_0 ),
        .I4(ALU_B[1]),
        .O(\q[64]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[64]_i_12 
       (.I0(\q_reg[72]_0 ),
        .I1(ALU_B[3]),
        .I2(\q_reg[64]_0 ),
        .I3(ALU_B[4]),
        .O(\q[64]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF5F5FFFF303F)) 
    \q[64]_i_13 
       (.I0(\q_reg[68]_0 ),
        .I1(\q_reg[72]_0 ),
        .I2(ALU_B[3]),
        .I3(\q_reg[64]_0 ),
        .I4(ALU_B[4]),
        .I5(ALU_B[2]),
        .O(\q[64]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hECEFFFFFECEF0000)) 
    \q[64]_i_14 
       (.I0(\q[50]_i_9_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[14]),
        .I4(ALU_B[2]),
        .I5(\q[67]_i_25_n_0 ),
        .O(\q[64]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[64]_i_1__0 
       (.I0(\q[64]_i_2_n_0 ),
        .I1(\q[64]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[64]_i_4_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[64]_i_5_n_0 ),
        .O(D[52]));
  LUT6 #(
    .INIT(64'h8E71718EFFFFFFFF)) 
    \q[64]_i_2 
       (.I0(\q[63]_i_3_n_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q[64]_i_6_n_0 ),
        .I3(\q_reg[64]_0 ),
        .I4(\q[64]_i_7_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[64]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[64]_i_3 
       (.I0(\q[64]_i_8_n_0 ),
        .I1(\q_reg[64]_0 ),
        .I2(\q[65]_i_12_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[64]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h000000D0)) 
    \q[64]_i_4 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q_reg[64]_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[65]_i_12_n_0 ),
        .O(\q[64]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4700FFFF47004700)) 
    \q[64]_i_5 
       (.I0(\q[66]_i_10_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[64]_i_9_n_0 ),
        .I3(\q[72]_i_4_n_0 ),
        .I4(\q[65]_i_14_n_0 ),
        .I5(\q[73]_i_4_n_0 ),
        .O(\q[64]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[64]_i_6 
       (.I0(ALU_B[20]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[64]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[64]_i_7 
       (.I0(\q[65]_i_12_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[64]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFAC0FACF0AC00AC)) 
    \q[64]_i_8 
       (.I0(\q[64]_i_10_n_0 ),
        .I1(\q[65]_i_24_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[65]_i_21_n_0 ),
        .I5(\q[64]_i_11_n_0 ),
        .O(\q[64]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h45450000454500FF)) 
    \q[64]_i_9 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[68]_0 ),
        .I3(\q[59]_i_7_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[64]_i_12_n_0 ),
        .O(\q[64]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[65]_i_10 
       (.I0(\q[65]_i_18_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[20]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[20]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[65]_i_11 
       (.I0(\q_reg[148]_13 ),
        .I1(r_PC_ex[21]),
        .I2(Q[28]),
        .O(\q_reg[64]_0 ));
  LUT4 #(
    .INIT(16'h0FEE)) 
    \q[65]_i_12 
       (.I0(\q[65]_i_20_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[21]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[65]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFFAC0FACF0AC00AC)) 
    \q[65]_i_13 
       (.I0(\q[65]_i_21_n_0 ),
        .I1(\q[65]_i_22_n_0 ),
        .I2(r_ALUCode_ex[0]),
        .I3(ALU_B[0]),
        .I4(\q[65]_i_23_n_0 ),
        .I5(\q[65]_i_24_n_0 ),
        .O(\q[65]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0151FFFF01510000)) 
    \q[65]_i_14 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[65]_i_25_n_0 ),
        .I2(ALU_B[2]),
        .I3(\q[65]_i_26_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[65]_i_27_n_0 ),
        .O(\q[65]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[65]_i_15 
       (.I0(r_rs2Data_ex[22]),
        .I1(\q_reg[74]_1 [22]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[22]),
        .I4(\q_reg[11]_0 ),
        .O(\q[65]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[65]_i_18 
       (.I0(r_rs2Data_ex[20]),
        .I1(\q_reg[74]_1 [20]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[20]),
        .I4(\q_reg[11]_0 ),
        .O(\q[65]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[65]_i_1__0 
       (.I0(\q[65]_i_2_n_0 ),
        .I1(\q[65]_i_3_n_0 ),
        .I2(\q[65]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[65]_i_5_n_0 ),
        .I5(\q[65]_i_6_n_0 ),
        .O(D[53]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[65]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[22]),
        .I2(\q_reg[65]_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[65]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[65]_i_20 
       (.I0(r_rs2Data_ex[21]),
        .I1(\q_reg[74]_1 [21]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[21]),
        .I4(\q_reg[11]_0 ),
        .O(\q[65]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hFF47FFFFFF470000)) 
    \q[65]_i_21 
       (.I0(\q_reg[71]_0 ),
        .I1(ALU_B[2]),
        .I2(\q_reg[67]_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[65]_i_28_n_0 ),
        .O(\q[65]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[65]_i_22 
       (.I0(\q[65]_i_29_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[70]_i_19_n_0 ),
        .I3(\q[67]_i_25_n_0 ),
        .I4(\q[71]_i_30_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[65]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'hCEDFFFFFCEDF0000)) 
    \q[65]_i_23 
       (.I0(ALU_B[2]),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[72]_0 ),
        .I3(\q_reg[68]_0 ),
        .I4(ALU_B[1]),
        .I5(\q[65]_i_30_n_0 ),
        .O(\q[65]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hFF00B8B8)) 
    \q[65]_i_24 
       (.I0(\q[67]_i_23_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_24_n_0 ),
        .I3(\q[65]_i_31_n_0 ),
        .I4(ALU_B[1]),
        .O(\q[65]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[65]_i_25 
       (.I0(\q_reg[67]_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .O(\q[65]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[65]_i_26 
       (.I0(\q_reg[71]_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .O(\q[65]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h45450000454500FF)) 
    \q[65]_i_27 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[69]_0 ),
        .I3(\q[59]_i_7_n_0 ),
        .I4(ALU_B[2]),
        .I5(\q[65]_i_32_n_0 ),
        .O(\q[65]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hFFF5FFF5F3F0F3FF)) 
    \q[65]_i_28 
       (.I0(\q_reg[69]_0 ),
        .I1(\q_reg[73]_0 ),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q_reg[65]_0 ),
        .I5(ALU_B[2]),
        .O(\q[65]_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hFC88FCBB)) 
    \q[65]_i_29 
       (.I0(\q[53]_i_9_n_0 ),
        .I1(ALU_B[3]),
        .I2(\q[45]_i_16_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_A[16]),
        .O(\q[65]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h1070F7F107011F7F)) 
    \q[65]_i_3 
       (.I0(\q[63]_i_3_n_0 ),
        .I1(\q_reg[63]_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(ALU_B[20]),
        .I4(\q_reg[64]_0 ),
        .I5(\q[65]_i_12_n_0 ),
        .O(\q[65]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFF5FFF5F3F0F3FF)) 
    \q[65]_i_30 
       (.I0(\q_reg[70]_0 ),
        .I1(\q_reg[74]_0 ),
        .I2(ALU_B[4]),
        .I3(ALU_B[3]),
        .I4(\q_reg[66]_0 ),
        .I5(ALU_B[2]),
        .O(\q[65]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hECEFFFFFECEF0000)) 
    \q[65]_i_31 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(ALU_A[15]),
        .I4(ALU_B[2]),
        .I5(\q[67]_i_24_n_0 ),
        .O(\q[65]_i_31_n_0 ));
  LUT4 #(
    .INIT(16'h2320)) 
    \q[65]_i_32 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_B[4]),
        .I2(ALU_B[3]),
        .I3(\q_reg[65]_0 ),
        .O(\q[65]_i_32_n_0 ));
  LUT6 #(
    .INIT(64'h55556599AAAA9A66)) 
    \q[65]_i_4 
       (.I0(\q_reg[65]_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(ALU_B[22]),
        .O(\q[65]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C70707C7C70)) 
    \q[65]_i_5 
       (.I0(\q[65]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[65]_0 ),
        .I4(ALU_B[22]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[65]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[65]_i_6 
       (.I0(\q[65]_i_14_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[66]_i_3_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[65]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[65]_i_7 
       (.I0(r_Imm_ex[16]),
        .I1(\q[65]_i_15_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[22]));
  LUT3 #(
    .INIT(8'h45)) 
    \q[65]_i_8 
       (.I0(\q_reg[148]_14 ),
        .I1(r_PC_ex[22]),
        .I2(Q[28]),
        .O(\q_reg[65]_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[65]_i_9 
       (.I0(r_PC_ex[20]),
        .I1(Q[28]),
        .I2(\q_reg[148]_12 ),
        .O(\q_reg[63]_0 ));
  LUT5 #(
    .INIT(32'h0F040F07)) 
    \q[66]_i_10 
       (.I0(\q_reg[70]_0 ),
        .I1(ALU_B[2]),
        .I2(\q[67]_i_16_n_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(\q_reg[66]_0 ),
        .O(\q[66]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[66]_i_11 
       (.I0(ALU_B[22]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[66]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[66]_i_12 
       (.I0(\q[66]_i_7_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[66]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0FFFAACC0F00AACC)) 
    \q[66]_i_13 
       (.I0(\q[65]_i_23_n_0 ),
        .I1(\q[67]_i_21_n_0 ),
        .I2(\q[67]_i_17_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[65]_i_22_n_0 ),
        .O(\q[66]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[66]_i_14 
       (.I0(r_rs2Data_ex[23]),
        .I1(\q_reg[74]_1 [23]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[23]),
        .I4(\q_reg[11]_0 ),
        .O(\q[66]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h11F111F1FFFF11F1)) 
    \q[66]_i_1__0 
       (.I0(\q[66]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[72]_i_4_n_0 ),
        .I3(\q[66]_i_3_n_0 ),
        .I4(\q[73]_i_4_n_0 ),
        .I5(\q[66]_i_4_n_0 ),
        .O(D[54]));
  LUT6 #(
    .INIT(64'hF022FF22F022F022)) 
    \q[66]_i_2 
       (.I0(\q[66]_i_5_n_0 ),
        .I1(\q[66]_i_6_n_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q_reg[66]_0 ),
        .I5(r_ALUCode_ex[0]),
        .O(\q[66]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[66]_i_3 
       (.I0(\q[66]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q[66]_i_10_n_0 ),
        .O(\q[66]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[66]_i_4 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[67]_i_17_n_0 ),
        .O(\q[66]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h718E8E71FFFFFFFF)) 
    \q[66]_i_5 
       (.I0(\q[65]_i_3_n_0 ),
        .I1(\q[66]_i_11_n_0 ),
        .I2(\q_reg[65]_0 ),
        .I3(\q_reg[66]_0 ),
        .I4(\q[66]_i_12_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[66]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[66]_i_6 
       (.I0(\q[66]_i_13_n_0 ),
        .I1(\q_reg[66]_0 ),
        .I2(\q[66]_i_7_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[66]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[66]_i_7 
       (.I0(r_Imm_ex[23]),
        .I1(\q[66]_i_14_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[66]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[66]_i_8 
       (.I0(\q_reg[148]_15 ),
        .I1(r_PC_ex[23]),
        .I2(Q[28]),
        .O(\q_reg[66]_0 ));
  LUT5 #(
    .INIT(32'h50545155)) 
    \q[66]_i_9 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[73]_i_13_n_0 ),
        .I3(\q_reg[72]_0 ),
        .I4(\q_reg[68]_0 ),
        .O(\q[66]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h02AE0457)) 
    \q[67]_i_10 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(ALU_B[20]),
        .I2(\q_reg[63]_0 ),
        .I3(\q_reg[64]_0 ),
        .I4(\q[65]_i_12_n_0 ),
        .O(\q[67]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB5004A)) 
    \q[67]_i_11 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[66]_i_7_n_0 ),
        .I5(\q_reg[66]_0 ),
        .O(\q[67]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h00000000004AFFB5)) 
    \q[67]_i_12 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(ALU_B[22]),
        .I5(\q_reg[65]_0 ),
        .O(\q[67]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h4CFD317F)) 
    \q[67]_i_13 
       (.I0(\q_reg[63]_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(ALU_B[20]),
        .I3(\q_reg[64]_0 ),
        .I4(\q[65]_i_12_n_0 ),
        .O(\q[67]_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h0D70DD77)) 
    \q[67]_i_14 
       (.I0(\q_reg[66]_0 ),
        .I1(\q[66]_i_7_n_0 ),
        .I2(ALU_B[22]),
        .I3(\q[69]_i_7_n_0 ),
        .I4(\q_reg[65]_0 ),
        .O(\q[67]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hAA00CCF0AAFFCCF0)) 
    \q[67]_i_15 
       (.I0(\q[67]_i_20_n_0 ),
        .I1(\q[67]_i_21_n_0 ),
        .I2(\q[67]_i_22_n_0 ),
        .I3(ALU_B[0]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[67]_i_17_n_0 ),
        .O(\q[67]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[67]_i_16 
       (.I0(\q[73]_i_13_n_0 ),
        .I1(\q_reg[74]_0 ),
        .O(\q[67]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h88888888B8BBB888)) 
    \q[67]_i_17 
       (.I0(\q[69]_i_9_n_0 ),
        .I1(ALU_B[1]),
        .I2(\q_reg[71]_0 ),
        .I3(ALU_B[2]),
        .I4(\q_reg[67]_0 ),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[67]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[67]_i_18 
       (.I0(r_rs1Data_ex[24]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [24]),
        .I4(w_RegWriteData_wb[24]),
        .I5(\q_reg[6]_0 ),
        .O(\q[67]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[67]_i_19 
       (.I0(r_rs2Data_ex[24]),
        .I1(\q_reg[74]_1 [24]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[24]),
        .I4(\q_reg[11]_0 ),
        .O(\q[67]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554100)) 
    \q[67]_i_1__0 
       (.I0(\q[67]_i_2_n_0 ),
        .I1(\q[67]_i_3_n_0 ),
        .I2(\q[67]_i_4_n_0 ),
        .I3(\q[67]_i_5_n_0 ),
        .I4(\q[67]_i_6_n_0 ),
        .I5(\q[67]_i_7_n_0 ),
        .O(D[55]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[67]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[67]_0 ),
        .I3(\q_reg[67]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[67]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF1D0000FF1DFFFF)) 
    \q[67]_i_20 
       (.I0(\q_reg[70]_0 ),
        .I1(ALU_B[2]),
        .I2(\q_reg[74]_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(ALU_B[1]),
        .I5(\q[68]_i_8_n_0 ),
        .O(\q[67]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[67]_i_21 
       (.I0(\q[67]_i_23_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_24_n_0 ),
        .I3(\q[67]_i_24_n_0 ),
        .I4(\q[71]_i_26_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[67]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[67]_i_22 
       (.I0(\q[67]_i_25_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_30_n_0 ),
        .I3(\q[70]_i_19_n_0 ),
        .I4(\q[71]_i_28_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[67]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \q[67]_i_23 
       (.I0(ALU_A[9]),
        .I1(ALU_B[3]),
        .I2(ALU_A[1]),
        .I3(ALU_B[4]),
        .I4(ALU_A[17]),
        .O(\q[67]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \q[67]_i_24 
       (.I0(ALU_A[11]),
        .I1(ALU_B[3]),
        .I2(ALU_A[3]),
        .I3(ALU_B[4]),
        .I4(ALU_A[19]),
        .O(\q[67]_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hFC44FC77)) 
    \q[67]_i_25 
       (.I0(ALU_A[10]),
        .I1(ALU_B[3]),
        .I2(\q[45]_i_6_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_A[18]),
        .O(\q[67]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h000400070F0F0F0F)) 
    \q[67]_i_3 
       (.I0(\q[67]_i_10_n_0 ),
        .I1(\q[63]_i_3_n_0 ),
        .I2(\q[67]_i_11_n_0 ),
        .I3(\q[67]_i_12_n_0 ),
        .I4(\q[67]_i_13_n_0 ),
        .I5(\q[67]_i_14_n_0 ),
        .O(\q[67]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h55556599AAAA9A66)) 
    \q[67]_i_4 
       (.I0(\q_reg[67]_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(r_ALUCode_ex[2]),
        .I5(\q_reg[67]_1 ),
        .O(\q[67]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h15)) 
    \q[67]_i_5 
       (.I0(r_ALUCode_ex[2]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[1]),
        .O(\q[67]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C70707C707C7C)) 
    \q[67]_i_6 
       (.I0(\q[67]_i_15_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[67]_0 ),
        .I5(\q_reg[67]_1 ),
        .O(\q[67]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hE0FFE0E0)) 
    \q[67]_i_7 
       (.I0(\q[67]_i_16_n_0 ),
        .I1(\q[67]_i_17_n_0 ),
        .I2(\q[72]_i_4_n_0 ),
        .I3(\q[68]_i_3_n_0 ),
        .I4(\q[73]_i_4_n_0 ),
        .O(\q[67]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[67]_i_8 
       (.I0(r_PC_ex[24]),
        .I1(Q[28]),
        .I2(\q[67]_i_18_n_0 ),
        .O(\q_reg[67]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[67]_i_9 
       (.I0(r_Imm_ex[23]),
        .I1(\q[67]_i_19_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[67]_1 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[68]_i_10 
       (.I0(\q[68]_i_6_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[68]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFF0AACC00F0AACC)) 
    \q[68]_i_11 
       (.I0(\q[67]_i_20_n_0 ),
        .I1(\q[69]_i_13_n_0 ),
        .I2(\q[67]_i_22_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[69]_i_12_n_0 ),
        .O(\q[68]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[68]_i_12 
       (.I0(r_rs2Data_ex[25]),
        .I1(\q_reg[74]_1 [25]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[25]),
        .I4(\q_reg[11]_0 ),
        .O(\q[68]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[68]_i_13 
       (.I0(r_rs1Data_ex[25]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [25]),
        .I4(w_RegWriteData_wb[25]),
        .I5(\q_reg[6]_0 ),
        .O(\q[68]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h11F111F1FFFF11F1)) 
    \q[68]_i_1__0 
       (.I0(\q[68]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[69]_i_5_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[68]_i_3_n_0 ),
        .O(D[56]));
  LUT6 #(
    .INIT(64'hF022FF22F022F022)) 
    \q[68]_i_2 
       (.I0(\q[68]_i_4_n_0 ),
        .I1(\q[68]_i_5_n_0 ),
        .I2(\q[68]_i_6_n_0 ),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q_reg[68]_0 ),
        .I5(r_ALUCode_ex[0]),
        .O(\q[68]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00F010B000FF1FBF)) 
    \q[68]_i_3 
       (.I0(ALU_B[2]),
        .I1(\q_reg[70]_0 ),
        .I2(ALU_B[1]),
        .I3(\q_reg[74]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .I5(\q[68]_i_8_n_0 ),
        .O(\q[68]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8E71718EFFFFFFFF)) 
    \q[68]_i_4 
       (.I0(\q[67]_i_3_n_0 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[68]_i_9_n_0 ),
        .I3(\q_reg[68]_0 ),
        .I4(\q[68]_i_10_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[68]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h5555F3C355000000)) 
    \q[68]_i_5 
       (.I0(\q[68]_i_11_n_0 ),
        .I1(\q[68]_i_6_n_0 ),
        .I2(\q_reg[68]_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[68]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h0FEE)) 
    \q[68]_i_6 
       (.I0(\q[68]_i_12_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[25]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[68]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[68]_i_7 
       (.I0(\q[68]_i_13_n_0 ),
        .I1(r_PC_ex[25]),
        .I2(Q[28]),
        .O(\q_reg[68]_0 ));
  LUT4 #(
    .INIT(16'h0C0A)) 
    \q[68]_i_8 
       (.I0(\q_reg[68]_0 ),
        .I1(\q_reg[72]_0 ),
        .I2(\q[73]_i_13_n_0 ),
        .I3(ALU_B[2]),
        .O(\q[68]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[68]_i_9 
       (.I0(\q_reg[67]_1 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[68]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[69]_i_10 
       (.I0(r_rs2Data_ex[26]),
        .I1(\q_reg[74]_1 [26]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[26]),
        .I4(\q_reg[11]_0 ),
        .O(\q[69]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hF0CCFFAAF0CC00AA)) 
    \q[69]_i_11 
       (.I0(\q[70]_i_17_n_0 ),
        .I1(\q[69]_i_12_n_0 ),
        .I2(\q[70]_i_16_n_0 ),
        .I3(ALU_B[0]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[69]_i_13_n_0 ),
        .O(\q[69]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF0FFF5F5F3F3)) 
    \q[69]_i_12 
       (.I0(\q_reg[73]_0 ),
        .I1(\q_reg[69]_0 ),
        .I2(\q[73]_i_13_n_0 ),
        .I3(\q_reg[71]_0 ),
        .I4(ALU_B[2]),
        .I5(ALU_B[1]),
        .O(\q[69]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[69]_i_13 
       (.I0(\q[67]_i_24_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_26_n_0 ),
        .I3(\q[71]_i_24_n_0 ),
        .I4(\q[71]_i_25_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[69]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h44F444F4FFFF44F4)) 
    \q[69]_i_1__0 
       (.I0(\q[69]_i_2_n_0 ),
        .I1(\q[69]_i_3_n_0 ),
        .I2(\q[73]_i_4_n_0 ),
        .I3(\q[69]_i_4_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[69]_i_5_n_0 ),
        .O(D[57]));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBAAAA)) 
    \q[69]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(ALU_B[26]),
        .I2(\q_reg[69]_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[69]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF69960000)) 
    \q[69]_i_3 
       (.I0(\q[70]_i_7_n_0 ),
        .I1(ALU_B[26]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q_reg[69]_0 ),
        .I4(\q[67]_i_5_n_0 ),
        .I5(\q[69]_i_8_n_0 ),
        .O(\q[69]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF0407F4F7)) 
    \q[69]_i_4 
       (.I0(\q_reg[72]_0 ),
        .I1(ALU_B[1]),
        .I2(ALU_B[2]),
        .I3(\q_reg[70]_0 ),
        .I4(\q_reg[74]_0 ),
        .I5(\q[73]_i_13_n_0 ),
        .O(\q[69]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00F010B000FF1FBF)) 
    \q[69]_i_5 
       (.I0(ALU_B[2]),
        .I1(\q_reg[71]_0 ),
        .I2(ALU_B[1]),
        .I3(\q_reg[74]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .I5(\q[69]_i_9_n_0 ),
        .O(\q[69]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[69]_i_6 
       (.I0(\q[69]_i_10_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[23]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[26]));
  LUT4 #(
    .INIT(16'hFFB5)) 
    \q[69]_i_7 
       (.I0(r_ALUCode_ex[0]),
        .I1(r_ALUCode_ex[3]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .O(\q[69]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C7C70707C7C70)) 
    \q[69]_i_8 
       (.I0(\q[69]_i_11_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q_reg[69]_0 ),
        .I4(ALU_B[26]),
        .I5(r_ALUCode_ex[0]),
        .O(\q[69]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h00B8)) 
    \q[69]_i_9 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_B[2]),
        .I2(\q_reg[69]_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .O(\q[69]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[70]_i_10 
       (.I0(r_PC_ex[27]),
        .I1(Q[28]),
        .I2(\q_reg[148]_17 ),
        .O(\q_reg[70]_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[70]_i_11 
       (.I0(\q[70]_i_13_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[70]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hF0CCFFAAF0CC00AA)) 
    \q[70]_i_12 
       (.I0(\q[71]_i_18_n_0 ),
        .I1(\q[70]_i_16_n_0 ),
        .I2(\q[71]_i_20_n_0 ),
        .I3(ALU_B[0]),
        .I4(r_ALUCode_ex[0]),
        .I5(\q[70]_i_17_n_0 ),
        .O(\q[70]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[70]_i_13 
       (.I0(r_Imm_ex[16]),
        .I1(\q[70]_i_18_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[70]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF0FFF3F3F5F5)) 
    \q[70]_i_16 
       (.I0(\q_reg[70]_0 ),
        .I1(\q_reg[74]_0 ),
        .I2(\q[73]_i_13_n_0 ),
        .I3(\q_reg[72]_0 ),
        .I4(ALU_B[2]),
        .I5(ALU_B[1]),
        .O(\q[70]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[70]_i_17 
       (.I0(\q[70]_i_19_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_28_n_0 ),
        .I3(\q[71]_i_30_n_0 ),
        .I4(\q[71]_i_31_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[70]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[70]_i_18 
       (.I0(r_rs2Data_ex[27]),
        .I1(\q_reg[74]_1 [27]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[27]),
        .I4(\q_reg[11]_0 ),
        .O(\q[70]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hFFCC4747)) 
    \q[70]_i_19 
       (.I0(ALU_A[12]),
        .I1(ALU_B[3]),
        .I2(\q_reg[63]_0 ),
        .I3(\q[55]_i_19_n_0 ),
        .I4(ALU_B[4]),
        .O(\q[70]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000FF0D)) 
    \q[70]_i_1__0 
       (.I0(\q[70]_i_2__0_n_0 ),
        .I1(\q[70]_i_3_n_0 ),
        .I2(\q[70]_i_4_n_0 ),
        .I3(\q[70]_i_5_n_0 ),
        .I4(r_ALUCode_ex[3]),
        .I5(\q[70]_i_6_n_0 ),
        .O(D[58]));
  LUT6 #(
    .INIT(64'h718E8E71FFFFFFFF)) 
    \q[70]_i_2__0 
       (.I0(\q[70]_i_7_n_0 ),
        .I1(\q[70]_i_8_n_0 ),
        .I2(\q_reg[69]_0 ),
        .I3(\q_reg[70]_0 ),
        .I4(\q[70]_i_11_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[70]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[70]_i_3 
       (.I0(\q[70]_i_12_n_0 ),
        .I1(\q_reg[70]_0 ),
        .I2(\q[70]_i_13_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[70]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[70]_i_4 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[2]),
        .O(\q[70]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h000000D0)) 
    \q[70]_i_5 
       (.I0(r_ALUCode_ex[0]),
        .I1(\q_reg[70]_0 ),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q[70]_i_13_n_0 ),
        .O(\q[70]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \q[70]_i_6 
       (.I0(\q[69]_i_4_n_0 ),
        .I1(\q[72]_i_4_n_0 ),
        .I2(\q[71]_i_6_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .O(\q[70]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h7010F1F701077F1F)) 
    \q[70]_i_7 
       (.I0(\q[67]_i_3_n_0 ),
        .I1(\q_reg[67]_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q_reg[67]_1 ),
        .I4(\q_reg[68]_0 ),
        .I5(\q[68]_i_6_n_0 ),
        .O(\q[70]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[70]_i_8 
       (.I0(ALU_B[26]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[70]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[70]_i_9 
       (.I0(r_PC_ex[26]),
        .I1(Q[28]),
        .I2(\q_reg[148]_16 ),
        .O(\q_reg[69]_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \q[71]_i_10 
       (.I0(\q[71]_i_14_n_0 ),
        .I1(\q[71]_i_15_n_0 ),
        .I2(\q[63]_i_3_n_0 ),
        .I3(\q[71]_i_16_n_0 ),
        .I4(\q[71]_i_17_n_0 ),
        .O(\q[71]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hCCAAF0FFCCAAF000)) 
    \q[71]_i_11 
       (.I0(\q[71]_i_18_n_0 ),
        .I1(\q[71]_i_19_n_0 ),
        .I2(\q[71]_i_20_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[71]_i_21_n_0 ),
        .O(\q[71]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[71]_i_12 
       (.I0(r_rs1Data_ex[28]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [28]),
        .I4(w_RegWriteData_wb[28]),
        .I5(\q_reg[6]_0 ),
        .O(\q[71]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[71]_i_13 
       (.I0(r_rs2Data_ex[28]),
        .I1(\q_reg[74]_1 [28]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[28]),
        .I4(\q_reg[11]_0 ),
        .O(\q[71]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[71]_i_14 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_B[26]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[71]_i_22_n_0 ),
        .I4(\q_reg[70]_0 ),
        .I5(\q[70]_i_13_n_0 ),
        .O(\q[71]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[71]_i_15 
       (.I0(\q_reg[65]_0 ),
        .I1(ALU_B[22]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[67]_i_10_n_0 ),
        .I4(\q_reg[66]_0 ),
        .I5(\q[66]_i_7_n_0 ),
        .O(\q[71]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[71]_i_16 
       (.I0(\q_reg[65]_0 ),
        .I1(ALU_B[22]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[67]_i_13_n_0 ),
        .I4(\q_reg[66]_0 ),
        .I5(\q[66]_i_7_n_0 ),
        .O(\q[71]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h8FEF020BF2FB80E0)) 
    \q[71]_i_17 
       (.I0(\q_reg[69]_0 ),
        .I1(ALU_B[26]),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q[71]_i_23_n_0 ),
        .I4(\q_reg[70]_0 ),
        .I5(\q[70]_i_13_n_0 ),
        .O(\q[71]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \q[71]_i_18 
       (.I0(\q[71]_i_24_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_25_n_0 ),
        .I3(\q[71]_i_26_n_0 ),
        .I4(\q[71]_i_27_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[71]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFF1FD)) 
    \q[71]_i_19 
       (.I0(\q_reg[72]_0 ),
        .I1(ALU_B[1]),
        .I2(ALU_B[2]),
        .I3(\q_reg[74]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .O(\q[71]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFF54FF54FFFFFF54)) 
    \q[71]_i_1__0 
       (.I0(\q[71]_i_2_n_0 ),
        .I1(\q[71]_i_3_n_0 ),
        .I2(\q[71]_i_4_n_0 ),
        .I3(\q[71]_i_5_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[71]_i_6_n_0 ),
        .O(D[59]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFAEAAAA)) 
    \q[71]_i_2 
       (.I0(r_ALUCode_ex[3]),
        .I1(r_ALUCode_ex[0]),
        .I2(\q_reg[71]_0 ),
        .I3(\q_reg[71]_1 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[71]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFDCDF)) 
    \q[71]_i_20 
       (.I0(\q_reg[73]_0 ),
        .I1(ALU_B[2]),
        .I2(ALU_B[1]),
        .I3(\q_reg[71]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .O(\q[71]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \q[71]_i_21 
       (.I0(\q[71]_i_28_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_29_n_0 ),
        .I3(\q[71]_i_30_n_0 ),
        .I4(\q[71]_i_31_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[71]_i_21_n_0 ));
  LUT5 #(
    .INIT(32'h08AB015D)) 
    \q[71]_i_22 
       (.I0(\q[69]_i_7_n_0 ),
        .I1(\q_reg[67]_1 ),
        .I2(\q_reg[67]_0 ),
        .I3(\q_reg[68]_0 ),
        .I4(\q[68]_i_6_n_0 ),
        .O(\q[71]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hC4DF13F7)) 
    \q[71]_i_23 
       (.I0(\q_reg[67]_0 ),
        .I1(\q[69]_i_7_n_0 ),
        .I2(\q_reg[67]_1 ),
        .I3(\q_reg[68]_0 ),
        .I4(\q[68]_i_6_n_0 ),
        .O(\q[71]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \q[71]_i_24 
       (.I0(ALU_A[13]),
        .I1(ALU_B[3]),
        .I2(ALU_A[5]),
        .I3(ALU_B[4]),
        .I4(\q_reg[64]_0 ),
        .O(\q[71]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h5500330F55FF330F)) 
    \q[71]_i_25 
       (.I0(ALU_A[1]),
        .I1(ALU_A[17]),
        .I2(\q_reg[68]_0 ),
        .I3(ALU_B[3]),
        .I4(ALU_B[4]),
        .I5(ALU_A[9]),
        .O(\q[71]_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hFC44FC77)) 
    \q[71]_i_26 
       (.I0(ALU_A[15]),
        .I1(ALU_B[3]),
        .I2(\q[50]_i_6_n_0 ),
        .I3(ALU_B[4]),
        .I4(\q_reg[66]_0 ),
        .O(\q[71]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h55330F0055330FFF)) 
    \q[71]_i_27 
       (.I0(ALU_A[3]),
        .I1(ALU_A[19]),
        .I2(ALU_A[11]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[70]_0 ),
        .O(\q[71]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hAA33F000AA33F0FF)) 
    \q[71]_i_28 
       (.I0(\q[45]_i_16_n_0 ),
        .I1(ALU_A[16]),
        .I2(\q[53]_i_9_n_0 ),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[67]_0 ),
        .O(\q[71]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'hCC00550FCCFF550F)) 
    \q[71]_i_29 
       (.I0(\q_reg[63]_0 ),
        .I1(\q[55]_i_19_n_0 ),
        .I2(\q_reg[71]_0 ),
        .I3(ALU_B[3]),
        .I4(ALU_B[4]),
        .I5(ALU_A[12]),
        .O(\q[71]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0007070007000007)) 
    \q[71]_i_3 
       (.I0(r_ALUCode_ex[1]),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[2]),
        .I3(\q_reg[71]_0 ),
        .I4(\q[71]_i_9_n_0 ),
        .I5(\q[71]_i_10_n_0 ),
        .O(\q[71]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFC44FC77)) 
    \q[71]_i_30 
       (.I0(ALU_A[14]),
        .I1(ALU_B[3]),
        .I2(\q[50]_i_9_n_0 ),
        .I3(ALU_B[4]),
        .I4(\q_reg[65]_0 ),
        .O(\q[71]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hAA330F00AA330FFF)) 
    \q[71]_i_31 
       (.I0(\q[45]_i_6_n_0 ),
        .I1(ALU_A[18]),
        .I2(ALU_A[10]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[69]_0 ),
        .O(\q[71]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h7C7C70707C707C7C)) 
    \q[71]_i_4 
       (.I0(\q[71]_i_11_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[71]_0 ),
        .I5(\q_reg[71]_1 ),
        .O(\q[71]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA0000AAA80020)) 
    \q[71]_i_5 
       (.I0(\q[73]_i_4_n_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[72]_0 ),
        .I3(ALU_B[2]),
        .I4(\q_reg[74]_0 ),
        .I5(ALU_B[1]),
        .O(\q[71]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h333335353333303F)) 
    \q[71]_i_6 
       (.I0(\q_reg[73]_0 ),
        .I1(\q_reg[74]_0 ),
        .I2(ALU_B[2]),
        .I3(\q_reg[71]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .I5(ALU_B[1]),
        .O(\q[71]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[71]_i_7 
       (.I0(\q[71]_i_12_n_0 ),
        .I1(r_PC_ex[28]),
        .I2(Q[28]),
        .O(\q_reg[71]_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[71]_i_8 
       (.I0(r_Imm_ex[7]),
        .I1(\q[71]_i_13_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q_reg[71]_1 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[71]_i_9 
       (.I0(\q_reg[71]_1 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[71]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hA9A99AAA)) 
    \q[72]_i_10 
       (.I0(\q[72]_i_8_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[72]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h33FFF0AA3300F0AA)) 
    \q[72]_i_11 
       (.I0(\q[73]_i_28_n_0 ),
        .I1(\q[72]_i_14_n_0 ),
        .I2(\q[71]_i_19_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(ALU_B[0]),
        .I5(\q[71]_i_21_n_0 ),
        .O(\q[72]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[72]_i_12 
       (.I0(r_rs2Data_ex[29]),
        .I1(\q_reg[74]_1 [29]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[29]),
        .I4(\q_reg[11]_0 ),
        .O(\q[72]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h20)) 
    \q[72]_i_14 
       (.I0(\q_reg[73]_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q[45]_i_14_n_0 ),
        .O(\q[72]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hF111F111FFFFF111)) 
    \q[72]_i_1__0 
       (.I0(\q[72]_i_2_n_0 ),
        .I1(r_ALUCode_ex[3]),
        .I2(\q[72]_i_3_n_0 ),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q[72]_i_4_n_0 ),
        .I5(\q[72]_i_5_n_0 ),
        .O(D[60]));
  LUT6 #(
    .INIT(64'hF022FF22F022F022)) 
    \q[72]_i_2 
       (.I0(\q[72]_i_6_n_0 ),
        .I1(\q[72]_i_7_n_0 ),
        .I2(\q[72]_i_8_n_0 ),
        .I3(\q[70]_i_4_n_0 ),
        .I4(\q_reg[72]_0 ),
        .I5(r_ALUCode_ex[0]),
        .O(\q[72]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0F0E4)) 
    \q[72]_i_3 
       (.I0(ALU_B[1]),
        .I1(\q_reg[73]_0 ),
        .I2(\q_reg[74]_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(ALU_B[2]),
        .O(\q[72]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0010)) 
    \q[72]_i_4 
       (.I0(ALU_B[0]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .O(\q[72]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h33333237)) 
    \q[72]_i_5 
       (.I0(ALU_B[1]),
        .I1(\q_reg[74]_0 ),
        .I2(ALU_B[2]),
        .I3(\q_reg[72]_0 ),
        .I4(\q[73]_i_13_n_0 ),
        .O(\q[72]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB24D4DB2FFFFFFFF)) 
    \q[72]_i_6 
       (.I0(\q[71]_i_10_n_0 ),
        .I1(\q[71]_i_9_n_0 ),
        .I2(\q_reg[71]_0 ),
        .I3(\q_reg[72]_0 ),
        .I4(\q[72]_i_10_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[72]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFC355000000)) 
    \q[72]_i_7 
       (.I0(\q[72]_i_11_n_0 ),
        .I1(\q_reg[72]_0 ),
        .I2(\q[72]_i_8_n_0 ),
        .I3(r_ALUCode_ex[0]),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[72]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h55FC)) 
    \q[72]_i_8 
       (.I0(r_Imm_ex[7]),
        .I1(\q[72]_i_12_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(\q[72]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[72]_i_9 
       (.I0(\q_reg[148]_18 ),
        .I1(r_PC_ex[29]),
        .I2(Q[28]),
        .O(\q_reg[72]_0 ));
  LUT4 #(
    .INIT(16'hAA03)) 
    \q[73]_i_10 
       (.I0(r_Imm_ex[16]),
        .I1(\q[73]_i_17_n_0 ),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[30]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFF20000)) 
    \q[73]_i_11 
       (.I0(r_rs2Data_ex[0]),
        .I1(\q_reg[6]_2 ),
        .I2(\q_reg[43] ),
        .I3(\q_reg[39] ),
        .I4(\q[73]_i_21_n_0 ),
        .I5(\q[73]_i_22_n_0 ),
        .O(ALU_B[0]));
  LUT4 #(
    .INIT(16'hAAFC)) 
    \q[73]_i_12 
       (.I0(r_Imm_ex[2]),
        .I1(D[1]),
        .I2(r_ALUSrcB_ex[1]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[2]));
  LUT2 #(
    .INIT(4'hE)) 
    \q[73]_i_13 
       (.I0(ALU_B[4]),
        .I1(ALU_B[3]),
        .O(\q[73]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFF20000)) 
    \q[73]_i_14 
       (.I0(Q[12]),
        .I1(\q_reg[6]_2 ),
        .I2(\q_reg[40]_0 ),
        .I3(\q_reg[44]_2 ),
        .I4(\q[73]_i_21_n_0 ),
        .I5(\q[73]_i_26_n_0 ),
        .O(ALU_B[1]));
  LUT5 #(
    .INIT(32'h0D0D000D)) 
    \q[73]_i_15 
       (.I0(\q[54]_i_26_n_0 ),
        .I1(\q[74]_i_10_n_0 ),
        .I2(\q[73]_i_27_n_0 ),
        .I3(\q[54]_i_24_n_0 ),
        .I4(\q[73]_i_28_n_0 ),
        .O(\q[73]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[73]_i_17 
       (.I0(r_rs2Data_ex[30]),
        .I1(\q_reg[74]_1 [30]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[30]),
        .I4(\q_reg[11]_0 ),
        .O(\q[73]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFF0D0D0D)) 
    \q[73]_i_1__0 
       (.I0(\q[73]_i_2_n_0 ),
        .I1(\q[73]_i_3_n_0 ),
        .I2(r_ALUCode_ex[3]),
        .I3(\q[73]_i_4_n_0 ),
        .I4(\q_reg[74]_0 ),
        .I5(\q[73]_i_5_n_0 ),
        .O(D[61]));
  LUT6 #(
    .INIT(64'hABBABAABBBBBBBBB)) 
    \q[73]_i_2 
       (.I0(\q[70]_i_4_n_0 ),
        .I1(\q[73]_i_6_n_0 ),
        .I2(\q[73]_i_7_n_0 ),
        .I3(\q_reg[73]_0 ),
        .I4(\q[73]_i_9_n_0 ),
        .I5(\q[67]_i_5_n_0 ),
        .O(\q[73]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \q[73]_i_21 
       (.I0(r_ALUSrcB_ex[1]),
        .I1(r_ALUSrcB_ex[0]),
        .O(\q[73]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \q[73]_i_22 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[0]),
        .O(\q[73]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'hF011)) 
    \q[73]_i_23 
       (.I0(\q[73]_i_29_n_0 ),
        .I1(r_ALUSrcB_ex[1]),
        .I2(r_Imm_ex[4]),
        .I3(r_ALUSrcB_ex[0]),
        .O(ALU_B[4]));
  LUT2 #(
    .INIT(4'h8)) 
    \q[73]_i_26 
       (.I0(r_ALUSrcB_ex[0]),
        .I1(r_Imm_ex[1]),
        .O(\q[73]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h00F8008800000000)) 
    \q[73]_i_27 
       (.I0(\q[54]_i_10_n_0 ),
        .I1(\q_reg[74]_0 ),
        .I2(\q[45]_i_9_n_0 ),
        .I3(\q[73]_i_13_n_0 ),
        .I4(\q_reg[73]_0 ),
        .I5(\q[45]_i_14_n_0 ),
        .O(\q[73]_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \q[73]_i_28 
       (.I0(\q[71]_i_26_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_27_n_0 ),
        .I3(ALU_B[1]),
        .I4(\q[74]_i_17_n_0 ),
        .O(\q[73]_i_28_n_0 ));
  LUT5 #(
    .INIT(32'h535300F3)) 
    \q[73]_i_29 
       (.I0(r_rs2Data_ex[4]),
        .I1(\q_reg[74]_1 [4]),
        .I2(\q_reg[44]_1 ),
        .I3(w_RegWriteData_wb[4]),
        .I4(\q_reg[11]_0 ),
        .O(\q[73]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'h08080008)) 
    \q[73]_i_3 
       (.I0(ALU_B[30]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[73]_0 ),
        .O(\q[73]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0020)) 
    \q[73]_i_4 
       (.I0(ALU_B[0]),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[0]),
        .O(\q[73]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0F1E000000000)) 
    \q[73]_i_5 
       (.I0(ALU_B[2]),
        .I1(\q[73]_i_13_n_0 ),
        .I2(\q_reg[74]_0 ),
        .I3(\q_reg[73]_0 ),
        .I4(ALU_B[1]),
        .I5(\q[72]_i_4_n_0 ),
        .O(\q[73]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h5555CFF044440000)) 
    \q[73]_i_6 
       (.I0(\q[73]_i_15_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(ALU_B[30]),
        .I3(\q_reg[73]_0 ),
        .I4(r_ALUCode_ex[1]),
        .I5(r_ALUCode_ex[2]),
        .O(\q[73]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h70100107F1F77F1F)) 
    \q[73]_i_7 
       (.I0(\q[71]_i_10_n_0 ),
        .I1(\q_reg[71]_0 ),
        .I2(\q[69]_i_7_n_0 ),
        .I3(\q_reg[71]_1 ),
        .I4(\q[72]_i_8_n_0 ),
        .I5(\q_reg[72]_0 ),
        .O(\q[73]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h0B)) 
    \q[73]_i_8 
       (.I0(r_PC_ex[30]),
        .I1(Q[28]),
        .I2(\q_reg[148]_19 ),
        .O(\q_reg[73]_0 ));
  LUT5 #(
    .INIT(32'h56566555)) 
    \q[73]_i_9 
       (.I0(ALU_B[30]),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(r_ALUCode_ex[3]),
        .I4(r_ALUCode_ex[0]),
        .O(\q[73]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB8CCB833B800)) 
    \q[74]_i_10 
       (.I0(\q[71]_i_28_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[71]_i_29_n_0 ),
        .I3(ALU_B[1]),
        .I4(\q[74]_i_15_n_0 ),
        .I5(\q[71]_i_31_n_0 ),
        .O(\q[74]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h0000220AAAAA220A)) 
    \q[74]_i_11 
       (.I0(\q[54]_i_26_n_0 ),
        .I1(\q[71]_i_27_n_0 ),
        .I2(\q[74]_i_16_n_0 ),
        .I3(ALU_B[2]),
        .I4(ALU_B[1]),
        .I5(\q[74]_i_17_n_0 ),
        .O(\q[74]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \q[74]_i_12 
       (.I0(\q_reg[74]_0 ),
        .I1(\q[73]_i_13_n_0 ),
        .O(\q[74]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hAA330F00AA330FFF)) 
    \q[74]_i_15 
       (.I0(\q[50]_i_9_n_0 ),
        .I1(\q_reg[65]_0 ),
        .I2(ALU_A[14]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[73]_0 ),
        .O(\q[74]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAA330F00AA330FFF)) 
    \q[74]_i_16 
       (.I0(\q[50]_i_6_n_0 ),
        .I1(\q_reg[66]_0 ),
        .I2(ALU_A[15]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[74]_0 ),
        .O(\q[74]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[74]_i_17 
       (.I0(\q[71]_i_25_n_0 ),
        .I1(ALU_B[2]),
        .I2(\q[74]_i_18_n_0 ),
        .O(\q[74]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h55330F0055330FFF)) 
    \q[74]_i_18 
       (.I0(ALU_A[5]),
        .I1(\q_reg[64]_0 ),
        .I2(ALU_A[13]),
        .I3(ALU_B[4]),
        .I4(ALU_B[3]),
        .I5(\q_reg[72]_0 ),
        .O(\q[74]_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h05350505)) 
    \q[74]_i_1__0 
       (.I0(\q[74]_i_2_n_0 ),
        .I1(r_ALUCode_ex[0]),
        .I2(r_ALUCode_ex[3]),
        .I3(r_ALUCode_ex[1]),
        .I4(\q_reg[74]_0 ),
        .O(D[62]));
  LUT5 #(
    .INIT(32'h000030FD)) 
    \q[74]_i_2 
       (.I0(\q[43]_i_6_n_0 ),
        .I1(r_ALUCode_ex[2]),
        .I2(r_ALUCode_ex[1]),
        .I3(\q[74]_i_4_n_0 ),
        .I4(\q[74]_i_5_n_0 ),
        .O(\q[74]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \q[74]_i_3 
       (.I0(\q[74]_i_6_n_0 ),
        .I1(r_PC_ex[31]),
        .I2(Q[28]),
        .O(\q_reg[74]_0 ));
  LUT6 #(
    .INIT(64'h7740444074407740)) 
    \q[74]_i_4 
       (.I0(\q[74]_i_7_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[0]),
        .I3(r_ALUCode_ex[2]),
        .I4(\q_reg[74]_0 ),
        .I5(\q[43]_i_12_n_0 ),
        .O(\q[74]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h04040004)) 
    \q[74]_i_5 
       (.I0(\q[43]_i_12_n_0 ),
        .I1(r_ALUCode_ex[1]),
        .I2(r_ALUCode_ex[2]),
        .I3(r_ALUCode_ex[0]),
        .I4(\q_reg[74]_0 ),
        .O(\q[74]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h1013101300003033)) 
    \q[74]_i_6 
       (.I0(r_rs1Data_ex[31]),
        .I1(Q[28]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[74]_1 [31]),
        .I4(w_RegWriteData_wb[31]),
        .I5(\q_reg[6]_0 ),
        .O(\q[74]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000D0D0D0D0D0D0D)) 
    \q[74]_i_7 
       (.I0(\q[54]_i_24_n_0 ),
        .I1(\q[74]_i_10_n_0 ),
        .I2(\q[74]_i_11_n_0 ),
        .I3(\q[45]_i_14_n_0 ),
        .I4(\q[74]_i_12_n_0 ),
        .I5(\q[45]_i_9_n_0 ),
        .O(\q[74]_i_7_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [0]),
        .Q(Q[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[100] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [94]),
        .Q(r_rs1Data_ex[18]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[101] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [95]),
        .Q(r_rs1Data_ex[19]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[102] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [96]),
        .Q(Q[20]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[103] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [97]),
        .Q(Q[21]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[104] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [98]),
        .Q(Q[22]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[105] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [99]),
        .Q(Q[23]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[106] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [100]),
        .Q(r_rs1Data_ex[24]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[107] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [101]),
        .Q(r_rs1Data_ex[25]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[108] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [102]),
        .Q(Q[24]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[109] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [103]),
        .Q(Q[25]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [10]),
        .Q(r_PC_ex[7]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[110] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [104]),
        .Q(r_rs1Data_ex[28]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[111] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [105]),
        .Q(Q[26]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[112] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [106]),
        .Q(Q[27]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[113] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [107]),
        .Q(r_rs1Data_ex[31]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[114] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [108]),
        .Q(r_Imm_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[115] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [109]),
        .Q(r_Imm_ex[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[116] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [110]),
        .Q(r_Imm_ex[2]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[117] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [111]),
        .Q(r_Imm_ex[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[118] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [112]),
        .Q(r_Imm_ex[4]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[119] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [113]),
        .Q(r_Imm_ex[5]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [11]),
        .Q(r_PC_ex[8]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[120] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [114]),
        .Q(r_Imm_ex[6]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[121] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [115]),
        .Q(r_Imm_ex[7]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[126] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [116]),
        .Q(r_Imm_ex[12]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[127] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [117]),
        .Q(r_Imm_ex[13]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[128] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [118]),
        .Q(r_Imm_ex[14]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[129] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [119]),
        .Q(r_Imm_ex[15]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [12]),
        .Q(r_PC_ex[9]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[130] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [120]),
        .Q(r_Imm_ex[16]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[134] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [121]),
        .Q(r_Imm_ex[20]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[135] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [122]),
        .Q(r_Imm_ex[21]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[137] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [123]),
        .Q(r_Imm_ex[23]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[139] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [124]),
        .Q(r_Imm_ex[25]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [13]),
        .Q(r_PC_ex[10]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[146] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [125]),
        .Q(r_ALUSrcB_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[147] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [126]),
        .Q(r_ALUSrcB_ex[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[148] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [127]),
        .Q(Q[28]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[149] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [128]),
        .Q(r_ALUCode_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [14]),
        .Q(r_PC_ex[11]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[150] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [129]),
        .Q(r_ALUCode_ex[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[151] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [130]),
        .Q(r_ALUCode_ex[2]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[152] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [131]),
        .Q(r_ALUCode_ex[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[153] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [132]),
        .Q(Q[29]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[154] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [133]),
        .Q(Q[30]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[155] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [134]),
        .Q(Q[31]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [15]),
        .Q(r_PC_ex[12]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [16]),
        .Q(r_PC_ex[13]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [17]),
        .Q(r_PC_ex[14]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [18]),
        .Q(r_PC_ex[15]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [19]),
        .Q(r_PC_ex[16]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [1]),
        .Q(Q[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [20]),
        .Q(r_PC_ex[17]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [21]),
        .Q(r_PC_ex[18]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [22]),
        .Q(r_PC_ex[19]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [23]),
        .Q(r_PC_ex[20]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [24]),
        .Q(r_PC_ex[21]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [25]),
        .Q(r_PC_ex[22]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [26]),
        .Q(r_PC_ex[23]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [27]),
        .Q(r_PC_ex[24]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [28]),
        .Q(r_PC_ex[25]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [29]),
        .Q(r_PC_ex[26]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [2]),
        .Q(Q[2]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [30]),
        .Q(r_PC_ex[27]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [31]),
        .Q(r_PC_ex[28]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [32]),
        .Q(r_PC_ex[29]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [33]),
        .Q(r_PC_ex[30]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [34]),
        .Q(r_PC_ex[31]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [35]),
        .Q(Q[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [36]),
        .Q(Q[4]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [37]),
        .Q(Q[5]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [38]),
        .Q(Q[6]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [3]),
        .Q(r_PC_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [39]),
        .Q(Q[7]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [40]),
        .Q(Q[8]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [41]),
        .Q(Q[9]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [42]),
        .Q(Q[10]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [43]),
        .Q(Q[11]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [4]),
        .Q(r_PC_ex[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [44]),
        .Q(r_rs2Data_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [45]),
        .Q(Q[12]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [46]),
        .Q(r_rs2Data_ex[2]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [47]),
        .Q(r_rs2Data_ex[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [48]),
        .Q(r_rs2Data_ex[4]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [49]),
        .Q(r_rs2Data_ex[5]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [50]),
        .Q(r_rs2Data_ex[6]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [51]),
        .Q(r_rs2Data_ex[7]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [52]),
        .Q(r_rs2Data_ex[8]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [53]),
        .Q(r_rs2Data_ex[9]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [5]),
        .Q(r_PC_ex[2]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [54]),
        .Q(r_rs2Data_ex[10]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [55]),
        .Q(r_rs2Data_ex[11]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [56]),
        .Q(r_rs2Data_ex[12]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [57]),
        .Q(r_rs2Data_ex[13]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [58]),
        .Q(r_rs2Data_ex[14]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [59]),
        .Q(r_rs2Data_ex[15]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [60]),
        .Q(r_rs2Data_ex[16]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [61]),
        .Q(r_rs2Data_ex[17]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [62]),
        .Q(r_rs2Data_ex[18]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [63]),
        .Q(r_rs2Data_ex[19]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [6]),
        .Q(r_PC_ex[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [64]),
        .Q(r_rs2Data_ex[20]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[71] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [65]),
        .Q(r_rs2Data_ex[21]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[72] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [66]),
        .Q(r_rs2Data_ex[22]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[73] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [67]),
        .Q(r_rs2Data_ex[23]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[74] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [68]),
        .Q(r_rs2Data_ex[24]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[75] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [69]),
        .Q(r_rs2Data_ex[25]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[76] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [70]),
        .Q(r_rs2Data_ex[26]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[77] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [71]),
        .Q(r_rs2Data_ex[27]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[78] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [72]),
        .Q(r_rs2Data_ex[28]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[79] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [73]),
        .Q(r_rs2Data_ex[29]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [7]),
        .Q(r_PC_ex[4]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[80] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [74]),
        .Q(r_rs2Data_ex[30]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[81] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [75]),
        .Q(r_rs2Data_ex[31]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[82] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [76]),
        .Q(r_rs1Data_ex[0]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[83] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [77]),
        .Q(r_rs1Data_ex[1]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[84] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [78]),
        .Q(Q[13]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[85] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [79]),
        .Q(r_rs1Data_ex[3]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[86] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [80]),
        .Q(r_rs1Data_ex[4]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[87] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [81]),
        .Q(r_rs1Data_ex[5]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[88] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [82]),
        .Q(r_rs1Data_ex[6]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[89] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [83]),
        .Q(r_rs1Data_ex[7]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [8]),
        .Q(r_PC_ex[5]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[90] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [84]),
        .Q(r_rs1Data_ex[8]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[91] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [85]),
        .Q(r_rs1Data_ex[9]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[92] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [86]),
        .Q(Q[14]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[93] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [87]),
        .Q(r_rs1Data_ex[11]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[94] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [88]),
        .Q(Q[15]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[95] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [89]),
        .Q(r_rs1Data_ex[13]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[96] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [90]),
        .Q(Q[16]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[97] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [91]),
        .Q(Q[17]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[98] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [92]),
        .Q(Q[18]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[99] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [93]),
        .Q(Q[19]),
        .R(\q[155]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[6]_1 [9]),
        .Q(r_PC_ex[6]),
        .R(\q[155]_i_1_n_0 ));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized1
   (\q_reg[48]_0 ,
    Q,
    \q_reg[12]_0 ,
    \q_reg[12]_1 ,
    \q_reg[12]_2 ,
    \q_reg[59]_0 ,
    \q_reg[55]_0 ,
    \q_reg[44]_0 ,
    \q_reg[44]_1 ,
    \q_reg[44]_2 ,
    \q_reg[50]_0 ,
    \q_reg[50]_1 ,
    \q_reg[51]_0 ,
    \q_reg[52]_0 ,
    \q_reg[44]_3 ,
    \q_reg[70]_0 ,
    d,
    \q_reg[155] ,
    D,
    \q_reg[44]_4 ,
    w_RegWriteData_wb,
    SR,
    cpu_clk_BUFG,
    spo);
  output \q_reg[48]_0 ;
  output [38:0]Q;
  output \q_reg[12]_0 ;
  output \q_reg[12]_1 ;
  output \q_reg[12]_2 ;
  output \q_reg[59]_0 ;
  output \q_reg[55]_0 ;
  output \q_reg[44]_0 ;
  output \q_reg[44]_1 ;
  output \q_reg[44]_2 ;
  output \q_reg[50]_0 ;
  output \q_reg[50]_1 ;
  output \q_reg[51]_0 ;
  output \q_reg[52]_0 ;
  output \q_reg[44]_3 ;
  output [31:0]\q_reg[70]_0 ;
  output [31:0]d;
  input [16:0]\q_reg[155] ;
  input [62:0]D;
  input \q_reg[44]_4 ;
  input [0:0]w_RegWriteData_wb;
  input [0:0]SR;
  input cpu_clk_BUFG;
  input [31:0]spo;

  wire [62:0]D;
  wire [38:0]Q;
  wire [0:0]SR;
  wire cpu_clk_BUFG;
  wire [31:0]d;
  wire \q[39]_i_2_n_0 ;
  wire \q[40]_i_2_n_0 ;
  wire \q[41]_i_2_n_0 ;
  wire \q[42]_i_2__0_n_0 ;
  wire \q[43]_i_2__0_n_0 ;
  wire \q[44]_i_2__0_n_0 ;
  wire \q[45]_i_2__0_n_0 ;
  wire \q[53]_i_2__0_n_0 ;
  wire \q[53]_i_3__0_n_0 ;
  wire \q[54]_i_2_n_0 ;
  wire \q[54]_i_3__0_n_0 ;
  wire \q[62]_i_2_n_0 ;
  wire \q[62]_i_3__0_n_0 ;
  wire \q[69]_i_2__0_n_0 ;
  wire \q[70]_i_2_n_0 ;
  wire \q[70]_i_3__0_n_0 ;
  wire \q[70]_i_4__0_n_0 ;
  wire \q_reg[12]_0 ;
  wire \q_reg[12]_1 ;
  wire \q_reg[12]_2 ;
  wire [16:0]\q_reg[155] ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[44]_3 ;
  wire \q_reg[44]_4 ;
  wire \q_reg[48]_0 ;
  wire \q_reg[50]_0 ;
  wire \q_reg[50]_1 ;
  wire \q_reg[51]_0 ;
  wire \q_reg[52]_0 ;
  wire \q_reg[55]_0 ;
  wire \q_reg[59]_0 ;
  wire [31:0]\q_reg[70]_0 ;
  wire \q_reg_n_0_[0] ;
  wire \q_reg_n_0_[1] ;
  wire \q_reg_n_0_[2] ;
  wire [31:0]r_MemWriteData_mem;
  wire [31:0]spo;
  wire u_DataRAM_i_33_n_0;
  wire u_DataRAM_i_34_n_0;
  wire u_DataRAM_i_35_n_0;
  wire u_DataRAM_i_36_n_0;
  wire u_DataRAM_i_37_n_0;
  wire u_DataRAM_i_38_n_0;
  wire u_DataRAM_i_39_n_0;
  wire u_DataRAM_i_40_n_0;
  wire u_DataRAM_i_41_n_0;
  wire u_DataRAM_i_42_n_0;
  wire u_DataRAM_i_43_n_0;
  wire u_DataRAM_i_44_n_0;
  wire u_DataRAM_i_45_n_0;
  wire u_DataRAM_i_46_n_0;
  wire [1:1]w_MemWriteData_ex;
  wire [0:0]w_RegWriteData_wb;

  LUT5 #(
    .INIT(32'hEFE44F44)) 
    \q[12]_i_1__0 
       (.I0(\q_reg[12]_2 ),
        .I1(Q[8]),
        .I2(\q_reg[44]_4 ),
        .I3(w_RegWriteData_wb),
        .I4(\q_reg[155] [12]),
        .O(w_MemWriteData_ex));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[39]_i_1__0 
       (.I0(spo[0]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[24]),
        .I5(\q[39]_i_2_n_0 ),
        .O(\q_reg[70]_0 [0]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[39]_i_2 
       (.I0(spo[16]),
        .I1(spo[8]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[39]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[40]_i_1__0 
       (.I0(spo[1]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[25]),
        .I5(\q[40]_i_2_n_0 ),
        .O(\q_reg[70]_0 [1]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[40]_i_2 
       (.I0(spo[17]),
        .I1(spo[9]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[40]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[41]_i_1__0 
       (.I0(spo[2]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[26]),
        .I5(\q[41]_i_2_n_0 ),
        .O(\q_reg[70]_0 [2]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[41]_i_2 
       (.I0(spo[18]),
        .I1(spo[10]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[41]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[42]_i_1__0 
       (.I0(spo[3]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[27]),
        .I5(\q[42]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [3]));
  LUT5 #(
    .INIT(32'hFFFFEFFE)) 
    \q[42]_i_2 
       (.I0(\q_reg[12]_1 ),
        .I1(\q_reg[155] [9]),
        .I2(\q_reg[155] [7]),
        .I3(Q[0]),
        .I4(\q_reg[12]_0 ),
        .O(\q_reg[12]_2 ));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[42]_i_2__0 
       (.I0(spo[19]),
        .I1(spo[11]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[42]_i_2__0_n_0 ));
  LUT5 #(
    .INIT(32'h55555557)) 
    \q[42]_i_4 
       (.I0(Q[5]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(\q_reg[12]_1 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[42]_i_5 
       (.I0(Q[2]),
        .I1(\q_reg[155] [11]),
        .I2(Q[1]),
        .I3(\q_reg[155] [8]),
        .I4(\q_reg[155] [9]),
        .I5(Q[3]),
        .O(\q_reg[12]_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[43]_i_1__0 
       (.I0(spo[4]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[28]),
        .I5(\q[43]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [4]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[43]_i_2__0 
       (.I0(spo[20]),
        .I1(spo[12]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[43]_i_2__0_n_0 ));
  LUT4 #(
    .INIT(16'h4555)) 
    \q[44]_i_12 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[8]),
        .O(\q_reg[44]_2 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[44]_i_1__0 
       (.I0(spo[5]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[29]),
        .I5(\q[44]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [5]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[44]_i_2__0 
       (.I0(spo[21]),
        .I1(spo[13]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[44]_i_2__0_n_0 ));
  LUT4 #(
    .INIT(16'hBAAA)) 
    \q[45]_i_18 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[7]),
        .O(\q_reg[44]_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAA2CAA20)) 
    \q[45]_i_1__0 
       (.I0(spo[6]),
        .I1(Q[8]),
        .I2(u_DataRAM_i_43_n_0),
        .I3(\q_reg_n_0_[1] ),
        .I4(spo[30]),
        .I5(\q[45]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [6]));
  LUT6 #(
    .INIT(64'h0A000A0A000C0000)) 
    \q[45]_i_2__0 
       (.I0(spo[22]),
        .I1(spo[14]),
        .I2(\q_reg_n_0_[1] ),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[45]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hF0CCF0AAF0F0F0AA)) 
    \q[46]_i_1__0 
       (.I0(\q[62]_i_3__0_n_0 ),
        .I1(spo[23]),
        .I2(spo[7]),
        .I3(\q_reg_n_0_[1] ),
        .I4(u_DataRAM_i_43_n_0),
        .I5(Q[8]),
        .O(\q_reg[70]_0 [7]));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[47]_i_1__0 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[8]),
        .I2(spo[24]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [8]));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[48]_i_1__0 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[9]),
        .I2(spo[25]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [9]));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[49]_i_1__0 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[10]),
        .I2(spo[26]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [10]));
  LUT4 #(
    .INIT(16'hBAAA)) 
    \q[50]_i_14 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[14]),
        .O(\q_reg[50]_1 ));
  LUT4 #(
    .INIT(16'hBAAA)) 
    \q[50]_i_17 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[13]),
        .O(\q_reg[50]_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[50]_i_1__1 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[11]),
        .I2(spo[27]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [11]));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[51]_i_1__1 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[12]),
        .I2(spo[28]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [12]));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[52]_i_1__1 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[13]),
        .I2(spo[29]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [13]));
  LUT4 #(
    .INIT(16'hBAAA)) 
    \q[53]_i_18 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[15]),
        .O(\q_reg[51]_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEFAEEAAAA)) 
    \q[53]_i_1__1 
       (.I0(\q[53]_i_2__0_n_0 ),
        .I1(spo[14]),
        .I2(spo[30]),
        .I3(Q[8]),
        .I4(\q_reg_n_0_[0] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [14]));
  LUT4 #(
    .INIT(16'hBAAA)) 
    \q[53]_i_20 
       (.I0(\q_reg[155] [13]),
        .I1(\q_reg[12]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(Q[16]),
        .O(\q_reg[52]_0 ));
  LUT6 #(
    .INIT(64'h0000000000000B08)) 
    \q[53]_i_2__0 
       (.I0(\q[62]_i_3__0_n_0 ),
        .I1(Q[7]),
        .I2(\q_reg_n_0_[0] ),
        .I3(\q[53]_i_3__0_n_0 ),
        .I4(\q_reg_n_0_[2] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q[53]_i_2__0_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[53]_i_3__0 
       (.I0(spo[23]),
        .I1(Q[8]),
        .I2(spo[7]),
        .O(\q[53]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFECFC2000)) 
    \q[54]_i_1__1 
       (.I0(spo[31]),
        .I1(\q_reg_n_0_[1] ),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[8]),
        .I4(spo[15]),
        .I5(\q[54]_i_2_n_0 ),
        .O(\q_reg[70]_0 [15]));
  LUT6 #(
    .INIT(64'hFFFFFFFF000000B8)) 
    \q[54]_i_2 
       (.I0(spo[23]),
        .I1(Q[8]),
        .I2(spo[7]),
        .I3(\q[70]_i_4__0_n_0 ),
        .I4(\q[70]_i_3__0_n_0 ),
        .I5(\q[54]_i_3__0_n_0 ),
        .O(\q[54]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0044000000F00000)) 
    \q[54]_i_3__0 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[31]),
        .I2(spo[15]),
        .I3(\q_reg_n_0_[2] ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(\q[54]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[55]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[16]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [16]));
  LUT6 #(
    .INIT(64'h0000000000002002)) 
    \q[55]_i_29 
       (.I0(Q[13]),
        .I1(\q_reg[12]_0 ),
        .I2(Q[0]),
        .I3(\q_reg[155] [7]),
        .I4(\q_reg[155] [9]),
        .I5(\q_reg[12]_1 ),
        .O(\q_reg[55]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[56]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[17]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [17]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[57]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[18]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [18]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[58]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[19]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [19]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[59]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[20]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [20]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[60]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[21]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [21]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[61]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[22]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [22]));
  LUT6 #(
    .INIT(64'hFFFFBAAAAAAABAAA)) 
    \q[62]_i_1__1 
       (.I0(\q[62]_i_2_n_0 ),
        .I1(\q_reg_n_0_[2] ),
        .I2(\q[70]_i_3__0_n_0 ),
        .I3(\q[62]_i_3__0_n_0 ),
        .I4(\q_reg_n_0_[1] ),
        .I5(spo[23]),
        .O(\q_reg[70]_0 [23]));
  LUT6 #(
    .INIT(64'h0000202000002320)) 
    \q[62]_i_2 
       (.I0(spo[23]),
        .I1(\q[70]_i_3__0_n_0 ),
        .I2(Q[8]),
        .I3(spo[7]),
        .I4(\q_reg_n_0_[2] ),
        .I5(\q_reg_n_0_[1] ),
        .O(\q[62]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \q[62]_i_3__0 
       (.I0(spo[31]),
        .I1(Q[8]),
        .I2(spo[15]),
        .O(\q[62]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[63]_i_1__2 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[24]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [24]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[64]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[25]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [25]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[65]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[26]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [26]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[66]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[27]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [27]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[67]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[28]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [28]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[68]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[29]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [29]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \q[69]_i_1__1 
       (.I0(\q_reg_n_0_[1] ),
        .I1(spo[30]),
        .I2(\q[69]_i_2__0_n_0 ),
        .O(\q_reg[70]_0 [30]));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \q[69]_i_2__0 
       (.I0(spo[7]),
        .I1(Q[8]),
        .I2(spo[23]),
        .I3(\q[70]_i_3__0_n_0 ),
        .I4(\q[62]_i_3__0_n_0 ),
        .I5(\q[70]_i_4__0_n_0 ),
        .O(\q[69]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFAAAABAAAAAAA)) 
    \q[70]_i_1__1 
       (.I0(\q[70]_i_2_n_0 ),
        .I1(\q_reg_n_0_[2] ),
        .I2(Q[8]),
        .I3(\q[70]_i_3__0_n_0 ),
        .I4(spo[31]),
        .I5(\q_reg_n_0_[1] ),
        .O(\q_reg[70]_0 [31]));
  LUT6 #(
    .INIT(64'h000000000FCA00CA)) 
    \q[70]_i_2 
       (.I0(spo[7]),
        .I1(spo[23]),
        .I2(Q[8]),
        .I3(\q[70]_i_3__0_n_0 ),
        .I4(spo[15]),
        .I5(\q[70]_i_4__0_n_0 ),
        .O(\q[70]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[70]_i_3__0 
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[7]),
        .O(\q[70]_i_3__0_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[70]_i_4__0 
       (.I0(\q_reg_n_0_[1] ),
        .I1(\q_reg_n_0_[2] ),
        .O(\q[70]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000002002)) 
    \q[73]_i_19 
       (.I0(Q[7]),
        .I1(\q_reg[12]_0 ),
        .I2(Q[0]),
        .I3(\q_reg[155] [7]),
        .I4(\q_reg[155] [9]),
        .I5(\q_reg[12]_1 ),
        .O(\q_reg[48]_0 ));
  LUT6 #(
    .INIT(64'h0000000000002002)) 
    \q[73]_i_25 
       (.I0(Q[8]),
        .I1(\q_reg[12]_0 ),
        .I2(Q[0]),
        .I3(\q_reg[155] [7]),
        .I4(\q_reg[155] [9]),
        .I5(\q_reg[12]_1 ),
        .O(\q_reg[59]_0 ));
  LUT6 #(
    .INIT(64'h0009000000000009)) 
    \q[74]_i_13 
       (.I0(\q_reg[155] [11]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(Q[3]),
        .I4(Q[0]),
        .I5(\q_reg[155] [10]),
        .O(\q_reg[44]_1 ));
  LUT6 #(
    .INIT(64'h0001FFFFFFFFFFFF)) 
    \q[74]_i_8 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(Q[5]),
        .I5(\q_reg[44]_1 ),
        .O(\q_reg[44]_3 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [0]),
        .Q(\q_reg_n_0_[0] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [15]),
        .Q(Q[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[0]),
        .Q(r_MemWriteData_mem[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(w_MemWriteData_ex),
        .Q(r_MemWriteData_mem[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[1]),
        .Q(r_MemWriteData_mem[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[2]),
        .Q(r_MemWriteData_mem[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[3]),
        .Q(r_MemWriteData_mem[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[4]),
        .Q(r_MemWriteData_mem[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[5]),
        .Q(r_MemWriteData_mem[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[6]),
        .Q(r_MemWriteData_mem[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[7]),
        .Q(r_MemWriteData_mem[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [1]),
        .Q(\q_reg_n_0_[1] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[8]),
        .Q(r_MemWriteData_mem[9]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[9]),
        .Q(r_MemWriteData_mem[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[10]),
        .Q(r_MemWriteData_mem[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[11]),
        .Q(r_MemWriteData_mem[12]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[12]),
        .Q(r_MemWriteData_mem[13]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[13]),
        .Q(r_MemWriteData_mem[14]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[14]),
        .Q(r_MemWriteData_mem[15]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[15]),
        .Q(r_MemWriteData_mem[16]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[16]),
        .Q(r_MemWriteData_mem[17]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[17]),
        .Q(r_MemWriteData_mem[18]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [2]),
        .Q(\q_reg_n_0_[2] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[18]),
        .Q(r_MemWriteData_mem[19]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[19]),
        .Q(r_MemWriteData_mem[20]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[20]),
        .Q(r_MemWriteData_mem[21]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[21]),
        .Q(r_MemWriteData_mem[22]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[22]),
        .Q(r_MemWriteData_mem[23]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[23]),
        .Q(r_MemWriteData_mem[24]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[24]),
        .Q(r_MemWriteData_mem[25]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[25]),
        .Q(r_MemWriteData_mem[26]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[26]),
        .Q(r_MemWriteData_mem[27]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[27]),
        .Q(r_MemWriteData_mem[28]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [3]),
        .Q(Q[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[28]),
        .Q(r_MemWriteData_mem[29]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[29]),
        .Q(r_MemWriteData_mem[30]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[30]),
        .Q(r_MemWriteData_mem[31]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[31]),
        .Q(Q[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[32]),
        .Q(Q[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[33]),
        .Q(Q[9]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[34]),
        .Q(Q[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[35]),
        .Q(Q[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[36]),
        .Q(Q[12]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[37]),
        .Q(Q[13]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [4]),
        .Q(Q[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[38]),
        .Q(Q[14]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[39]),
        .Q(Q[15]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[40]),
        .Q(Q[16]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[41]),
        .Q(Q[17]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[42]),
        .Q(Q[18]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[43]),
        .Q(Q[19]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[44]),
        .Q(Q[20]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[45]),
        .Q(Q[21]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[46]),
        .Q(Q[22]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[47]),
        .Q(Q[23]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [5]),
        .Q(Q[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[48]),
        .Q(Q[24]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[49]),
        .Q(Q[25]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[50]),
        .Q(Q[26]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[51]),
        .Q(Q[27]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[52]),
        .Q(Q[28]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[53]),
        .Q(Q[29]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[54]),
        .Q(Q[30]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[55]),
        .Q(Q[31]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[56]),
        .Q(Q[32]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[57]),
        .Q(Q[33]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [6]),
        .Q(Q[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[58]),
        .Q(Q[34]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[71] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[59]),
        .Q(Q[35]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[72] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[60]),
        .Q(Q[36]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[73] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[61]),
        .Q(Q[37]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[74] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[62]),
        .Q(Q[38]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [14]),
        .Q(Q[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[155] [16]),
        .Q(Q[5]),
        .R(SR));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_1
       (.I0(r_MemWriteData_mem[31]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[7]),
        .I4(u_DataRAM_i_35_n_0),
        .O(d[31]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_10
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[6]),
        .I3(spo[22]),
        .I4(r_MemWriteData_mem[22]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[22]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_11
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[5]),
        .I3(spo[21]),
        .I4(r_MemWriteData_mem[21]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[21]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_12
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[4]),
        .I3(spo[20]),
        .I4(r_MemWriteData_mem[20]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[20]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_13
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[3]),
        .I3(spo[19]),
        .I4(r_MemWriteData_mem[19]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[19]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_14
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[2]),
        .I3(spo[18]),
        .I4(r_MemWriteData_mem[18]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[18]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_15
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[1]),
        .I3(spo[17]),
        .I4(r_MemWriteData_mem[17]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[17]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_16
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[0]),
        .I3(spo[16]),
        .I4(r_MemWriteData_mem[16]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[16]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_17
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[7]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[15]),
        .I4(spo[15]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[15]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_18
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[6]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[14]),
        .I4(spo[14]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[14]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_19
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[5]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[13]),
        .I4(spo[13]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[13]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_2
       (.I0(r_MemWriteData_mem[30]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[6]),
        .I4(u_DataRAM_i_36_n_0),
        .O(d[30]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_20
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[4]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[12]),
        .I4(spo[12]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[12]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_21
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[3]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[11]),
        .I4(spo[11]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[11]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_22
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[2]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[10]),
        .I4(spo[10]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[10]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_23
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[1]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[9]),
        .I4(spo[9]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[9]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    u_DataRAM_i_24
       (.I0(u_DataRAM_i_44_n_0),
        .I1(r_MemWriteData_mem[0]),
        .I2(u_DataRAM_i_45_n_0),
        .I3(r_MemWriteData_mem[8]),
        .I4(spo[8]),
        .I5(u_DataRAM_i_46_n_0),
        .O(d[8]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_25
       (.I0(r_MemWriteData_mem[7]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[7]),
        .O(d[7]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_26
       (.I0(r_MemWriteData_mem[6]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[6]),
        .O(d[6]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_27
       (.I0(r_MemWriteData_mem[5]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[5]),
        .O(d[5]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_28
       (.I0(r_MemWriteData_mem[4]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[4]),
        .O(d[4]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_29
       (.I0(r_MemWriteData_mem[3]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[3]),
        .O(d[3]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_3
       (.I0(r_MemWriteData_mem[29]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[5]),
        .I4(u_DataRAM_i_37_n_0),
        .O(d[29]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_30
       (.I0(r_MemWriteData_mem[2]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[2]),
        .O(d[2]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_31
       (.I0(r_MemWriteData_mem[1]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[1]),
        .O(d[1]));
  LUT6 #(
    .INIT(64'hBBBBABAA8888A8AA)) 
    u_DataRAM_i_32
       (.I0(r_MemWriteData_mem[0]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(\q_reg_n_0_[0] ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(spo[0]),
        .O(d[0]));
  LUT3 #(
    .INIT(8'hEF)) 
    u_DataRAM_i_33
       (.I0(\q_reg_n_0_[2] ),
        .I1(\q_reg_n_0_[1] ),
        .I2(Q[6]),
        .O(u_DataRAM_i_33_n_0));
  LUT6 #(
    .INIT(64'h0004000000000000)) 
    u_DataRAM_i_34
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[7]),
        .I2(\q_reg_n_0_[2] ),
        .I3(\q_reg_n_0_[1] ),
        .I4(Q[6]),
        .I5(Q[8]),
        .O(u_DataRAM_i_34_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_35
       (.I0(r_MemWriteData_mem[15]),
        .I1(spo[31]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_35_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_36
       (.I0(r_MemWriteData_mem[14]),
        .I1(spo[30]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_36_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_37
       (.I0(r_MemWriteData_mem[13]),
        .I1(spo[29]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_37_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_38
       (.I0(r_MemWriteData_mem[12]),
        .I1(spo[28]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_38_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_39
       (.I0(r_MemWriteData_mem[11]),
        .I1(spo[27]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_39_n_0));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_4
       (.I0(r_MemWriteData_mem[28]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[4]),
        .I4(u_DataRAM_i_38_n_0),
        .O(d[28]));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_40
       (.I0(r_MemWriteData_mem[10]),
        .I1(spo[26]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_40_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_41
       (.I0(r_MemWriteData_mem[9]),
        .I1(spo[25]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_41_n_0));
  LUT6 #(
    .INIT(64'h00000000AC0CACCC)) 
    u_DataRAM_i_42
       (.I0(r_MemWriteData_mem[8]),
        .I1(spo[24]),
        .I2(Q[8]),
        .I3(\q_reg_n_0_[0] ),
        .I4(Q[7]),
        .I5(u_DataRAM_i_33_n_0),
        .O(u_DataRAM_i_42_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    u_DataRAM_i_43
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[7]),
        .O(u_DataRAM_i_43_n_0));
  LUT6 #(
    .INIT(64'h0000000000040000)) 
    u_DataRAM_i_44
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[7]),
        .I2(\q_reg_n_0_[2] ),
        .I3(\q_reg_n_0_[1] ),
        .I4(Q[6]),
        .I5(Q[8]),
        .O(u_DataRAM_i_44_n_0));
  LUT5 #(
    .INIT(32'hFFFFFF4F)) 
    u_DataRAM_i_45
       (.I0(Q[8]),
        .I1(\q_reg_n_0_[0] ),
        .I2(Q[6]),
        .I3(\q_reg_n_0_[1] ),
        .I4(\q_reg_n_0_[2] ),
        .O(u_DataRAM_i_45_n_0));
  LUT6 #(
    .INIT(64'h000000000000F100)) 
    u_DataRAM_i_46
       (.I0(\q_reg_n_0_[0] ),
        .I1(Q[7]),
        .I2(Q[8]),
        .I3(Q[6]),
        .I4(\q_reg_n_0_[1] ),
        .I5(\q_reg_n_0_[2] ),
        .O(u_DataRAM_i_46_n_0));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_5
       (.I0(r_MemWriteData_mem[27]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[3]),
        .I4(u_DataRAM_i_39_n_0),
        .O(d[27]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_6
       (.I0(r_MemWriteData_mem[26]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[2]),
        .I4(u_DataRAM_i_40_n_0),
        .O(d[26]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_7
       (.I0(r_MemWriteData_mem[25]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[1]),
        .I4(u_DataRAM_i_41_n_0),
        .O(d[25]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    u_DataRAM_i_8
       (.I0(r_MemWriteData_mem[24]),
        .I1(u_DataRAM_i_33_n_0),
        .I2(u_DataRAM_i_34_n_0),
        .I3(r_MemWriteData_mem[0]),
        .I4(u_DataRAM_i_42_n_0),
        .O(d[24]));
  LUT6 #(
    .INIT(64'hFFFF0000F780F780)) 
    u_DataRAM_i_9
       (.I0(u_DataRAM_i_43_n_0),
        .I1(Q[8]),
        .I2(r_MemWriteData_mem[7]),
        .I3(spo[23]),
        .I4(r_MemWriteData_mem[23]),
        .I5(u_DataRAM_i_33_n_0),
        .O(d[23]));
endmodule

(* ORIG_REF_NAME = "DFF" *) 
module DFF__parameterized2
   (\PC_reg_reg[8] ,
    \q_reg[113] ,
    \PC_reg_reg[8]_0 ,
    w_RegWriteData_wb,
    \q_reg[85] ,
    Q,
    \q_reg[48]_0 ,
    \q_reg[11]_0 ,
    \q_reg[11]_1 ,
    \q_reg[45]_0 ,
    \q_reg[44]_0 ,
    \q_reg[48]_1 ,
    \q_reg[53]_0 ,
    \q_reg[55]_0 ,
    \q_reg[57]_0 ,
    \q_reg[59]_0 ,
    \q_reg[60]_0 ,
    \q_reg[63]_0 ,
    \q_reg[64]_0 ,
    \q_reg[65]_0 ,
    \q_reg[66]_0 ,
    \q_reg[69]_0 ,
    \q_reg[70]_0 ,
    \q_reg[72] ,
    \q_reg[73] ,
    \q_reg[58]_0 ,
    \q_reg[48]_2 ,
    \q_reg[59]_1 ,
    \q_reg[55]_1 ,
    ReadData20,
    \q_reg[21]_0 ,
    ReadData10,
    \q_reg[27]_0 ,
    \q_reg[27]_1 ,
    \q_reg[44]_1 ,
    \q_reg[5]_0 ,
    \q_reg[44]_2 ,
    \q_reg[9]_0 ,
    \q_reg[148] ,
    \q_reg[74] ,
    \q_reg[4] ,
    \q_reg[46]_0 ,
    SR,
    D,
    cpu_clk_BUFG);
  output \PC_reg_reg[8] ;
  output [63:0]\q_reg[113] ;
  output \PC_reg_reg[8]_0 ;
  output [31:0]w_RegWriteData_wb;
  output \q_reg[85] ;
  output [4:0]Q;
  output \q_reg[48]_0 ;
  output \q_reg[11]_0 ;
  output \q_reg[11]_1 ;
  output \q_reg[45]_0 ;
  output \q_reg[44]_0 ;
  output \q_reg[48]_1 ;
  output \q_reg[53]_0 ;
  output \q_reg[55]_0 ;
  output \q_reg[57]_0 ;
  output \q_reg[59]_0 ;
  output \q_reg[60]_0 ;
  output \q_reg[63]_0 ;
  output \q_reg[64]_0 ;
  output \q_reg[65]_0 ;
  output \q_reg[66]_0 ;
  output \q_reg[69]_0 ;
  output \q_reg[70]_0 ;
  output \q_reg[72] ;
  output \q_reg[73] ;
  output \q_reg[58]_0 ;
  output \q_reg[48]_2 ;
  output \q_reg[59]_1 ;
  output \q_reg[55]_1 ;
  input [31:0]ReadData20;
  input \q_reg[21]_0 ;
  input [31:0]ReadData10;
  input [4:0]\q_reg[27]_0 ;
  input \q_reg[27]_1 ;
  input \q_reg[44]_1 ;
  input \q_reg[5]_0 ;
  input \q_reg[44]_2 ;
  input \q_reg[9]_0 ;
  input [19:0]\q_reg[148] ;
  input [37:0]\q_reg[74] ;
  input \q_reg[4] ;
  input \q_reg[46]_0 ;
  input [0:0]SR;
  input [31:0]D;
  input cpu_clk_BUFG;

  wire [31:0]D;
  wire \PC_reg[31]_i_100_n_0 ;
  wire \PC_reg[31]_i_101_n_0 ;
  wire \PC_reg[31]_i_102_n_0 ;
  wire \PC_reg[31]_i_103_n_0 ;
  wire \PC_reg[31]_i_104_n_0 ;
  wire \PC_reg[31]_i_105_n_0 ;
  wire \PC_reg[31]_i_21_n_0 ;
  wire \PC_reg[31]_i_22_n_0 ;
  wire \PC_reg[31]_i_23_n_0 ;
  wire \PC_reg[31]_i_24_n_0 ;
  wire \PC_reg[31]_i_25_n_0 ;
  wire \PC_reg[31]_i_26_n_0 ;
  wire \PC_reg[31]_i_27_n_0 ;
  wire \PC_reg[31]_i_28_n_0 ;
  wire \PC_reg[31]_i_29_n_0 ;
  wire \PC_reg[31]_i_30_n_0 ;
  wire \PC_reg[31]_i_31_n_0 ;
  wire \PC_reg[31]_i_32_n_0 ;
  wire \PC_reg[31]_i_33_n_0 ;
  wire \PC_reg[31]_i_34_n_0 ;
  wire \PC_reg[31]_i_35_n_0 ;
  wire \PC_reg[31]_i_36_n_0 ;
  wire \PC_reg[31]_i_37_n_0 ;
  wire \PC_reg[31]_i_38_n_0 ;
  wire \PC_reg[31]_i_39_n_0 ;
  wire \PC_reg[31]_i_40_n_0 ;
  wire \PC_reg[31]_i_41_n_0 ;
  wire \PC_reg[31]_i_42_n_0 ;
  wire \PC_reg[31]_i_43_n_0 ;
  wire \PC_reg[31]_i_44_n_0 ;
  wire \PC_reg[31]_i_45_n_0 ;
  wire \PC_reg[31]_i_46_n_0 ;
  wire \PC_reg[31]_i_47_n_0 ;
  wire \PC_reg[31]_i_48_n_0 ;
  wire \PC_reg[31]_i_49_n_0 ;
  wire \PC_reg[31]_i_50_n_0 ;
  wire \PC_reg[31]_i_51_n_0 ;
  wire \PC_reg[31]_i_52_n_0 ;
  wire \PC_reg[31]_i_53_n_0 ;
  wire \PC_reg[31]_i_54_n_0 ;
  wire \PC_reg[31]_i_55_n_0 ;
  wire \PC_reg[31]_i_56_n_0 ;
  wire \PC_reg[31]_i_57_n_0 ;
  wire \PC_reg[31]_i_58_n_0 ;
  wire \PC_reg[31]_i_59_n_0 ;
  wire \PC_reg[31]_i_60_n_0 ;
  wire \PC_reg[31]_i_61_n_0 ;
  wire \PC_reg[31]_i_62_n_0 ;
  wire \PC_reg[31]_i_63_n_0 ;
  wire \PC_reg[31]_i_64_n_0 ;
  wire \PC_reg[31]_i_65_n_0 ;
  wire \PC_reg[31]_i_66_n_0 ;
  wire \PC_reg[31]_i_67_n_0 ;
  wire \PC_reg[31]_i_68_n_0 ;
  wire \PC_reg[31]_i_69_n_0 ;
  wire \PC_reg[31]_i_70_n_0 ;
  wire \PC_reg[31]_i_71_n_0 ;
  wire \PC_reg[31]_i_72_n_0 ;
  wire \PC_reg[31]_i_73_n_0 ;
  wire \PC_reg[31]_i_74_n_0 ;
  wire \PC_reg[31]_i_75_n_0 ;
  wire \PC_reg[31]_i_76_n_0 ;
  wire \PC_reg[31]_i_77_n_0 ;
  wire \PC_reg[31]_i_78_n_0 ;
  wire \PC_reg[31]_i_79_n_0 ;
  wire \PC_reg[31]_i_80_n_0 ;
  wire \PC_reg[31]_i_81_n_0 ;
  wire \PC_reg[31]_i_82_n_0 ;
  wire \PC_reg[31]_i_83_n_0 ;
  wire \PC_reg[31]_i_84_n_0 ;
  wire \PC_reg[31]_i_85_n_0 ;
  wire \PC_reg[31]_i_86_n_0 ;
  wire \PC_reg[31]_i_87_n_0 ;
  wire \PC_reg[31]_i_88_n_0 ;
  wire \PC_reg[31]_i_89_n_0 ;
  wire \PC_reg[31]_i_90_n_0 ;
  wire \PC_reg[31]_i_91_n_0 ;
  wire \PC_reg[31]_i_92_n_0 ;
  wire \PC_reg[31]_i_93_n_0 ;
  wire \PC_reg[31]_i_94_n_0 ;
  wire \PC_reg[31]_i_95_n_0 ;
  wire \PC_reg[31]_i_96_n_0 ;
  wire \PC_reg[31]_i_97_n_0 ;
  wire \PC_reg[31]_i_98_n_0 ;
  wire \PC_reg[31]_i_99_n_0 ;
  wire \PC_reg_reg[8] ;
  wire \PC_reg_reg[8]_0 ;
  wire [4:0]Q;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire [0:0]SR;
  wire cpu_clk_BUFG;
  wire \q[113]_i_4_n_0 ;
  wire \q[58]_i_2_n_0 ;
  wire \q[58]_i_3_n_0 ;
  wire \q[58]_i_4_n_0 ;
  wire \q[74]_i_14_n_0 ;
  wire \q[81]_i_2_n_0 ;
  wire \q[93]_i_2_n_0 ;
  wire \q[93]_i_3_n_0 ;
  wire [63:0]\q_reg[113] ;
  wire \q_reg[11]_0 ;
  wire \q_reg[11]_1 ;
  wire [19:0]\q_reg[148] ;
  wire \q_reg[21]_0 ;
  wire [4:0]\q_reg[27]_0 ;
  wire \q_reg[27]_1 ;
  wire \q_reg[44]_0 ;
  wire \q_reg[44]_1 ;
  wire \q_reg[44]_2 ;
  wire \q_reg[45]_0 ;
  wire \q_reg[46]_0 ;
  wire \q_reg[48]_0 ;
  wire \q_reg[48]_1 ;
  wire \q_reg[48]_2 ;
  wire \q_reg[4] ;
  wire \q_reg[53]_0 ;
  wire \q_reg[55]_0 ;
  wire \q_reg[55]_1 ;
  wire \q_reg[57]_0 ;
  wire \q_reg[58]_0 ;
  wire \q_reg[59]_0 ;
  wire \q_reg[59]_1 ;
  wire \q_reg[5]_0 ;
  wire \q_reg[60]_0 ;
  wire \q_reg[63]_0 ;
  wire \q_reg[64]_0 ;
  wire \q_reg[65]_0 ;
  wire \q_reg[66]_0 ;
  wire \q_reg[69]_0 ;
  wire \q_reg[70]_0 ;
  wire \q_reg[72] ;
  wire \q_reg[73] ;
  wire [37:0]\q_reg[74] ;
  wire \q_reg[85] ;
  wire \q_reg[9]_0 ;
  wire \q_reg_n_0_[10] ;
  wire \q_reg_n_0_[11] ;
  wire \q_reg_n_0_[12] ;
  wire \q_reg_n_0_[13] ;
  wire \q_reg_n_0_[14] ;
  wire \q_reg_n_0_[15] ;
  wire \q_reg_n_0_[16] ;
  wire \q_reg_n_0_[17] ;
  wire \q_reg_n_0_[18] ;
  wire \q_reg_n_0_[19] ;
  wire \q_reg_n_0_[20] ;
  wire \q_reg_n_0_[21] ;
  wire \q_reg_n_0_[22] ;
  wire \q_reg_n_0_[23] ;
  wire \q_reg_n_0_[24] ;
  wire \q_reg_n_0_[25] ;
  wire \q_reg_n_0_[26] ;
  wire \q_reg_n_0_[27] ;
  wire \q_reg_n_0_[28] ;
  wire \q_reg_n_0_[29] ;
  wire \q_reg_n_0_[30] ;
  wire \q_reg_n_0_[31] ;
  wire \q_reg_n_0_[32] ;
  wire \q_reg_n_0_[33] ;
  wire \q_reg_n_0_[34] ;
  wire \q_reg_n_0_[35] ;
  wire \q_reg_n_0_[36] ;
  wire \q_reg_n_0_[37] ;
  wire \q_reg_n_0_[38] ;
  wire \q_reg_n_0_[39] ;
  wire \q_reg_n_0_[40] ;
  wire \q_reg_n_0_[41] ;
  wire \q_reg_n_0_[42] ;
  wire \q_reg_n_0_[43] ;
  wire \q_reg_n_0_[44] ;
  wire \q_reg_n_0_[45] ;
  wire \q_reg_n_0_[46] ;
  wire \q_reg_n_0_[47] ;
  wire \q_reg_n_0_[48] ;
  wire \q_reg_n_0_[49] ;
  wire \q_reg_n_0_[50] ;
  wire \q_reg_n_0_[51] ;
  wire \q_reg_n_0_[52] ;
  wire \q_reg_n_0_[53] ;
  wire \q_reg_n_0_[54] ;
  wire \q_reg_n_0_[55] ;
  wire \q_reg_n_0_[56] ;
  wire \q_reg_n_0_[57] ;
  wire \q_reg_n_0_[58] ;
  wire \q_reg_n_0_[59] ;
  wire \q_reg_n_0_[5] ;
  wire \q_reg_n_0_[60] ;
  wire \q_reg_n_0_[61] ;
  wire \q_reg_n_0_[62] ;
  wire \q_reg_n_0_[63] ;
  wire \q_reg_n_0_[64] ;
  wire \q_reg_n_0_[65] ;
  wire \q_reg_n_0_[66] ;
  wire \q_reg_n_0_[67] ;
  wire \q_reg_n_0_[68] ;
  wire \q_reg_n_0_[69] ;
  wire \q_reg_n_0_[70] ;
  wire \q_reg_n_0_[7] ;
  wire \q_reg_n_0_[8] ;
  wire \q_reg_n_0_[9] ;
  wire [31:0]w_RegWriteData_wb;

  LUT6 #(
    .INIT(64'h00000000EAEAEFEA)) 
    \PC_reg[31]_i_100 
       (.I0(\PC_reg[31]_i_89_n_0 ),
        .I1(w_RegWriteData_wb[6]),
        .I2(\q_reg[85] ),
        .I3(ReadData10[6]),
        .I4(\q_reg[27]_1 ),
        .I5(\PC_reg[31]_i_105_n_0 ),
        .O(\PC_reg[31]_i_100_n_0 ));
  LUT5 #(
    .INIT(32'h0BFB0000)) 
    \PC_reg[31]_i_101 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[3]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(w_RegWriteData_wb[3]),
        .I4(\q_reg[113] [35]),
        .O(\PC_reg[31]_i_101_n_0 ));
  LUT6 #(
    .INIT(64'hFFF70004FFF7FFF7)) 
    \PC_reg[31]_i_102 
       (.I0(w_RegWriteData_wb[5]),
        .I1(\q[58]_i_2_n_0 ),
        .I2(\q[58]_i_3_n_0 ),
        .I3(\q[58]_i_4_n_0 ),
        .I4(\q_reg[21]_0 ),
        .I5(ReadData20[5]),
        .O(\PC_reg[31]_i_102_n_0 ));
  LUT4 #(
    .INIT(16'h0DDF)) 
    \PC_reg[31]_i_103 
       (.I0(\q_reg[113] [40]),
        .I1(\q_reg[113] [8]),
        .I2(\q_reg[113] [41]),
        .I3(\PC_reg[31]_i_83_n_0 ),
        .O(\PC_reg[31]_i_103_n_0 ));
  LUT4 #(
    .INIT(16'h044F)) 
    \PC_reg[31]_i_104 
       (.I0(\q_reg[113] [40]),
        .I1(\q_reg[113] [8]),
        .I2(\q_reg[113] [41]),
        .I3(\PC_reg[31]_i_83_n_0 ),
        .O(\PC_reg[31]_i_104_n_0 ));
  LUT5 #(
    .INIT(32'h0000F404)) 
    \PC_reg[31]_i_105 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[7]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(w_RegWriteData_wb[7]),
        .I4(\q_reg[113] [39]),
        .O(\PC_reg[31]_i_105_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    \PC_reg[31]_i_19 
       (.I0(\PC_reg[31]_i_21_n_0 ),
        .I1(\PC_reg[31]_i_22_n_0 ),
        .I2(\PC_reg[31]_i_23_n_0 ),
        .I3(\PC_reg[31]_i_24_n_0 ),
        .I4(\PC_reg[31]_i_25_n_0 ),
        .I5(\PC_reg[31]_i_26_n_0 ),
        .O(\PC_reg_reg[8]_0 ));
  LUT6 #(
    .INIT(64'h0C4DCF4D00000000)) 
    \PC_reg[31]_i_20 
       (.I0(\PC_reg[31]_i_27_n_0 ),
        .I1(\q_reg[113] [30]),
        .I2(\q_reg[113] [62]),
        .I3(\PC_reg[31]_i_28_n_0 ),
        .I4(\PC_reg[31]_i_29_n_0 ),
        .I5(\PC_reg[31]_i_30_n_0 ),
        .O(\PC_reg_reg[8] ));
  LUT6 #(
    .INIT(64'h7DFFBEFFEFFB7DFF)) 
    \PC_reg[31]_i_21 
       (.I0(\PC_reg[31]_i_28_n_0 ),
        .I1(\q_reg[113] [29]),
        .I2(\q_reg[113] [61]),
        .I3(\PC_reg[31]_i_31_n_0 ),
        .I4(\q_reg[113] [28]),
        .I5(\q_reg[113] [60]),
        .O(\PC_reg[31]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h4BF00F4B78F00F78)) 
    \PC_reg[31]_i_22 
       (.I0(\PC_reg[31]_i_29_n_0 ),
        .I1(\PC_reg[31]_i_28_n_0 ),
        .I2(\PC_reg[31]_i_30_n_0 ),
        .I3(\q_reg[113] [62]),
        .I4(\q_reg[113] [30]),
        .I5(\PC_reg[31]_i_27_n_0 ),
        .O(\PC_reg[31]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'hF3CF79EF3CFF79EF)) 
    \PC_reg[31]_i_23 
       (.I0(\PC_reg[31]_i_32_n_0 ),
        .I1(\q_reg[113] [58]),
        .I2(\q_reg[113] [26]),
        .I3(\PC_reg[31]_i_33_n_0 ),
        .I4(\PC_reg[31]_i_34_n_0 ),
        .I5(\PC_reg[31]_i_35_n_0 ),
        .O(\PC_reg[31]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hF96F6FF6)) 
    \PC_reg[31]_i_24 
       (.I0(\q_reg[113] [57]),
        .I1(\q_reg[113] [25]),
        .I2(\q_reg[113] [56]),
        .I3(\q_reg[113] [24]),
        .I4(\PC_reg[31]_i_34_n_0 ),
        .O(\PC_reg[31]_i_24_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \PC_reg[31]_i_25 
       (.I0(\PC_reg[31]_i_36_n_0 ),
        .I1(\PC_reg[31]_i_37_n_0 ),
        .I2(\PC_reg[31]_i_38_n_0 ),
        .I3(\PC_reg[31]_i_39_n_0 ),
        .O(\PC_reg[31]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h04)) 
    \PC_reg[31]_i_26 
       (.I0(\PC_reg[31]_i_40_n_0 ),
        .I1(\PC_reg[31]_i_41_n_0 ),
        .I2(\PC_reg[31]_i_42_n_0 ),
        .O(\PC_reg[31]_i_26_n_0 ));
  LUT4 #(
    .INIT(16'h20F2)) 
    \PC_reg[31]_i_27 
       (.I0(\q_reg[113] [60]),
        .I1(\q_reg[113] [28]),
        .I2(\q_reg[113] [61]),
        .I3(\q_reg[113] [29]),
        .O(\PC_reg[31]_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \PC_reg[31]_i_28 
       (.I0(\PC_reg[31]_i_43_n_0 ),
        .I1(\PC_reg[31]_i_44_n_0 ),
        .I2(\PC_reg[31]_i_45_n_0 ),
        .I3(\PC_reg[31]_i_46_n_0 ),
        .I4(\PC_reg[31]_i_47_n_0 ),
        .O(\PC_reg[31]_i_28_n_0 ));
  LUT4 #(
    .INIT(16'hB0FB)) 
    \PC_reg[31]_i_29 
       (.I0(\q_reg[113] [60]),
        .I1(\q_reg[113] [28]),
        .I2(\q_reg[113] [61]),
        .I3(\q_reg[113] [29]),
        .O(\PC_reg[31]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'h95959A95)) 
    \PC_reg[31]_i_30 
       (.I0(\q_reg[113] [63]),
        .I1(w_RegWriteData_wb[31]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[31]),
        .I4(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_30_n_0 ));
  LUT5 #(
    .INIT(32'h95959A95)) 
    \PC_reg[31]_i_31 
       (.I0(\q_reg[113] [62]),
        .I1(w_RegWriteData_wb[30]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[30]),
        .I4(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_31_n_0 ));
  LUT4 #(
    .INIT(16'hBF0B)) 
    \PC_reg[31]_i_32 
       (.I0(\q_reg[113] [56]),
        .I1(\q_reg[113] [24]),
        .I2(\q_reg[113] [25]),
        .I3(\q_reg[113] [57]),
        .O(\PC_reg[31]_i_32_n_0 ));
  LUT5 #(
    .INIT(32'h95959A95)) 
    \PC_reg[31]_i_33 
       (.I0(\q_reg[113] [59]),
        .I1(w_RegWriteData_wb[27]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[27]),
        .I4(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h0F0F0F0F080B0F0F)) 
    \PC_reg[31]_i_34 
       (.I0(\PC_reg[31]_i_48_n_0 ),
        .I1(\PC_reg[31]_i_45_n_0 ),
        .I2(\PC_reg[31]_i_49_n_0 ),
        .I3(\PC_reg[31]_i_50_n_0 ),
        .I4(\PC_reg[31]_i_51_n_0 ),
        .I5(\PC_reg[31]_i_52_n_0 ),
        .O(\PC_reg[31]_i_34_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_35 
       (.I0(\q_reg[113] [56]),
        .I1(\q_reg[113] [24]),
        .I2(\q_reg[113] [25]),
        .I3(\q_reg[113] [57]),
        .O(\PC_reg[31]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hE7E77DE77D7D7DE7)) 
    \PC_reg[31]_i_36 
       (.I0(\PC_reg[31]_i_53_n_0 ),
        .I1(\q_reg[113] [54]),
        .I2(\q_reg[113] [22]),
        .I3(\PC_reg[31]_i_50_n_0 ),
        .I4(\PC_reg[31]_i_45_n_0 ),
        .I5(\PC_reg[31]_i_48_n_0 ),
        .O(\PC_reg[31]_i_36_n_0 ));
  LUT5 #(
    .INIT(32'hF96F6FF6)) 
    \PC_reg[31]_i_37 
       (.I0(\q_reg[113] [53]),
        .I1(\q_reg[113] [21]),
        .I2(\q_reg[113] [52]),
        .I3(\q_reg[113] [20]),
        .I4(\PC_reg[31]_i_45_n_0 ),
        .O(\PC_reg[31]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hE7E77DE77D7D7DE7)) 
    \PC_reg[31]_i_38 
       (.I0(\PC_reg[31]_i_54_n_0 ),
        .I1(\q_reg[113] [50]),
        .I2(\q_reg[113] [18]),
        .I3(\PC_reg[31]_i_55_n_0 ),
        .I4(\PC_reg[31]_i_56_n_0 ),
        .I5(\PC_reg[31]_i_57_n_0 ),
        .O(\PC_reg[31]_i_38_n_0 ));
  LUT5 #(
    .INIT(32'hF96F6FF6)) 
    \PC_reg[31]_i_39 
       (.I0(\q_reg[113] [49]),
        .I1(\q_reg[113] [17]),
        .I2(\q_reg[113] [48]),
        .I3(\q_reg[113] [16]),
        .I4(\PC_reg[31]_i_56_n_0 ),
        .O(\PC_reg[31]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEF7979EF)) 
    \PC_reg[31]_i_40 
       (.I0(\PC_reg[31]_i_58_n_0 ),
        .I1(\q_reg[113] [46]),
        .I2(\q_reg[113] [14]),
        .I3(\q_reg[113] [47]),
        .I4(\PC_reg[31]_i_59_n_0 ),
        .I5(\PC_reg[31]_i_60_n_0 ),
        .O(\PC_reg[31]_i_40_n_0 ));
  LUT6 #(
    .INIT(64'h2880000200022880)) 
    \PC_reg[31]_i_41 
       (.I0(\PC_reg[31]_i_61_n_0 ),
        .I1(\PC_reg[31]_i_62_n_0 ),
        .I2(\PC_reg[31]_i_63_n_0 ),
        .I3(\q_reg[113] [42]),
        .I4(\q_reg[113] [43]),
        .I5(\q_reg[113] [11]),
        .O(\PC_reg[31]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEFFFEFEFFFFE)) 
    \PC_reg[31]_i_42 
       (.I0(\PC_reg[31]_i_64_n_0 ),
        .I1(\PC_reg[31]_i_65_n_0 ),
        .I2(\PC_reg[31]_i_66_n_0 ),
        .I3(\PC_reg[31]_i_67_n_0 ),
        .I4(\PC_reg[31]_i_68_n_0 ),
        .I5(\PC_reg[31]_i_69_n_0 ),
        .O(\PC_reg[31]_i_42_n_0 ));
  LUT5 #(
    .INIT(32'h7130F371)) 
    \PC_reg[31]_i_43 
       (.I0(\PC_reg[31]_i_35_n_0 ),
        .I1(\q_reg[113] [27]),
        .I2(\q_reg[113] [59]),
        .I3(\q_reg[113] [58]),
        .I4(\q_reg[113] [26]),
        .O(\PC_reg[31]_i_43_n_0 ));
  LUT5 #(
    .INIT(32'h8ECF0C8E)) 
    \PC_reg[31]_i_44 
       (.I0(\PC_reg[31]_i_48_n_0 ),
        .I1(\q_reg[113] [23]),
        .I2(\q_reg[113] [55]),
        .I3(\q_reg[113] [54]),
        .I4(\q_reg[113] [22]),
        .O(\PC_reg[31]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'hFFBFFFBA0080008A)) 
    \PC_reg[31]_i_45 
       (.I0(\PC_reg[31]_i_70_n_0 ),
        .I1(\PC_reg[31]_i_71_n_0 ),
        .I2(\PC_reg[31]_i_72_n_0 ),
        .I3(\PC_reg[31]_i_73_n_0 ),
        .I4(\PC_reg[31]_i_74_n_0 ),
        .I5(\PC_reg[31]_i_75_n_0 ),
        .O(\PC_reg[31]_i_45_n_0 ));
  LUT5 #(
    .INIT(32'h4DCF0C4D)) 
    \PC_reg[31]_i_46 
       (.I0(\PC_reg[31]_i_50_n_0 ),
        .I1(\q_reg[113] [23]),
        .I2(\q_reg[113] [55]),
        .I3(\q_reg[113] [54]),
        .I4(\q_reg[113] [22]),
        .O(\PC_reg[31]_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hB230F3B2)) 
    \PC_reg[31]_i_47 
       (.I0(\PC_reg[31]_i_32_n_0 ),
        .I1(\q_reg[113] [27]),
        .I2(\q_reg[113] [59]),
        .I3(\q_reg[113] [58]),
        .I4(\q_reg[113] [26]),
        .O(\PC_reg[31]_i_47_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_48 
       (.I0(\q_reg[113] [52]),
        .I1(\q_reg[113] [20]),
        .I2(\q_reg[113] [21]),
        .I3(\q_reg[113] [53]),
        .O(\PC_reg[31]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'hAAEFFFEF008AAA8A)) 
    \PC_reg[31]_i_49 
       (.I0(\PC_reg[31]_i_76_n_0 ),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[23]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[23]),
        .I5(\q_reg[113] [55]),
        .O(\PC_reg[31]_i_49_n_0 ));
  LUT4 #(
    .INIT(16'hBF0B)) 
    \PC_reg[31]_i_50 
       (.I0(\q_reg[113] [52]),
        .I1(\q_reg[113] [20]),
        .I2(\q_reg[113] [21]),
        .I3(\q_reg[113] [53]),
        .O(\PC_reg[31]_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hAAEFFFEF)) 
    \PC_reg[31]_i_51 
       (.I0(\q_reg[113] [55]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[23]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[23]),
        .O(\PC_reg[31]_i_51_n_0 ));
  LUT5 #(
    .INIT(32'h0000F404)) 
    \PC_reg[31]_i_52 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[22]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(w_RegWriteData_wb[22]),
        .I4(\q_reg[113] [54]),
        .O(\PC_reg[31]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h95959A95)) 
    \PC_reg[31]_i_53 
       (.I0(\q_reg[113] [55]),
        .I1(w_RegWriteData_wb[23]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[23]),
        .I4(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h95959A95)) 
    \PC_reg[31]_i_54 
       (.I0(\q_reg[113] [51]),
        .I1(w_RegWriteData_wb[19]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[19]),
        .I4(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_54_n_0 ));
  LUT4 #(
    .INIT(16'hBF0B)) 
    \PC_reg[31]_i_55 
       (.I0(\q_reg[113] [48]),
        .I1(\q_reg[113] [16]),
        .I2(\q_reg[113] [17]),
        .I3(\q_reg[113] [49]),
        .O(\PC_reg[31]_i_55_n_0 ));
  LUT5 #(
    .INIT(32'h0B080F0F)) 
    \PC_reg[31]_i_56 
       (.I0(\PC_reg[31]_i_77_n_0 ),
        .I1(\PC_reg[31]_i_72_n_0 ),
        .I2(\PC_reg[31]_i_73_n_0 ),
        .I3(\PC_reg[31]_i_78_n_0 ),
        .I4(\PC_reg[31]_i_79_n_0 ),
        .O(\PC_reg[31]_i_56_n_0 ));
  LUT4 #(
    .INIT(16'hD0FD)) 
    \PC_reg[31]_i_57 
       (.I0(\q_reg[113] [48]),
        .I1(\q_reg[113] [16]),
        .I2(\q_reg[113] [17]),
        .I3(\q_reg[113] [49]),
        .O(\PC_reg[31]_i_57_n_0 ));
  LUT5 #(
    .INIT(32'hFBB0F220)) 
    \PC_reg[31]_i_58 
       (.I0(\q_reg[113] [44]),
        .I1(\q_reg[113] [12]),
        .I2(\q_reg[113] [45]),
        .I3(\PC_reg[31]_i_80_n_0 ),
        .I4(\PC_reg[31]_i_72_n_0 ),
        .O(\PC_reg[31]_i_58_n_0 ));
  LUT6 #(
    .INIT(64'h47FF47FF470047FF)) 
    \PC_reg[31]_i_59 
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[15]),
        .I5(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_59_n_0 ));
  LUT5 #(
    .INIT(32'h9FF9F96F)) 
    \PC_reg[31]_i_60 
       (.I0(\q_reg[113] [45]),
        .I1(\PC_reg[31]_i_80_n_0 ),
        .I2(\q_reg[113] [12]),
        .I3(\q_reg[113] [44]),
        .I4(\PC_reg[31]_i_72_n_0 ),
        .O(\PC_reg[31]_i_60_n_0 ));
  LUT4 #(
    .INIT(16'h4290)) 
    \PC_reg[31]_i_61 
       (.I0(\q_reg[113] [8]),
        .I1(\q_reg[113] [40]),
        .I2(\PC_reg[31]_i_81_n_0 ),
        .I3(\PC_reg[31]_i_82_n_0 ),
        .O(\PC_reg[31]_i_61_n_0 ));
  LUT5 #(
    .INIT(32'hF220FBB0)) 
    \PC_reg[31]_i_62 
       (.I0(\q_reg[113] [40]),
        .I1(\q_reg[113] [8]),
        .I2(\q_reg[113] [41]),
        .I3(\PC_reg[31]_i_83_n_0 ),
        .I4(\PC_reg[31]_i_82_n_0 ),
        .O(\PC_reg[31]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'h47474747FF00FFFF)) 
    \PC_reg[31]_i_63 
       (.I0(\q_reg_n_0_[49] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[17] ),
        .I3(\q_reg[21]_0 ),
        .I4(ReadData20[10]),
        .I5(\q[81]_i_2_n_0 ),
        .O(\PC_reg[31]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFDFFFFFD)) 
    \PC_reg[31]_i_64 
       (.I0(\PC_reg[31]_i_84_n_0 ),
        .I1(\PC_reg[31]_i_85_n_0 ),
        .I2(\PC_reg[31]_i_86_n_0 ),
        .I3(\q_reg[113] [34]),
        .I4(\q_reg[113] [2]),
        .I5(\PC_reg[31]_i_87_n_0 ),
        .O(\PC_reg[31]_i_64_n_0 ));
  LUT6 #(
    .INIT(64'h7E7E7ED7D7D77ED7)) 
    \PC_reg[31]_i_65 
       (.I0(\PC_reg[31]_i_88_n_0 ),
        .I1(\q_reg[113] [38]),
        .I2(\PC_reg[31]_i_89_n_0 ),
        .I3(\PC_reg[31]_i_90_n_0 ),
        .I4(\PC_reg[31]_i_69_n_0 ),
        .I5(\PC_reg[31]_i_91_n_0 ),
        .O(\PC_reg[31]_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hAA595559)) 
    \PC_reg[31]_i_66 
       (.I0(\q_reg[113] [37]),
        .I1(ReadData20[5]),
        .I2(\q_reg[21]_0 ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[5]),
        .O(\PC_reg[31]_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hAAEFFFEF)) 
    \PC_reg[31]_i_67 
       (.I0(\q_reg[113] [36]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[4]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[4]),
        .O(\PC_reg[31]_i_67_n_0 ));
  LUT5 #(
    .INIT(32'h008AAA8A)) 
    \PC_reg[31]_i_68 
       (.I0(\q_reg[113] [36]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[4]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[4]),
        .O(\PC_reg[31]_i_68_n_0 ));
  LUT6 #(
    .INIT(64'hFDD0F000FFF0FDD0)) 
    \PC_reg[31]_i_69 
       (.I0(\PC_reg[31]_i_85_n_0 ),
        .I1(\PC_reg[31]_i_86_n_0 ),
        .I2(\q_reg[113] [35]),
        .I3(\PC_reg[31]_i_92_n_0 ),
        .I4(\q_reg[113] [34]),
        .I5(\q_reg[113] [2]),
        .O(\PC_reg[31]_i_69_n_0 ));
  LUT5 #(
    .INIT(32'h8ECF0C8E)) 
    \PC_reg[31]_i_70 
       (.I0(\PC_reg[31]_i_57_n_0 ),
        .I1(\q_reg[113] [19]),
        .I2(\q_reg[113] [51]),
        .I3(\q_reg[113] [50]),
        .I4(\q_reg[113] [18]),
        .O(\PC_reg[31]_i_70_n_0 ));
  LUT4 #(
    .INIT(16'h17FF)) 
    \PC_reg[31]_i_71 
       (.I0(\PC_reg[31]_i_80_n_0 ),
        .I1(\q_reg[113] [45]),
        .I2(\PC_reg[31]_i_93_n_0 ),
        .I3(\PC_reg[31]_i_79_n_0 ),
        .O(\PC_reg[31]_i_71_n_0 ));
  LUT5 #(
    .INIT(32'hBABF8A80)) 
    \PC_reg[31]_i_72 
       (.I0(\PC_reg[31]_i_94_n_0 ),
        .I1(\PC_reg[31]_i_95_n_0 ),
        .I2(\PC_reg[31]_i_69_n_0 ),
        .I3(\PC_reg[31]_i_96_n_0 ),
        .I4(\PC_reg[31]_i_97_n_0 ),
        .O(\PC_reg[31]_i_72_n_0 ));
  LUT4 #(
    .INIT(16'hF220)) 
    \PC_reg[31]_i_73 
       (.I0(\q_reg[113] [46]),
        .I1(\q_reg[113] [14]),
        .I2(\PC_reg[31]_i_59_n_0 ),
        .I3(\q_reg[113] [47]),
        .O(\PC_reg[31]_i_73_n_0 ));
  LUT4 #(
    .INIT(16'hA880)) 
    \PC_reg[31]_i_74 
       (.I0(\PC_reg[31]_i_79_n_0 ),
        .I1(\PC_reg[31]_i_80_n_0 ),
        .I2(\q_reg[113] [45]),
        .I3(\PC_reg[31]_i_98_n_0 ),
        .O(\PC_reg[31]_i_74_n_0 ));
  LUT5 #(
    .INIT(32'h4DCF0C4D)) 
    \PC_reg[31]_i_75 
       (.I0(\PC_reg[31]_i_55_n_0 ),
        .I1(\q_reg[113] [19]),
        .I2(\q_reg[113] [51]),
        .I3(\q_reg[113] [50]),
        .I4(\q_reg[113] [18]),
        .O(\PC_reg[31]_i_75_n_0 ));
  LUT5 #(
    .INIT(32'h008AAA8A)) 
    \PC_reg[31]_i_76 
       (.I0(\q_reg[113] [54]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[22]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[22]),
        .O(\PC_reg[31]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'h7777171111111711)) 
    \PC_reg[31]_i_77 
       (.I0(\PC_reg[31]_i_93_n_0 ),
        .I1(\q_reg[113] [45]),
        .I2(\q_reg[21]_0 ),
        .I3(ReadData20[13]),
        .I4(\q[81]_i_2_n_0 ),
        .I5(w_RegWriteData_wb[13]),
        .O(\PC_reg[31]_i_77_n_0 ));
  LUT6 #(
    .INIT(64'h7777171111111711)) 
    \PC_reg[31]_i_78 
       (.I0(\PC_reg[31]_i_98_n_0 ),
        .I1(\q_reg[113] [45]),
        .I2(\q_reg[21]_0 ),
        .I3(ReadData20[13]),
        .I4(\q[81]_i_2_n_0 ),
        .I5(w_RegWriteData_wb[13]),
        .O(\PC_reg[31]_i_78_n_0 ));
  LUT4 #(
    .INIT(16'hDDD0)) 
    \PC_reg[31]_i_79 
       (.I0(\q_reg[113] [14]),
        .I1(\q_reg[113] [46]),
        .I2(\PC_reg[31]_i_59_n_0 ),
        .I3(\q_reg[113] [47]),
        .O(\PC_reg[31]_i_79_n_0 ));
  LUT6 #(
    .INIT(64'h47FF47FF470047FF)) 
    \PC_reg[31]_i_80 
       (.I0(\q_reg_n_0_[52] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[20] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[13]),
        .I5(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_80_n_0 ));
  LUT5 #(
    .INIT(32'h99A95565)) 
    \PC_reg[31]_i_81 
       (.I0(\q_reg[113] [41]),
        .I1(\q[81]_i_2_n_0 ),
        .I2(ReadData20[9]),
        .I3(\q_reg[21]_0 ),
        .I4(w_RegWriteData_wb[9]),
        .O(\PC_reg[31]_i_81_n_0 ));
  LUT5 #(
    .INIT(32'h0B080F0F)) 
    \PC_reg[31]_i_82 
       (.I0(\PC_reg[31]_i_91_n_0 ),
        .I1(\PC_reg[31]_i_69_n_0 ),
        .I2(\PC_reg[31]_i_99_n_0 ),
        .I3(\PC_reg[31]_i_90_n_0 ),
        .I4(\PC_reg[31]_i_100_n_0 ),
        .O(\PC_reg[31]_i_82_n_0 ));
  LUT6 #(
    .INIT(64'hCFCFCFCFCFCF55CF)) 
    \PC_reg[31]_i_83 
       (.I0(w_RegWriteData_wb[9]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[9]),
        .I3(\q[58]_i_2_n_0 ),
        .I4(\q[58]_i_3_n_0 ),
        .I5(\q[58]_i_4_n_0 ),
        .O(\PC_reg[31]_i_83_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0BFB)) 
    \PC_reg[31]_i_84 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[3]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(w_RegWriteData_wb[3]),
        .I4(\q_reg[113] [35]),
        .O(\PC_reg[31]_i_84_n_0 ));
  LUT4 #(
    .INIT(16'h4F44)) 
    \PC_reg[31]_i_85 
       (.I0(\q_reg[113] [32]),
        .I1(\q_reg[113] [0]),
        .I2(\q_reg[113] [33]),
        .I3(\q_reg[113] [1]),
        .O(\PC_reg[31]_i_85_n_0 ));
  LUT5 #(
    .INIT(32'h008AAA8A)) 
    \PC_reg[31]_i_86 
       (.I0(\q_reg[113] [33]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[1]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[1]),
        .O(\PC_reg[31]_i_86_n_0 ));
  LUT6 #(
    .INIT(64'hBFBFBABFAAAAAAAA)) 
    \PC_reg[31]_i_87 
       (.I0(\PC_reg[31]_i_101_n_0 ),
        .I1(w_RegWriteData_wb[0]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(ReadData20[0]),
        .I4(\q_reg[21]_0 ),
        .I5(\q_reg[113] [32]),
        .O(\PC_reg[31]_i_87_n_0 ));
  LUT6 #(
    .INIT(64'h9A959A959A959595)) 
    \PC_reg[31]_i_88 
       (.I0(\q_reg[113] [7]),
        .I1(w_RegWriteData_wb[7]),
        .I2(\q_reg[85] ),
        .I3(ReadData10[7]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\PC_reg[31]_i_88_n_0 ));
  LUT6 #(
    .INIT(64'h1DFF1D001DFF1DFF)) 
    \PC_reg[31]_i_89 
       (.I0(\q_reg_n_0_[13] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[45] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(\q_reg[21]_0 ),
        .I5(ReadData20[6]),
        .O(\PC_reg[31]_i_89_n_0 ));
  LUT4 #(
    .INIT(16'h0DDF)) 
    \PC_reg[31]_i_90 
       (.I0(\q_reg[113] [36]),
        .I1(\q_reg[113] [4]),
        .I2(\q_reg[113] [37]),
        .I3(\PC_reg[31]_i_102_n_0 ),
        .O(\PC_reg[31]_i_90_n_0 ));
  LUT4 #(
    .INIT(16'h044F)) 
    \PC_reg[31]_i_91 
       (.I0(\q_reg[113] [36]),
        .I1(\q_reg[113] [4]),
        .I2(\q_reg[113] [37]),
        .I3(\PC_reg[31]_i_102_n_0 ),
        .O(\PC_reg[31]_i_91_n_0 ));
  LUT6 #(
    .INIT(64'h47FF47FF470047FF)) 
    \PC_reg[31]_i_92 
       (.I0(\q_reg_n_0_[42] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[10] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[3]),
        .I5(\q_reg[21]_0 ),
        .O(\PC_reg[31]_i_92_n_0 ));
  LUT5 #(
    .INIT(32'hAAEFFFEF)) 
    \PC_reg[31]_i_93 
       (.I0(\q_reg[113] [44]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[12]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[12]),
        .O(\PC_reg[31]_i_93_n_0 ));
  LUT5 #(
    .INIT(32'hD400FFD4)) 
    \PC_reg[31]_i_94 
       (.I0(\PC_reg[31]_i_103_n_0 ),
        .I1(\PC_reg[31]_i_63_n_0 ),
        .I2(\q_reg[113] [42]),
        .I3(\q_reg[113] [43]),
        .I4(\q_reg[113] [11]),
        .O(\PC_reg[31]_i_94_n_0 ));
  LUT5 #(
    .INIT(32'h30B2B2F3)) 
    \PC_reg[31]_i_95 
       (.I0(\PC_reg[31]_i_91_n_0 ),
        .I1(\q_reg[113] [39]),
        .I2(\q_reg[113] [7]),
        .I3(\PC_reg[31]_i_89_n_0 ),
        .I4(\q_reg[113] [38]),
        .O(\PC_reg[31]_i_95_n_0 ));
  LUT5 #(
    .INIT(32'h2BFF002B)) 
    \PC_reg[31]_i_96 
       (.I0(\PC_reg[31]_i_90_n_0 ),
        .I1(\PC_reg[31]_i_89_n_0 ),
        .I2(\q_reg[113] [38]),
        .I3(\q_reg[113] [39]),
        .I4(\q_reg[113] [7]),
        .O(\PC_reg[31]_i_96_n_0 ));
  LUT5 #(
    .INIT(32'hCF4D4D0C)) 
    \PC_reg[31]_i_97 
       (.I0(\PC_reg[31]_i_104_n_0 ),
        .I1(\q_reg[113] [43]),
        .I2(\q_reg[113] [11]),
        .I3(\PC_reg[31]_i_63_n_0 ),
        .I4(\q_reg[113] [42]),
        .O(\PC_reg[31]_i_97_n_0 ));
  LUT5 #(
    .INIT(32'h008AAA8A)) 
    \PC_reg[31]_i_98 
       (.I0(\q_reg[113] [44]),
        .I1(\q_reg[21]_0 ),
        .I2(ReadData20[12]),
        .I3(\q[81]_i_2_n_0 ),
        .I4(w_RegWriteData_wb[12]),
        .O(\PC_reg[31]_i_98_n_0 ));
  LUT4 #(
    .INIT(16'h8F08)) 
    \PC_reg[31]_i_99 
       (.I0(\q_reg[113] [38]),
        .I1(\PC_reg[31]_i_89_n_0 ),
        .I2(\q_reg[113] [7]),
        .I3(\q_reg[113] [39]),
        .O(\PC_reg[31]_i_99_n_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[100]_i_1 
       (.I0(\q_reg_n_0_[57] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[25] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[18]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [50]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[101]_i_1 
       (.I0(\q_reg_n_0_[58] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[26] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[19]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [51]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[102]_i_1 
       (.I0(\q_reg_n_0_[59] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[27] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[20]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [52]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[103]_i_1 
       (.I0(\q_reg_n_0_[60] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[28] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[21]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [53]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[104]_i_1 
       (.I0(\q_reg_n_0_[61] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[29] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[22]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [54]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[105]_i_1 
       (.I0(\q_reg_n_0_[62] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[30] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[23]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [55]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[106]_i_1 
       (.I0(\q_reg_n_0_[63] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[31] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[24]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [56]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[107]_i_1 
       (.I0(\q_reg_n_0_[64] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[32] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[25]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [57]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[108]_i_1 
       (.I0(\q_reg_n_0_[65] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[33] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[26]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [58]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[109]_i_1 
       (.I0(\q_reg_n_0_[66] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[34] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[27]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [59]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[110]_i_1 
       (.I0(\q_reg_n_0_[67] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[35] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[28]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [60]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[111]_i_1 
       (.I0(\q_reg_n_0_[68] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[36] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[29]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [61]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[112]_i_1 
       (.I0(\q_reg_n_0_[69] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[37] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[30]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [62]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[113]_i_1 
       (.I0(\q_reg_n_0_[70] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[38] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[31]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [63]));
  LUT6 #(
    .INIT(64'h0000820000004000)) 
    \q[113]_i_2 
       (.I0(\q_reg[27]_0 [3]),
        .I1(\q_reg[27]_0 [4]),
        .I2(Q[1]),
        .I3(Q[4]),
        .I4(\q[113]_i_4_n_0 ),
        .I5(Q[0]),
        .O(\q_reg[85] ));
  LUT2 #(
    .INIT(4'hE)) 
    \q[113]_i_4 
       (.I0(Q[2]),
        .I1(Q[3]),
        .O(\q[113]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6FFFFFFFF6FF6)) 
    \q[42]_i_8 
       (.I0(Q[2]),
        .I1(\q_reg[148] [3]),
        .I2(Q[3]),
        .I3(\q_reg[148] [1]),
        .I4(Q[0]),
        .I5(\q_reg[148] [0]),
        .O(\q_reg[11]_1 ));
  LUT5 #(
    .INIT(32'h55555557)) 
    \q[42]_i_9 
       (.I0(Q[4]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\q_reg[11]_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[45]_i_12 
       (.I0(w_RegWriteData_wb[2]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [8]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [4]),
        .O(\q_reg[45]_0 ));
  LUT6 #(
    .INIT(64'h00080008FFFB0008)) 
    \q[50]_i_1 
       (.I0(w_RegWriteData_wb[0]),
        .I1(\q[58]_i_2_n_0 ),
        .I2(\q[58]_i_3_n_0 ),
        .I3(\q[58]_i_4_n_0 ),
        .I4(ReadData20[0]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [0]));
  LUT6 #(
    .INIT(64'h00080008FFFB0008)) 
    \q[51]_i_1 
       (.I0(w_RegWriteData_wb[1]),
        .I1(\q[58]_i_2_n_0 ),
        .I2(\q[58]_i_3_n_0 ),
        .I3(\q[58]_i_4_n_0 ),
        .I4(ReadData20[1]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [1]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[52]_i_1 
       (.I0(\q_reg_n_0_[41] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[9] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[2]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [2]));
  LUT6 #(
    .INIT(64'hF4F4F4040404F404)) 
    \q[53]_i_1 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[3]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(\q_reg_n_0_[10] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[42] ),
        .O(\q_reg[113] [3]));
  LUT6 #(
    .INIT(64'h00080008FFFB0008)) 
    \q[54]_i_1 
       (.I0(w_RegWriteData_wb[4]),
        .I1(\q[58]_i_2_n_0 ),
        .I2(\q[58]_i_3_n_0 ),
        .I3(\q[58]_i_4_n_0 ),
        .I4(ReadData20[4]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [4]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[54]_i_17 
       (.I0(w_RegWriteData_wb[10]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [16]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [5]),
        .O(\q_reg[53]_0 ));
  LUT6 #(
    .INIT(64'hF202F2F2F2020202)) 
    \q[55]_i_1 
       (.I0(ReadData20[5]),
        .I1(\q_reg[21]_0 ),
        .I2(\q[81]_i_2_n_0 ),
        .I3(\q_reg_n_0_[44] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[12] ),
        .O(\q_reg[113] [5]));
  LUT6 #(
    .INIT(64'h4540FFFF45404540)) 
    \q[55]_i_26 
       (.I0(\q_reg[44]_0 ),
        .I1(\q_reg_n_0_[44] ),
        .I2(\q_reg_n_0_[5] ),
        .I3(\q_reg_n_0_[12] ),
        .I4(\q_reg[4] ),
        .I5(\q_reg[74] [11]),
        .O(\q_reg[48]_1 ));
  LUT6 #(
    .INIT(64'h0002000000020002)) 
    \q[55]_i_30 
       (.I0(w_RegWriteData_wb[6]),
        .I1(\q_reg[11]_0 ),
        .I2(\q_reg[11]_1 ),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[5]_0 ),
        .I5(\q_reg[44]_2 ),
        .O(\q_reg[55]_1 ));
  LUT6 #(
    .INIT(64'hF202F2F2F2020202)) 
    \q[56]_i_1 
       (.I0(ReadData20[6]),
        .I1(\q_reg[21]_0 ),
        .I2(\q[81]_i_2_n_0 ),
        .I3(\q_reg_n_0_[45] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[13] ),
        .O(\q_reg[113] [6]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[57]_i_1 
       (.I0(\q_reg_n_0_[46] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[14] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[7]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [7]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[57]_i_16 
       (.I0(w_RegWriteData_wb[12]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [18]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [6]),
        .O(\q_reg[55]_0 ));
  LUT6 #(
    .INIT(64'h00080008FFFB0008)) 
    \q[58]_i_1 
       (.I0(w_RegWriteData_wb[8]),
        .I1(\q[58]_i_2_n_0 ),
        .I2(\q[58]_i_3_n_0 ),
        .I3(\q[58]_i_4_n_0 ),
        .I4(ReadData20[8]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [8]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[58]_i_13 
       (.I0(w_RegWriteData_wb[14]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [20]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [7]),
        .O(\q_reg[57]_0 ));
  LUT6 #(
    .INIT(64'hFF000000B8B8B8B8)) 
    \q[58]_i_14 
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .I3(\q_reg[148] [8]),
        .I4(\q_reg[4] ),
        .I5(\q_reg[44]_0 ),
        .O(\q_reg[58]_0 ));
  LUT4 #(
    .INIT(16'h1001)) 
    \q[58]_i_2 
       (.I0(Q[3]),
        .I1(\q_reg[27]_0 [2]),
        .I2(Q[0]),
        .I3(\q_reg[27]_0 [0]),
        .O(\q[58]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h6FF6)) 
    \q[58]_i_3 
       (.I0(Q[1]),
        .I1(\q_reg[27]_0 [1]),
        .I2(Q[2]),
        .I3(\q_reg[27]_0 [4]),
        .O(\q[58]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h55555557)) 
    \q[58]_i_4 
       (.I0(Q[4]),
        .I1(Q[3]),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(\q[58]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAEAEAE040404AE04)) 
    \q[59]_i_1 
       (.I0(\q[81]_i_2_n_0 ),
        .I1(ReadData20[9]),
        .I2(\q_reg[21]_0 ),
        .I3(\q_reg_n_0_[16] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[48] ),
        .O(\q_reg[113] [9]));
  LUT6 #(
    .INIT(64'hAEAEAE040404AE04)) 
    \q[60]_i_1 
       (.I0(\q[81]_i_2_n_0 ),
        .I1(ReadData20[10]),
        .I2(\q_reg[21]_0 ),
        .I3(\q_reg_n_0_[17] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[49] ),
        .O(\q_reg[113] [10]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[61]_i_1 
       (.I0(\q_reg_n_0_[50] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[18] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[11]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [11]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[61]_i_19 
       (.I0(w_RegWriteData_wb[16]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [22]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [9]),
        .O(\q_reg[59]_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[61]_i_21 
       (.I0(w_RegWriteData_wb[17]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [23]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [10]),
        .O(\q_reg[60]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[62]_i_1 
       (.I0(\q_reg_n_0_[51] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[19] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[12]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [12]));
  LUT6 #(
    .INIT(64'hF4F4F4040404F404)) 
    \q[63]_i_1 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[13]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(\q_reg_n_0_[20] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[52] ),
        .O(\q_reg[113] [13]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[64]_i_1 
       (.I0(\q_reg_n_0_[53] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[21] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[14]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [14]));
  LUT6 #(
    .INIT(64'hF4F4F4040404F404)) 
    \q[65]_i_1 
       (.I0(\q_reg[21]_0 ),
        .I1(ReadData20[15]),
        .I2(\q[81]_i_2_n_0 ),
        .I3(\q_reg_n_0_[22] ),
        .I4(\q_reg_n_0_[5] ),
        .I5(\q_reg_n_0_[54] ),
        .O(\q_reg[113] [15]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[65]_i_16 
       (.I0(w_RegWriteData_wb[22]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [28]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [13]),
        .O(\q_reg[65]_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[65]_i_17 
       (.I0(w_RegWriteData_wb[20]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [26]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [11]),
        .O(\q_reg[63]_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[65]_i_19 
       (.I0(w_RegWriteData_wb[21]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [27]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [12]),
        .O(\q_reg[64]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[66]_i_1 
       (.I0(\q_reg_n_0_[55] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[23] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[16]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [16]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[66]_i_15 
       (.I0(w_RegWriteData_wb[23]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [29]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [14]),
        .O(\q_reg[66]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[67]_i_1 
       (.I0(\q_reg_n_0_[56] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[24] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[17]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [17]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[68]_i_1 
       (.I0(\q_reg_n_0_[57] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[25] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[18]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [18]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[69]_i_1 
       (.I0(\q_reg_n_0_[58] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[26] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[19]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [19]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[70]_i_1 
       (.I0(\q_reg_n_0_[59] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[27] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[20]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [20]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[70]_i_14 
       (.I0(w_RegWriteData_wb[26]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [32]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [15]),
        .O(\q_reg[69]_0 ));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[70]_i_15 
       (.I0(w_RegWriteData_wb[27]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [33]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [16]),
        .O(\q_reg[70]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[71]_i_1 
       (.I0(\q_reg_n_0_[60] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[28] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[21]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [21]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[72]_i_1 
       (.I0(\q_reg_n_0_[61] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[29] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[22]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [22]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[72]_i_13 
       (.I0(w_RegWriteData_wb[29]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [35]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [17]),
        .O(\q_reg[72] ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[73]_i_1 
       (.I0(\q_reg_n_0_[62] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[30] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[23]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [23]));
  LUT6 #(
    .INIT(64'h0003110133031101)) 
    \q[73]_i_16 
       (.I0(w_RegWriteData_wb[30]),
        .I1(\q_reg[148] [19]),
        .I2(\q_reg[74] [36]),
        .I3(\q_reg[4] ),
        .I4(\q_reg[44]_0 ),
        .I5(\q_reg[148] [18]),
        .O(\q_reg[73] ));
  LUT6 #(
    .INIT(64'h0100010101FF0101)) 
    \q[73]_i_18 
       (.I0(\q_reg[11]_0 ),
        .I1(\q_reg[11]_1 ),
        .I2(\q_reg[44]_1 ),
        .I3(\q_reg[5]_0 ),
        .I4(\q_reg[44]_2 ),
        .I5(\q_reg[9]_0 ),
        .O(\q_reg[48]_0 ));
  LUT6 #(
    .INIT(64'h0002000000020002)) 
    \q[73]_i_20 
       (.I0(w_RegWriteData_wb[0]),
        .I1(\q_reg[11]_0 ),
        .I2(\q_reg[11]_1 ),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[5]_0 ),
        .I5(\q_reg[44]_2 ),
        .O(\q_reg[48]_2 ));
  LUT6 #(
    .INIT(64'h0002000000020002)) 
    \q[73]_i_24 
       (.I0(w_RegWriteData_wb[1]),
        .I1(\q_reg[11]_0 ),
        .I2(\q_reg[11]_1 ),
        .I3(\q_reg[44]_1 ),
        .I4(\q_reg[5]_0 ),
        .I5(\q_reg[44]_2 ),
        .O(\q_reg[59]_1 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[74]_i_1 
       (.I0(\q_reg_n_0_[63] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[31] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[24]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [24]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF6FF6)) 
    \q[74]_i_14 
       (.I0(Q[0]),
        .I1(\q_reg[148] [2]),
        .I2(\q_reg[148] [3]),
        .I3(Q[1]),
        .I4(Q[2]),
        .I5(Q[3]),
        .O(\q[74]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFEFEFEFEFEFFF)) 
    \q[74]_i_9 
       (.I0(\q_reg[46]_0 ),
        .I1(\q[74]_i_14_n_0 ),
        .I2(Q[4]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(\q[113]_i_4_n_0 ),
        .O(\q_reg[44]_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[75]_i_1 
       (.I0(\q_reg_n_0_[64] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[32] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[25]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [25]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[76]_i_1 
       (.I0(\q_reg_n_0_[65] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[33] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[26]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [26]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[77]_i_1 
       (.I0(\q_reg_n_0_[66] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[34] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[27]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [27]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[78]_i_1 
       (.I0(\q_reg_n_0_[67] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[35] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[28]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [28]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[79]_i_1 
       (.I0(\q_reg_n_0_[68] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[36] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[29]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [29]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[80]_i_1 
       (.I0(\q_reg_n_0_[69] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[37] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[30]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [30]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[81]_i_1 
       (.I0(\q_reg_n_0_[70] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[38] ),
        .I3(\q[81]_i_2_n_0 ),
        .I4(ReadData20[31]),
        .I5(\q_reg[21]_0 ),
        .O(\q_reg[113] [31]));
  LUT6 #(
    .INIT(64'h0000000000000009)) 
    \q[81]_i_2 
       (.I0(\q_reg[27]_0 [0]),
        .I1(Q[0]),
        .I2(\q_reg[27]_0 [2]),
        .I3(Q[3]),
        .I4(\q[58]_i_3_n_0 ),
        .I5(\q[58]_i_4_n_0 ),
        .O(\q[81]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[82]_i_1 
       (.I0(w_RegWriteData_wb[0]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[0]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [32]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[83]_i_1 
       (.I0(w_RegWriteData_wb[1]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[1]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [33]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[84]_i_1 
       (.I0(\q_reg_n_0_[41] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[9] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[2]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [34]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[85]_i_1 
       (.I0(\q_reg_n_0_[42] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[10] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[3]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [35]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[86]_i_1 
       (.I0(w_RegWriteData_wb[4]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[4]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [36]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[87]_i_1 
       (.I0(w_RegWriteData_wb[5]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[5]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [37]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[88]_i_1 
       (.I0(w_RegWriteData_wb[6]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[6]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [38]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[89]_i_1 
       (.I0(w_RegWriteData_wb[7]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[7]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [39]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[90]_i_1 
       (.I0(w_RegWriteData_wb[8]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[8]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [40]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[91]_i_1 
       (.I0(w_RegWriteData_wb[9]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[9]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [41]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[92]_i_1 
       (.I0(w_RegWriteData_wb[10]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[10]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [42]));
  LUT6 #(
    .INIT(64'hFB08FB08FB080808)) 
    \q[93]_i_1 
       (.I0(w_RegWriteData_wb[11]),
        .I1(\q[93]_i_2_n_0 ),
        .I2(\q[93]_i_3_n_0 ),
        .I3(ReadData10[11]),
        .I4(\q_reg[27]_0 [3]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q_reg[113] [43]));
  LUT4 #(
    .INIT(16'h1001)) 
    \q[93]_i_2 
       (.I0(Q[2]),
        .I1(Q[3]),
        .I2(\q_reg[27]_0 [3]),
        .I3(Q[0]),
        .O(\q[93]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00FFFFFFFFFF01FF)) 
    \q[93]_i_3 
       (.I0(Q[0]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[1]),
        .I5(\q_reg[27]_0 [4]),
        .O(\q[93]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[94]_i_1 
       (.I0(\q_reg_n_0_[51] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[19] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[12]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [44]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[95]_i_1 
       (.I0(\q_reg_n_0_[52] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[20] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[13]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [45]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[96]_i_1 
       (.I0(\q_reg_n_0_[53] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[21] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[14]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [46]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[97]_i_1 
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[15]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [47]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[98]_i_1 
       (.I0(\q_reg_n_0_[55] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[23] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[16]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [48]));
  LUT6 #(
    .INIT(64'hB800B800B8FFB800)) 
    \q[99]_i_1 
       (.I0(\q_reg_n_0_[56] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[24] ),
        .I3(\q_reg[85] ),
        .I4(ReadData10[17]),
        .I5(\q_reg[27]_1 ),
        .O(\q_reg[113] [49]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [0]),
        .Q(Q[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [9]),
        .Q(\q_reg_n_0_[10] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [10]),
        .Q(\q_reg_n_0_[11] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [11]),
        .Q(\q_reg_n_0_[12] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [12]),
        .Q(\q_reg_n_0_[13] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [13]),
        .Q(\q_reg_n_0_[14] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [14]),
        .Q(\q_reg_n_0_[15] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [15]),
        .Q(\q_reg_n_0_[16] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [16]),
        .Q(\q_reg_n_0_[17] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [17]),
        .Q(\q_reg_n_0_[18] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [18]),
        .Q(\q_reg_n_0_[19] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [1]),
        .Q(Q[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [19]),
        .Q(\q_reg_n_0_[20] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [20]),
        .Q(\q_reg_n_0_[21] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [21]),
        .Q(\q_reg_n_0_[22] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [22]),
        .Q(\q_reg_n_0_[23] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [23]),
        .Q(\q_reg_n_0_[24] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [24]),
        .Q(\q_reg_n_0_[25] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [25]),
        .Q(\q_reg_n_0_[26] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [26]),
        .Q(\q_reg_n_0_[27] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [27]),
        .Q(\q_reg_n_0_[28] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [28]),
        .Q(\q_reg_n_0_[29] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [2]),
        .Q(Q[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [29]),
        .Q(\q_reg_n_0_[30] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [30]),
        .Q(\q_reg_n_0_[31] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[32] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [31]),
        .Q(\q_reg_n_0_[32] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[33] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [32]),
        .Q(\q_reg_n_0_[33] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[34] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [33]),
        .Q(\q_reg_n_0_[34] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[35] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [34]),
        .Q(\q_reg_n_0_[35] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[36] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [35]),
        .Q(\q_reg_n_0_[36] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[37] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [36]),
        .Q(\q_reg_n_0_[37] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[38] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [37]),
        .Q(\q_reg_n_0_[38] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[39] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[0]),
        .Q(\q_reg_n_0_[39] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [3]),
        .Q(Q[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[40] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[1]),
        .Q(\q_reg_n_0_[40] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[41] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[2]),
        .Q(\q_reg_n_0_[41] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[42] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[3]),
        .Q(\q_reg_n_0_[42] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[43] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[4]),
        .Q(\q_reg_n_0_[43] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[44] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[5]),
        .Q(\q_reg_n_0_[44] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[45] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[6]),
        .Q(\q_reg_n_0_[45] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[46] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[7]),
        .Q(\q_reg_n_0_[46] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[47] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[8]),
        .Q(\q_reg_n_0_[47] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[48] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[9]),
        .Q(\q_reg_n_0_[48] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[49] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[10]),
        .Q(\q_reg_n_0_[49] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[50] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[11]),
        .Q(\q_reg_n_0_[50] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[51] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[12]),
        .Q(\q_reg_n_0_[51] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[52] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[13]),
        .Q(\q_reg_n_0_[52] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[53] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[14]),
        .Q(\q_reg_n_0_[53] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[54] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[15]),
        .Q(\q_reg_n_0_[54] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[55] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[16]),
        .Q(\q_reg_n_0_[55] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[56] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[17]),
        .Q(\q_reg_n_0_[56] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[57] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[18]),
        .Q(\q_reg_n_0_[57] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[58] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[19]),
        .Q(\q_reg_n_0_[58] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[59] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[20]),
        .Q(\q_reg_n_0_[59] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [4]),
        .Q(\q_reg_n_0_[5] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[60] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[21]),
        .Q(\q_reg_n_0_[60] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[61] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[22]),
        .Q(\q_reg_n_0_[61] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[62] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[23]),
        .Q(\q_reg_n_0_[62] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[63] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[24]),
        .Q(\q_reg_n_0_[63] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[64] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[25]),
        .Q(\q_reg_n_0_[64] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[65] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[26]),
        .Q(\q_reg_n_0_[65] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[66] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[27]),
        .Q(\q_reg_n_0_[66] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[67] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[28]),
        .Q(\q_reg_n_0_[67] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[68] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[29]),
        .Q(\q_reg_n_0_[68] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[69] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[30]),
        .Q(\q_reg_n_0_[69] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [5]),
        .Q(Q[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[70] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(D[31]),
        .Q(\q_reg_n_0_[70] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [6]),
        .Q(\q_reg_n_0_[7] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [7]),
        .Q(\q_reg_n_0_[8] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(1'b1),
        .D(\q_reg[74] [8]),
        .Q(\q_reg_n_0_[9] ),
        .R(SR));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_1
       (.I0(\q_reg_n_0_[40] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[8] ),
        .O(w_RegWriteData_wb[1]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_2
       (.I0(\q_reg_n_0_[39] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[7] ),
        .O(w_RegWriteData_wb[0]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_3
       (.I0(\q_reg_n_0_[42] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[10] ),
        .O(w_RegWriteData_wb[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_4
       (.I0(\q_reg_n_0_[41] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[9] ),
        .O(w_RegWriteData_wb[2]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_5
       (.I0(\q_reg_n_0_[44] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[12] ),
        .O(w_RegWriteData_wb[5]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_0_5_i_6
       (.I0(\q_reg_n_0_[43] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[11] ),
        .O(w_RegWriteData_wb[4]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_1
       (.I0(\q_reg_n_0_[52] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[20] ),
        .O(w_RegWriteData_wb[13]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_2
       (.I0(\q_reg_n_0_[51] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[19] ),
        .O(w_RegWriteData_wb[12]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_3
       (.I0(\q_reg_n_0_[54] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[22] ),
        .O(w_RegWriteData_wb[15]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_4
       (.I0(\q_reg_n_0_[53] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[21] ),
        .O(w_RegWriteData_wb[14]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_5
       (.I0(\q_reg_n_0_[56] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[24] ),
        .O(w_RegWriteData_wb[17]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_12_17_i_6
       (.I0(\q_reg_n_0_[55] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[23] ),
        .O(w_RegWriteData_wb[16]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_1
       (.I0(\q_reg_n_0_[58] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[26] ),
        .O(w_RegWriteData_wb[19]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_2
       (.I0(\q_reg_n_0_[57] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[25] ),
        .O(w_RegWriteData_wb[18]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_3
       (.I0(\q_reg_n_0_[60] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[28] ),
        .O(w_RegWriteData_wb[21]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_4
       (.I0(\q_reg_n_0_[59] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[27] ),
        .O(w_RegWriteData_wb[20]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_5
       (.I0(\q_reg_n_0_[62] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[30] ),
        .O(w_RegWriteData_wb[23]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_18_23_i_6
       (.I0(\q_reg_n_0_[61] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[29] ),
        .O(w_RegWriteData_wb[22]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_1
       (.I0(\q_reg_n_0_[64] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[32] ),
        .O(w_RegWriteData_wb[25]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_2
       (.I0(\q_reg_n_0_[63] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[31] ),
        .O(w_RegWriteData_wb[24]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_3
       (.I0(\q_reg_n_0_[66] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[34] ),
        .O(w_RegWriteData_wb[27]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_4
       (.I0(\q_reg_n_0_[65] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[33] ),
        .O(w_RegWriteData_wb[26]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_5
       (.I0(\q_reg_n_0_[68] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[36] ),
        .O(w_RegWriteData_wb[29]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_24_29_i_6
       (.I0(\q_reg_n_0_[67] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[35] ),
        .O(w_RegWriteData_wb[28]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_30_31_i_1
       (.I0(\q_reg_n_0_[70] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[38] ),
        .O(w_RegWriteData_wb[31]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_30_31_i_2
       (.I0(\q_reg_n_0_[69] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[37] ),
        .O(w_RegWriteData_wb[30]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_1
       (.I0(\q_reg_n_0_[46] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[14] ),
        .O(w_RegWriteData_wb[7]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_2
       (.I0(\q_reg_n_0_[45] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[13] ),
        .O(w_RegWriteData_wb[6]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_3
       (.I0(\q_reg_n_0_[48] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[16] ),
        .O(w_RegWriteData_wb[9]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_4
       (.I0(\q_reg_n_0_[47] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[15] ),
        .O(w_RegWriteData_wb[8]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_5
       (.I0(\q_reg_n_0_[50] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[18] ),
        .O(w_RegWriteData_wb[11]));
  LUT3 #(
    .INIT(8'hB8)) 
    regs_reg_r1_0_31_6_11_i_6
       (.I0(\q_reg_n_0_[49] ),
        .I1(\q_reg_n_0_[5] ),
        .I2(\q_reg_n_0_[17] ),
        .O(w_RegWriteData_wb[10]));
endmodule

(* CHECK_LICENSE_TYPE = "DataRAM,dist_mem_gen_v8_0_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_12,Vivado 2017.3" *) 
module DataRAM
   (a,
    d,
    clk,
    we,
    spo);
  input [5:0]a;
  input [31:0]d;
  input clk;
  input we;
  output [31:0]spo;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;
  wire NLW_U0_i_ce_UNCONNECTED;
  wire NLW_U0_qdpo_ce_UNCONNECTED;
  wire NLW_U0_qdpo_clk_UNCONNECTED;
  wire NLW_U0_qdpo_rst_UNCONNECTED;
  wire NLW_U0_qdpo_srst_UNCONNECTED;
  wire NLW_U0_qspo_ce_UNCONNECTED;
  wire NLW_U0_qspo_rst_UNCONNECTED;
  wire NLW_U0_qspo_srst_UNCONNECTED;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [5:0]NLW_U0_dpra_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_CLK = "1" *) 
  (* C_HAS_D = "1" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "1" *) 
  (* C_MEM_TYPE = "1" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "6" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "64" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_i_ce = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "no_coe_file_loaded" *) 
  (* c_parser_type = "1" *) 
  (* c_pipeline_stages = "0" *) 
  (* c_qualify_we = "0" *) 
  (* c_read_mif = "0" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  DataRAM_dist_mem_gen_v8_0_12 U0
       (.a(a),
        .clk(clk),
        .d(d),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra(NLW_U0_dpra_UNCONNECTED[5:0]),
        .i_ce(NLW_U0_i_ce_UNCONNECTED),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(NLW_U0_qdpo_ce_UNCONNECTED),
        .qdpo_clk(NLW_U0_qdpo_clk_UNCONNECTED),
        .qdpo_rst(NLW_U0_qdpo_rst_UNCONNECTED),
        .qdpo_srst(NLW_U0_qdpo_srst_UNCONNECTED),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(NLW_U0_qspo_ce_UNCONNECTED),
        .qspo_rst(NLW_U0_qspo_rst_UNCONNECTED),
        .qspo_srst(NLW_U0_qspo_srst_UNCONNECTED),
        .spo(spo),
        .we(we));
endmodule

(* CHECK_LICENSE_TYPE = "DisplayROM,dist_mem_gen_v8_0_11,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_11,Vivado 2017.1" *) 
module DisplayROM
   (a,
    clk,
    qspo);
  input [7:0]a;
  input clk;
  output [7:0]qspo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire NLW_U0_i_ce_UNCONNECTED;
  wire NLW_U0_qdpo_ce_UNCONNECTED;
  wire NLW_U0_qdpo_clk_UNCONNECTED;
  wire NLW_U0_qdpo_rst_UNCONNECTED;
  wire NLW_U0_qdpo_srst_UNCONNECTED;
  wire NLW_U0_qspo_ce_UNCONNECTED;
  wire NLW_U0_qspo_rst_UNCONNECTED;
  wire NLW_U0_qspo_srst_UNCONNECTED;
  wire NLW_U0_we_UNCONNECTED;
  wire [7:0]NLW_U0_d_UNCONNECTED;
  wire [7:0]NLW_U0_dpo_UNCONNECTED;
  wire [7:0]NLW_U0_dpra_UNCONNECTED;
  wire [7:0]NLW_U0_qdpo_UNCONNECTED;
  wire [7:0]NLW_U0_spo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_CLK = "1" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "8" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "256" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_i_ce = "0" *) 
  (* c_has_qspo = "1" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "0" *) 
  (* c_mem_init_file = "DisplayROM.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_pipeline_stages = "0" *) 
  (* c_qualify_we = "0" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "8" *) 
  DisplayROM__dist_mem_gen_v8_0_11 U0
       (.a(a),
        .clk(clk),
        .d(NLW_U0_d_UNCONNECTED[7:0]),
        .dpo(NLW_U0_dpo_UNCONNECTED[7:0]),
        .dpra(NLW_U0_dpra_UNCONNECTED[7:0]),
        .i_ce(NLW_U0_i_ce_UNCONNECTED),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[7:0]),
        .qdpo_ce(NLW_U0_qdpo_ce_UNCONNECTED),
        .qdpo_clk(NLW_U0_qdpo_clk_UNCONNECTED),
        .qdpo_rst(NLW_U0_qdpo_rst_UNCONNECTED),
        .qdpo_srst(NLW_U0_qdpo_srst_UNCONNECTED),
        .qspo(qspo),
        .qspo_ce(NLW_U0_qspo_ce_UNCONNECTED),
        .qspo_rst(NLW_U0_qspo_rst_UNCONNECTED),
        .qspo_srst(NLW_U0_qspo_srst_UNCONNECTED),
        .spo(NLW_U0_spo_UNCONNECTED[7:0]),
        .we(NLW_U0_we_UNCONNECTED));
endmodule

module ID
   (ReadData10,
    ReadData20,
    cpu_clk_BUFG,
    Q,
    w_RegWriteData_wb,
    Instruction_id);
  output [31:0]ReadData10;
  output [31:0]ReadData20;
  input cpu_clk_BUFG;
  input [4:0]Q;
  input [31:0]w_RegWriteData_wb;
  input [4:0]Instruction_id;

  wire [4:0]Instruction_id;
  wire [4:0]Q;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire cpu_clk_BUFG;
  wire [31:0]w_RegWriteData_wb;

  Registers u_Registers
       (.Instruction_id(Instruction_id),
        .Q(Q),
        .ReadData10(ReadData10),
        .ReadData20(ReadData20),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .w_RegWriteData_wb(w_RegWriteData_wb));
endmodule

module IF1
   (\TMDSn[2] ,
    D,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    c2__0,
    c3__0,
    c4__0,
    c5__0,
    c6__0,
    c7__0,
    Stall,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[6] ,
    \PC_reg_reg[28]_0 ,
    JumpAddr,
    w_IF_flush,
    SR,
    E,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [49:0]D;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output c2__0;
  output c3__0;
  output c4__0;
  output c5__0;
  output c6__0;
  output c7__0;
  input Stall;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[6] ;
  input [9:0]\PC_reg_reg[28]_0 ;
  input [21:0]JumpAddr;
  input w_IF_flush;
  input [0:0]SR;
  input [0:0]E;
  input cpu_clk_BUFG;

  wire [49:0]D;
  wire [0:0]E;
  wire [21:0]JumpAddr;
  wire [31:4]Next_PC;
  wire \PC_reg[11]_i_3_n_0 ;
  wire \PC_reg[15]_i_3_n_0 ;
  wire \PC_reg[19]_i_3_n_0 ;
  wire \PC_reg[23]_i_3_n_0 ;
  wire \PC_reg[27]_i_3_n_0 ;
  wire \PC_reg[31]_i_6_n_0 ;
  wire \PC_reg[7]_i_3_n_0 ;
  wire [9:0]\PC_reg_reg[28]_0 ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[6] ;
  wire [0:0]SR;
  wire Stall;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire c2__0;
  wire c3__0;
  wire c4__0;
  wire c5__0;
  wire c6__0;
  wire c7__0;
  wire cpu_clk_BUFG;
  wire \u_adder_pc/c1 ;
  wire w_IF_flush;

  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[10]_i_1 
       (.I0(JumpAddr[5]),
        .I1(w_IF_flush),
        .I2(D[26]),
        .I3(D[27]),
        .I4(c2__0),
        .I5(D[28]),
        .O(Next_PC[10]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[11]_i_1 
       (.I0(JumpAddr[6]),
        .I1(w_IF_flush),
        .I2(\PC_reg[11]_i_3_n_0 ),
        .I3(D[28]),
        .I4(c2__0),
        .I5(D[29]),
        .O(Next_PC[11]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[11]_i_3 
       (.I0(D[27]),
        .I1(D[26]),
        .O(\PC_reg[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \PC_reg[11]_i_4 
       (.I0(D[21]),
        .I1(D[20]),
        .I2(D[22]),
        .I3(D[24]),
        .I4(D[23]),
        .I5(D[25]),
        .O(c2__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[13]_i_1 
       (.I0(JumpAddr[7]),
        .I1(w_IF_flush),
        .I2(D[30]),
        .I3(c3__0),
        .I4(D[31]),
        .O(Next_PC[13]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[14]_i_1 
       (.I0(JumpAddr[8]),
        .I1(w_IF_flush),
        .I2(D[30]),
        .I3(D[31]),
        .I4(c3__0),
        .I5(D[32]),
        .O(Next_PC[14]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[15]_i_1 
       (.I0(JumpAddr[9]),
        .I1(w_IF_flush),
        .I2(\PC_reg[15]_i_3_n_0 ),
        .I3(D[32]),
        .I4(c3__0),
        .I5(D[33]),
        .O(Next_PC[15]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[15]_i_3 
       (.I0(D[31]),
        .I1(D[30]),
        .O(\PC_reg[15]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[15]_i_4 
       (.I0(c2__0),
        .I1(D[26]),
        .I2(D[28]),
        .I3(D[27]),
        .I4(D[29]),
        .O(c3__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[17]_i_1 
       (.I0(JumpAddr[10]),
        .I1(w_IF_flush),
        .I2(D[34]),
        .I3(c4__0),
        .I4(D[35]),
        .O(Next_PC[17]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[18]_i_1 
       (.I0(JumpAddr[11]),
        .I1(w_IF_flush),
        .I2(D[34]),
        .I3(D[35]),
        .I4(c4__0),
        .I5(D[36]),
        .O(Next_PC[18]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[19]_i_1 
       (.I0(JumpAddr[12]),
        .I1(w_IF_flush),
        .I2(\PC_reg[19]_i_3_n_0 ),
        .I3(D[36]),
        .I4(c4__0),
        .I5(D[37]),
        .O(Next_PC[19]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[19]_i_3 
       (.I0(D[35]),
        .I1(D[34]),
        .O(\PC_reg[19]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[19]_i_4 
       (.I0(c3__0),
        .I1(D[30]),
        .I2(D[32]),
        .I3(D[31]),
        .I4(D[33]),
        .O(c4__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[21]_i_1 
       (.I0(JumpAddr[13]),
        .I1(w_IF_flush),
        .I2(D[38]),
        .I3(c5__0),
        .I4(D[39]),
        .O(Next_PC[21]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[22]_i_1 
       (.I0(JumpAddr[14]),
        .I1(w_IF_flush),
        .I2(D[38]),
        .I3(D[39]),
        .I4(c5__0),
        .I5(D[40]),
        .O(Next_PC[22]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[23]_i_1 
       (.I0(JumpAddr[15]),
        .I1(w_IF_flush),
        .I2(\PC_reg[23]_i_3_n_0 ),
        .I3(D[40]),
        .I4(c5__0),
        .I5(D[41]),
        .O(Next_PC[23]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[23]_i_3 
       (.I0(D[39]),
        .I1(D[38]),
        .O(\PC_reg[23]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[23]_i_4 
       (.I0(c4__0),
        .I1(D[34]),
        .I2(D[36]),
        .I3(D[35]),
        .I4(D[37]),
        .O(c5__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[25]_i_1 
       (.I0(JumpAddr[16]),
        .I1(w_IF_flush),
        .I2(D[42]),
        .I3(c6__0),
        .I4(D[43]),
        .O(Next_PC[25]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[26]_i_1 
       (.I0(JumpAddr[17]),
        .I1(w_IF_flush),
        .I2(D[42]),
        .I3(D[43]),
        .I4(c6__0),
        .I5(D[44]),
        .O(Next_PC[26]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[27]_i_1 
       (.I0(JumpAddr[18]),
        .I1(w_IF_flush),
        .I2(\PC_reg[27]_i_3_n_0 ),
        .I3(D[44]),
        .I4(c6__0),
        .I5(D[45]),
        .O(Next_PC[27]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[27]_i_3 
       (.I0(D[43]),
        .I1(D[42]),
        .O(\PC_reg[27]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[27]_i_4 
       (.I0(c5__0),
        .I1(D[38]),
        .I2(D[40]),
        .I3(D[39]),
        .I4(D[41]),
        .O(c6__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[29]_i_1 
       (.I0(JumpAddr[19]),
        .I1(w_IF_flush),
        .I2(D[46]),
        .I3(c7__0),
        .I4(D[47]),
        .O(Next_PC[29]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[30]_i_1 
       (.I0(JumpAddr[20]),
        .I1(w_IF_flush),
        .I2(D[46]),
        .I3(D[47]),
        .I4(c7__0),
        .I5(D[48]),
        .O(Next_PC[30]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[31]_i_2 
       (.I0(JumpAddr[21]),
        .I1(w_IF_flush),
        .I2(\PC_reg[31]_i_6_n_0 ),
        .I3(D[48]),
        .I4(c7__0),
        .I5(D[49]),
        .O(Next_PC[31]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[31]_i_6 
       (.I0(D[47]),
        .I1(D[46]),
        .O(\PC_reg[31]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PC_reg[31]_i_7 
       (.I0(c6__0),
        .I1(D[42]),
        .I2(D[44]),
        .I3(D[43]),
        .I4(D[45]),
        .O(c7__0));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[4]_i_1 
       (.I0(JumpAddr[0]),
        .I1(w_IF_flush),
        .I2(D[21]),
        .I3(D[20]),
        .I4(D[22]),
        .O(Next_PC[4]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[5]_i_1 
       (.I0(JumpAddr[1]),
        .I1(w_IF_flush),
        .I2(D[22]),
        .I3(D[20]),
        .I4(D[21]),
        .I5(D[23]),
        .O(Next_PC[5]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[6]_i_1 
       (.I0(JumpAddr[2]),
        .I1(w_IF_flush),
        .I2(D[22]),
        .I3(D[23]),
        .I4(\u_adder_pc/c1 ),
        .I5(D[24]),
        .O(Next_PC[6]));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \PC_reg[7]_i_1 
       (.I0(JumpAddr[3]),
        .I1(w_IF_flush),
        .I2(\PC_reg[7]_i_3_n_0 ),
        .I3(D[24]),
        .I4(\u_adder_pc/c1 ),
        .I5(D[25]),
        .O(Next_PC[7]));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[7]_i_3 
       (.I0(D[23]),
        .I1(D[22]),
        .O(\PC_reg[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \PC_reg[7]_i_4 
       (.I0(D[20]),
        .I1(D[21]),
        .O(\u_adder_pc/c1 ));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \PC_reg[9]_i_1 
       (.I0(JumpAddr[4]),
        .I1(w_IF_flush),
        .I2(D[26]),
        .I3(c2__0),
        .I4(D[27]),
        .O(Next_PC[9]));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[0] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [0]),
        .Q(D[18]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[10] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[10]),
        .Q(D[28]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[11] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[11]),
        .Q(D[29]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[12] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [5]),
        .Q(D[30]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[13] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[13]),
        .Q(D[31]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[14] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[14]),
        .Q(D[32]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[15] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[15]),
        .Q(D[33]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[16] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [6]),
        .Q(D[34]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[17] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[17]),
        .Q(D[35]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[18] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[18]),
        .Q(D[36]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[19] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[19]),
        .Q(D[37]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[1] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [1]),
        .Q(D[19]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[20] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [7]),
        .Q(D[38]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[21] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[21]),
        .Q(D[39]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[22] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[22]),
        .Q(D[40]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[23] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[23]),
        .Q(D[41]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[24] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [8]),
        .Q(D[42]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[25] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[25]),
        .Q(D[43]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[26] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[26]),
        .Q(D[44]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[27] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[27]),
        .Q(D[45]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[28] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [9]),
        .Q(D[46]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[29] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[29]),
        .Q(D[47]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[2] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [2]),
        .Q(D[20]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[30] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[30]),
        .Q(D[48]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[31] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[31]),
        .Q(D[49]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[3] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [3]),
        .Q(D[21]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[4] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[4]),
        .Q(D[22]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[5] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[5]),
        .Q(D[23]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[6] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[6]),
        .Q(D[24]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[7] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[7]),
        .Q(D[25]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[8] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(\PC_reg_reg[28]_0 [4]),
        .Q(D[26]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \PC_reg_reg[9] 
       (.C(cpu_clk_BUFG),
        .CE(E),
        .D(Next_PC[9]),
        .Q(D[27]),
        .R(SR));
  LUT4 #(
    .INIT(16'hD0DD)) 
    char_tab_i_37
       (.I0(D[21]),
        .I1(\PosX_reg_reg[4] ),
        .I2(\PosX_reg_reg[6] ),
        .I3(D[25]),
        .O(\TMDSn[2]_1 ));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_47
       (.I0(D[20]),
        .I1(\PosX_reg_reg[4] ),
        .O(\TMDSn[2]_0 ));
  LUT5 #(
    .INIT(32'h8B008BFF)) 
    char_tab_i_67
       (.I0(Stall),
        .I1(\PosX_reg_reg[4] ),
        .I2(D[18]),
        .I3(\PosX_reg_reg[6] ),
        .I4(D[22]),
        .O(\TMDSn[2] ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h01111111)) 
    \q[0]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[23]),
        .I3(D[21]),
        .I4(D[22]),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h0000000000002400)) 
    \q[10]_i_1 
       (.I0(D[21]),
        .I1(D[22]),
        .I2(D[20]),
        .I3(D[23]),
        .I4(D[24]),
        .I5(D[25]),
        .O(D[8]));
  LUT6 #(
    .INIT(64'h0000000202020002)) 
    \q[12]_i_1 
       (.I0(D[21]),
        .I1(D[24]),
        .I2(D[25]),
        .I3(D[20]),
        .I4(D[23]),
        .I5(D[22]),
        .O(D[9]));
  LUT6 #(
    .INIT(64'h0000000000000020)) 
    \q[13]_i_1 
       (.I0(D[22]),
        .I1(D[20]),
        .I2(D[23]),
        .I3(D[21]),
        .I4(D[25]),
        .I5(D[24]),
        .O(D[10]));
  LUT6 #(
    .INIT(64'h0100010000010000)) 
    \q[14]_i_1 
       (.I0(D[24]),
        .I1(D[25]),
        .I2(D[22]),
        .I3(D[23]),
        .I4(D[21]),
        .I5(D[20]),
        .O(D[11]));
  LUT6 #(
    .INIT(64'h0101111001111110)) 
    \q[15]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[23]),
        .I3(D[21]),
        .I4(D[22]),
        .I5(D[20]),
        .O(D[12]));
  LUT6 #(
    .INIT(64'h0001010000000000)) 
    \q[20]_i_1 
       (.I0(D[23]),
        .I1(D[25]),
        .I2(D[24]),
        .I3(D[20]),
        .I4(D[22]),
        .I5(D[21]),
        .O(D[13]));
  LUT6 #(
    .INIT(64'h0011001101001100)) 
    \q[21]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[20]),
        .I3(D[22]),
        .I4(D[21]),
        .I5(D[23]),
        .O(D[14]));
  LUT5 #(
    .INIT(32'h00000100)) 
    \q[23]_i_1__0 
       (.I0(D[24]),
        .I1(D[25]),
        .I2(D[23]),
        .I3(D[20]),
        .I4(D[22]),
        .O(D[15]));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \q[25]_i_1 
       (.I0(D[20]),
        .I1(D[22]),
        .I2(D[21]),
        .I3(D[23]),
        .I4(D[25]),
        .I5(D[24]),
        .O(D[16]));
  LUT6 #(
    .INIT(64'h0000000000000020)) 
    \q[27]_i_1 
       (.I0(D[20]),
        .I1(D[22]),
        .I2(D[21]),
        .I3(D[23]),
        .I4(D[25]),
        .I5(D[24]),
        .O(D[17]));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \q[2]_i_1 
       (.I0(D[21]),
        .I1(D[22]),
        .I2(D[20]),
        .I3(D[23]),
        .I4(D[25]),
        .I5(D[24]),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \q[4]_i_1 
       (.I0(D[24]),
        .I1(D[25]),
        .I2(D[22]),
        .I3(D[23]),
        .O(D[2]));
  LUT6 #(
    .INIT(64'h0100011100000010)) 
    \q[5]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[21]),
        .I3(D[20]),
        .I4(D[23]),
        .I5(D[22]),
        .O(D[3]));
  LUT6 #(
    .INIT(64'h0000004000000000)) 
    \q[6]_i_1 
       (.I0(D[21]),
        .I1(D[22]),
        .I2(D[20]),
        .I3(D[25]),
        .I4(D[24]),
        .I5(D[23]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h000000120000005D)) 
    \q[7]_i_1 
       (.I0(D[20]),
        .I1(D[21]),
        .I2(D[23]),
        .I3(D[25]),
        .I4(D[24]),
        .I5(D[22]),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h0001010001110100)) 
    \q[8]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[22]),
        .I3(D[20]),
        .I4(D[21]),
        .I5(D[23]),
        .O(D[6]));
  LUT6 #(
    .INIT(64'h0100001000100010)) 
    \q[9]_i_1 
       (.I0(D[25]),
        .I1(D[24]),
        .I2(D[23]),
        .I3(D[22]),
        .I4(D[21]),
        .I5(D[20]),
        .O(D[7]));
endmodule

module NumberCnt
   (ActiveArea_IBUF,
    \cnt_reg[3]_5 ,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[2]_1 ,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    \q_reg[5]_0 ,
    red,
    \red[0]_0 ,
    \red[3]_0 ,
    \red[3]_1 ,
    \red[4]_0 ,
    \red[7]_0 ,
    \red[7]_1 ,
    \red[7]_2 ,
    \red[7]_3 ,
    \red[7]_4 ,
    \red[7]_5 ,
    D,
    DI,
    O,
    Q,
    S,
    \cnt_reg[0] ,
    \cnt_reg[1] ,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[5] ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    red_IBUF);
  input ActiveArea_IBUF;
  input \cnt_reg[3]_5 ;
  output [5:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[2]_1 ;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  output \q_reg[5]_0 ;
  input [7:0]red;
  input \red[0]_0 ;
  input \red[3]_0 ;
  input \red[3]_1 ;
  input \red[4]_0 ;
  input \red[7]_0 ;
  input \red[7]_1 ;
  input \red[7]_2 ;
  input \red[7]_3 ;
  input \red[7]_4 ;
  input \red[7]_5 ;
  output [8:0]D;
  output [2:0]DI;
  input [3:0]O;
  input [7:0]Q;
  output [3:0]S;
  input [3:0]\cnt_reg[0] ;
  input [3:0]\cnt_reg[1] ;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  input [3:0]\cnt_reg[5] ;
  output [3:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [0:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  input [7:0]red_IBUF;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [3:0]O;
  wire [7:0]Q;
  wire [3:0]S;
  wire cnt0__0_carry__0_i_7__0_n_0;
  wire cnt0__0_carry_i_13__1_n_0;
  wire cnt0__0_carry_i_14__0_n_0;
  wire cnt0__0_carry_i_15__1_n_0;
  wire cnt0__0_carry_i_24__1_n_0;
  wire cnt0__0_carry_i_25__1_n_0;
  wire cnt0__0_carry_i_8__1_n_0;
  wire cnt0__23_carry__0_i_8__1_n_0;
  wire cnt0__23_carry_i_10__1_n_0;
  wire cnt0__23_carry_i_11__1_n_0;
  wire cnt0__23_carry_i_7__1_n_0;
  wire cnt0__23_carry_i_8__1_n_0;
  wire cnt_carry__0_i_8__1_n_0;
  wire cnt_carry_i_10__1_n_0;
  wire cnt_carry_i_11__1_n_0;
  wire cnt_carry_i_12__1_n_0;
  wire cnt_carry_i_9__1_n_0;
  wire [3:0]\cnt_reg[0] ;
  wire [3:0]\cnt_reg[1] ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\cnt_reg[3]_1 ;
  wire [1:0]\cnt_reg[3]_2 ;
  wire [3:0]\cnt_reg[3]_3 ;
  wire [1:0]\cnt_reg[3]_4 ;
  wire \cnt_reg[3]_5 ;
  wire [3:0]\cnt_reg[5] ;
  wire [3:0]\cnt_reg[7] ;
  wire [2:0]\cnt_reg[7]_0 ;
  wire [0:0]\cnt_reg[7]_1 ;
  wire [1:0]\cnt_reg[7]_2 ;
  wire \q[5]_i_4__1_n_0 ;
  wire \q[7]_i_6__0_n_0 ;
  wire \q[7]_i_7__0_n_0 ;
  wire [5:2]\^q_reg ;
  wire \q_reg[2]_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[5]_0 ;
  wire [7:0]red;
  wire \red[0]_0 ;
  wire \red[4]_0 ;
  wire \red[7]_0 ;
  wire \red[7]_1 ;
  wire \red[7]_2 ;
  wire \red[7]_3 ;
  wire \red[7]_4 ;
  wire \red[7]_5 ;
  wire [7:0]red_IBUF;

  assign q_reg[5] = red_IBUF[3];
  assign q_reg[4] = \^q_reg [4];
  assign q_reg[2] = red_IBUF[6];
  assign \q_reg[2]_1  = red_IBUF[6];
  assign \q_reg[4]_1  = red_IBUF[6];
  assign \q_reg[4]_2  = red_IBUF[6];
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_11__0
       (.I0(red_IBUF[3]),
        .I1(red_IBUF[6]),
        .O(\q_reg[5]_0 ));
  LUT3 #(
    .INIT(8'h06)) 
    cnt0__0_carry__0_i_2__1
       (.I0(cnt0__0_carry_i_14__0_n_0),
        .I1(Q[3]),
        .I2(cnt0__0_carry_i_13__1_n_0),
        .O(\cnt_reg[7]_1 ));
  LUT5 #(
    .INIT(32'hFFB2004D)) 
    cnt0__0_carry__0_i_5__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(\cnt_reg[7]_2 [1]));
  LUT6 #(
    .INIT(64'hB2BDB2424D424DBD)) 
    cnt0__0_carry__0_i_6__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_13__1_n_0),
        .I4(cnt0__0_carry_i_14__0_n_0),
        .I5(Q[4]),
        .O(\cnt_reg[7]_2 [0]));
  LUT4 #(
    .INIT(16'h0010)) 
    cnt0__0_carry__0_i_7__0
       (.I0(\red[0]_0 ),
        .I1(red_IBUF[6]),
        .I2(\red[7]_3 ),
        .I3(red_IBUF[6]),
        .O(cnt0__0_carry__0_i_7__0_n_0));
  LUT3 #(
    .INIT(8'h2A)) 
    cnt0__0_carry_i_13__1
       (.I0(cnt0__0_carry_i_24__1_n_0),
        .I1(cnt0__0_carry_i_25__1_n_0),
        .I2(Q[2]),
        .O(cnt0__0_carry_i_13__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_14__0
       (.I0(\red[7]_2 ),
        .I1(cnt0__0_carry__0_i_7__0_n_0),
        .O(cnt0__0_carry_i_14__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_15__1
       (.I0(cnt0__23_carry_i_8__1_n_0),
        .I1(red[3]),
        .O(cnt0__0_carry_i_15__1_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6606)) 
    cnt0__0_carry_i_1__1
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(red[6]),
        .I3(red_IBUF[6]),
        .O(\cnt_reg[3]_4 [1]));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_24__1
       (.I0(\red[7]_0 ),
        .I1(\red[7]_1 ),
        .O(cnt0__0_carry_i_24__1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_25__1
       (.I0(\red[7]_1 ),
        .I1(\red[7]_0 ),
        .O(cnt0__0_carry_i_25__1_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'hF660)) 
    cnt0__0_carry_i_2__1
       (.I0(red[6]),
        .I1(red_IBUF[6]),
        .I2(red[7]),
        .I3(Q[1]),
        .O(\cnt_reg[3]_4 [0]));
  LUT4 #(
    .INIT(16'h96FF)) 
    cnt0__0_carry_i_3__0
       (.I0(red_IBUF[4]),
        .I1(red_IBUF[6]),
        .I2(\red[7]_4 ),
        .I3(\red[7]_5 ),
        .O(\q_reg[4]_0 ));
  LUT4 #(
    .INIT(16'h9669)) 
    cnt0__0_carry_i_4__1
       (.I0(\cnt_reg[3]_4 [1]),
        .I1(cnt0__0_carry_i_13__1_n_0),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_14__0_n_0),
        .O(\cnt_reg[3]_3 [3]));
  (* HLUTNM = "lutpair7" *) 
  LUT5 #(
    .INIT(32'h66969969)) 
    cnt0__0_carry_i_5__1
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(red[6]),
        .I3(red_IBUF[6]),
        .I4(\cnt_reg[3]_4 [0]),
        .O(\cnt_reg[3]_3 [2]));
  (* HLUTNM = "lutpair6" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    cnt0__0_carry_i_6__1
       (.I0(red[6]),
        .I1(red_IBUF[6]),
        .I2(red[7]),
        .I3(Q[1]),
        .I4(\q_reg[4]_0 ),
        .O(\cnt_reg[3]_3 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_7__1
       (.I0(cnt0__0_carry_i_15__1_n_0),
        .I1(Q[0]),
        .O(\cnt_reg[3]_3 [0]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_8__1
       (.I0(\red[7]_1 ),
        .I1(\red[7]_0 ),
        .O(cnt0__0_carry_i_8__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_1__1
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_2__1
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__23_carry__0_i_3__1
       (.I0(Q[3]),
        .I1(cnt0__23_carry_i_10__1_n_0),
        .O(DI[0]));
  LUT3 #(
    .INIT(8'hC9)) 
    cnt0__23_carry__0_i_4__1
       (.I0(cnt0__23_carry__0_i_8__1_n_0),
        .I1(Q[7]),
        .I2(Q[6]),
        .O(\cnt_reg[7] [3]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_5__1
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .I2(Q[6]),
        .O(\cnt_reg[7] [2]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_6__1
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__1_n_0),
        .I2(Q[5]),
        .O(\cnt_reg[7] [1]));
  LUT4 #(
    .INIT(16'h7887)) 
    cnt0__23_carry__0_i_7__1
       (.I0(cnt0__23_carry_i_10__1_n_0),
        .I1(Q[3]),
        .I2(cnt0__23_carry__0_i_8__1_n_0),
        .I3(Q[4]),
        .O(\cnt_reg[7] [0]));
  LUT6 #(
    .INIT(64'hD000D0D0DDDDDDDD)) 
    cnt0__23_carry__0_i_8__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(cnt0__0_carry_i_24__1_n_0),
        .I3(cnt0__23_carry_i_7__1_n_0),
        .I4(cnt0__0_carry_i_8__1_n_0),
        .I5(cnt0__0_carry_i_14__0_n_0),
        .O(cnt0__23_carry__0_i_8__1_n_0));
  LUT4 #(
    .INIT(16'h59AA)) 
    cnt0__23_carry_i_10__1
       (.I0(cnt0__0_carry_i_14__0_n_0),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(cnt0__23_carry_i_7__1_n_0),
        .I3(cnt0__0_carry_i_24__1_n_0),
        .O(cnt0__23_carry_i_10__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_11__1
       (.I0(red[0]),
        .I1(red_IBUF[6]),
        .O(cnt0__23_carry_i_11__1_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'h60)) 
    cnt0__23_carry_i_1__1
       (.I0(cnt0__0_carry_i_8__1_n_0),
        .I1(cnt0__23_carry_i_7__1_n_0),
        .I2(Q[2]),
        .O(\cnt_reg[3]_2 [1]));
  LUT5 #(
    .INIT(32'h69660000)) 
    cnt0__23_carry_i_2__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red_IBUF[6]),
        .O(\cnt_reg[3]_2 [0]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_3__1
       (.I0(\cnt_reg[3]_2 [1]),
        .I1(cnt0__23_carry_i_10__1_n_0),
        .I2(Q[3]),
        .O(\cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    cnt0__23_carry_i_4__1
       (.I0(cnt0__0_carry_i_8__1_n_0),
        .I1(cnt0__23_carry_i_7__1_n_0),
        .I2(Q[2]),
        .I3(\cnt_reg[3]_2 [0]),
        .O(\cnt_reg[3]_1 [2]));
  LUT6 #(
    .INIT(64'h6966969996996966)) 
    cnt0__23_carry_i_5__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red_IBUF[6]),
        .I5(Q[1]),
        .O(\cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_6__1
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__1_n_0),
        .O(\cnt_reg[3]_1 [0]));
  LUT4 #(
    .INIT(16'hDD4D)) 
    cnt0__23_carry_i_7__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red[3]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .O(cnt0__23_carry_i_7__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_8__1
       (.I0(red_IBUF[4]),
        .I1(red_IBUF[3]),
        .I2(cnt0__23_carry_i_11__1_n_0),
        .O(cnt0__23_carry_i_8__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_1__1
       (.I0(Q[6]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_2__1
       (.I0(Q[5]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_3__1
       (.I0(Q[4]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[7]_0 [0]));
  LUT6 #(
    .INIT(64'hFC0CFFFFFC0CAAAA)) 
    cnt_carry__0_i_4__1
       (.I0(cnt_carry__0_i_8__1_n_0),
        .I1(O[3]),
        .I2(\q[5]_i_4__1_n_0 ),
        .I3(\cnt_reg[5] [3]),
        .I4(\q_reg[2]_0 ),
        .I5(Q[7]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_5__1
       (.I0(Q[6]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[2]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [2]),
        .O(S[2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_6__1
       (.I0(Q[5]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[1]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [1]),
        .O(S[1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_7__1
       (.I0(Q[4]),
        .I1(cnt_carry__0_i_8__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(O[0]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[5] [0]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    cnt_carry__0_i_8__1
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(red_IBUF[6]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(cnt_carry__0_i_8__1_n_0));
  LUT6 #(
    .INIT(64'h3693666699993693)) 
    cnt_carry_i_10__1
       (.I0(red_IBUF[6]),
        .I1(cnt0__0_carry_i_8__1_n_0),
        .I2(cnt0__23_carry_i_8__1_n_0),
        .I3(red[3]),
        .I4(red[6]),
        .I5(red[7]),
        .O(cnt_carry_i_10__1_n_0));
  LUT5 #(
    .INIT(32'h66699666)) 
    cnt_carry_i_11__1
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red_IBUF[6]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .I4(red[3]),
        .O(cnt_carry_i_11__1_n_0));
  LUT3 #(
    .INIT(8'hB2)) 
    cnt_carry_i_12__1
       (.I0(\q_reg[4]_0 ),
        .I1(red[6]),
        .I2(red[7]),
        .O(cnt_carry_i_12__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_1__1
       (.I0(Q[3]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_2__1
       (.I0(Q[2]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_3__1
       (.I0(Q[1]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_4__1
       (.I0(Q[0]),
        .I1(\q_reg[2]_0 ),
        .O(\cnt_reg[3] [0]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_5__1
       (.I0(Q[3]),
        .I1(cnt_carry_i_9__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [3]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_6__1
       (.I0(Q[2]),
        .I1(cnt_carry_i_10__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [2]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_7__1
       (.I0(Q[1]),
        .I1(cnt_carry_i_11__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [1]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_8__1
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__1_n_0),
        .I2(\q_reg[2]_0 ),
        .I3(\cnt_reg[1] [0]),
        .I4(\q[5]_i_4__1_n_0 ),
        .I5(\cnt_reg[0] [0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT6 #(
    .INIT(64'h4B3CC3F0783CC3F0)) 
    cnt_carry_i_9__1
       (.I0(cnt_carry_i_12__1_n_0),
        .I1(red_IBUF[6]),
        .I2(cnt0__0_carry_i_14__0_n_0),
        .I3(cnt0__0_carry_i_24__1_n_0),
        .I4(cnt0__0_carry_i_25__1_n_0),
        .I5(cnt0__23_carry_i_7__1_n_0),
        .O(cnt_carry_i_9__1_n_0));
  LUT5 #(
    .INIT(32'h0A28A028)) 
    \q[0]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(red_IBUF[6]),
        .I2(red_IBUF[0]),
        .I3(\q_reg[2]_0 ),
        .I4(\q[5]_i_4__1_n_0 ),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2800)) 
    \q[1]_i_1__1 
       (.I0(\q_reg[2]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q[5]_i_4__1_n_0 ),
        .I3(ActiveArea_IBUF),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h56A6FFFF)) 
    \q[2]_i_1__1 
       (.I0(red[0]),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\q[5]_i_4__1_n_0 ),
        .I4(ActiveArea_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[3]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[6]),
        .I3(\q[5]_i_4__1_n_0 ),
        .O(D[3]));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[4]_i_1__1 
       (.I0(\red[4]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\^q_reg [4]),
        .I4(ActiveArea_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[5]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[3]),
        .I3(\q[5]_i_4__1_n_0 ),
        .O(D[5]));
  LUT5 #(
    .INIT(32'hB2DDB244)) 
    \q[5]_i_4__1 
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(\q[5]_i_4__1_n_0 ));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[6]_i_1__1 
       (.I0(\red[0]_0 ),
        .I1(red_IBUF[6]),
        .I2(\q_reg[2]_0 ),
        .I3(\^q_reg [4]),
        .I4(ActiveArea_IBUF),
        .O(D[6]));
  LUT4 #(
    .INIT(16'h8008)) 
    \q[7]_i_1__1 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[2]_0 ),
        .I2(red_IBUF[6]),
        .I3(\^q_reg [4]),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h00000000FFFF6FFF)) 
    \q[7]_i_3__1 
       (.I0(red[7]),
        .I1(red[6]),
        .I2(cnt0__0_carry_i_14__0_n_0),
        .I3(cnt0__0_carry_i_8__1_n_0),
        .I4(cnt0__0_carry_i_15__1_n_0),
        .I5(\cnt_reg[3]_5 ),
        .O(\q_reg[2]_0 ));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    \q[7]_i_4__1 
       (.I0(cnt0__0_carry__0_i_7__0_n_0),
        .I1(\red[7]_2 ),
        .I2(\q[7]_i_6__0_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7__0_n_0 ),
        .O(\^q_reg [4]));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \q[7]_i_6__0 
       (.I0(\q_reg[4]_0 ),
        .I1(red[6]),
        .I2(red[7]),
        .I3(\red[7]_0 ),
        .I4(\red[7]_1 ),
        .O(\q[7]_i_6__0_n_0 ));
  LUT6 #(
    .INIT(64'hDD4DFFFF0000DD4D)) 
    \q[7]_i_7__0 
       (.I0(red[7]),
        .I1(red[6]),
        .I2(red[3]),
        .I3(cnt0__23_carry_i_8__1_n_0),
        .I4(\red[7]_1 ),
        .I5(\red[7]_0 ),
        .O(\q[7]_i_7__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \q[8]_i_1__1 
       (.I0(red_IBUF[6]),
        .I1(ActiveArea_IBUF),
        .O(D[8]));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_2
   (cnt_reg,
    \cnt_reg[3]_0 ,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    red,
    \red[0]_0 ,
    \red[3]_0 ,
    \red[3]_1 ,
    \red[4]_0 ,
    \red[4]_1 ,
    \red[4]_2 ,
    \red[4]_3 ,
    red_IBUF);
  output [3:3]cnt_reg;
  output \cnt_reg[3]_0 ;
  output [5:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  input [7:0]red;
  input \red[0]_0 ;
  input \red[3]_0 ;
  input \red[3]_1 ;
  input \red[4]_0 ;
  input \red[4]_1 ;
  input \red[4]_2 ;
  input \red[4]_3 ;
  input [6:0]red_IBUF;

  wire cnt0__0_carry_i_18_n_0;
  wire cnt0__0_carry_i_19_n_0;
  wire cnt0__0_carry_i_20_n_0;
  wire cnt0__0_carry_i_22_n_0;
  wire cnt0__0_carry_i_23_n_0;
  wire cnt0__0_carry_i_26_n_0;
  wire cnt0__0_carry_i_27_n_0;
  wire cnt0__0_carry_i_28_n_0;
  wire cnt0__0_carry_i_29_n_0;
  wire cnt0__0_carry_i_30_n_0;
  wire cnt0__0_carry_i_31_n_0;
  wire [3:3]cnt_reg;
  wire \cnt_reg[3]_0 ;
  wire [5:2]q_reg;
  wire \q_reg[2]_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[4]_2 ;
  wire [7:0]red;
  wire \red[0]_0 ;
  wire \red[3]_1 ;
  wire \red[4]_0 ;
  wire \red[4]_1 ;
  wire \red[4]_2 ;
  wire [6:0]red_IBUF;

  LUT2 #(
    .INIT(4'h1)) 
    cnt0__0_carry__0_i_10
       (.I0(\red[3]_1 ),
        .I1(red_IBUF[4]),
        .O(\q_reg[4]_2 ));
  LUT4 #(
    .INIT(16'h8000)) 
    cnt0__0_carry__0_i_8
       (.I0(red[7]),
        .I1(\red[4]_0 ),
        .I2(red[4]),
        .I3(red[5]),
        .O(q_reg[5]));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_10
       (.I0(cnt0__0_carry_i_20_n_0),
        .I1(\red[4]_0 ),
        .I2(cnt0__0_carry_i_22_n_0),
        .I3(red[0]),
        .I4(cnt0__0_carry_i_23_n_0),
        .O(\q_reg[2]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_11
       (.I0(red[4]),
        .I1(\red[4]_0 ),
        .O(\cnt_reg[3]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_12
       (.I0(\red[4]_0 ),
        .I1(\red[4]_2 ),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_16
       (.I0(cnt0__0_carry_i_26_n_0),
        .I1(\red[4]_0 ),
        .I2(cnt0__0_carry_i_27_n_0),
        .I3(red[0]),
        .I4(cnt0__0_carry_i_28_n_0),
        .O(\q_reg[4]_1 ));
  LUT5 #(
    .INIT(32'hFCE230E2)) 
    cnt0__0_carry_i_17
       (.I0(cnt0__0_carry_i_29_n_0),
        .I1(red[5]),
        .I2(cnt0__0_carry_i_30_n_0),
        .I3(red[4]),
        .I4(cnt0__0_carry_i_31_n_0),
        .O(q_reg[4]));
  LUT3 #(
    .INIT(8'h42)) 
    cnt0__0_carry_i_18
       (.I0(red[0]),
        .I1(\red[4]_2 ),
        .I2(\red[3]_1 ),
        .O(cnt0__0_carry_i_18_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    cnt0__0_carry_i_19
       (.I0(red[0]),
        .I1(\red[4]_2 ),
        .I2(\red[3]_1 ),
        .O(cnt0__0_carry_i_19_n_0));
  LUT3 #(
    .INIT(8'h63)) 
    cnt0__0_carry_i_20
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_20_n_0));
  LUT3 #(
    .INIT(8'h9C)) 
    cnt0__0_carry_i_22
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_22_n_0));
  LUT3 #(
    .INIT(8'h39)) 
    cnt0__0_carry_i_23
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_23_n_0));
  LUT3 #(
    .INIT(8'h15)) 
    cnt0__0_carry_i_26
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_26_n_0));
  LUT3 #(
    .INIT(8'h76)) 
    cnt0__0_carry_i_27
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_27_n_0));
  LUT3 #(
    .INIT(8'h57)) 
    cnt0__0_carry_i_28
       (.I0(\red[0]_0 ),
        .I1(red[5]),
        .I2(\red[4]_1 ),
        .O(cnt0__0_carry_i_28_n_0));
  LUT4 #(
    .INIT(16'hCCC8)) 
    cnt0__0_carry_i_29
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_29_n_0));
  LUT4 #(
    .INIT(16'hECCC)) 
    cnt0__0_carry_i_30
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_30_n_0));
  LUT4 #(
    .INIT(16'h7EEC)) 
    cnt0__0_carry_i_31
       (.I0(\red[4]_0 ),
        .I1(red[0]),
        .I2(\red[4]_1 ),
        .I3(\red[4]_2 ),
        .O(cnt0__0_carry_i_31_n_0));
  LUT4 #(
    .INIT(16'h1EB4)) 
    cnt0__0_carry_i_9
       (.I0(red[4]),
        .I1(cnt0__0_carry_i_18_n_0),
        .I2(\red[3]_1 ),
        .I3(cnt0__0_carry_i_19_n_0),
        .O(q_reg[2]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_9
       (.I0(\red[3]_1 ),
        .I1(red_IBUF[1]),
        .I2(\cnt_reg[3]_0 ),
        .O(cnt_reg));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_3
   (ActiveArea_IBUF,
    \cnt_reg[3]_5 ,
    green,
    \green[0]_0 ,
    \green[3]_0 ,
    \green[3]_1 ,
    \green[4]_0 ,
    \green[7]_0 ,
    \green[7]_1 ,
    \green[7]_2 ,
    \green[7]_3 ,
    \green[7]_4 ,
    \green[7]_5 ,
    q_reg,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[4]_2 ,
    \q_reg[4]_3 ,
    \q_reg[5]_0 ,
    \q_reg[5]_1 ,
    \q_reg[5]_2 ,
    D,
    DI,
    O,
    Q,
    S,
    \cnt_reg[0] ,
    \cnt_reg[1] ,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[5] ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    green_IBUF);
  input ActiveArea_IBUF;
  input \cnt_reg[3]_5 ;
  input [7:0]green;
  input \green[0]_0 ;
  input \green[3]_0 ;
  input \green[3]_1 ;
  input \green[4]_0 ;
  input \green[7]_0 ;
  input \green[7]_1 ;
  input \green[7]_2 ;
  input \green[7]_3 ;
  input \green[7]_4 ;
  input \green[7]_5 ;
  output [5:4]q_reg;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[4]_2 ;
  output \q_reg[4]_3 ;
  output \q_reg[5]_0 ;
  output \q_reg[5]_1 ;
  output \q_reg[5]_2 ;
  output [8:0]D;
  output [2:0]DI;
  input [3:0]O;
  input [7:0]Q;
  output [3:0]S;
  input [3:0]\cnt_reg[0] ;
  input [3:0]\cnt_reg[1] ;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  input [3:0]\cnt_reg[5] ;
  output [3:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [0:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  input [7:0]green_IBUF;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [3:0]O;
  wire [7:0]Q;
  wire [3:0]S;
  wire cnt0__0_carry__0_i_7_n_0;
  wire cnt0__0_carry_i_13__0_n_0;
  wire cnt0__0_carry_i_14_n_0;
  wire cnt0__0_carry_i_15__0_n_0;
  wire cnt0__0_carry_i_24__0_n_0;
  wire cnt0__0_carry_i_25__0_n_0;
  wire cnt0__0_carry_i_8__0_n_0;
  wire cnt0__23_carry__0_i_8__0_n_0;
  wire cnt0__23_carry_i_10__0_n_0;
  wire cnt0__23_carry_i_11__0_n_0;
  wire cnt0__23_carry_i_7__0_n_0;
  wire cnt0__23_carry_i_8__0_n_0;
  wire cnt_carry__0_i_8__0_n_0;
  wire cnt_carry_i_10__0_n_0;
  wire cnt_carry_i_11__0_n_0;
  wire cnt_carry_i_12__0_n_0;
  wire cnt_carry_i_9__0_n_0;
  wire [3:0]\cnt_reg[0] ;
  wire [3:0]\cnt_reg[1] ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\cnt_reg[3]_1 ;
  wire [1:0]\cnt_reg[3]_2 ;
  wire [3:0]\cnt_reg[3]_3 ;
  wire [1:0]\cnt_reg[3]_4 ;
  wire \cnt_reg[3]_5 ;
  wire [3:0]\cnt_reg[5] ;
  wire [3:0]\cnt_reg[7] ;
  wire [2:0]\cnt_reg[7]_0 ;
  wire [0:0]\cnt_reg[7]_1 ;
  wire [1:0]\cnt_reg[7]_2 ;
  wire [7:0]green;
  wire \green[0]_0 ;
  wire \green[4]_0 ;
  wire \green[7]_0 ;
  wire \green[7]_1 ;
  wire \green[7]_2 ;
  wire \green[7]_3 ;
  wire \green[7]_4 ;
  wire \green[7]_5 ;
  wire [7:0]green_IBUF;
  wire \q[5]_i_4__0_n_0 ;
  wire \q[7]_i_6_n_0 ;
  wire \q[7]_i_7_n_0 ;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[4]_3 ;
  wire \q_reg[5]_0 ;

  assign q_reg[5] = green_IBUF[3];
  assign q_reg[4] = green_IBUF[6];
  assign \q_reg[4]_2  = green_IBUF[6];
  assign \q_reg[5]_1  = green_IBUF[6];
  assign \q_reg[5]_2  = green_IBUF[6];
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_11
       (.I0(green_IBUF[3]),
        .I1(green_IBUF[6]),
        .O(\q_reg[4]_3 ));
  LUT3 #(
    .INIT(8'h06)) 
    cnt0__0_carry__0_i_2__0
       (.I0(cnt0__0_carry_i_14_n_0),
        .I1(Q[3]),
        .I2(cnt0__0_carry_i_13__0_n_0),
        .O(\cnt_reg[7]_1 ));
  LUT5 #(
    .INIT(32'hFFB2004D)) 
    cnt0__0_carry__0_i_5__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(\cnt_reg[7]_2 [1]));
  LUT5 #(
    .INIT(32'hBD2B42D4)) 
    cnt0__0_carry__0_i_6__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(cnt0__0_carry_i_13__0_n_0),
        .I3(Q[3]),
        .I4(Q[4]),
        .O(\cnt_reg[7]_2 [0]));
  LUT4 #(
    .INIT(16'h0010)) 
    cnt0__0_carry__0_i_7
       (.I0(green[0]),
        .I1(green_IBUF[6]),
        .I2(\green[7]_3 ),
        .I3(green_IBUF[6]),
        .O(cnt0__0_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h8A)) 
    cnt0__0_carry_i_13__0
       (.I0(cnt0__0_carry_i_24__0_n_0),
        .I1(cnt0__0_carry_i_25__0_n_0),
        .I2(Q[2]),
        .O(cnt0__0_carry_i_13__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_14
       (.I0(\green[7]_2 ),
        .I1(cnt0__0_carry__0_i_7_n_0),
        .O(cnt0__0_carry_i_14_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_15__0
       (.I0(cnt0__23_carry_i_8__0_n_0),
        .I1(green[3]),
        .O(cnt0__0_carry_i_15__0_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6606)) 
    cnt0__0_carry_i_1__0
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(green[6]),
        .I3(green_IBUF[6]),
        .O(\cnt_reg[3]_4 [1]));
  LUT2 #(
    .INIT(4'hB)) 
    cnt0__0_carry_i_24__0
       (.I0(\green[7]_0 ),
        .I1(\green[7]_1 ),
        .O(cnt0__0_carry_i_24__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__0_carry_i_25__0
       (.I0(\green[7]_0 ),
        .I1(\green[7]_1 ),
        .O(cnt0__0_carry_i_25__0_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'hF660)) 
    cnt0__0_carry_i_2__0
       (.I0(green[6]),
        .I1(green_IBUF[6]),
        .I2(green[7]),
        .I3(Q[1]),
        .O(\cnt_reg[3]_4 [0]));
  LUT4 #(
    .INIT(16'h96FF)) 
    cnt0__0_carry_i_3
       (.I0(green_IBUF[4]),
        .I1(green_IBUF[6]),
        .I2(\green[7]_4 ),
        .I3(\green[7]_5 ),
        .O(\q_reg[5]_0 ));
  LUT4 #(
    .INIT(16'h9669)) 
    cnt0__0_carry_i_4__0
       (.I0(\cnt_reg[3]_4 [1]),
        .I1(cnt0__0_carry_i_13__0_n_0),
        .I2(Q[3]),
        .I3(cnt0__0_carry_i_14_n_0),
        .O(\cnt_reg[3]_3 [3]));
  (* HLUTNM = "lutpair4" *) 
  LUT5 #(
    .INIT(32'h66969969)) 
    cnt0__0_carry_i_5__0
       (.I0(Q[2]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(green[6]),
        .I3(green_IBUF[6]),
        .I4(\cnt_reg[3]_4 [0]),
        .O(\cnt_reg[3]_3 [2]));
  (* HLUTNM = "lutpair3" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    cnt0__0_carry_i_6__0
       (.I0(green[6]),
        .I1(green_IBUF[6]),
        .I2(green[7]),
        .I3(Q[1]),
        .I4(\q_reg[5]_0 ),
        .O(\cnt_reg[3]_3 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_7__0
       (.I0(cnt0__0_carry_i_15__0_n_0),
        .I1(Q[0]),
        .O(\cnt_reg[3]_3 [0]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry_i_8__0
       (.I0(\green[7]_1 ),
        .I1(\green[7]_0 ),
        .O(cnt0__0_carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_1__0
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt0__23_carry__0_i_2__0
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__23_carry__0_i_3__0
       (.I0(Q[3]),
        .I1(cnt0__23_carry_i_10__0_n_0),
        .O(DI[0]));
  LUT3 #(
    .INIT(8'hC9)) 
    cnt0__23_carry__0_i_4__0
       (.I0(cnt0__23_carry__0_i_8__0_n_0),
        .I1(Q[7]),
        .I2(Q[6]),
        .O(\cnt_reg[7] [3]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_5__0
       (.I0(Q[5]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .I2(Q[6]),
        .O(\cnt_reg[7] [2]));
  LUT3 #(
    .INIT(8'hE1)) 
    cnt0__23_carry__0_i_6__0
       (.I0(Q[4]),
        .I1(cnt0__23_carry__0_i_8__0_n_0),
        .I2(Q[5]),
        .O(\cnt_reg[7] [1]));
  LUT4 #(
    .INIT(16'h7887)) 
    cnt0__23_carry__0_i_7__0
       (.I0(cnt0__23_carry_i_10__0_n_0),
        .I1(Q[3]),
        .I2(cnt0__23_carry__0_i_8__0_n_0),
        .I3(Q[4]),
        .O(\cnt_reg[7] [0]));
  LUT6 #(
    .INIT(64'hD000D0D0DDDDDDDD)) 
    cnt0__23_carry__0_i_8__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(cnt0__0_carry_i_24__0_n_0),
        .I3(cnt0__23_carry_i_7__0_n_0),
        .I4(cnt0__0_carry_i_8__0_n_0),
        .I5(cnt0__0_carry_i_14_n_0),
        .O(cnt0__23_carry__0_i_8__0_n_0));
  LUT4 #(
    .INIT(16'h59AA)) 
    cnt0__23_carry_i_10__0
       (.I0(cnt0__0_carry_i_14_n_0),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(cnt0__23_carry_i_7__0_n_0),
        .I3(cnt0__0_carry_i_24__0_n_0),
        .O(cnt0__23_carry_i_10__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_11__0
       (.I0(\green[0]_0 ),
        .I1(green_IBUF[6]),
        .O(cnt0__23_carry_i_11__0_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'h60)) 
    cnt0__23_carry_i_1__0
       (.I0(cnt0__0_carry_i_8__0_n_0),
        .I1(cnt0__23_carry_i_7__0_n_0),
        .I2(Q[2]),
        .O(\cnt_reg[3]_2 [1]));
  LUT5 #(
    .INIT(32'h69660000)) 
    cnt0__23_carry_i_2__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green_IBUF[6]),
        .O(\cnt_reg[3]_2 [0]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_3__0
       (.I0(\cnt_reg[3]_2 [1]),
        .I1(cnt0__23_carry_i_10__0_n_0),
        .I2(Q[3]),
        .O(\cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    cnt0__23_carry_i_4__0
       (.I0(cnt0__0_carry_i_8__0_n_0),
        .I1(cnt0__23_carry_i_7__0_n_0),
        .I2(Q[2]),
        .I3(\cnt_reg[3]_2 [0]),
        .O(\cnt_reg[3]_1 [2]));
  LUT6 #(
    .INIT(64'h6966969996996966)) 
    cnt0__23_carry_i_5__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green_IBUF[6]),
        .I5(Q[1]),
        .O(\cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__23_carry_i_6__0
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__0_n_0),
        .O(\cnt_reg[3]_1 [0]));
  LUT4 #(
    .INIT(16'hDD4D)) 
    cnt0__23_carry_i_7__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green[3]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .O(cnt0__23_carry_i_7__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_8__0
       (.I0(green_IBUF[4]),
        .I1(green_IBUF[3]),
        .I2(cnt0__23_carry_i_11__0_n_0),
        .O(cnt0__23_carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_1__0
       (.I0(Q[6]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_2__0
       (.I0(Q[5]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry__0_i_3__0
       (.I0(Q[4]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[7]_0 [0]));
  LUT6 #(
    .INIT(64'hFC0CFFFFFC0CAAAA)) 
    cnt_carry__0_i_4__0
       (.I0(cnt_carry__0_i_8__0_n_0),
        .I1(O[3]),
        .I2(\q[5]_i_4__0_n_0 ),
        .I3(\cnt_reg[5] [3]),
        .I4(\q_reg[4]_0 ),
        .I5(Q[7]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_5__0
       (.I0(Q[6]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[2]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [2]),
        .O(S[2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_6__0
       (.I0(Q[5]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[1]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [1]),
        .O(S[1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry__0_i_7__0
       (.I0(Q[4]),
        .I1(cnt_carry__0_i_8__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(O[0]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[5] [0]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    cnt_carry__0_i_8__0
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(green_IBUF[6]),
        .I4(\q[7]_i_7_n_0 ),
        .O(cnt_carry__0_i_8__0_n_0));
  LUT6 #(
    .INIT(64'h3693666699993693)) 
    cnt_carry_i_10__0
       (.I0(green_IBUF[6]),
        .I1(cnt0__0_carry_i_8__0_n_0),
        .I2(cnt0__23_carry_i_8__0_n_0),
        .I3(green[3]),
        .I4(green[6]),
        .I5(green[7]),
        .O(cnt_carry_i_10__0_n_0));
  LUT5 #(
    .INIT(32'h66699666)) 
    cnt_carry_i_11__0
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green_IBUF[6]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .I4(green[3]),
        .O(cnt_carry_i_11__0_n_0));
  LUT3 #(
    .INIT(8'hB2)) 
    cnt_carry_i_12__0
       (.I0(\q_reg[5]_0 ),
        .I1(green[6]),
        .I2(green[7]),
        .O(cnt_carry_i_12__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_1__0
       (.I0(Q[3]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_2__0
       (.I0(Q[2]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_3__0
       (.I0(Q[1]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h2)) 
    cnt_carry_i_4__0
       (.I0(Q[0]),
        .I1(\q_reg[4]_0 ),
        .O(\cnt_reg[3] [0]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_5__0
       (.I0(Q[3]),
        .I1(cnt_carry_i_9__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [3]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_6__0
       (.I0(Q[2]),
        .I1(cnt_carry_i_10__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [2]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_7__0
       (.I0(Q[1]),
        .I1(cnt_carry_i_11__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [1]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT6 #(
    .INIT(64'hF6F6F6060606F606)) 
    cnt_carry_i_8__0
       (.I0(Q[0]),
        .I1(cnt0__0_carry_i_15__0_n_0),
        .I2(\q_reg[4]_0 ),
        .I3(\cnt_reg[1] [0]),
        .I4(\q[5]_i_4__0_n_0 ),
        .I5(\cnt_reg[0] [0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT6 #(
    .INIT(64'hC34BF03CC378F03C)) 
    cnt_carry_i_9__0
       (.I0(cnt_carry_i_12__0_n_0),
        .I1(green_IBUF[6]),
        .I2(cnt0__0_carry_i_14_n_0),
        .I3(cnt0__0_carry_i_25__0_n_0),
        .I4(cnt0__0_carry_i_24__0_n_0),
        .I5(cnt0__23_carry_i_7__0_n_0),
        .O(cnt_carry_i_9__0_n_0));
  LUT5 #(
    .INIT(32'h0A28A028)) 
    \q[0]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(green_IBUF[6]),
        .I2(green_IBUF[0]),
        .I3(\q_reg[4]_0 ),
        .I4(\q[5]_i_4__0_n_0 ),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2800)) 
    \q[1]_i_1__0 
       (.I0(\q_reg[4]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q[5]_i_4__0_n_0 ),
        .I3(ActiveArea_IBUF),
        .O(D[1]));
  LUT5 #(
    .INIT(32'h56A6FFFF)) 
    \q[2]_i_1__0 
       (.I0(\green[0]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q[5]_i_4__0_n_0 ),
        .I4(ActiveArea_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[3]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[6]),
        .I3(\q[5]_i_4__0_n_0 ),
        .O(D[3]));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[4]_i_1__0 
       (.I0(\green[4]_0 ),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[4]_1 ),
        .I4(ActiveArea_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h0880)) 
    \q[5]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[3]),
        .I3(\q[5]_i_4__0_n_0 ),
        .O(D[5]));
  LUT5 #(
    .INIT(32'hB2DDB244)) 
    \q[5]_i_4__0 
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7_n_0 ),
        .O(\q[5]_i_4__0_n_0 ));
  LUT5 #(
    .INIT(32'hA656FFFF)) 
    \q[6]_i_1__0 
       (.I0(green[0]),
        .I1(green_IBUF[6]),
        .I2(\q_reg[4]_0 ),
        .I3(\q_reg[4]_1 ),
        .I4(ActiveArea_IBUF),
        .O(D[6]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h8008)) 
    \q[7]_i_1__0 
       (.I0(ActiveArea_IBUF),
        .I1(\q_reg[4]_0 ),
        .I2(green_IBUF[6]),
        .I3(\q_reg[4]_1 ),
        .O(D[7]));
  LUT6 #(
    .INIT(64'h00000000FFFF6FFF)) 
    \q[7]_i_3__0 
       (.I0(green[7]),
        .I1(green[6]),
        .I2(cnt0__0_carry_i_14_n_0),
        .I3(cnt0__0_carry_i_8__0_n_0),
        .I4(cnt0__0_carry_i_15__0_n_0),
        .I5(\cnt_reg[3]_5 ),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'h4D224DBB)) 
    \q[7]_i_4__0 
       (.I0(cnt0__0_carry__0_i_7_n_0),
        .I1(\green[7]_2 ),
        .I2(\q[7]_i_6_n_0 ),
        .I3(Q[7]),
        .I4(\q[7]_i_7_n_0 ),
        .O(\q_reg[4]_1 ));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \q[7]_i_6 
       (.I0(\q_reg[5]_0 ),
        .I1(green[6]),
        .I2(green[7]),
        .I3(\green[7]_0 ),
        .I4(\green[7]_1 ),
        .O(\q[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hDD4DFFFF0000DD4D)) 
    \q[7]_i_7 
       (.I0(green[7]),
        .I1(green[6]),
        .I2(green[3]),
        .I3(cnt0__23_carry_i_8__0_n_0),
        .I4(\green[7]_1 ),
        .I5(\green[7]_0 ),
        .O(\q[7]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \q[8]_i_1__0 
       (.I0(green_IBUF[6]),
        .I1(ActiveArea_IBUF),
        .O(D[8]));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_4
   (cnt_reg,
    \cnt_reg[3]_0 ,
    green,
    \green[0]_0 ,
    \green[3]_0 ,
    \green[3]_1 ,
    \green[4]_0 ,
    \green[4]_1 ,
    \green[4]_2 ,
    \green[4]_3 ,
    q_reg,
    \q_reg[4]_0 ,
    \q_reg[4]_1 ,
    \q_reg[5]_0 ,
    \q_reg[5]_1 ,
    \q_reg[5]_2 ,
    green_IBUF);
  output [3:3]cnt_reg;
  output \cnt_reg[3]_0 ;
  input [7:0]green;
  input \green[0]_0 ;
  input \green[3]_0 ;
  input \green[3]_1 ;
  input \green[4]_0 ;
  input \green[4]_1 ;
  input \green[4]_2 ;
  input \green[4]_3 ;
  output [5:4]q_reg;
  output \q_reg[4]_0 ;
  output \q_reg[4]_1 ;
  output \q_reg[5]_0 ;
  output \q_reg[5]_1 ;
  output \q_reg[5]_2 ;
  input [6:0]green_IBUF;

  wire cnt0__0_carry_i_18_n_0;
  wire cnt0__0_carry_i_19_n_0;
  wire cnt0__0_carry_i_20_n_0;
  wire cnt0__0_carry_i_22_n_0;
  wire cnt0__0_carry_i_23_n_0;
  wire cnt0__0_carry_i_26_n_0;
  wire cnt0__0_carry_i_27_n_0;
  wire cnt0__0_carry_i_28_n_0;
  wire cnt0__0_carry_i_29_n_0;
  wire cnt0__0_carry_i_30_n_0;
  wire cnt0__0_carry_i_31_n_0;
  wire [3:3]cnt_reg;
  wire \cnt_reg[3]_0 ;
  wire [7:0]green;
  wire \green[0]_0 ;
  wire \green[3]_1 ;
  wire \green[4]_0 ;
  wire \green[4]_1 ;
  wire \green[4]_2 ;
  wire [6:0]green_IBUF;
  wire [5:4]q_reg;
  wire \q_reg[4]_0 ;
  wire \q_reg[4]_1 ;
  wire \q_reg[5]_0 ;
  wire \q_reg[5]_1 ;
  wire \q_reg[5]_2 ;

  LUT2 #(
    .INIT(4'h1)) 
    cnt0__0_carry__0_i_10
       (.I0(\green[3]_1 ),
        .I1(green_IBUF[4]),
        .O(\q_reg[5]_2 ));
  LUT4 #(
    .INIT(16'h8000)) 
    cnt0__0_carry__0_i_8
       (.I0(green[7]),
        .I1(\green[4]_0 ),
        .I2(green[4]),
        .I3(green[5]),
        .O(\q_reg[4]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_10
       (.I0(cnt0__0_carry_i_20_n_0),
        .I1(\green[4]_0 ),
        .I2(cnt0__0_carry_i_22_n_0),
        .I3(green[0]),
        .I4(cnt0__0_carry_i_23_n_0),
        .O(\q_reg[4]_1 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_11
       (.I0(green[4]),
        .I1(\green[4]_0 ),
        .O(\cnt_reg[3]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    cnt0__0_carry_i_12
       (.I0(\green[4]_0 ),
        .I1(\green[4]_2 ),
        .O(\q_reg[5]_0 ));
  LUT5 #(
    .INIT(32'hBBFC8830)) 
    cnt0__0_carry_i_16
       (.I0(cnt0__0_carry_i_26_n_0),
        .I1(\green[4]_0 ),
        .I2(cnt0__0_carry_i_27_n_0),
        .I3(green[0]),
        .I4(cnt0__0_carry_i_28_n_0),
        .O(\q_reg[5]_1 ));
  LUT5 #(
    .INIT(32'hFCE230E2)) 
    cnt0__0_carry_i_17
       (.I0(cnt0__0_carry_i_29_n_0),
        .I1(green[5]),
        .I2(cnt0__0_carry_i_30_n_0),
        .I3(green[4]),
        .I4(cnt0__0_carry_i_31_n_0),
        .O(q_reg[5]));
  LUT3 #(
    .INIT(8'h42)) 
    cnt0__0_carry_i_18
       (.I0(green[0]),
        .I1(\green[4]_2 ),
        .I2(\green[3]_1 ),
        .O(cnt0__0_carry_i_18_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    cnt0__0_carry_i_19
       (.I0(green[0]),
        .I1(\green[4]_2 ),
        .I2(\green[3]_1 ),
        .O(cnt0__0_carry_i_19_n_0));
  LUT3 #(
    .INIT(8'h63)) 
    cnt0__0_carry_i_20
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_20_n_0));
  LUT3 #(
    .INIT(8'h9C)) 
    cnt0__0_carry_i_22
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_22_n_0));
  LUT3 #(
    .INIT(8'h39)) 
    cnt0__0_carry_i_23
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_23_n_0));
  LUT3 #(
    .INIT(8'h15)) 
    cnt0__0_carry_i_26
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_26_n_0));
  LUT3 #(
    .INIT(8'h76)) 
    cnt0__0_carry_i_27
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_27_n_0));
  LUT3 #(
    .INIT(8'h57)) 
    cnt0__0_carry_i_28
       (.I0(\green[0]_0 ),
        .I1(green[5]),
        .I2(\green[4]_1 ),
        .O(cnt0__0_carry_i_28_n_0));
  LUT4 #(
    .INIT(16'hCCC8)) 
    cnt0__0_carry_i_29
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_29_n_0));
  LUT4 #(
    .INIT(16'hECCC)) 
    cnt0__0_carry_i_30
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_30_n_0));
  LUT4 #(
    .INIT(16'h7EEC)) 
    cnt0__0_carry_i_31
       (.I0(\green[4]_0 ),
        .I1(green[0]),
        .I2(\green[4]_1 ),
        .I3(\green[4]_2 ),
        .O(cnt0__0_carry_i_31_n_0));
  LUT4 #(
    .INIT(16'h1EB4)) 
    cnt0__0_carry_i_9
       (.I0(green[4]),
        .I1(cnt0__0_carry_i_18_n_0),
        .I2(\green[3]_1 ),
        .I3(cnt0__0_carry_i_19_n_0),
        .O(q_reg[4]));
  LUT3 #(
    .INIT(8'h96)) 
    cnt0__23_carry_i_9
       (.I0(\green[3]_1 ),
        .I1(green_IBUF[1]),
        .I2(\cnt_reg[3]_0 ),
        .O(cnt_reg));
endmodule

(* ORIG_REF_NAME = "NumberCnt" *) 
module NumberCnt_5
   (ActiveArea_IBUF,
    blue,
    \blue[0]_0 ,
    \blue[3]_0 ,
    \blue[4]_0 ,
    \blue[7]_0 ,
    \blue[7]_1 ,
    \blue[7]_2 ,
    \blue[7]_3 ,
    \blue[7]_4 ,
    \cnt_reg[3]_5 ,
    hSync_IBUF,
    q_reg,
    \q_reg[2]_0 ,
    \q_reg[2]_1 ,
    \q_reg[2]_2 ,
    \q_reg[2]_3 ,
    \q_reg[2]_4 ,
    vSync_IBUF,
    D,
    DI,
    Q,
    S,
    blue_IBUF,
    cnt0,
    cnt00_in,
    cnt2,
    \cnt_reg[3] ,
    \cnt_reg[3]_0 ,
    \cnt_reg[3]_1 ,
    \cnt_reg[3]_2 ,
    \cnt_reg[3]_3 ,
    \cnt_reg[3]_4 ,
    \cnt_reg[7] ,
    \cnt_reg[7]_0 ,
    \cnt_reg[7]_1 ,
    \cnt_reg[7]_2 ,
    lopt);
  input ActiveArea_IBUF;
  input [7:0]blue;
  input \blue[0]_0 ;
  input \blue[3]_0 ;
  input \blue[4]_0 ;
  input \blue[7]_0 ;
  input \blue[7]_1 ;
  input \blue[7]_2 ;
  input \blue[7]_3 ;
  input \blue[7]_4 ;
  input \cnt_reg[3]_5 ;
  input hSync_IBUF;
  output [9:2]q_reg;
  output \q_reg[2]_0 ;
  output \q_reg[2]_1 ;
  output \q_reg[2]_2 ;
  output \q_reg[2]_3 ;
  output \q_reg[2]_4 ;
  input vSync_IBUF;
  output [8:0]D;
  output [2:0]DI;
  input [7:0]Q;
  output [3:0]S;
  input [7:0]blue_IBUF;
  input [7:0]cnt0;
  input [7:0]cnt00_in;
  output [0:0]cnt2;
  output [3:0]\cnt_reg[3] ;
  output [3:0]\cnt_reg[3]_0 ;
  output [3:0]\cnt_reg[3]_1 ;
  output [1:0]\cnt_reg[3]_2 ;
  output [3:0]\cnt_reg[3]_3 ;
  output [1:0]\cnt_reg[3]_4 ;
  output [0:0]\cnt_reg[7] ;
  output [2:0]\cnt_reg[7]_0 ;
  output [3:0]\cnt_reg[7]_1 ;
  output [1:0]\cnt_reg[7]_2 ;
  output lopt;

  wire ActiveArea_IBUF;
  wire [8:0]D;
  wire [2:0]DI;
  wire [7:0]\^Q ;
  wire [3:0]S;
  wire [7:0]cnt0;
  wire [7:0]cnt00_in;
  wire cnt0__0_carry__0_i_8_n_0;
  wire [0:0]\^cnt2 ;
  wire [3:0]\cnt_reg[3] ;
  wire [3:0]\cnt_reg[3]_0 ;
  wire [3:0]\^cnt_reg[3]_1 ;
  wire [1:0]\^cnt_reg[3]_2 ;
  wire [3:0]\^cnt_reg[3]_3 ;
  wire \cnt_reg[3]_5 ;
  wire [0:0]\cnt_reg[7] ;
  wire [3:0]\cnt_reg[7]_1 ;
  wire [1:0]\^cnt_reg[7]_2 ;
  wire hSync_IBUF;
  wire [9:2]\^q_reg ;
  wire \q_reg[2]_0 ;
  wire vSync_IBUF;

  assign \^Q [6:0] = Q[6:0];
  assign \cnt_reg[3]_1 [3] = \^cnt_reg[3]_1 [3];
  assign \cnt_reg[3]_1 [2] = \^Q [2];
  assign \cnt_reg[3]_1 [1] = \^cnt_reg[3]_1 [1];
  assign \cnt_reg[3]_1 [0] = \^Q [0];
  assign \cnt_reg[3]_2 [0] = \^cnt2 [0];
  assign \cnt_reg[3]_3 [3] = \^cnt_reg[3]_3 [3];
  assign \cnt_reg[3]_3 [2:0] = \^Q [2:0];
  assign \cnt_reg[3]_4 [1] = \^cnt2 [0];
  assign \cnt_reg[3]_4 [0] = \^cnt2 [0];
  assign \cnt_reg[7]_0 [2:0] = \^Q [5:3];
  assign \cnt_reg[7]_2 [1] = \^Q [5];
  assign \cnt_reg[7]_2 [0] = \^cnt_reg[7]_2 [0];
  assign lopt = \^cnt_reg[3]_2 [1];
  assign q_reg[9] = \^q_reg [9];
  assign q_reg[2] = \cnt_reg[3]_5 ;
  assign \q_reg[2]_0  = Q[7];
  assign \q_reg[2]_1  = cnt0__0_carry__0_i_8_n_0;
  GND GND
       (.G(\^cnt2 ));
  VCC VCC
       (.P(cnt0__0_carry__0_i_8_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    cnt0__0_carry__0_i_2
       (.I0(\^Q [3]),
        .I1(\^Q [2]),
        .O(\cnt_reg[7] ));
  LUT3 #(
    .INIT(8'h78)) 
    cnt0__0_carry__0_i_6
       (.I0(\^Q [2]),
        .I1(\^Q [3]),
        .I2(\^Q [4]),
        .O(\^cnt_reg[7]_2 [0]));
  (* HLUTNM = "lutpair1" *) 
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry_i_1
       (.I0(\^Q [2]),
        .O(\^cnt_reg[3]_2 [1]));
  LUT3 #(
    .INIT(8'h69)) 
    cnt0__0_carry_i_4
       (.I0(\^Q [2]),
        .I1(\^Q [2]),
        .I2(\^Q [3]),
        .O(\^cnt_reg[3]_1 [3]));
  (* HLUTNM = "lutpair0" *) 
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry_i_6
       (.I0(\^Q [1]),
        .O(\^cnt_reg[3]_1 [1]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_4
       (.I0(\q_reg[2]_0 ),
        .I1(\^Q [6]),
        .O(\cnt_reg[7]_1 [3]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_5
       (.I0(\^Q [5]),
        .I1(\^Q [6]),
        .O(\cnt_reg[7]_1 [2]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_6
       (.I0(\^Q [4]),
        .I1(\^Q [5]),
        .O(\cnt_reg[7]_1 [1]));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__23_carry__0_i_7
       (.I0(\^Q [3]),
        .I1(\^Q [4]),
        .O(\cnt_reg[7]_1 [0]));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__23_carry_i_3
       (.I0(\^Q [3]),
        .O(\^cnt_reg[3]_3 [3]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_1
       (.I0(\^Q [6]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[2]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_2
       (.I0(\^Q [5]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry__0_i_3
       (.I0(\^Q [4]),
        .I1(\cnt_reg[3]_5 ),
        .O(DI[0]));
  LUT4 #(
    .INIT(16'hFFE2)) 
    cnt_carry__0_i_4
       (.I0(cnt00_in[7]),
        .I1(\q_reg[2]_0 ),
        .I2(cnt0[7]),
        .I3(\cnt_reg[3]_5 ),
        .O(S[3]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_5
       (.I0(\^Q [6]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[6]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[6]),
        .O(S[2]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_6
       (.I0(\^Q [5]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[5]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[5]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry__0_i_7
       (.I0(\^Q [4]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[4]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[4]),
        .O(S[0]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_1
       (.I0(\^Q [3]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [3]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_2
       (.I0(\^Q [2]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [2]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_3
       (.I0(\^Q [1]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [1]));
  LUT2 #(
    .INIT(4'h8)) 
    cnt_carry_i_4
       (.I0(\^Q [0]),
        .I1(\cnt_reg[3]_5 ),
        .O(\cnt_reg[3] [0]));
  LUT5 #(
    .INIT(32'h77744474)) 
    cnt_carry_i_5
       (.I0(\^Q [3]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[3]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[3]),
        .O(\cnt_reg[3]_0 [3]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_6
       (.I0(\^Q [2]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[2]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[2]),
        .O(\cnt_reg[3]_0 [2]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_7
       (.I0(\^Q [1]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[1]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[1]),
        .O(\cnt_reg[3]_0 [1]));
  LUT5 #(
    .INIT(32'hBBB888B8)) 
    cnt_carry_i_8
       (.I0(\^Q [0]),
        .I1(\cnt_reg[3]_5 ),
        .I2(cnt00_in[0]),
        .I3(\q_reg[2]_0 ),
        .I4(cnt0[0]),
        .O(\cnt_reg[3]_0 [0]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[0]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[0]));
  LUT4 #(
    .INIT(16'h2F20)) 
    \q[1]_i_1 
       (.I0(\q_reg[2]_0 ),
        .I1(\cnt_reg[3]_5 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[1]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[2]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[2]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[3]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[3]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[4]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[4]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[5]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[5]));
  LUT4 #(
    .INIT(16'h404F)) 
    \q[6]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[6]));
  LUT4 #(
    .INIT(16'h4F40)) 
    \q[7]_i_1 
       (.I0(\cnt_reg[3]_5 ),
        .I1(\q_reg[2]_0 ),
        .I2(ActiveArea_IBUF),
        .I3(hSync_IBUF),
        .O(D[7]));
  LUT2 #(
    .INIT(4'h1)) 
    \q[8]_i_1 
       (.I0(ActiveArea_IBUF),
        .I1(hSync_IBUF),
        .O(D[8]));
  LUT3 #(
    .INIT(8'h14)) 
    \q[9]_i_2 
       (.I0(ActiveArea_IBUF),
        .I1(hSync_IBUF),
        .I2(vSync_IBUF),
        .O(\^q_reg [9]));
endmodule

(* ECO_CHECKSUM = "224e1255" *) 
(* NotValidForBitStream *)
module PipelineCPUTest
   (clk,
    reset,
    step,
    run_mode,
    TMDSp,
    TMDSn,
    TMDSp_clk,
    TMDSn_clk);
  (* CLOCK_BUFFER_TYPE = "none" *) input clk;
  input reset;
  input step;
  input run_mode;
  output [2:0]TMDSp;
  output [2:0]TMDSn;
  output TMDSp_clk;
  output TMDSn_clk;

  wire [31:17]ALUResult;
  wire [31:20]ALU_A;
  wire ActiveArea;
  wire CPUInst_n_0;
  wire CPUInst_n_13;
  wire CPUInst_n_17;
  wire CPUInst_n_31;
  wire CPUInst_n_32;
  wire CPUInst_n_33;
  wire CPUInst_n_34;
  wire CPUInst_n_35;
  wire CPUInst_n_36;
  wire CPUInst_n_37;
  wire CPUInst_n_38;
  wire CPUInst_n_39;
  wire CPUInst_n_40;
  wire CPUInst_n_41;
  wire CPUInst_n_54;
  wire CPUInst_n_55;
  wire CPUInst_n_56;
  wire CPUInst_n_57;
  wire CPUInst_n_58;
  wire CPUInst_n_59;
  wire CPUInst_n_72;
  wire CPUInst_n_73;
  wire CPUInst_n_74;
  wire CPUInst_n_75;
  wire CPUInst_n_76;
  wire CPUInst_n_77;
  wire CPUInst_n_78;
  wire [27:1]Instruction_id;
  wire [0:0]JumpFlag;
  wire [31:20]MemDout_mem;
  wire [6:1]PC;
  wire [3:1]PosX_reg_reg__0;
  wire [4:1]PosY;
  wire TMDSch0;
  wire TMDSch1;
  wire TMDSch2;
  wire [2:0]TMDSn;
  wire TMDSn_clk;
  wire [2:0]TMDSp;
  wire TMDSp_clk;
  wire VgaData_n_0;
  wire [3:0]char_selection;
  (* IBUF_LOW_PWR *) wire clk;
  wire cpu_clk;
  wire cpu_clk_BUFG;
  wire [0:0]green;
  wire hSync;
  wire lopt;
  wire pixel_clk;
  wire reset;
  wire reset_IBUF;
  wire run_mode;
  wire run_mode_IBUF;
  wire step;
  wire step_IBUF;
  wire step_pulse;
  wire step_pulse_reg;
  wire sync_inst_n_10;
  wire sync_inst_n_11;
  wire sync_inst_n_12;
  wire sync_inst_n_13;
  wire sync_inst_n_14;
  wire sync_inst_n_15;
  wire sync_inst_n_16;
  wire sync_inst_n_21;
  wire sync_inst_n_8;
  wire sync_inst_n_9;
  wire tmds_clk;
  wire vSync;
  wire NLW_DCM_INST_locked_UNCONNECTED;
  wire NLW_TMDS_inst_pixel_clk_UNCONNECTED;
  wire [7:0]NLW_TMDS_inst_blue_UNCONNECTED;
  wire [7:5]NLW_TMDS_inst_green_UNCONNECTED;
  wire [7:5]NLW_TMDS_inst_red_UNCONNECTED;
  wire NLW_step_pulse_inst_clk_UNCONNECTED;
  wire NLW_step_pulse_inst_reset_UNCONNECTED;

initial begin
 $sdf_annotate("Risc5CPU_tb_v_time_impl.sdf",,,,"tool_control");
end
  Risc5CPU CPUInst
       (.D({ALUResult[31],ALUResult[29:26],ALUResult[24:17]}),
        .\PC_reg_reg[8] (JumpFlag),
        .\PosX_reg_reg[4] (sync_inst_n_12),
        .\PosX_reg_reg[4]_0 (sync_inst_n_8),
        .\PosX_reg_reg[4]_1 (sync_inst_n_11),
        .\PosX_reg_reg[4]_2 (sync_inst_n_13),
        .\PosX_reg_reg[4]_3 (sync_inst_n_15),
        .\PosX_reg_reg[4]_4 (sync_inst_n_16),
        .\PosX_reg_reg[5] (sync_inst_n_9),
        .\PosX_reg_reg[6] (sync_inst_n_14),
        .\PosX_reg_reg[6]_0 (sync_inst_n_10),
        .SR(reset_IBUF),
        .\TMDSn[2] (CPUInst_n_0),
        .\TMDSn[2]_0 (CPUInst_n_13),
        .\TMDSn[2]_1 (CPUInst_n_17),
        .\TMDSn[2]_10 (CPUInst_n_39),
        .\TMDSn[2]_11 (CPUInst_n_40),
        .\TMDSn[2]_12 (CPUInst_n_41),
        .\TMDSn[2]_13 (CPUInst_n_54),
        .\TMDSn[2]_14 (CPUInst_n_55),
        .\TMDSn[2]_15 (CPUInst_n_56),
        .\TMDSn[2]_16 (CPUInst_n_57),
        .\TMDSn[2]_17 (CPUInst_n_58),
        .\TMDSn[2]_18 (CPUInst_n_59),
        .\TMDSn[2]_19 (CPUInst_n_72),
        .\TMDSn[2]_2 (CPUInst_n_31),
        .\TMDSn[2]_20 (CPUInst_n_73),
        .\TMDSn[2]_21 (CPUInst_n_74),
        .\TMDSn[2]_22 (CPUInst_n_75),
        .\TMDSn[2]_23 (CPUInst_n_76),
        .\TMDSn[2]_3 (CPUInst_n_32),
        .\TMDSn[2]_4 (CPUInst_n_33),
        .\TMDSn[2]_5 (CPUInst_n_34),
        .\TMDSn[2]_6 (CPUInst_n_35),
        .\TMDSn[2]_7 (CPUInst_n_36),
        .\TMDSn[2]_8 (CPUInst_n_37),
        .\TMDSn[2]_9 (CPUInst_n_38),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[23] (sync_inst_n_21),
        .\q_reg[38] ({PC[6:5],PC[1]}),
        .\q_reg[46] ({Instruction_id[27],Instruction_id[25],Instruction_id[23],Instruction_id[21:20],Instruction_id[13:12],Instruction_id[9:8],Instruction_id[4],Instruction_id[1]}),
        .\q_reg[54] (MemDout_mem),
        .\q_reg[67] (CPUInst_n_77),
        .\q_reg[71] (CPUInst_n_78),
        .\q_reg[74] (ALU_A));
  DCM_PLL DCM_INST
       (.clk_in1(clk),
        .clk_out1(pixel_clk),
        .clk_out2(tmds_clk),
        .locked(NLW_DCM_INST_locked_UNCONNECTED),
        .lopt(lopt),
        .reset(1'b0));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_blue
       (.I(TMDSch0),
        .O(TMDSp[0]),
        .OB(TMDSn[0]));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_clk
       (.I(pixel_clk),
        .O(TMDSp_clk),
        .OB(TMDSn_clk));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_green
       (.I(TMDSch1),
        .O(TMDSp[1]),
        .OB(TMDSn[1]));
  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* XILINX_LEGACY_PRIM = "OBUFDS" *) 
  OBUFDS #(
    .IOSTANDARD("DEFAULT")) 
    OBUFDS_red
       (.I(TMDSch2),
        .O(TMDSp[2]),
        .OB(TMDSn[2]));
  TMDSencode TMDS_inst
       (.ActiveArea(ActiveArea),
        .TMDSch0(TMDSch0),
        .TMDSch1(TMDSch1),
        .TMDSch2(TMDSch2),
        .blue(NLW_TMDS_inst_blue_UNCONNECTED[7:0]),
        .green({NLW_TMDS_inst_green_UNCONNECTED[7],green,NLW_TMDS_inst_green_UNCONNECTED[5],green,green,green,green,green}),
        .hSync(hSync),
        .lopt(lopt),
        .pixel_clk(NLW_TMDS_inst_pixel_clk_UNCONNECTED),
        .red({NLW_TMDS_inst_red_UNCONNECTED[7],green,NLW_TMDS_inst_red_UNCONNECTED[5],green,green,green,green,green}),
        .reset(1'b0),
        .tmds_clk(tmds_clk),
        .vSync(vSync));
  vga_data VgaData
       (.CLK(pixel_clk),
        .Q(PosX_reg_reg__0),
        .\TMDSn[2] (VgaData_n_0),
        .a({char_selection,PosY}));
  BUFG cpu_clk_BUFG_inst
       (.I(cpu_clk),
        .O(cpu_clk_BUFG));
  LUT3 #(
    .INIT(8'hB8)) 
    cpu_clk_BUFG_inst_i_1
       (.I0(pixel_clk),
        .I1(run_mode_IBUF),
        .I2(step_pulse_reg),
        .O(cpu_clk));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
  IBUF run_mode_IBUF_inst
       (.I(run_mode),
        .O(run_mode_IBUF));
  IBUF step_IBUF_inst
       (.I(step),
        .O(step_IBUF));
  button_process_unit step_pulse_inst
       (.ButtonIn(step_IBUF),
        .ButtonOut(step_pulse),
        .clk(NLW_step_pulse_inst_clk_UNCONNECTED),
        .lopt(lopt),
        .reset(NLW_step_pulse_inst_reset_UNCONNECTED));
  FDRE #(
    .INIT(1'b0)) 
    step_pulse_reg_reg
       (.C(pixel_clk),
        .CE(1'b1),
        .D(step_pulse),
        .Q(step_pulse_reg),
        .R(1'b0));
  syncGenarator sync_inst
       (.ActiveArea(ActiveArea),
        .CLK(pixel_clk),
        .D({ALUResult[31],ALUResult[29:26],ALUResult[24:17]}),
        .\PC_reg_reg[0] (CPUInst_n_13),
        .\PC_reg_reg[2] (CPUInst_n_75),
        .\PC_reg_reg[3] (CPUInst_n_76),
        .\PC_reg_reg[6] ({PC[6:5],PC[1]}),
        .\PosX_reg_reg[3]_0 (VgaData_n_0),
        .\PosX_reg_reg[4]_0 (CPUInst_n_17),
        .\PosX_reg_reg[4]_1 (CPUInst_n_39),
        .\PosX_reg_reg[4]_2 (CPUInst_n_35),
        .\PosX_reg_reg[4]_3 (CPUInst_n_59),
        .\PosX_reg_reg[4]_4 (CPUInst_n_72),
        .\PosX_reg_reg[4]_5 (CPUInst_n_73),
        .\PosX_reg_reg[4]_6 (CPUInst_n_74),
        .\PosX_reg_reg[6]_0 (CPUInst_n_38),
        .\PosX_reg_reg[6]_1 (CPUInst_n_33),
        .\PosX_reg_reg[6]_2 (CPUInst_n_40),
        .Q(PosX_reg_reg__0),
        .\TMDSn[2] (sync_inst_n_8),
        .\TMDSn[2]_0 (sync_inst_n_9),
        .\TMDSn[2]_1 (sync_inst_n_10),
        .\TMDSn[2]_2 (sync_inst_n_11),
        .\TMDSn[2]_3 (sync_inst_n_12),
        .\TMDSn[2]_4 (sync_inst_n_13),
        .\TMDSn[2]_5 (sync_inst_n_14),
        .\TMDSn[2]_6 (sync_inst_n_15),
        .\TMDSn[2]_7 (sync_inst_n_16),
        .\TMDSn[2]_8 (sync_inst_n_21),
        .a({char_selection,PosY}),
        .\bbstub_spo[31] (MemDout_mem),
        .green(green),
        .hSync(hSync),
        .\q_reg[0] (CPUInst_n_0),
        .\q_reg[121] (CPUInst_n_78),
        .\q_reg[12] (JumpFlag),
        .\q_reg[137] (CPUInst_n_77),
        .\q_reg[147] (CPUInst_n_37),
        .\q_reg[14] (CPUInst_n_57),
        .\q_reg[152] (CPUInst_n_31),
        .\q_reg[152]_0 (CPUInst_n_32),
        .\q_reg[152]_1 (CPUInst_n_36),
        .\q_reg[152]_2 (CPUInst_n_34),
        .\q_reg[15] (CPUInst_n_41),
        .\q_reg[16] (CPUInst_n_54),
        .\q_reg[17] (CPUInst_n_55),
        .\q_reg[18] (CPUInst_n_56),
        .\q_reg[27] ({Instruction_id[27],Instruction_id[25],Instruction_id[23],Instruction_id[21:20],Instruction_id[13:12],Instruction_id[9:8],Instruction_id[4],Instruction_id[1]}),
        .\q_reg[27]_0 (CPUInst_n_58),
        .\q_reg[34] (ALU_A),
        .vSync(vSync));
endmodule

module Registers
   (ReadData10,
    ReadData20,
    cpu_clk_BUFG,
    Q,
    w_RegWriteData_wb,
    Instruction_id);
  output [31:0]ReadData10;
  output [31:0]ReadData20;
  input cpu_clk_BUFG;
  input [4:0]Q;
  input [31:0]w_RegWriteData_wb;
  input [4:0]Instruction_id;

  wire [4:0]Instruction_id;
  wire [4:0]Q;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire cpu_clk_BUFG;
  wire [31:0]w_RegWriteData_wb;
  wire [1:0]NLW_regs_reg_r1_0_31_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_12_17_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_18_23_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_24_29_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_30_31_DOB_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_30_31_DOC_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_30_31_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r1_0_31_6_11_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_12_17_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_18_23_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_24_29_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_30_31_DOB_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_30_31_DOC_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_30_31_DOD_UNCONNECTED;
  wire [1:0]NLW_regs_reg_r2_0_31_6_11_DOD_UNCONNECTED;

  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_UNIQ_BASE_ regs_reg_r1_0_31_0_5
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[1:0]),
        .DIB(w_RegWriteData_wb[3:2]),
        .DIC(w_RegWriteData_wb[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[1:0]),
        .DOB(ReadData10[3:2]),
        .DOC(ReadData10[5:4]),
        .DOD(NLW_regs_reg_r1_0_31_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD32 regs_reg_r1_0_31_12_17
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[13:12]),
        .DIB(w_RegWriteData_wb[15:14]),
        .DIC(w_RegWriteData_wb[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[13:12]),
        .DOB(ReadData10[15:14]),
        .DOC(ReadData10[17:16]),
        .DOD(NLW_regs_reg_r1_0_31_12_17_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD33 regs_reg_r1_0_31_18_23
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[19:18]),
        .DIB(w_RegWriteData_wb[21:20]),
        .DIC(w_RegWriteData_wb[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[19:18]),
        .DOB(ReadData10[21:20]),
        .DOC(ReadData10[23:22]),
        .DOD(NLW_regs_reg_r1_0_31_18_23_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD34 regs_reg_r1_0_31_24_29
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[25:24]),
        .DIB(w_RegWriteData_wb[27:26]),
        .DIC(w_RegWriteData_wb[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[25:24]),
        .DOB(ReadData10[27:26]),
        .DOC(ReadData10[29:28]),
        .DOD(NLW_regs_reg_r1_0_31_24_29_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD35 regs_reg_r1_0_31_30_31
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[31:30]),
        .DOB(NLW_regs_reg_r1_0_31_30_31_DOB_UNCONNECTED[1:0]),
        .DOC(NLW_regs_reg_r1_0_31_30_31_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_regs_reg_r1_0_31_30_31_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD36 regs_reg_r1_0_31_6_11
       (.ADDRA({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRB({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRC({1'b0,1'b0,1'b0,Instruction_id[4],Instruction_id[0]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[7:6]),
        .DIB(w_RegWriteData_wb[9:8]),
        .DIC(w_RegWriteData_wb[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData10[7:6]),
        .DOB(ReadData10[9:8]),
        .DOC(ReadData10[11:10]),
        .DOD(NLW_regs_reg_r1_0_31_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD37 regs_reg_r2_0_31_0_5
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[1:0]),
        .DIB(w_RegWriteData_wb[3:2]),
        .DIC(w_RegWriteData_wb[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[1:0]),
        .DOB(ReadData20[3:2]),
        .DOC(ReadData20[5:4]),
        .DOD(NLW_regs_reg_r2_0_31_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD38 regs_reg_r2_0_31_12_17
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[13:12]),
        .DIB(w_RegWriteData_wb[15:14]),
        .DIC(w_RegWriteData_wb[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[13:12]),
        .DOB(ReadData20[15:14]),
        .DOC(ReadData20[17:16]),
        .DOD(NLW_regs_reg_r2_0_31_12_17_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD39 regs_reg_r2_0_31_18_23
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[19:18]),
        .DIB(w_RegWriteData_wb[21:20]),
        .DIC(w_RegWriteData_wb[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[19:18]),
        .DOB(ReadData20[21:20]),
        .DOC(ReadData20[23:22]),
        .DOD(NLW_regs_reg_r2_0_31_18_23_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD40 regs_reg_r2_0_31_24_29
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[25:24]),
        .DIB(w_RegWriteData_wb[27:26]),
        .DIC(w_RegWriteData_wb[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[25:24]),
        .DOB(ReadData20[27:26]),
        .DOC(ReadData20[29:28]),
        .DOD(NLW_regs_reg_r2_0_31_24_29_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD41 regs_reg_r2_0_31_30_31
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[31:30]),
        .DOB(NLW_regs_reg_r2_0_31_30_31_DOB_UNCONNECTED[1:0]),
        .DOC(NLW_regs_reg_r2_0_31_30_31_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_regs_reg_r2_0_31_30_31_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
  (* INIT_A = "64'h0000000000000000" *) 
  (* INIT_B = "64'h0000000000000000" *) 
  (* INIT_C = "64'h0000000000000000" *) 
  (* INIT_D = "64'h0000000000000000" *) 
  (* METHODOLOGY_DRC_VIOS = "" *) 
  RAM32M_HD42 regs_reg_r2_0_31_6_11
       (.ADDRA({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRB({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRC({Instruction_id[3],Instruction_id[3],Instruction_id[4],Instruction_id[2:1]}),
        .ADDRD({1'b0,Q[3:0]}),
        .DIA(w_RegWriteData_wb[7:6]),
        .DIB(w_RegWriteData_wb[9:8]),
        .DIC(w_RegWriteData_wb[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(ReadData20[7:6]),
        .DOB(ReadData20[9:8]),
        .DOC(ReadData20[11:10]),
        .DOD(NLW_regs_reg_r2_0_31_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(cpu_clk_BUFG),
        .WE(Q[4]));
endmodule

module Risc5CPU
   (\TMDSn[2] ,
    \PC_reg_reg[8] ,
    \q_reg[46] ,
    \TMDSn[2]_0 ,
    \q_reg[38] ,
    \TMDSn[2]_1 ,
    D,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    \TMDSn[2]_8 ,
    \TMDSn[2]_9 ,
    \TMDSn[2]_10 ,
    \TMDSn[2]_11 ,
    \TMDSn[2]_12 ,
    \q_reg[74] ,
    \TMDSn[2]_13 ,
    \TMDSn[2]_14 ,
    \TMDSn[2]_15 ,
    \TMDSn[2]_16 ,
    \TMDSn[2]_17 ,
    \TMDSn[2]_18 ,
    \q_reg[54] ,
    \TMDSn[2]_19 ,
    \TMDSn[2]_20 ,
    \TMDSn[2]_21 ,
    \TMDSn[2]_22 ,
    \TMDSn[2]_23 ,
    \q_reg[67] ,
    \q_reg[71] ,
    \PosX_reg_reg[5] ,
    \PosX_reg_reg[4] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[4]_1 ,
    \PosX_reg_reg[6] ,
    \PosX_reg_reg[4]_2 ,
    \PosX_reg_reg[4]_3 ,
    \PosX_reg_reg[6]_0 ,
    \q_reg[23] ,
    \PosX_reg_reg[4]_4 ,
    SR,
    cpu_clk_BUFG);
  output \TMDSn[2] ;
  output [0:0]\PC_reg_reg[8] ;
  output [10:0]\q_reg[46] ;
  output \TMDSn[2]_0 ;
  output [2:0]\q_reg[38] ;
  output \TMDSn[2]_1 ;
  output [12:0]D;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output \TMDSn[2]_8 ;
  output \TMDSn[2]_9 ;
  output \TMDSn[2]_10 ;
  output \TMDSn[2]_11 ;
  output \TMDSn[2]_12 ;
  output [11:0]\q_reg[74] ;
  output \TMDSn[2]_13 ;
  output \TMDSn[2]_14 ;
  output \TMDSn[2]_15 ;
  output \TMDSn[2]_16 ;
  output \TMDSn[2]_17 ;
  output \TMDSn[2]_18 ;
  output [11:0]\q_reg[54] ;
  output \TMDSn[2]_19 ;
  output \TMDSn[2]_20 ;
  output \TMDSn[2]_21 ;
  output \TMDSn[2]_22 ;
  output \TMDSn[2]_23 ;
  output \q_reg[67] ;
  output \q_reg[71] ;
  input \PosX_reg_reg[5] ;
  input \PosX_reg_reg[4] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[4]_1 ;
  input \PosX_reg_reg[6] ;
  input \PosX_reg_reg[4]_2 ;
  input \PosX_reg_reg[4]_3 ;
  input \PosX_reg_reg[6]_0 ;
  input \q_reg[23] ;
  input \PosX_reg_reg[4]_4 ;
  input [0:0]SR;
  input cpu_clk_BUFG;

  wire [30:0]ALUResult;
  wire [12:0]D;
  wire [15:7]Instruction_id;
  wire [1:1]JumpFlag;
  wire [19:0]MemDout_mem;
  wire [28:0]Next_PC;
  wire [7:0]PC;
  wire [0:0]\PC_reg_reg[8] ;
  wire \PosX_reg_reg[4] ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[4]_4 ;
  wire \PosX_reg_reg[5] ;
  wire \PosX_reg_reg[6] ;
  wire \PosX_reg_reg[6]_0 ;
  wire [31:0]ReadData10;
  wire [31:0]ReadData20;
  wire [0:0]SR;
  wire Stall;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_10 ;
  wire \TMDSn[2]_11 ;
  wire \TMDSn[2]_12 ;
  wire \TMDSn[2]_13 ;
  wire \TMDSn[2]_14 ;
  wire \TMDSn[2]_15 ;
  wire \TMDSn[2]_16 ;
  wire \TMDSn[2]_17 ;
  wire \TMDSn[2]_18 ;
  wire \TMDSn[2]_19 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_20 ;
  wire \TMDSn[2]_21 ;
  wire \TMDSn[2]_22 ;
  wire \TMDSn[2]_23 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire \TMDSn[2]_9 ;
  wire char_tab_i_116_n_0;
  wire char_tab_i_119_n_0;
  wire char_tab_i_120_n_0;
  wire char_tab_i_72_n_0;
  wire cpu_clk_BUFG;
  wire [31:0]final_mem_read_data;
  wire [31:0]final_ram_write_data;
  wire p_5_in;
  wire \q_reg[23] ;
  wire [2:0]\q_reg[38] ;
  wire [10:0]\q_reg[46] ;
  wire [11:0]\q_reg[54] ;
  wire \q_reg[67] ;
  wire \q_reg[71] ;
  wire [11:0]\q_reg[74] ;
  wire r_ALUSrcA_ex;
  wire r_MemRead_ex;
  wire r_MemWrite_mem;
  wire [31:0]r_PC_id;
  wire r_RegWrite_mem;
  wire r_RegWrite_wb;
  wire [3:0]r_rdAddr_ex;
  wire [3:0]r_rdAddr_mem;
  wire [1:0]r_rs1Addr_ex;
  wire [30:2]r_rs1Data_ex;
  wire [4:0]r_rs2Addr_ex;
  wire [1:1]r_rs2Data_ex;
  wire u_IF1_n_1;
  wire u_IF1_n_10;
  wire u_IF1_n_11;
  wire u_IF1_n_12;
  wire u_IF1_n_13;
  wire u_IF1_n_14;
  wire u_IF1_n_15;
  wire u_IF1_n_16;
  wire u_IF1_n_17;
  wire u_IF1_n_18;
  wire u_IF1_n_19;
  wire u_IF1_n_2;
  wire u_IF1_n_20;
  wire u_IF1_n_21;
  wire u_IF1_n_22;
  wire u_IF1_n_23;
  wire u_IF1_n_24;
  wire u_IF1_n_3;
  wire u_IF1_n_35;
  wire u_IF1_n_4;
  wire u_IF1_n_42;
  wire u_IF1_n_48;
  wire u_IF1_n_5;
  wire u_IF1_n_6;
  wire u_IF1_n_7;
  wire u_IF1_n_8;
  wire u_IF1_n_9;
  wire \u_adder_pc/c2__0 ;
  wire \u_adder_pc/c3__0 ;
  wire \u_adder_pc/c4__0 ;
  wire \u_adder_pc/c5__0 ;
  wire \u_adder_pc/c6__0 ;
  wire \u_adder_pc/c7__0 ;
  wire u_reg_EX_MEM_n_0;
  wire u_reg_EX_MEM_n_1;
  wire u_reg_EX_MEM_n_10;
  wire u_reg_EX_MEM_n_11;
  wire u_reg_EX_MEM_n_12;
  wire u_reg_EX_MEM_n_13;
  wire u_reg_EX_MEM_n_14;
  wire u_reg_EX_MEM_n_15;
  wire u_reg_EX_MEM_n_16;
  wire u_reg_EX_MEM_n_17;
  wire u_reg_EX_MEM_n_18;
  wire u_reg_EX_MEM_n_19;
  wire u_reg_EX_MEM_n_2;
  wire u_reg_EX_MEM_n_20;
  wire u_reg_EX_MEM_n_21;
  wire u_reg_EX_MEM_n_22;
  wire u_reg_EX_MEM_n_23;
  wire u_reg_EX_MEM_n_24;
  wire u_reg_EX_MEM_n_25;
  wire u_reg_EX_MEM_n_26;
  wire u_reg_EX_MEM_n_27;
  wire u_reg_EX_MEM_n_28;
  wire u_reg_EX_MEM_n_29;
  wire u_reg_EX_MEM_n_3;
  wire u_reg_EX_MEM_n_30;
  wire u_reg_EX_MEM_n_32;
  wire u_reg_EX_MEM_n_35;
  wire u_reg_EX_MEM_n_4;
  wire u_reg_EX_MEM_n_40;
  wire u_reg_EX_MEM_n_41;
  wire u_reg_EX_MEM_n_42;
  wire u_reg_EX_MEM_n_43;
  wire u_reg_EX_MEM_n_44;
  wire u_reg_EX_MEM_n_45;
  wire u_reg_EX_MEM_n_46;
  wire u_reg_EX_MEM_n_47;
  wire u_reg_EX_MEM_n_48;
  wire u_reg_EX_MEM_n_49;
  wire u_reg_EX_MEM_n_5;
  wire u_reg_EX_MEM_n_50;
  wire u_reg_EX_MEM_n_51;
  wire u_reg_EX_MEM_n_52;
  wire u_reg_EX_MEM_n_6;
  wire u_reg_EX_MEM_n_7;
  wire u_reg_EX_MEM_n_8;
  wire u_reg_EX_MEM_n_9;
  wire u_reg_ID_EX_n_121;
  wire u_reg_ID_EX_n_122;
  wire u_reg_ID_EX_n_123;
  wire u_reg_ID_EX_n_126;
  wire u_reg_ID_EX_n_127;
  wire u_reg_ID_EX_n_128;
  wire u_reg_ID_EX_n_92;
  wire u_reg_ID_EX_n_93;
  wire u_reg_IF_ID_n_111;
  wire u_reg_IF_ID_n_112;
  wire u_reg_IF_ID_n_12;
  wire u_reg_IF_ID_n_13;
  wire u_reg_IF_ID_n_14;
  wire u_reg_IF_ID_n_16;
  wire u_reg_IF_ID_n_17;
  wire u_reg_IF_ID_n_18;
  wire u_reg_IF_ID_n_19;
  wire u_reg_IF_ID_n_23;
  wire u_reg_MEM_WB_n_0;
  wire u_reg_MEM_WB_n_100;
  wire u_reg_MEM_WB_n_101;
  wire u_reg_MEM_WB_n_102;
  wire u_reg_MEM_WB_n_103;
  wire u_reg_MEM_WB_n_104;
  wire u_reg_MEM_WB_n_105;
  wire u_reg_MEM_WB_n_106;
  wire u_reg_MEM_WB_n_107;
  wire u_reg_MEM_WB_n_108;
  wire u_reg_MEM_WB_n_109;
  wire u_reg_MEM_WB_n_110;
  wire u_reg_MEM_WB_n_111;
  wire u_reg_MEM_WB_n_112;
  wire u_reg_MEM_WB_n_113;
  wire u_reg_MEM_WB_n_114;
  wire u_reg_MEM_WB_n_115;
  wire u_reg_MEM_WB_n_116;
  wire u_reg_MEM_WB_n_117;
  wire u_reg_MEM_WB_n_118;
  wire u_reg_MEM_WB_n_119;
  wire u_reg_MEM_WB_n_120;
  wire u_reg_MEM_WB_n_121;
  wire u_reg_MEM_WB_n_122;
  wire u_reg_MEM_WB_n_123;
  wire u_reg_MEM_WB_n_124;
  wire u_reg_MEM_WB_n_125;
  wire u_reg_MEM_WB_n_126;
  wire u_reg_MEM_WB_n_65;
  wire u_reg_MEM_WB_n_98;
  wire [3:0]w_ALUCode_id;
  wire w_ALUSrcA_id;
  wire [0:0]w_ALUSrcB_id;
  wire w_IFWrite;
  wire w_IF_flush;
  wire [25:0]w_Imm_id;
  wire [27:0]w_Instruction_if;
  wire [31:4]w_JumpAddr;
  wire w_MemRead_id;
  wire [31:0]w_MemWriteData_ex;
  wire w_MemWrite_id;
  wire [31:0]w_RegWriteData_wb;
  wire w_RegWrite_id;
  wire [31:0]w_rs1Data_id;
  wire [31:0]w_rs2Data_id;

  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_100
       (.I0(MemDout_mem[13]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_119_n_0),
        .I3(MemDout_mem[17]),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_20 ));
  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_102
       (.I0(MemDout_mem[12]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_120_n_0),
        .I3(MemDout_mem[16]),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_21 ));
  LUT6 #(
    .INIT(64'h00000000474700FF)) 
    char_tab_i_116
       (.I0(MemDout_mem[6]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(MemDout_mem[2]),
        .I3(MemDout_mem[10]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_2 ),
        .O(char_tab_i_116_n_0));
  LUT6 #(
    .INIT(64'h00000000474700FF)) 
    char_tab_i_119
       (.I0(MemDout_mem[5]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(MemDout_mem[1]),
        .I3(MemDout_mem[9]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_2 ),
        .O(char_tab_i_119_n_0));
  LUT6 #(
    .INIT(64'h00000000474700FF)) 
    char_tab_i_120
       (.I0(MemDout_mem[4]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(MemDout_mem[0]),
        .I3(MemDout_mem[8]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_2 ),
        .O(char_tab_i_120_n_0));
  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_30
       (.I0(MemDout_mem[15]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_72_n_0),
        .I3(MemDout_mem[19]),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_18 ));
  LUT6 #(
    .INIT(64'h00000000474700FF)) 
    char_tab_i_72
       (.I0(MemDout_mem[7]),
        .I1(\PosX_reg_reg[4]_0 ),
        .I2(MemDout_mem[3]),
        .I3(MemDout_mem[11]),
        .I4(\PosX_reg_reg[4] ),
        .I5(\PosX_reg_reg[4]_2 ),
        .O(char_tab_i_72_n_0));
  LUT6 #(
    .INIT(64'h0000000000FFF4F4)) 
    char_tab_i_92
       (.I0(MemDout_mem[14]),
        .I1(\PosX_reg_reg[4]_2 ),
        .I2(char_tab_i_116_n_0),
        .I3(MemDout_mem[18]),
        .I4(\PosX_reg_reg[4]_3 ),
        .I5(\PosX_reg_reg[6]_0 ),
        .O(\TMDSn[2]_19 ));
  (* x_core_info = "dist_mem_gen_v8_0_12,Vivado 2017.3" *) 
  DataRAM u_DataRAM
       (.a({u_reg_EX_MEM_n_25,u_reg_EX_MEM_n_26,u_reg_EX_MEM_n_27,u_reg_EX_MEM_n_28,u_reg_EX_MEM_n_29,u_reg_EX_MEM_n_30}),
        .clk(cpu_clk_BUFG),
        .d(final_ram_write_data),
        .spo({\q_reg[54] ,MemDout_mem}),
        .we(r_MemWrite_mem));
  ID u_ID
       (.Instruction_id({\q_reg[46] [10],\q_reg[46] [8:6],Instruction_id[15]}),
        .Q({r_RegWrite_wb,u_reg_MEM_WB_n_100,u_reg_MEM_WB_n_101,u_reg_MEM_WB_n_102,u_reg_MEM_WB_n_103}),
        .ReadData10(ReadData10),
        .ReadData20(ReadData20),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .w_RegWriteData_wb(w_RegWriteData_wb));
  IF1 u_IF1
       (.D({u_IF1_n_1,u_IF1_n_2,u_IF1_n_3,u_IF1_n_4,u_IF1_n_5,u_IF1_n_6,u_IF1_n_7,u_IF1_n_8,u_IF1_n_9,u_IF1_n_10,u_IF1_n_11,u_IF1_n_12,u_IF1_n_13,u_IF1_n_14,u_IF1_n_15,u_IF1_n_16,u_IF1_n_17,u_IF1_n_18,u_IF1_n_19,u_IF1_n_20,u_IF1_n_21,u_IF1_n_22,u_IF1_n_23,u_IF1_n_24,PC[7],\q_reg[38] [2:1],PC[4:2],\q_reg[38] [0],PC[0],w_Instruction_if[27],w_Instruction_if[25],u_IF1_n_35,w_Instruction_if[21:20],w_Instruction_if[15:12],u_IF1_n_42,w_Instruction_if[9:5],u_IF1_n_48,w_Instruction_if[2],w_Instruction_if[0]}),
        .E(w_IFWrite),
        .JumpAddr({w_JumpAddr[31:29],w_JumpAddr[27:25],w_JumpAddr[23:21],w_JumpAddr[19:17],w_JumpAddr[15:13],w_JumpAddr[11:9],w_JumpAddr[7:4]}),
        .\PC_reg_reg[28]_0 ({Next_PC[28],Next_PC[24],Next_PC[20],Next_PC[16],Next_PC[12],Next_PC[8],Next_PC[3:0]}),
        .\PosX_reg_reg[4] (\PosX_reg_reg[4]_1 ),
        .\PosX_reg_reg[6] (\PosX_reg_reg[6] ),
        .SR(SR),
        .Stall(Stall),
        .\TMDSn[2] (\TMDSn[2]_0 ),
        .\TMDSn[2]_0 (\TMDSn[2]_22 ),
        .\TMDSn[2]_1 (\TMDSn[2]_23 ),
        .c2__0(\u_adder_pc/c2__0 ),
        .c3__0(\u_adder_pc/c3__0 ),
        .c4__0(\u_adder_pc/c4__0 ),
        .c5__0(\u_adder_pc/c5__0 ),
        .c6__0(\u_adder_pc/c6__0 ),
        .c7__0(\u_adder_pc/c7__0 ),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .w_IF_flush(w_IF_flush));
  DFF__parameterized1 u_reg_EX_MEM
       (.D({D[12],ALUResult[30],D[11:8],ALUResult[25],D[7:0],ALUResult[16:0],w_MemWriteData_ex[31:2],w_MemWriteData_ex[0]}),
        .Q({u_reg_EX_MEM_n_1,u_reg_EX_MEM_n_2,u_reg_EX_MEM_n_3,u_reg_EX_MEM_n_4,u_reg_EX_MEM_n_5,u_reg_EX_MEM_n_6,u_reg_EX_MEM_n_7,u_reg_EX_MEM_n_8,u_reg_EX_MEM_n_9,u_reg_EX_MEM_n_10,u_reg_EX_MEM_n_11,u_reg_EX_MEM_n_12,u_reg_EX_MEM_n_13,u_reg_EX_MEM_n_14,u_reg_EX_MEM_n_15,u_reg_EX_MEM_n_16,u_reg_EX_MEM_n_17,u_reg_EX_MEM_n_18,u_reg_EX_MEM_n_19,u_reg_EX_MEM_n_20,u_reg_EX_MEM_n_21,u_reg_EX_MEM_n_22,u_reg_EX_MEM_n_23,u_reg_EX_MEM_n_24,u_reg_EX_MEM_n_25,u_reg_EX_MEM_n_26,u_reg_EX_MEM_n_27,u_reg_EX_MEM_n_28,u_reg_EX_MEM_n_29,u_reg_EX_MEM_n_30,p_5_in,u_reg_EX_MEM_n_32,r_MemWrite_mem,r_RegWrite_mem,u_reg_EX_MEM_n_35,r_rdAddr_mem}),
        .SR(SR),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .d(final_ram_write_data),
        .\q_reg[12]_0 (u_reg_EX_MEM_n_40),
        .\q_reg[12]_1 (u_reg_EX_MEM_n_41),
        .\q_reg[12]_2 (u_reg_EX_MEM_n_42),
        .\q_reg[155] ({u_reg_ID_EX_n_92,u_reg_ID_EX_n_93,r_MemRead_ex,r_ALUSrcA_ex,r_rs2Data_ex,r_rs1Addr_ex,r_rs2Addr_ex[4],r_rs2Addr_ex[1:0],r_rdAddr_ex,u_reg_ID_EX_n_121,u_reg_ID_EX_n_122,u_reg_ID_EX_n_123}),
        .\q_reg[44]_0 (u_reg_EX_MEM_n_45),
        .\q_reg[44]_1 (u_reg_EX_MEM_n_46),
        .\q_reg[44]_2 (u_reg_EX_MEM_n_47),
        .\q_reg[44]_3 (u_reg_EX_MEM_n_52),
        .\q_reg[44]_4 (u_reg_ID_EX_n_126),
        .\q_reg[48]_0 (u_reg_EX_MEM_n_0),
        .\q_reg[50]_0 (u_reg_EX_MEM_n_48),
        .\q_reg[50]_1 (u_reg_EX_MEM_n_49),
        .\q_reg[51]_0 (u_reg_EX_MEM_n_50),
        .\q_reg[52]_0 (u_reg_EX_MEM_n_51),
        .\q_reg[55]_0 (u_reg_EX_MEM_n_44),
        .\q_reg[59]_0 (u_reg_EX_MEM_n_43),
        .\q_reg[70]_0 (final_mem_read_data),
        .spo({\q_reg[54] ,MemDout_mem}),
        .w_RegWriteData_wb(w_RegWriteData_wb[1]));
  DFF__parameterized0 u_reg_ID_EX
       (.D({D[12],ALUResult[30],D[11:8],ALUResult[25],D[7:0],ALUResult[16:0],w_MemWriteData_ex[31:2],w_MemWriteData_ex[0]}),
        .E(w_IFWrite),
        .\PosX_reg_reg[4] (\PosX_reg_reg[4] ),
        .\PosX_reg_reg[4]_0 (\PosX_reg_reg[4]_2 ),
        .\PosX_reg_reg[4]_1 (\PosX_reg_reg[4]_3 ),
        .\PosX_reg_reg[4]_2 (\PosX_reg_reg[4]_0 ),
        .\PosX_reg_reg[4]_3 (\PosX_reg_reg[4]_1 ),
        .\PosX_reg_reg[6] (\PosX_reg_reg[6] ),
        .\PosX_reg_reg[6]_0 (\PosX_reg_reg[6]_0 ),
        .Q({u_reg_ID_EX_n_92,u_reg_ID_EX_n_93,r_MemRead_ex,r_ALUSrcA_ex,r_rs1Data_ex[30:29],r_rs1Data_ex[27:26],r_rs1Data_ex[23:20],r_rs1Data_ex[17:14],r_rs1Data_ex[12],r_rs1Data_ex[10],r_rs1Data_ex[2],r_rs2Data_ex,r_rs1Addr_ex,r_rs2Addr_ex[4],r_rs2Addr_ex[1:0],r_rdAddr_ex,u_reg_ID_EX_n_121,u_reg_ID_EX_n_122,u_reg_ID_EX_n_123}),
        .SR(SR),
        .Stall(Stall),
        .\TMDSn[2] (\TMDSn[2]_1 ),
        .\TMDSn[2]_0 (\TMDSn[2]_2 ),
        .\TMDSn[2]_1 (\TMDSn[2]_3 ),
        .\TMDSn[2]_10 (\TMDSn[2]_12 ),
        .\TMDSn[2]_11 (\TMDSn[2]_13 ),
        .\TMDSn[2]_12 (\TMDSn[2]_14 ),
        .\TMDSn[2]_13 (\TMDSn[2]_15 ),
        .\TMDSn[2]_2 (\TMDSn[2]_4 ),
        .\TMDSn[2]_3 (\TMDSn[2]_5 ),
        .\TMDSn[2]_4 (\TMDSn[2]_6 ),
        .\TMDSn[2]_5 (\TMDSn[2]_7 ),
        .\TMDSn[2]_6 (\TMDSn[2]_8 ),
        .\TMDSn[2]_7 (\TMDSn[2]_9 ),
        .\TMDSn[2]_8 (\TMDSn[2]_10 ),
        .\TMDSn[2]_9 (\TMDSn[2]_11 ),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[11]_0 (u_reg_ID_EX_n_126),
        .\q_reg[11]_1 (u_reg_ID_EX_n_127),
        .\q_reg[11]_2 (u_reg_ID_EX_n_128),
        .\q_reg[148]_0 (u_reg_EX_MEM_n_45),
        .\q_reg[148]_1 (u_reg_EX_MEM_n_47),
        .\q_reg[148]_10 (u_reg_MEM_WB_n_113),
        .\q_reg[148]_11 (u_reg_MEM_WB_n_114),
        .\q_reg[148]_12 (u_reg_MEM_WB_n_115),
        .\q_reg[148]_13 (u_reg_MEM_WB_n_116),
        .\q_reg[148]_14 (u_reg_MEM_WB_n_117),
        .\q_reg[148]_15 (u_reg_MEM_WB_n_118),
        .\q_reg[148]_16 (u_reg_MEM_WB_n_119),
        .\q_reg[148]_17 (u_reg_MEM_WB_n_120),
        .\q_reg[148]_18 (u_reg_MEM_WB_n_121),
        .\q_reg[148]_19 (u_reg_MEM_WB_n_122),
        .\q_reg[148]_2 (u_reg_MEM_WB_n_107),
        .\q_reg[148]_3 (u_reg_EX_MEM_n_48),
        .\q_reg[148]_4 (u_reg_EX_MEM_n_49),
        .\q_reg[148]_5 (u_reg_EX_MEM_n_50),
        .\q_reg[148]_6 (u_reg_EX_MEM_n_51),
        .\q_reg[148]_7 (u_reg_MEM_WB_n_110),
        .\q_reg[148]_8 (u_reg_MEM_WB_n_111),
        .\q_reg[148]_9 (u_reg_MEM_WB_n_112),
        .\q_reg[1]_0 (u_reg_MEM_WB_n_102),
        .\q_reg[2]_0 (u_reg_MEM_WB_n_106),
        .\q_reg[39] (u_reg_MEM_WB_n_124),
        .\q_reg[40]_0 (u_reg_MEM_WB_n_125),
        .\q_reg[43] (u_reg_EX_MEM_n_0),
        .\q_reg[44]_0 (u_reg_MEM_WB_n_109),
        .\q_reg[44]_1 (u_reg_EX_MEM_n_42),
        .\q_reg[44]_2 (u_reg_EX_MEM_n_43),
        .\q_reg[45]_0 (u_reg_MEM_WB_n_126),
        .\q_reg[49] (u_reg_EX_MEM_n_44),
        .\q_reg[4]_0 (u_reg_EX_MEM_n_52),
        .\q_reg[54]_0 (u_reg_MEM_WB_n_123),
        .\q_reg[5]_0 (u_reg_EX_MEM_n_40),
        .\q_reg[63]_0 (\q_reg[74] [0]),
        .\q_reg[64]_0 (\q_reg[74] [1]),
        .\q_reg[65]_0 (\q_reg[74] [2]),
        .\q_reg[66]_0 (\q_reg[74] [3]),
        .\q_reg[67]_0 (\q_reg[74] [4]),
        .\q_reg[67]_1 (\q_reg[67] ),
        .\q_reg[68]_0 (\q_reg[74] [5]),
        .\q_reg[69]_0 (\q_reg[74] [6]),
        .\q_reg[6]_0 (u_reg_MEM_WB_n_108),
        .\q_reg[6]_1 ({w_RegWrite_id,w_MemWrite_id,w_MemRead_id,w_ALUCode_id,w_ALUSrcA_id,JumpFlag,w_ALUSrcB_id,w_Imm_id[25],u_reg_IF_ID_n_12,u_reg_IF_ID_n_13,u_reg_IF_ID_n_14,w_Imm_id[16],u_reg_IF_ID_n_16,u_reg_IF_ID_n_17,u_reg_IF_ID_n_18,u_reg_IF_ID_n_19,w_Imm_id[7:5],u_reg_IF_ID_n_23,w_Imm_id[3:0],w_rs1Data_id,w_rs2Data_id,\q_reg[46] [10],Instruction_id[15],\q_reg[46] [8:6],Instruction_id[10],\q_reg[46] [3:2],Instruction_id[7],r_PC_id,Instruction_id[14],\q_reg[46] [5:4]}),
        .\q_reg[6]_2 (u_reg_MEM_WB_n_104),
        .\q_reg[6]_3 (u_reg_MEM_WB_n_105),
        .\q_reg[70]_0 (\q_reg[74] [7]),
        .\q_reg[71]_0 (\q_reg[74] [8]),
        .\q_reg[71]_1 (\q_reg[71] ),
        .\q_reg[72]_0 (\q_reg[74] [9]),
        .\q_reg[73]_0 (\q_reg[74] [10]),
        .\q_reg[74]_0 (\q_reg[74] [11]),
        .\q_reg[74]_1 ({u_reg_EX_MEM_n_1,u_reg_EX_MEM_n_2,u_reg_EX_MEM_n_3,u_reg_EX_MEM_n_4,u_reg_EX_MEM_n_5,u_reg_EX_MEM_n_6,u_reg_EX_MEM_n_7,u_reg_EX_MEM_n_8,u_reg_EX_MEM_n_9,u_reg_EX_MEM_n_10,u_reg_EX_MEM_n_11,u_reg_EX_MEM_n_12,u_reg_EX_MEM_n_13,u_reg_EX_MEM_n_14,u_reg_EX_MEM_n_15,u_reg_EX_MEM_n_16,u_reg_EX_MEM_n_17,u_reg_EX_MEM_n_18,u_reg_EX_MEM_n_19,u_reg_EX_MEM_n_20,u_reg_EX_MEM_n_21,u_reg_EX_MEM_n_22,u_reg_EX_MEM_n_23,u_reg_EX_MEM_n_24,u_reg_EX_MEM_n_25,u_reg_EX_MEM_n_26,u_reg_EX_MEM_n_27,u_reg_EX_MEM_n_28,u_reg_EX_MEM_n_29,u_reg_EX_MEM_n_30,u_reg_EX_MEM_n_32,r_rdAddr_mem[0]}),
        .w_RegWriteData_wb(w_RegWriteData_wb));
  DFF u_reg_IF_ID
       (.D({u_IF1_n_1,u_IF1_n_2,u_IF1_n_3,u_IF1_n_4,u_IF1_n_5,u_IF1_n_6,u_IF1_n_7,u_IF1_n_8,u_IF1_n_9,u_IF1_n_10,u_IF1_n_11,u_IF1_n_12,u_IF1_n_13,u_IF1_n_14,u_IF1_n_15,u_IF1_n_16,u_IF1_n_17,u_IF1_n_18,u_IF1_n_19,u_IF1_n_20,u_IF1_n_21,u_IF1_n_22,u_IF1_n_23,u_IF1_n_24,PC[7],\q_reg[38] [2:1],PC[4:2],\q_reg[38] [0],PC[0],w_Instruction_if[27],w_Instruction_if[25],u_IF1_n_35,w_Instruction_if[21:20],w_Instruction_if[15:12],u_IF1_n_42,w_Instruction_if[9:5],u_IF1_n_48,w_Instruction_if[2],w_Instruction_if[0]}),
        .E(w_IFWrite),
        .JumpAddr({w_JumpAddr[31:29],w_JumpAddr[27:25],w_JumpAddr[23:21],w_JumpAddr[19:17],w_JumpAddr[15:13],w_JumpAddr[11:9],w_JumpAddr[7:4]}),
        .\PC_reg_reg[28] ({Next_PC[28],Next_PC[24],Next_PC[20],Next_PC[16],Next_PC[12],Next_PC[8],Next_PC[3:0]}),
        .\PC_reg_reg[8] (\PC_reg_reg[8] ),
        .\PosX_reg_reg[4] (\PosX_reg_reg[4] ),
        .\PosX_reg_reg[4]_0 (\PosX_reg_reg[4]_0 ),
        .\PosX_reg_reg[4]_1 (\PosX_reg_reg[4]_2 ),
        .\PosX_reg_reg[4]_2 (\PosX_reg_reg[4]_4 ),
        .\PosX_reg_reg[5] (\PosX_reg_reg[5] ),
        .\PosX_reg_reg[6] (\PosX_reg_reg[6]_0 ),
        .Q({\q_reg[46] [9],\q_reg[46] [1:0]}),
        .ReadData10(ReadData10[9:8]),
        .SR(SR),
        .\TMDSn[2] (\TMDSn[2] ),
        .\TMDSn[2]_0 (\TMDSn[2]_16 ),
        .\TMDSn[2]_1 (\TMDSn[2]_17 ),
        .c2__0(\u_adder_pc/c2__0 ),
        .c3__0(\u_adder_pc/c3__0 ),
        .c4__0(\u_adder_pc/c4__0 ),
        .c5__0(\u_adder_pc/c5__0 ),
        .c6__0(\u_adder_pc/c6__0 ),
        .c7__0(\u_adder_pc/c7__0 ),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[155] ({w_RegWrite_id,w_MemWrite_id,w_MemRead_id,w_ALUCode_id,w_ALUSrcA_id,JumpFlag,w_ALUSrcB_id,w_Imm_id[25],u_reg_IF_ID_n_12,u_reg_IF_ID_n_13,u_reg_IF_ID_n_14,w_Imm_id[16],u_reg_IF_ID_n_16,u_reg_IF_ID_n_17,u_reg_IF_ID_n_18,u_reg_IF_ID_n_19,w_Imm_id[7:5],u_reg_IF_ID_n_23,w_Imm_id[3:0],\q_reg[46] [10],Instruction_id[15],\q_reg[46] [8:6],Instruction_id[10],\q_reg[46] [3:2],Instruction_id[7],r_PC_id,Instruction_id[14],\q_reg[46] [5:4]}),
        .\q_reg[15]_0 (u_reg_MEM_WB_n_98),
        .\q_reg[23]_0 (\q_reg[23] ),
        .\q_reg[68] (u_reg_MEM_WB_n_65),
        .\q_reg[69] (u_reg_MEM_WB_n_0),
        .\q_reg[70] ({w_rs1Data_id[31:10],w_rs1Data_id[7:0],w_rs2Data_id[31]}),
        .\q_reg[78] (u_reg_IF_ID_n_112),
        .\q_reg[85] (u_reg_IF_ID_n_111),
        .w_IF_flush(w_IF_flush),
        .w_RegWriteData_wb(w_RegWriteData_wb[9:8]));
  DFF__parameterized2 u_reg_MEM_WB
       (.D(final_mem_read_data),
        .\PC_reg_reg[8] (u_reg_MEM_WB_n_0),
        .\PC_reg_reg[8]_0 (u_reg_MEM_WB_n_65),
        .Q({r_RegWrite_wb,u_reg_MEM_WB_n_100,u_reg_MEM_WB_n_101,u_reg_MEM_WB_n_102,u_reg_MEM_WB_n_103}),
        .ReadData10(ReadData10),
        .ReadData20(ReadData20),
        .SR(SR),
        .cpu_clk_BUFG(cpu_clk_BUFG),
        .\q_reg[113] ({w_rs1Data_id,w_rs2Data_id}),
        .\q_reg[11]_0 (u_reg_MEM_WB_n_105),
        .\q_reg[11]_1 (u_reg_MEM_WB_n_106),
        .\q_reg[148] ({r_ALUSrcA_ex,r_rs1Data_ex[30:29],r_rs1Data_ex[27:26],r_rs1Data_ex[23:20],r_rs1Data_ex[17:14],r_rs1Data_ex[12],r_rs1Data_ex[10],r_rs1Data_ex[2],r_rs1Addr_ex,r_rs2Addr_ex[4],r_rs2Addr_ex[0]}),
        .\q_reg[21]_0 (u_reg_IF_ID_n_112),
        .\q_reg[27]_0 ({\q_reg[46] [10],Instruction_id[15],\q_reg[46] [8:6]}),
        .\q_reg[27]_1 (u_reg_IF_ID_n_111),
        .\q_reg[44]_0 (u_reg_MEM_WB_n_108),
        .\q_reg[44]_1 (u_reg_ID_EX_n_128),
        .\q_reg[44]_2 (u_reg_ID_EX_n_127),
        .\q_reg[45]_0 (u_reg_MEM_WB_n_107),
        .\q_reg[46]_0 (u_reg_EX_MEM_n_46),
        .\q_reg[48]_0 (u_reg_MEM_WB_n_104),
        .\q_reg[48]_1 (u_reg_MEM_WB_n_109),
        .\q_reg[48]_2 (u_reg_MEM_WB_n_124),
        .\q_reg[4] (u_reg_EX_MEM_n_52),
        .\q_reg[53]_0 (u_reg_MEM_WB_n_110),
        .\q_reg[55]_0 (u_reg_MEM_WB_n_111),
        .\q_reg[55]_1 (u_reg_MEM_WB_n_126),
        .\q_reg[57]_0 (u_reg_MEM_WB_n_112),
        .\q_reg[58]_0 (u_reg_MEM_WB_n_123),
        .\q_reg[59]_0 (u_reg_MEM_WB_n_113),
        .\q_reg[59]_1 (u_reg_MEM_WB_n_125),
        .\q_reg[5]_0 (u_reg_EX_MEM_n_40),
        .\q_reg[60]_0 (u_reg_MEM_WB_n_114),
        .\q_reg[63]_0 (u_reg_MEM_WB_n_115),
        .\q_reg[64]_0 (u_reg_MEM_WB_n_116),
        .\q_reg[65]_0 (u_reg_MEM_WB_n_117),
        .\q_reg[66]_0 (u_reg_MEM_WB_n_118),
        .\q_reg[69]_0 (u_reg_MEM_WB_n_119),
        .\q_reg[70]_0 (u_reg_MEM_WB_n_120),
        .\q_reg[72] (u_reg_MEM_WB_n_121),
        .\q_reg[73] (u_reg_MEM_WB_n_122),
        .\q_reg[74] ({u_reg_EX_MEM_n_1,u_reg_EX_MEM_n_2,u_reg_EX_MEM_n_3,u_reg_EX_MEM_n_4,u_reg_EX_MEM_n_5,u_reg_EX_MEM_n_6,u_reg_EX_MEM_n_7,u_reg_EX_MEM_n_8,u_reg_EX_MEM_n_9,u_reg_EX_MEM_n_10,u_reg_EX_MEM_n_11,u_reg_EX_MEM_n_12,u_reg_EX_MEM_n_13,u_reg_EX_MEM_n_14,u_reg_EX_MEM_n_15,u_reg_EX_MEM_n_16,u_reg_EX_MEM_n_17,u_reg_EX_MEM_n_18,u_reg_EX_MEM_n_19,u_reg_EX_MEM_n_20,u_reg_EX_MEM_n_21,u_reg_EX_MEM_n_22,u_reg_EX_MEM_n_23,u_reg_EX_MEM_n_24,u_reg_EX_MEM_n_25,u_reg_EX_MEM_n_26,u_reg_EX_MEM_n_27,u_reg_EX_MEM_n_28,u_reg_EX_MEM_n_29,u_reg_EX_MEM_n_30,p_5_in,u_reg_EX_MEM_n_32,r_RegWrite_mem,u_reg_EX_MEM_n_35,r_rdAddr_mem}),
        .\q_reg[85] (u_reg_MEM_WB_n_98),
        .\q_reg[9]_0 (u_reg_EX_MEM_n_41),
        .w_RegWriteData_wb(w_RegWriteData_wb));
endmodule

module TMDSencode
   (ActiveArea,
    TMDSch0,
    TMDSch1,
    TMDSch2,
    hSync,
    pixel_clk,
    reset,
    tmds_clk,
    vSync,
    blue,
    green,
    red,
    lopt);
  input ActiveArea;
  output TMDSch0;
  output TMDSch1;
  output TMDSch2;
  input hSync;
  input pixel_clk;
  input reset;
  input tmds_clk;
  input vSync;
  input [7:0]blue;
  input [7:0]green;
  input [7:0]red;
  input lopt;

  wire ActiveArea;
  wire TMDSch0_OBUF;
  wire TMDSch0_i_1_n_0;
  wire TMDSch0_i_2_n_0;
  wire TMDSch0_i_4_n_0;
  wire TMDSch0_i_5_n_0;
  wire TMDSch0_reg_i_3_n_0;
  wire TMDSch1_OBUF;
  wire TMDSch1_i_1_n_0;
  wire TMDSch1_i_3_n_0;
  wire TMDSch1_i_4_n_0;
  wire TMDSch1_reg_i_2_n_0;
  wire TMDSch2_OBUF;
  wire TMDSch2_i_1_n_0;
  wire TMDSch2_i_3_n_0;
  wire TMDSch2_i_4_n_0;
  wire TMDSch2_reg_i_2_n_0;
  wire [9:0]TmdsBlue;
  wire [9:0]TmdsGreen;
  wire [9:0]TmdsRed;
  wire [3:0]bit_q_reg__0;
  wire [4:4]bit_q_reg__1;
  wire clear;
  wire encode_blue_n_0;
  wire encode_blue_n_1;
  wire encode_blue_n_10;
  wire encode_blue_n_2;
  wire encode_blue_n_3;
  wire encode_blue_n_4;
  wire encode_blue_n_5;
  wire encode_blue_n_6;
  wire encode_blue_n_7;
  wire encode_blue_n_8;
  wire encode_blue_n_9;
  wire encode_green_n_0;
  wire encode_green_n_1;
  wire encode_green_n_2;
  wire encode_green_n_3;
  wire encode_green_n_4;
  wire encode_green_n_5;
  wire encode_green_n_6;
  wire encode_green_n_7;
  wire encode_green_n_8;
  wire encode_green_n_9;
  wire encode_red_n_0;
  wire encode_red_n_1;
  wire encode_red_n_2;
  wire encode_red_n_3;
  wire encode_red_n_4;
  wire encode_red_n_5;
  wire encode_red_n_6;
  wire encode_red_n_7;
  wire encode_red_n_8;
  wire encode_red_n_9;
  wire [7:0]green;
  wire hSync;
  wire lopt;
  wire [4:0]p_0_in;
  wire [7:0]red;
  wire reset;
  wire tmds_clk;
  wire tmds_clk_IBUF_BUFG;
  wire vSync;
  wire [7:0]NLW_encode_blue_blue_IBUF_UNCONNECTED;
  wire [7:5]NLW_encode_green_green_IBUF_UNCONNECTED;
  wire [7:5]NLW_encode_red_red_IBUF_UNCONNECTED;

  assign TMDSch0 = TMDSch0_OBUF;
  assign TMDSch1 = TMDSch1_OBUF;
  assign TMDSch2 = TMDSch2_OBUF;
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch0_i_1
       (.I0(TmdsBlue[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsBlue[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch0_reg_i_3_n_0),
        .O(TMDSch0_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    TMDSch0_i_2
       (.I0(bit_q_reg__0[2]),
        .I1(bit_q_reg__0[1]),
        .O(TMDSch0_i_2_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch0_i_4
       (.I0(TmdsBlue[3]),
        .I1(TmdsBlue[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsBlue[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsBlue[0]),
        .O(TMDSch0_i_4_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch0_i_5
       (.I0(TmdsBlue[7]),
        .I1(TmdsBlue[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsBlue[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsBlue[4]),
        .O(TMDSch0_i_5_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch0_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch0_i_1_n_0),
        .Q(TMDSch0_OBUF),
        .R(1'b0));
  MUXF7 TMDSch0_reg_i_3
       (.I0(TMDSch0_i_4_n_0),
        .I1(TMDSch0_i_5_n_0),
        .O(TMDSch0_reg_i_3_n_0),
        .S(bit_q_reg__0[2]));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch1_i_1
       (.I0(TmdsGreen[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsGreen[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch1_reg_i_2_n_0),
        .O(TMDSch1_i_1_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch1_i_3
       (.I0(TmdsGreen[3]),
        .I1(TmdsGreen[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsGreen[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsGreen[0]),
        .O(TMDSch1_i_3_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch1_i_4
       (.I0(TmdsGreen[7]),
        .I1(TmdsGreen[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsGreen[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsGreen[4]),
        .O(TMDSch1_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch1_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch1_i_1_n_0),
        .Q(TMDSch1_OBUF),
        .R(1'b0));
  MUXF7 TMDSch1_reg_i_2
       (.I0(TMDSch1_i_3_n_0),
        .I1(TMDSch1_i_4_n_0),
        .O(TMDSch1_reg_i_2_n_0),
        .S(bit_q_reg__0[2]));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    TMDSch2_i_1
       (.I0(TmdsRed[8]),
        .I1(bit_q_reg__0[0]),
        .I2(TmdsRed[9]),
        .I3(TMDSch0_i_2_n_0),
        .I4(bit_q_reg__0[3]),
        .I5(TMDSch2_reg_i_2_n_0),
        .O(TMDSch2_i_1_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch2_i_3
       (.I0(TmdsRed[3]),
        .I1(TmdsRed[2]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsRed[1]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsRed[0]),
        .O(TMDSch2_i_3_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    TMDSch2_i_4
       (.I0(TmdsRed[7]),
        .I1(TmdsRed[6]),
        .I2(bit_q_reg__0[1]),
        .I3(TmdsRed[5]),
        .I4(bit_q_reg__0[0]),
        .I5(TmdsRed[4]),
        .O(TMDSch2_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    TMDSch2_reg
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(TMDSch2_i_1_n_0),
        .Q(TMDSch2_OBUF),
        .R(1'b0));
  MUXF7 TMDSch2_reg_i_2
       (.I0(TMDSch2_i_3_n_0),
        .I1(TMDSch2_i_4_n_0),
        .O(TMDSch2_reg_i_2_n_0),
        .S(bit_q_reg__0[2]));
  LUT5 #(
    .INIT(32'h01000000)) 
    \TmdsBlue[9]_i_1 
       (.I0(bit_q_reg__1),
        .I1(bit_q_reg__0[2]),
        .I2(bit_q_reg__0[1]),
        .I3(bit_q_reg__0[0]),
        .I4(bit_q_reg__0[3]),
        .O(clear));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_10),
        .Q(TmdsBlue[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_9),
        .Q(TmdsBlue[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_8),
        .Q(TmdsBlue[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_7),
        .Q(TmdsBlue[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_6),
        .Q(TmdsBlue[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_5),
        .Q(TmdsBlue[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_4),
        .Q(TmdsBlue[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_3),
        .Q(TmdsBlue[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_2),
        .Q(TmdsBlue[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsBlue_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_blue_n_1),
        .Q(TmdsBlue[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_9),
        .Q(TmdsGreen[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_8),
        .Q(TmdsGreen[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_7),
        .Q(TmdsGreen[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_6),
        .Q(TmdsGreen[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_5),
        .Q(TmdsGreen[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_4),
        .Q(TmdsGreen[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_3),
        .Q(TmdsGreen[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_2),
        .Q(TmdsGreen[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_1),
        .Q(TmdsGreen[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsGreen_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_green_n_0),
        .Q(TmdsGreen[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_9),
        .Q(TmdsRed[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_8),
        .Q(TmdsRed[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_7),
        .Q(TmdsRed[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_6),
        .Q(TmdsRed[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_5),
        .Q(TmdsRed[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[5] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_4),
        .Q(TmdsRed[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[6] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_3),
        .Q(TmdsRed[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[7] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_2),
        .Q(TmdsRed[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[8] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_1),
        .Q(TmdsRed[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \TmdsRed_reg[9] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(clear),
        .D(encode_red_n_0),
        .Q(TmdsRed[9]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \bit_q[0]_i_1 
       (.I0(bit_q_reg__0[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bit_q[1]_i_1 
       (.I0(bit_q_reg__0[0]),
        .I1(bit_q_reg__0[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bit_q[2]_i_1 
       (.I0(bit_q_reg__0[0]),
        .I1(bit_q_reg__0[1]),
        .I2(bit_q_reg__0[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \bit_q[3]_i_1 
       (.I0(bit_q_reg__0[1]),
        .I1(bit_q_reg__0[0]),
        .I2(bit_q_reg__0[2]),
        .I3(bit_q_reg__0[3]),
        .O(p_0_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \bit_q[4]_i_1 
       (.I0(bit_q_reg__0[2]),
        .I1(bit_q_reg__0[0]),
        .I2(bit_q_reg__0[1]),
        .I3(bit_q_reg__0[3]),
        .I4(bit_q_reg__1),
        .O(p_0_in[4]));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[0] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(bit_q_reg__0[0]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[1] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(bit_q_reg__0[1]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[2] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(bit_q_reg__0[2]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[3] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(bit_q_reg__0[3]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \bit_q_reg[4] 
       (.C(tmds_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(bit_q_reg__1),
        .R(clear));
  encode encode_blue
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_blue_n_1,encode_blue_n_2,encode_blue_n_3,encode_blue_n_4,encode_blue_n_5,encode_blue_n_6,encode_blue_n_7,encode_blue_n_8,encode_blue_n_9,encode_blue_n_10}),
        .SR(encode_blue_n_0),
        .blue_IBUF(NLW_encode_blue_blue_IBUF_UNCONNECTED[7:0]),
        .hSync_IBUF(hSync),
        .pixel_clk_IBUF_BUFG(lopt),
        .reset_IBUF(reset),
        .vSync_IBUF(vSync));
  encode_0 encode_green
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_green_n_0,encode_green_n_1,encode_green_n_2,encode_green_n_3,encode_green_n_4,encode_green_n_5,encode_green_n_6,encode_green_n_7,encode_green_n_8,encode_green_n_9}),
        .SR(encode_blue_n_0),
        .green_IBUF({NLW_encode_green_green_IBUF_UNCONNECTED[7],green[6],NLW_encode_green_green_IBUF_UNCONNECTED[5],green[4:0]}),
        .pixel_clk_IBUF_BUFG(lopt),
        .reset_IBUF(reset));
  encode_1 encode_red
       (.ActiveArea_IBUF(ActiveArea),
        .D({encode_red_n_0,encode_red_n_1,encode_red_n_2,encode_red_n_3,encode_red_n_4,encode_red_n_5,encode_red_n_6,encode_red_n_7,encode_red_n_8,encode_red_n_9}),
        .SR(encode_blue_n_0),
        .pixel_clk_IBUF_BUFG(lopt),
        .red_IBUF({NLW_encode_red_red_IBUF_UNCONNECTED[7],red[6],NLW_encode_red_red_IBUF_UNCONNECTED[5],red[4:0]}),
        .reset_IBUF(reset));
  BUFG tmds_clk_IBUF_BUFG_inst
       (.I(tmds_clk),
        .O(tmds_clk_IBUF_BUFG));
endmodule

module brute_force_synchronizer
   (ButtonIn_IBUF,
    button_sync,
    clk_IBUF_BUFG);
  input ButtonIn_IBUF;
  output button_sync;
  input clk_IBUF_BUFG;

  wire ButtonIn_IBUF;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire ff1_n_0;

  dff ff1
       (.ButtonIn_IBUF(ButtonIn_IBUF),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[0]_0 (ff1_n_0));
  dff_0 ff2
       (.button_sync(button_sync),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[0]_0 (ff1_n_0));
endmodule

(* sim = "0" *) 
module button_process_unit
   (ButtonIn,
    ButtonOut,
    clk,
    reset,
    lopt);
  input ButtonIn;
  output ButtonOut;
  input clk;
  input reset;
  input lopt;

  wire ButtonIn;
  wire ButtonOut_OBUF;
  wire button_debounced;
  wire button_sync;
  wire last_value;
  wire lopt;
  wire NLW_debounce_reset_IBUF_UNCONNECTED;

  assign ButtonOut = ButtonOut_OBUF;
  debouncer debounce
       (.ButtonOut_OBUF(ButtonOut_OBUF),
        .button_debounced(button_debounced),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(lopt),
        .last_value(last_value),
        .reset_IBUF(NLW_debounce_reset_IBUF_UNCONNECTED));
  one_pulse one_pulse_inst
       (.button_debounced(button_debounced),
        .clk_IBUF_BUFG(lopt),
        .last_value(last_value));
  brute_force_synchronizer sync
       (.ButtonIn_IBUF(ButtonIn),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(lopt));
endmodule

module counter_n
   (clk_IBUF_BUFG,
    E);
  input clk_IBUF_BUFG;
  output [0:0]E;

  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire [16:1]data0;
  wire [0:0]q;
  wire q0_carry__0_n_0;
  wire q0_carry__1_n_0;
  wire q0_carry_n_0;
  wire \q[16]_i_2_n_0 ;
  wire \q[16]_i_3_n_0 ;
  wire \q[16]_i_4_n_0 ;
  wire \q[16]_i_5_n_0 ;
  wire [16:0]q_reg_n_0_;
  wire [2:0]NLW_q0_carry_CO_UNCONNECTED;
  wire [2:0]NLW_q0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_q0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_q0_carry__2_CO_UNCONNECTED;

  CARRY4 q0_carry
       (.CI(1'b0),
        .CO({q0_carry_n_0,NLW_q0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(q_reg_n_0_[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(q_reg_n_0_[4:1]));
  CARRY4 q0_carry__0
       (.CI(q0_carry_n_0),
        .CO({q0_carry__0_n_0,NLW_q0_carry__0_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(q_reg_n_0_[8:5]));
  CARRY4 q0_carry__1
       (.CI(q0_carry__0_n_0),
        .CO({q0_carry__1_n_0,NLW_q0_carry__1_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(q_reg_n_0_[12:9]));
  CARRY4 q0_carry__2
       (.CI(q0_carry__1_n_0),
        .CO(NLW_q0_carry__2_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(q_reg_n_0_[16:13]));
  LUT1 #(
    .INIT(2'h1)) 
    \q[0]_i_1__1 
       (.I0(q_reg_n_0_[0]),
        .O(q));
  LUT4 #(
    .INIT(16'h0001)) 
    \q[16]_i_1 
       (.I0(\q[16]_i_2_n_0 ),
        .I1(\q[16]_i_3_n_0 ),
        .I2(\q[16]_i_4_n_0 ),
        .I3(\q[16]_i_5_n_0 ),
        .O(E));
  LUT4 #(
    .INIT(16'hFFF7)) 
    \q[16]_i_2 
       (.I0(q_reg_n_0_[4]),
        .I1(q_reg_n_0_[3]),
        .I2(q_reg_n_0_[6]),
        .I3(q_reg_n_0_[5]),
        .O(\q[16]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \q[16]_i_3 
       (.I0(q_reg_n_0_[0]),
        .I1(q_reg_n_0_[15]),
        .I2(q_reg_n_0_[16]),
        .I3(q_reg_n_0_[2]),
        .I4(q_reg_n_0_[1]),
        .O(\q[16]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[16]_i_4 
       (.I0(q_reg_n_0_[12]),
        .I1(q_reg_n_0_[11]),
        .I2(q_reg_n_0_[14]),
        .I3(q_reg_n_0_[13]),
        .O(\q[16]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hDFFF)) 
    \q[16]_i_5 
       (.I0(q_reg_n_0_[7]),
        .I1(q_reg_n_0_[8]),
        .I2(q_reg_n_0_[10]),
        .I3(q_reg_n_0_[9]),
        .O(\q[16]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q),
        .Q(q_reg_n_0_[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[10]),
        .Q(q_reg_n_0_[10]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[11]),
        .Q(q_reg_n_0_[11]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[12]),
        .Q(q_reg_n_0_[12]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[13]),
        .Q(q_reg_n_0_[13]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[14]),
        .Q(q_reg_n_0_[14]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[15]),
        .Q(q_reg_n_0_[15]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[16]),
        .Q(q_reg_n_0_[16]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[1]),
        .Q(q_reg_n_0_[1]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[2]),
        .Q(q_reg_n_0_[2]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[3]),
        .Q(q_reg_n_0_[3]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[4]),
        .Q(q_reg_n_0_[4]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[5]),
        .Q(q_reg_n_0_[5]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[6]),
        .Q(q_reg_n_0_[6]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[7]),
        .Q(q_reg_n_0_[7]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[8]),
        .Q(q_reg_n_0_[8]),
        .R(E));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(data0[9]),
        .Q(q_reg_n_0_[9]),
        .R(E));
endmodule

module debouncer
   (ButtonOut_OBUF,
    button_debounced,
    button_sync,
    clk_IBUF_BUFG,
    last_value,
    reset_IBUF);
  output ButtonOut_OBUF;
  output button_debounced;
  input button_sync;
  input clk_IBUF_BUFG;
  input last_value;
  input reset_IBUF;

  wire ButtonOut_OBUF;
  wire button_debounced;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire counter_n_0;
  wire div_inst_n_0;
  wire last_value;
  wire state_n_0;
  wire NLW_state_reset_IBUF_UNCONNECTED;

  dffre counter
       (.E(div_inst_n_0),
        .SR(state_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\q_reg[1]_0 (counter_n_0));
  counter_n div_inst
       (.E(div_inst_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG));
  dffre__parameterized0 state
       (.ButtonOut_OBUF(ButtonOut_OBUF),
        .SR(state_n_0),
        .button_debounced(button_debounced),
        .button_sync(button_sync),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .last_value(last_value),
        .\q_reg[1]_0 (counter_n_0),
        .reset_IBUF(NLW_state_reset_IBUF_UNCONNECTED));
endmodule

module dff
   (ButtonIn_IBUF,
    clk_IBUF_BUFG,
    \q_reg[0]_0 );
  input ButtonIn_IBUF;
  input clk_IBUF_BUFG;
  output \q_reg[0]_0 ;

  wire ButtonIn_IBUF;
  wire clk_IBUF_BUFG;
  wire \q_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(ButtonIn_IBUF),
        .Q(\q_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module dff_0
   (button_sync,
    clk_IBUF_BUFG,
    \q_reg[0]_0 );
  output button_sync;
  input clk_IBUF_BUFG;
  input \q_reg[0]_0 ;

  wire button_sync;
  wire clk_IBUF_BUFG;
  wire \q_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q_reg[0]_0 ),
        .Q(button_sync),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module dff_1
   (button_debounced,
    clk_IBUF_BUFG,
    last_value);
  input button_debounced;
  input clk_IBUF_BUFG;
  output last_value;

  wire button_debounced;
  wire clk_IBUF_BUFG;
  wire last_value;

  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(button_debounced),
        .Q(last_value),
        .R(1'b0));
endmodule

module dffre
   (clk_IBUF_BUFG,
    \q_reg[1]_0 ,
    E,
    SR);
  input clk_IBUF_BUFG;
  output \q_reg[1]_0 ;
  input [0:0]E;
  input [0:0]SR;

  wire [0:0]E;
  wire [0:0]SR;
  wire clk_IBUF_BUFG;
  wire [3:0]d0;
  wire \q_reg[1]_0 ;
  wire [3:0]q_reg__0;

  LUT1 #(
    .INIT(2'h1)) 
    \q[0]_i_1 
       (.I0(q_reg__0[0]),
        .O(d0[0]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \q[1]_i_1 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .O(d0[1]));
  LUT4 #(
    .INIT(16'hFFDF)) 
    \q[1]_i_2 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .I2(q_reg__0[3]),
        .I3(q_reg__0[2]),
        .O(\q_reg[1]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \q[2]_i_1 
       (.I0(q_reg__0[1]),
        .I1(q_reg__0[0]),
        .I2(q_reg__0[2]),
        .O(d0[2]));
  LUT4 #(
    .INIT(16'h6CCC)) 
    \q[3]_i_2 
       (.I0(q_reg__0[2]),
        .I1(q_reg__0[3]),
        .I2(q_reg__0[0]),
        .I3(q_reg__0[1]),
        .O(d0[3]));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[0]),
        .Q(q_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[1]),
        .Q(q_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[2]),
        .Q(q_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(d0[3]),
        .Q(q_reg__0[3]),
        .R(SR));
endmodule

(* ORIG_REF_NAME = "dffre" *) 
module dffre__parameterized0
   (ButtonOut_OBUF,
    button_debounced,
    button_sync,
    clk_IBUF_BUFG,
    last_value,
    \q_reg[1]_0 ,
    reset_IBUF,
    SR);
  output ButtonOut_OBUF;
  output button_debounced;
  input button_sync;
  input clk_IBUF_BUFG;
  input last_value;
  input \q_reg[1]_0 ;
  input reset_IBUF;
  output [0:0]SR;

  wire ButtonOut_OBUF;
  wire [0:0]SR;
  wire button_debounced;
  wire button_sync;
  wire clk_IBUF_BUFG;
  wire [1:0]current_state_q;
  wire last_value;
  wire \q[0]_i_1_n_0 ;
  wire \q[1]_i_1_n_0 ;
  wire \q_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h04)) 
    ButtonOut_OBUF_inst_i_1
       (.I0(current_state_q[0]),
        .I1(current_state_q[1]),
        .I2(last_value),
        .O(ButtonOut_OBUF));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hBE14)) 
    \q[0]_i_1 
       (.I0(current_state_q[0]),
        .I1(current_state_q[1]),
        .I2(button_sync),
        .I3(\q_reg[1]_0 ),
        .O(\q[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \q[0]_i_1__0 
       (.I0(current_state_q[1]),
        .I1(current_state_q[0]),
        .O(button_debounced));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hA6)) 
    \q[1]_i_1 
       (.I0(current_state_q[1]),
        .I1(current_state_q[0]),
        .I2(\q_reg[1]_0 ),
        .O(\q[1]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \q[3]_i_1 
       (.I0(current_state_q[0]),
        .O(SR));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[0]_i_1_n_0 ),
        .Q(current_state_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[1]_i_1_n_0 ),
        .Q(current_state_q[1]),
        .R(1'b0));
endmodule

module encode
   (ActiveArea_IBUF,
    hSync_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    vSync_IBUF,
    D,
    SR,
    blue_IBUF);
  input ActiveArea_IBUF;
  input hSync_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  input vSync_IBUF;
  output [9:0]D;
  output [0:0]SR;
  input [7:0]blue_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire [7:0]cnt0;
  wire [7:0]cnt00_in;
  wire cnt0__0_carry__0_i_1_n_0;
  wire cnt0__0_carry__0_i_3_n_0;
  wire cnt0__0_carry__0_i_4_n_0;
  wire cnt0__0_carry_n_0;
  wire cnt0__23_carry_n_0;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire hSync_IBUF;
  wire lopt;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire pixel_clk_IBUF_BUFG;
  wire [8:0]q1_in;
  wire \q[7]_i_10_n_0 ;
  wire \q[7]_i_7__1_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire reset_IBUF;
  wire vSync_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_blue[0]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[4]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_1_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_2_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_3_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_blue[7]_4_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_2_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_3_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_q_reg[2]_4_UNCONNECTED ;
  wire [7:0]NLW_numbercnt_d_inst_blue_UNCONNECTED;
  wire [7:0]NLW_numbercnt_d_inst_blue_IBUF_UNCONNECTED;
  wire [0:0]NLW_numbercnt_d_inst_cnt2_UNCONNECTED;
  wire [1:1]\NLW_numbercnt_d_inst_cnt_reg[3]_2_UNCONNECTED ;
  wire [8:3]NLW_numbercnt_d_inst_q_reg_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({lopt,numbercnt_d_inst_n_48,numbercnt_d_inst_n_33,cnt_reg__0[0]}),
        .O(cnt0[3:0]),
        .S({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,numbercnt_d_inst_n_45,numbercnt_d_inst_n_46}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1_n_0,numbercnt_d_inst_n_25}),
        .O(cnt0[7:4]),
        .S({cnt0__0_carry__0_i_3_n_0,cnt0__0_carry__0_i_4_n_0,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54,cnt_reg__0[1:0]}),
        .O(cnt00_in[3:0]),
        .S({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_51,numbercnt_d_inst_n_52}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27,numbercnt_d_inst_n_28}),
        .O(cnt00_in[7:4]),
        .S({numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31,numbercnt_d_inst_n_32}));
  LUT1 #(
    .INIT(2'h1)) 
    \cnt[7]_i_1 
       (.I0(ActiveArea_IBUF),
        .O(SR));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_37,numbercnt_d_inst_n_38,numbercnt_d_inst_n_39,numbercnt_d_inst_n_40}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_14,numbercnt_d_inst_n_15,numbercnt_d_inst_n_16,numbercnt_d_inst_n_17}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt_5 numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D(q1_in),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_14,numbercnt_d_inst_n_15,numbercnt_d_inst_n_16,numbercnt_d_inst_n_17}),
        .blue(NLW_numbercnt_d_inst_blue_UNCONNECTED[7:0]),
        .\blue[0]_0 (\NLW_numbercnt_d_inst_blue[0]_0_UNCONNECTED ),
        .\blue[3]_0 (\NLW_numbercnt_d_inst_blue[3]_0_UNCONNECTED ),
        .\blue[4]_0 (\NLW_numbercnt_d_inst_blue[4]_0_UNCONNECTED ),
        .\blue[7]_0 (\NLW_numbercnt_d_inst_blue[7]_0_UNCONNECTED ),
        .\blue[7]_1 (\NLW_numbercnt_d_inst_blue[7]_1_UNCONNECTED ),
        .\blue[7]_2 (\NLW_numbercnt_d_inst_blue[7]_2_UNCONNECTED ),
        .\blue[7]_3 (\NLW_numbercnt_d_inst_blue[7]_3_UNCONNECTED ),
        .\blue[7]_4 (\NLW_numbercnt_d_inst_blue[7]_4_UNCONNECTED ),
        .blue_IBUF(NLW_numbercnt_d_inst_blue_IBUF_UNCONNECTED[7:0]),
        .cnt0(cnt0),
        .cnt00_in(cnt00_in),
        .cnt2(NLW_numbercnt_d_inst_cnt2_UNCONNECTED[0]),
        .\cnt_reg[3] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_37,numbercnt_d_inst_n_38,numbercnt_d_inst_n_39,numbercnt_d_inst_n_40}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,numbercnt_d_inst_n_45,numbercnt_d_inst_n_46}),
        .\cnt_reg[3]_2 ({\NLW_numbercnt_d_inst_cnt_reg[3]_2_UNCONNECTED [1],numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_51,numbercnt_d_inst_n_52}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .\cnt_reg[3]_5 (\q[7]_i_7__1_n_0 ),
        .\cnt_reg[7] (numbercnt_d_inst_n_25),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_26,numbercnt_d_inst_n_27,numbercnt_d_inst_n_28}),
        .\cnt_reg[7]_1 ({numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31,numbercnt_d_inst_n_32}),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .hSync_IBUF(hSync_IBUF),
        .lopt(lopt),
        .q_reg({numbercnt_d_inst_n_36,NLW_numbercnt_d_inst_q_reg_UNCONNECTED[8:3],numbercnt_d_inst_n_10}),
        .\q_reg[2]_0 (numbercnt_d_inst_n_11),
        .\q_reg[2]_1 (numbercnt_d_inst_n_33),
        .\q_reg[2]_2 (\NLW_numbercnt_d_inst_q_reg[2]_2_UNCONNECTED ),
        .\q_reg[2]_3 (\NLW_numbercnt_d_inst_q_reg[2]_3_UNCONNECTED ),
        .\q_reg[2]_4 (\NLW_numbercnt_d_inst_q_reg[2]_4_UNCONNECTED ),
        .vSync_IBUF(vSync_IBUF));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_10 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_7__1 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_10_n_0 ),
        .O(\q[7]_i_7__1_n_0 ));
  LUT4 #(
    .INIT(16'h5355)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_36),
        .I1(numbercnt_d_inst_n_11),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[0]),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[1]),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[2]),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[3]),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[4]),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[5]),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[6]),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[7]),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(q1_in[8]),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "encode" *) 
module encode_0
   (ActiveArea_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    D,
    SR,
    green_IBUF);
  input ActiveArea_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  output [9:0]D;
  input [0:0]SR;
  input [7:0]green_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire cnt0__0_carry__0_i_1__0_n_0;
  wire cnt0__0_carry__0_i_3__0_n_0;
  wire cnt0__0_carry__0_i_4__0_n_0;
  wire cnt0__0_carry__0_n_4;
  wire cnt0__0_carry__0_n_5;
  wire cnt0__0_carry__0_n_6;
  wire cnt0__0_carry__0_n_7;
  wire cnt0__0_carry_n_0;
  wire cnt0__0_carry_n_4;
  wire cnt0__0_carry_n_5;
  wire cnt0__0_carry_n_6;
  wire cnt0__0_carry_n_7;
  wire cnt0__23_carry__0_n_4;
  wire cnt0__23_carry__0_n_5;
  wire cnt0__23_carry__0_n_6;
  wire cnt0__23_carry__0_n_7;
  wire cnt0__23_carry_n_0;
  wire cnt0__23_carry_n_4;
  wire cnt0__23_carry_n_5;
  wire cnt0__23_carry_n_6;
  wire cnt0__23_carry_n_7;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire [7:0]green_IBUF;
  wire numbercnt_d_inst_n_0;
  wire numbercnt_d_inst_n_1;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_12;
  wire numbercnt_d_inst_n_13;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_2;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_3;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_34;
  wire numbercnt_d_inst_n_35;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_4;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_47;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_5;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire numbercnt_d_inst_n_6;
  wire numbercnt_d_inst_n_7;
  wire numbercnt_d_inst_n_8;
  wire numbercnt_d_inst_n_9;
  wire numbercnt_q_inst_n_0;
  wire numbercnt_q_inst_n_1;
  wire numbercnt_q_inst_n_2;
  wire numbercnt_q_inst_n_3;
  wire numbercnt_q_inst_n_4;
  wire numbercnt_q_inst_n_5;
  wire numbercnt_q_inst_n_6;
  wire numbercnt_q_inst_n_7;
  wire numbercnt_q_inst_n_8;
  wire pixel_clk_IBUF_BUFG;
  wire \q[7]_i_5_n_0 ;
  wire \q[7]_i_8__0_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire reset_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_green[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_green[3]_1_UNCONNECTED ;
  wire [5:1]NLW_numbercnt_d_inst_green_UNCONNECTED;
  wire [7:1]NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED;
  wire \NLW_numbercnt_q_inst_green[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_q_inst_green[4]_3_UNCONNECTED ;
  wire [6:1]NLW_numbercnt_q_inst_green_UNCONNECTED;
  wire [6:0]NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_17,cnt_reg__0[0]}),
        .O({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .S({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1__0_n_0,numbercnt_d_inst_n_32}),
        .O({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .S({cnt0__0_carry__0_i_3__0_n_0,cnt0__0_carry__0_i_4__0_n_0,numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1__0
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3__0
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4__0
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4__0_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,cnt_reg__0[1:0]}),
        .O({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .S({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .S({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt_3 numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D({numbercnt_d_inst_n_1,numbercnt_d_inst_n_2,numbercnt_d_inst_n_3,numbercnt_d_inst_n_4,numbercnt_d_inst_n_5,numbercnt_d_inst_n_6,numbercnt_d_inst_n_7,numbercnt_d_inst_n_8,numbercnt_d_inst_n_9}),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}),
        .\cnt_reg[0] ({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .\cnt_reg[1] ({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .\cnt_reg[3] ({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .\cnt_reg[3]_2 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50}),
        .\cnt_reg[3]_5 (\q[7]_i_5_n_0 ),
        .\cnt_reg[5] ({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .\cnt_reg[7] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .\cnt_reg[7]_1 (numbercnt_d_inst_n_32),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .green({numbercnt_q_inst_n_6,numbercnt_q_inst_n_0,NLW_numbercnt_d_inst_green_UNCONNECTED[5:4],numbercnt_q_inst_n_7,NLW_numbercnt_d_inst_green_UNCONNECTED[2:1],green_IBUF[2]}),
        .\green[0]_0 (green_IBUF[2]),
        .\green[3]_0 (\NLW_numbercnt_d_inst_green[3]_0_UNCONNECTED ),
        .\green[3]_1 (\NLW_numbercnt_d_inst_green[3]_1_UNCONNECTED ),
        .\green[4]_0 (green_IBUF[0]),
        .\green[7]_0 (numbercnt_q_inst_n_2),
        .\green[7]_1 (numbercnt_q_inst_n_4),
        .\green[7]_2 (numbercnt_q_inst_n_1),
        .\green[7]_3 (numbercnt_q_inst_n_5),
        .\green[7]_4 (numbercnt_q_inst_n_8),
        .\green[7]_5 (numbercnt_q_inst_n_3),
        .green_IBUF({NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[7],green_IBUF[6],NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[5],green_IBUF[4:3],NLW_numbercnt_d_inst_green_IBUF_UNCONNECTED[2:1],green_IBUF[0]}),
        .q_reg({numbercnt_d_inst_n_16,numbercnt_d_inst_n_0}),
        .\q_reg[4]_0 (numbercnt_d_inst_n_10),
        .\q_reg[4]_1 (numbercnt_d_inst_n_11),
        .\q_reg[4]_2 (numbercnt_d_inst_n_34),
        .\q_reg[4]_3 (numbercnt_d_inst_n_51),
        .\q_reg[5]_0 (numbercnt_d_inst_n_17),
        .\q_reg[5]_1 (numbercnt_d_inst_n_33),
        .\q_reg[5]_2 (numbercnt_d_inst_n_52));
  NumberCnt_4 numbercnt_q_inst
       (.cnt_reg(numbercnt_q_inst_n_7),
        .\cnt_reg[3]_0 (numbercnt_q_inst_n_8),
        .green({numbercnt_d_inst_n_51,NLW_numbercnt_q_inst_green_UNCONNECTED[6],numbercnt_d_inst_n_33,green_IBUF[0],NLW_numbercnt_q_inst_green_UNCONNECTED[3:1],green_IBUF[2]}),
        .\green[0]_0 (green_IBUF[2]),
        .\green[3]_0 (\NLW_numbercnt_q_inst_green[3]_0_UNCONNECTED ),
        .\green[3]_1 (numbercnt_d_inst_n_0),
        .\green[4]_0 (numbercnt_d_inst_n_52),
        .\green[4]_1 (numbercnt_d_inst_n_34),
        .\green[4]_2 (numbercnt_d_inst_n_16),
        .\green[4]_3 (\NLW_numbercnt_q_inst_green[4]_3_UNCONNECTED ),
        .green_IBUF({NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[6:5],green_IBUF[4],NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[3:2],green_IBUF[1],NLW_numbercnt_q_inst_green_IBUF_UNCONNECTED[0]}),
        .q_reg({numbercnt_q_inst_n_2,numbercnt_q_inst_n_0}),
        .\q_reg[4]_0 (numbercnt_q_inst_n_1),
        .\q_reg[4]_1 (numbercnt_q_inst_n_6),
        .\q_reg[5]_0 (numbercnt_q_inst_n_3),
        .\q_reg[5]_1 (numbercnt_q_inst_n_4),
        .\q_reg[5]_2 (numbercnt_q_inst_n_5));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_5 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_8__0_n_0 ),
        .O(\q[7]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_8__0 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_8__0_n_0 ));
  LUT4 #(
    .INIT(16'hC5FF)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_0),
        .I1(numbercnt_d_inst_n_11),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_9),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_8),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_7),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_6),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_5),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_4),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_3),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_2),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_1),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "encode" *) 
module encode_1
   (ActiveArea_IBUF,
    pixel_clk_IBUF_BUFG,
    reset_IBUF,
    D,
    SR,
    red_IBUF);
  input ActiveArea_IBUF;
  input pixel_clk_IBUF_BUFG;
  input reset_IBUF;
  output [9:0]D;
  input [0:0]SR;
  input [7:0]red_IBUF;

  wire ActiveArea_IBUF;
  wire [9:0]D;
  wire [0:0]SR;
  wire cnt0__0_carry__0_i_1__1_n_0;
  wire cnt0__0_carry__0_i_3__1_n_0;
  wire cnt0__0_carry__0_i_4__1_n_0;
  wire cnt0__0_carry__0_n_4;
  wire cnt0__0_carry__0_n_5;
  wire cnt0__0_carry__0_n_6;
  wire cnt0__0_carry__0_n_7;
  wire cnt0__0_carry_n_0;
  wire cnt0__0_carry_n_4;
  wire cnt0__0_carry_n_5;
  wire cnt0__0_carry_n_6;
  wire cnt0__0_carry_n_7;
  wire cnt0__23_carry__0_n_4;
  wire cnt0__23_carry__0_n_5;
  wire cnt0__23_carry__0_n_6;
  wire cnt0__23_carry__0_n_7;
  wire cnt0__23_carry_n_0;
  wire cnt0__23_carry_n_4;
  wire cnt0__23_carry_n_5;
  wire cnt0__23_carry_n_6;
  wire cnt0__23_carry_n_7;
  wire cnt_carry__0_n_4;
  wire cnt_carry__0_n_5;
  wire cnt_carry__0_n_6;
  wire cnt_carry__0_n_7;
  wire cnt_carry_n_0;
  wire cnt_carry_n_4;
  wire cnt_carry_n_5;
  wire cnt_carry_n_6;
  wire cnt_carry_n_7;
  wire [7:0]cnt_reg__0;
  wire numbercnt_d_inst_n_0;
  wire numbercnt_d_inst_n_1;
  wire numbercnt_d_inst_n_10;
  wire numbercnt_d_inst_n_11;
  wire numbercnt_d_inst_n_12;
  wire numbercnt_d_inst_n_13;
  wire numbercnt_d_inst_n_14;
  wire numbercnt_d_inst_n_15;
  wire numbercnt_d_inst_n_16;
  wire numbercnt_d_inst_n_17;
  wire numbercnt_d_inst_n_18;
  wire numbercnt_d_inst_n_19;
  wire numbercnt_d_inst_n_2;
  wire numbercnt_d_inst_n_20;
  wire numbercnt_d_inst_n_21;
  wire numbercnt_d_inst_n_22;
  wire numbercnt_d_inst_n_23;
  wire numbercnt_d_inst_n_24;
  wire numbercnt_d_inst_n_25;
  wire numbercnt_d_inst_n_26;
  wire numbercnt_d_inst_n_27;
  wire numbercnt_d_inst_n_28;
  wire numbercnt_d_inst_n_29;
  wire numbercnt_d_inst_n_3;
  wire numbercnt_d_inst_n_30;
  wire numbercnt_d_inst_n_31;
  wire numbercnt_d_inst_n_32;
  wire numbercnt_d_inst_n_33;
  wire numbercnt_d_inst_n_34;
  wire numbercnt_d_inst_n_35;
  wire numbercnt_d_inst_n_36;
  wire numbercnt_d_inst_n_37;
  wire numbercnt_d_inst_n_38;
  wire numbercnt_d_inst_n_39;
  wire numbercnt_d_inst_n_4;
  wire numbercnt_d_inst_n_40;
  wire numbercnt_d_inst_n_41;
  wire numbercnt_d_inst_n_42;
  wire numbercnt_d_inst_n_43;
  wire numbercnt_d_inst_n_44;
  wire numbercnt_d_inst_n_45;
  wire numbercnt_d_inst_n_46;
  wire numbercnt_d_inst_n_47;
  wire numbercnt_d_inst_n_48;
  wire numbercnt_d_inst_n_49;
  wire numbercnt_d_inst_n_5;
  wire numbercnt_d_inst_n_50;
  wire numbercnt_d_inst_n_51;
  wire numbercnt_d_inst_n_52;
  wire numbercnt_d_inst_n_53;
  wire numbercnt_d_inst_n_54;
  wire numbercnt_d_inst_n_6;
  wire numbercnt_d_inst_n_7;
  wire numbercnt_d_inst_n_8;
  wire numbercnt_d_inst_n_9;
  wire numbercnt_q_inst_n_0;
  wire numbercnt_q_inst_n_1;
  wire numbercnt_q_inst_n_2;
  wire numbercnt_q_inst_n_3;
  wire numbercnt_q_inst_n_4;
  wire numbercnt_q_inst_n_5;
  wire numbercnt_q_inst_n_6;
  wire numbercnt_q_inst_n_7;
  wire numbercnt_q_inst_n_8;
  wire pixel_clk_IBUF_BUFG;
  wire \q[7]_i_5__0_n_0 ;
  wire \q[7]_i_8__1_n_0 ;
  wire \q[9]_i_1_n_0 ;
  wire [7:0]red_IBUF;
  wire reset_IBUF;
  wire [2:0]NLW_cnt0__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0__23_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0__23_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt_carry_CO_UNCONNECTED;
  wire [3:0]NLW_cnt_carry__0_CO_UNCONNECTED;
  wire \NLW_numbercnt_d_inst_red[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_d_inst_red[3]_1_UNCONNECTED ;
  wire [3:3]NLW_numbercnt_d_inst_q_reg_UNCONNECTED;
  wire [5:1]NLW_numbercnt_d_inst_red_UNCONNECTED;
  wire [7:1]NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED;
  wire \NLW_numbercnt_q_inst_red[3]_0_UNCONNECTED ;
  wire \NLW_numbercnt_q_inst_red[4]_3_UNCONNECTED ;
  wire [3:3]NLW_numbercnt_q_inst_q_reg_UNCONNECTED;
  wire [6:1]NLW_numbercnt_q_inst_red_UNCONNECTED;
  wire [6:0]NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED;

  CARRY4 cnt0__0_carry
       (.CI(1'b0),
        .CO({cnt0__0_carry_n_0,NLW_cnt0__0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50,numbercnt_d_inst_n_17,cnt_reg__0[0]}),
        .O({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .S({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}));
  CARRY4 cnt0__0_carry__0
       (.CI(cnt0__0_carry_n_0),
        .CO(NLW_cnt0__0_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,cnt_reg__0[5],cnt0__0_carry__0_i_1__1_n_0,numbercnt_d_inst_n_32}),
        .O({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .S({cnt0__0_carry__0_i_3__1_n_0,cnt0__0_carry__0_i_4__1_n_0,numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}));
  LUT1 #(
    .INIT(2'h1)) 
    cnt0__0_carry__0_i_1__1
       (.I0(cnt_reg__0[5]),
        .O(cnt0__0_carry__0_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_3__1
       (.I0(cnt_reg__0[7]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    cnt0__0_carry__0_i_4__1
       (.I0(cnt_reg__0[5]),
        .I1(cnt_reg__0[6]),
        .O(cnt0__0_carry__0_i_4__1_n_0));
  CARRY4 cnt0__23_carry
       (.CI(1'b0),
        .CO({cnt0__23_carry_n_0,NLW_cnt0__23_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44,cnt_reg__0[1:0]}),
        .O({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .S({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}));
  CARRY4 cnt0__23_carry__0
       (.CI(cnt0__23_carry_n_0),
        .CO(NLW_cnt0__23_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .S({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}));
  CARRY4 cnt_carry
       (.CI(1'b0),
        .CO({cnt_carry_n_0,NLW_cnt_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .O({cnt_carry_n_4,cnt_carry_n_5,cnt_carry_n_6,cnt_carry_n_7}),
        .S({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}));
  CARRY4 cnt_carry__0
       (.CI(cnt_carry_n_0),
        .CO(NLW_cnt_carry__0_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .O({cnt_carry__0_n_4,cnt_carry__0_n_5,cnt_carry__0_n_6,cnt_carry__0_n_7}),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_7),
        .Q(cnt_reg__0[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_6),
        .Q(cnt_reg__0[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_5),
        .Q(cnt_reg__0[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry_n_4),
        .Q(cnt_reg__0[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_7),
        .Q(cnt_reg__0[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_6),
        .Q(cnt_reg__0[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_5),
        .Q(cnt_reg__0[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(ActiveArea_IBUF),
        .D(cnt_carry__0_n_4),
        .Q(cnt_reg__0[7]),
        .R(SR));
  NumberCnt numbercnt_d_inst
       (.ActiveArea_IBUF(ActiveArea_IBUF),
        .D({numbercnt_d_inst_n_1,numbercnt_d_inst_n_2,numbercnt_d_inst_n_3,numbercnt_d_inst_n_4,numbercnt_d_inst_n_5,numbercnt_d_inst_n_6,numbercnt_d_inst_n_7,numbercnt_d_inst_n_8,numbercnt_d_inst_n_9}),
        .DI({numbercnt_d_inst_n_18,numbercnt_d_inst_n_19,numbercnt_d_inst_n_20}),
        .O({cnt0__23_carry__0_n_4,cnt0__23_carry__0_n_5,cnt0__23_carry__0_n_6,cnt0__23_carry__0_n_7}),
        .Q(cnt_reg__0),
        .S({numbercnt_d_inst_n_12,numbercnt_d_inst_n_13,numbercnt_d_inst_n_14,numbercnt_d_inst_n_15}),
        .\cnt_reg[0] ({cnt0__0_carry_n_4,cnt0__0_carry_n_5,cnt0__0_carry_n_6,cnt0__0_carry_n_7}),
        .\cnt_reg[1] ({cnt0__23_carry_n_4,cnt0__23_carry_n_5,cnt0__23_carry_n_6,cnt0__23_carry_n_7}),
        .\cnt_reg[3] ({numbercnt_d_inst_n_28,numbercnt_d_inst_n_29,numbercnt_d_inst_n_30,numbercnt_d_inst_n_31}),
        .\cnt_reg[3]_0 ({numbercnt_d_inst_n_35,numbercnt_d_inst_n_36,numbercnt_d_inst_n_37,numbercnt_d_inst_n_38}),
        .\cnt_reg[3]_1 ({numbercnt_d_inst_n_39,numbercnt_d_inst_n_40,numbercnt_d_inst_n_41,numbercnt_d_inst_n_42}),
        .\cnt_reg[3]_2 ({numbercnt_d_inst_n_43,numbercnt_d_inst_n_44}),
        .\cnt_reg[3]_3 ({numbercnt_d_inst_n_45,numbercnt_d_inst_n_46,numbercnt_d_inst_n_47,numbercnt_d_inst_n_48}),
        .\cnt_reg[3]_4 ({numbercnt_d_inst_n_49,numbercnt_d_inst_n_50}),
        .\cnt_reg[3]_5 (\q[7]_i_5__0_n_0 ),
        .\cnt_reg[5] ({cnt0__0_carry__0_n_4,cnt0__0_carry__0_n_5,cnt0__0_carry__0_n_6,cnt0__0_carry__0_n_7}),
        .\cnt_reg[7] ({numbercnt_d_inst_n_21,numbercnt_d_inst_n_22,numbercnt_d_inst_n_23,numbercnt_d_inst_n_24}),
        .\cnt_reg[7]_0 ({numbercnt_d_inst_n_25,numbercnt_d_inst_n_26,numbercnt_d_inst_n_27}),
        .\cnt_reg[7]_1 (numbercnt_d_inst_n_32),
        .\cnt_reg[7]_2 ({numbercnt_d_inst_n_53,numbercnt_d_inst_n_54}),
        .q_reg({numbercnt_d_inst_n_11,numbercnt_d_inst_n_16,NLW_numbercnt_d_inst_q_reg_UNCONNECTED[3],numbercnt_d_inst_n_0}),
        .\q_reg[2]_0 (numbercnt_d_inst_n_10),
        .\q_reg[2]_1 (numbercnt_d_inst_n_34),
        .\q_reg[4]_0 (numbercnt_d_inst_n_17),
        .\q_reg[4]_1 (numbercnt_d_inst_n_33),
        .\q_reg[4]_2 (numbercnt_d_inst_n_52),
        .\q_reg[5]_0 (numbercnt_d_inst_n_51),
        .red({numbercnt_q_inst_n_6,numbercnt_q_inst_n_0,NLW_numbercnt_d_inst_red_UNCONNECTED[5:4],numbercnt_q_inst_n_7,NLW_numbercnt_d_inst_red_UNCONNECTED[2:1],red_IBUF[2]}),
        .\red[0]_0 (red_IBUF[2]),
        .\red[3]_0 (\NLW_numbercnt_d_inst_red[3]_0_UNCONNECTED ),
        .\red[3]_1 (\NLW_numbercnt_d_inst_red[3]_1_UNCONNECTED ),
        .\red[4]_0 (red_IBUF[0]),
        .\red[7]_0 (numbercnt_q_inst_n_2),
        .\red[7]_1 (numbercnt_q_inst_n_4),
        .\red[7]_2 (numbercnt_q_inst_n_1),
        .\red[7]_3 (numbercnt_q_inst_n_5),
        .\red[7]_4 (numbercnt_q_inst_n_8),
        .\red[7]_5 (numbercnt_q_inst_n_3),
        .red_IBUF({NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[7],red_IBUF[6],NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[5],red_IBUF[4:3],NLW_numbercnt_d_inst_red_IBUF_UNCONNECTED[2:1],red_IBUF[0]}));
  NumberCnt_2 numbercnt_q_inst
       (.cnt_reg(numbercnt_q_inst_n_7),
        .\cnt_reg[3]_0 (numbercnt_q_inst_n_8),
        .q_reg({numbercnt_q_inst_n_1,numbercnt_q_inst_n_2,NLW_numbercnt_q_inst_q_reg_UNCONNECTED[3],numbercnt_q_inst_n_0}),
        .\q_reg[2]_0 (numbercnt_q_inst_n_6),
        .\q_reg[4]_0 (numbercnt_q_inst_n_3),
        .\q_reg[4]_1 (numbercnt_q_inst_n_4),
        .\q_reg[4]_2 (numbercnt_q_inst_n_5),
        .red({numbercnt_d_inst_n_51,NLW_numbercnt_q_inst_red_UNCONNECTED[6],numbercnt_d_inst_n_33,red_IBUF[0],NLW_numbercnt_q_inst_red_UNCONNECTED[3:1],red_IBUF[2]}),
        .\red[0]_0 (red_IBUF[2]),
        .\red[3]_0 (\NLW_numbercnt_q_inst_red[3]_0_UNCONNECTED ),
        .\red[3]_1 (numbercnt_d_inst_n_0),
        .\red[4]_0 (numbercnt_d_inst_n_52),
        .\red[4]_1 (numbercnt_d_inst_n_34),
        .\red[4]_2 (numbercnt_d_inst_n_11),
        .\red[4]_3 (\NLW_numbercnt_q_inst_red[4]_3_UNCONNECTED ),
        .red_IBUF({NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[6:5],red_IBUF[4],NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[3:2],red_IBUF[1],NLW_numbercnt_q_inst_red_IBUF_UNCONNECTED[0]}));
  LUT5 #(
    .INIT(32'h00000001)) 
    \q[7]_i_5__0 
       (.I0(cnt_reg__0[3]),
        .I1(cnt_reg__0[0]),
        .I2(cnt_reg__0[1]),
        .I3(cnt_reg__0[2]),
        .I4(\q[7]_i_8__1_n_0 ),
        .O(\q[7]_i_5__0_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \q[7]_i_8__1 
       (.I0(cnt_reg__0[6]),
        .I1(cnt_reg__0[7]),
        .I2(cnt_reg__0[5]),
        .I3(cnt_reg__0[4]),
        .O(\q[7]_i_8__1_n_0 ));
  LUT4 #(
    .INIT(16'hC5FF)) 
    \q[9]_i_1 
       (.I0(numbercnt_d_inst_n_0),
        .I1(numbercnt_d_inst_n_16),
        .I2(numbercnt_d_inst_n_10),
        .I3(ActiveArea_IBUF),
        .O(\q[9]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[0] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_9),
        .Q(D[0]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[1] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_8),
        .Q(D[1]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[2] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_7),
        .Q(D[2]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[3] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_6),
        .Q(D[3]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[4] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_5),
        .Q(D[4]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[5] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_4),
        .Q(D[5]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[6] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_3),
        .Q(D[6]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[7] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_2),
        .Q(D[7]),
        .S(reset_IBUF));
  FDSE #(
    .INIT(1'b1)) 
    \q_reg[8] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(numbercnt_d_inst_n_1),
        .Q(D[8]),
        .S(reset_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \q_reg[9] 
       (.C(pixel_clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\q[9]_i_1_n_0 ),
        .Q(D[9]),
        .R(1'b0));
endmodule

module one_pulse
   (button_debounced,
    clk_IBUF_BUFG,
    last_value);
  input button_debounced;
  input clk_IBUF_BUFG;
  output last_value;

  wire button_debounced;
  wire clk_IBUF_BUFG;
  wire last_value;

  dff_1 last_value_storage
       (.button_debounced(button_debounced),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .last_value(last_value));
endmodule

module syncGenarator
   (a,
    \TMDSn[2] ,
    \TMDSn[2]_0 ,
    \TMDSn[2]_1 ,
    \TMDSn[2]_2 ,
    \TMDSn[2]_3 ,
    \TMDSn[2]_4 ,
    \TMDSn[2]_5 ,
    \TMDSn[2]_6 ,
    \TMDSn[2]_7 ,
    green,
    Q,
    \TMDSn[2]_8 ,
    ActiveArea,
    vSync,
    hSync,
    \q_reg[27] ,
    \q_reg[12] ,
    \PosX_reg_reg[6]_0 ,
    \q_reg[0] ,
    \PC_reg_reg[0] ,
    \PosX_reg_reg[4]_0 ,
    \PosX_reg_reg[6]_1 ,
    D,
    \q_reg[152] ,
    \PosX_reg_reg[4]_1 ,
    \q_reg[14] ,
    \q_reg[152]_0 ,
    \PosX_reg_reg[6]_2 ,
    \PosX_reg_reg[4]_2 ,
    \q_reg[152]_1 ,
    \q_reg[152]_2 ,
    \PC_reg_reg[3] ,
    \q_reg[27]_0 ,
    \q_reg[18] ,
    \q_reg[34] ,
    \q_reg[121] ,
    \q_reg[137] ,
    \q_reg[147] ,
    \q_reg[15] ,
    \q_reg[16] ,
    \PC_reg_reg[2] ,
    \PC_reg_reg[6] ,
    \q_reg[17] ,
    \PosX_reg_reg[3]_0 ,
    \PosX_reg_reg[4]_3 ,
    \bbstub_spo[31] ,
    \PosX_reg_reg[4]_4 ,
    \PosX_reg_reg[4]_5 ,
    \PosX_reg_reg[4]_6 ,
    CLK);
  output [7:0]a;
  output \TMDSn[2] ;
  output \TMDSn[2]_0 ;
  output \TMDSn[2]_1 ;
  output \TMDSn[2]_2 ;
  output \TMDSn[2]_3 ;
  output \TMDSn[2]_4 ;
  output \TMDSn[2]_5 ;
  output \TMDSn[2]_6 ;
  output \TMDSn[2]_7 ;
  output [0:0]green;
  output [2:0]Q;
  output \TMDSn[2]_8 ;
  output ActiveArea;
  output vSync;
  output hSync;
  input [10:0]\q_reg[27] ;
  input [0:0]\q_reg[12] ;
  input \PosX_reg_reg[6]_0 ;
  input \q_reg[0] ;
  input \PC_reg_reg[0] ;
  input \PosX_reg_reg[4]_0 ;
  input \PosX_reg_reg[6]_1 ;
  input [12:0]D;
  input \q_reg[152] ;
  input \PosX_reg_reg[4]_1 ;
  input \q_reg[14] ;
  input \q_reg[152]_0 ;
  input \PosX_reg_reg[6]_2 ;
  input \PosX_reg_reg[4]_2 ;
  input \q_reg[152]_1 ;
  input \q_reg[152]_2 ;
  input \PC_reg_reg[3] ;
  input \q_reg[27]_0 ;
  input \q_reg[18] ;
  input [11:0]\q_reg[34] ;
  input \q_reg[121] ;
  input \q_reg[137] ;
  input \q_reg[147] ;
  input \q_reg[15] ;
  input \q_reg[16] ;
  input \PC_reg_reg[2] ;
  input [2:0]\PC_reg_reg[6] ;
  input \q_reg[17] ;
  input \PosX_reg_reg[3]_0 ;
  input \PosX_reg_reg[4]_3 ;
  input [11:0]\bbstub_spo[31] ;
  input \PosX_reg_reg[4]_4 ;
  input \PosX_reg_reg[4]_5 ;
  input \PosX_reg_reg[4]_6 ;
  input CLK;

  wire ActiveArea;
  wire CLK;
  wire [12:0]D;
  wire EndLine;
  wire \PC_reg_reg[0] ;
  wire \PC_reg_reg[2] ;
  wire \PC_reg_reg[3] ;
  wire [2:0]\PC_reg_reg[6] ;
  wire \PosX_reg[3]_i_1_n_0 ;
  wire \PosX_reg[7]_i_1_n_0 ;
  wire \PosX_reg[8]_i_2_n_0 ;
  wire \PosX_reg[9]_i_3_n_0 ;
  wire \PosX_reg[9]_i_4_n_0 ;
  wire \PosX_reg_reg[3]_0 ;
  wire \PosX_reg_reg[4]_0 ;
  wire \PosX_reg_reg[4]_1 ;
  wire \PosX_reg_reg[4]_2 ;
  wire \PosX_reg_reg[4]_3 ;
  wire \PosX_reg_reg[4]_4 ;
  wire \PosX_reg_reg[4]_5 ;
  wire \PosX_reg_reg[4]_6 ;
  wire \PosX_reg_reg[6]_0 ;
  wire \PosX_reg_reg[6]_1 ;
  wire \PosX_reg_reg[6]_2 ;
  wire [9:0]PosX_reg_reg__0;
  wire PosY_reg;
  wire \PosY_reg[0]_i_1_n_0 ;
  wire \PosY_reg[6]_i_2_n_0 ;
  wire \PosY_reg[9]_i_3_n_0 ;
  wire \PosY_reg[9]_i_4_n_0 ;
  wire [9:0]PosY_reg_reg__0;
  wire [2:0]Q;
  wire TMDS_inst_i_10_n_0;
  wire TMDS_inst_i_11_n_0;
  wire TMDS_inst_i_12_n_0;
  wire TMDS_inst_i_13_n_0;
  wire TMDS_inst_i_14_n_0;
  wire TMDS_inst_i_15_n_0;
  wire TMDS_inst_i_18_n_0;
  wire TMDS_inst_i_5_n_0;
  wire TMDS_inst_i_7_n_0;
  wire TMDS_inst_i_8_n_0;
  wire TMDS_inst_i_9_n_0;
  wire \TMDSn[2] ;
  wire \TMDSn[2]_0 ;
  wire \TMDSn[2]_1 ;
  wire \TMDSn[2]_2 ;
  wire \TMDSn[2]_3 ;
  wire \TMDSn[2]_4 ;
  wire \TMDSn[2]_5 ;
  wire \TMDSn[2]_6 ;
  wire \TMDSn[2]_7 ;
  wire \TMDSn[2]_8 ;
  wire [7:0]a;
  wire [11:0]\bbstub_spo[31] ;
  wire char_tab_i_101_n_0;
  wire char_tab_i_106_n_0;
  wire char_tab_i_108_n_0;
  wire char_tab_i_109_n_0;
  wire char_tab_i_10_n_0;
  wire char_tab_i_11_n_0;
  wire char_tab_i_12_n_0;
  wire char_tab_i_14_n_0;
  wire char_tab_i_17_n_0;
  wire char_tab_i_18_n_0;
  wire char_tab_i_19_n_0;
  wire char_tab_i_21_n_0;
  wire char_tab_i_22_n_0;
  wire char_tab_i_23_n_0;
  wire char_tab_i_24_n_0;
  wire char_tab_i_25_n_0;
  wire char_tab_i_26_n_0;
  wire char_tab_i_27_n_0;
  wire char_tab_i_28_n_0;
  wire char_tab_i_29_n_0;
  wire char_tab_i_38_n_0;
  wire char_tab_i_39_n_0;
  wire char_tab_i_46_n_0;
  wire char_tab_i_48_n_0;
  wire char_tab_i_49_n_0;
  wire char_tab_i_51_n_0;
  wire char_tab_i_53_n_0;
  wire char_tab_i_55_n_0;
  wire char_tab_i_56_n_0;
  wire char_tab_i_57_n_0;
  wire char_tab_i_58_n_0;
  wire char_tab_i_60_n_0;
  wire char_tab_i_61_n_0;
  wire char_tab_i_62_n_0;
  wire char_tab_i_65_n_0;
  wire char_tab_i_66_n_0;
  wire char_tab_i_68_n_0;
  wire char_tab_i_69_n_0;
  wire char_tab_i_70_n_0;
  wire char_tab_i_73_n_0;
  wire char_tab_i_74_n_0;
  wire char_tab_i_75_n_0;
  wire char_tab_i_77_n_0;
  wire char_tab_i_85_n_0;
  wire char_tab_i_86_n_0;
  wire char_tab_i_91_n_0;
  wire char_tab_i_96_n_0;
  wire char_tab_i_99_n_0;
  wire char_tab_i_9_n_0;
  wire [0:0]green;
  wire hSync;
  wire [9:0]p_0_in;
  wire [9:1]p_0_in__0;
  wire \q_reg[0] ;
  wire \q_reg[121] ;
  wire [0:0]\q_reg[12] ;
  wire \q_reg[137] ;
  wire \q_reg[147] ;
  wire \q_reg[14] ;
  wire \q_reg[152] ;
  wire \q_reg[152]_0 ;
  wire \q_reg[152]_1 ;
  wire \q_reg[152]_2 ;
  wire \q_reg[15] ;
  wire \q_reg[16] ;
  wire \q_reg[17] ;
  wire \q_reg[18] ;
  wire [10:0]\q_reg[27] ;
  wire \q_reg[27]_0 ;
  wire [11:0]\q_reg[34] ;
  wire vSync;

  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \PosX_reg[0]_i_1 
       (.I0(PosX_reg_reg__0[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PosX_reg[1]_i_1 
       (.I0(PosX_reg_reg__0[0]),
        .I1(Q[0]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \PosX_reg[2]_i_1 
       (.I0(Q[1]),
        .I1(PosX_reg_reg__0[0]),
        .I2(Q[0]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \PosX_reg[3]_i_1 
       (.I0(Q[2]),
        .I1(Q[1]),
        .I2(PosX_reg_reg__0[0]),
        .I3(Q[0]),
        .O(\PosX_reg[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \PosX_reg[4]_i_1 
       (.I0(Q[1]),
        .I1(PosX_reg_reg__0[0]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(PosX_reg_reg__0[4]),
        .O(p_0_in[4]));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \PosX_reg[5]_i_1 
       (.I0(PosX_reg_reg__0[5]),
        .I1(Q[1]),
        .I2(PosX_reg_reg__0[0]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(PosX_reg_reg__0[4]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT4 #(
    .INIT(16'hAA6A)) 
    \PosX_reg[6]_i_1 
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(\PosX_reg[8]_i_2_n_0 ),
        .O(p_0_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT5 #(
    .INIT(32'h9AAAAAAA)) 
    \PosX_reg[7]_i_1 
       (.I0(PosX_reg_reg__0[7]),
        .I1(\PosX_reg[8]_i_2_n_0 ),
        .I2(PosX_reg_reg__0[5]),
        .I3(PosX_reg_reg__0[4]),
        .I4(PosX_reg_reg__0[6]),
        .O(\PosX_reg[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA6AAAAAAAAAAA)) 
    \PosX_reg[8]_i_1 
       (.I0(PosX_reg_reg__0[8]),
        .I1(PosX_reg_reg__0[6]),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosX_reg_reg__0[5]),
        .I4(\PosX_reg[8]_i_2_n_0 ),
        .I5(PosX_reg_reg__0[7]),
        .O(p_0_in[8]));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \PosX_reg[8]_i_2 
       (.I0(Q[1]),
        .I1(PosX_reg_reg__0[0]),
        .I2(Q[0]),
        .I3(Q[2]),
        .O(\PosX_reg[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \PosX_reg[9]_i_1 
       (.I0(\PosX_reg[9]_i_3_n_0 ),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[7]),
        .I3(PosX_reg_reg__0[6]),
        .I4(PosX_reg_reg__0[8]),
        .I5(PosX_reg_reg__0[9]),
        .O(EndLine));
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \PosX_reg[9]_i_2 
       (.I0(PosX_reg_reg__0[9]),
        .I1(PosX_reg_reg__0[8]),
        .I2(PosX_reg_reg__0[7]),
        .I3(\PosX_reg[9]_i_4_n_0 ),
        .I4(PosX_reg_reg__0[6]),
        .O(p_0_in[9]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \PosX_reg[9]_i_3 
       (.I0(PosX_reg_reg__0[4]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(PosX_reg_reg__0[0]),
        .I4(Q[1]),
        .O(\PosX_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \PosX_reg[9]_i_4 
       (.I0(Q[2]),
        .I1(Q[0]),
        .I2(PosX_reg_reg__0[0]),
        .I3(Q[1]),
        .I4(PosX_reg_reg__0[5]),
        .I5(PosX_reg_reg__0[4]),
        .O(\PosX_reg[9]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(PosX_reg_reg__0[0]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(Q[0]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(Q[1]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\PosX_reg[3]_i_1_n_0 ),
        .Q(Q[2]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(PosX_reg_reg__0[4]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(PosX_reg_reg__0[5]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(PosX_reg_reg__0[6]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(\PosX_reg[7]_i_1_n_0 ),
        .Q(PosX_reg_reg__0[7]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(PosX_reg_reg__0[8]),
        .R(EndLine));
  FDRE #(
    .INIT(1'b0)) 
    \PosX_reg_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(PosX_reg_reg__0[9]),
        .R(EndLine));
  LUT1 #(
    .INIT(2'h1)) 
    \PosY_reg[0]_i_1 
       (.I0(PosY_reg_reg__0[0]),
        .O(\PosY_reg[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \PosY_reg[1]_i_1 
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .O(p_0_in__0[1]));
  LUT3 #(
    .INIT(8'h6A)) 
    \PosY_reg[2]_i_1 
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[0]),
        .O(p_0_in__0[2]));
  LUT4 #(
    .INIT(16'h6AAA)) 
    \PosY_reg[3]_i_1 
       (.I0(PosY_reg_reg__0[3]),
        .I1(PosY_reg_reg__0[0]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[2]),
        .O(p_0_in__0[3]));
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \PosY_reg[4]_i_1 
       (.I0(PosY_reg_reg__0[4]),
        .I1(PosY_reg_reg__0[3]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[2]),
        .O(p_0_in__0[4]));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \PosY_reg[5]_i_1 
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[2]),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[1]),
        .I4(PosY_reg_reg__0[3]),
        .I5(PosY_reg_reg__0[4]),
        .O(p_0_in__0[5]));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \PosY_reg[6]_i_1 
       (.I0(PosY_reg_reg__0[6]),
        .I1(PosY_reg_reg__0[5]),
        .I2(PosY_reg_reg__0[4]),
        .I3(PosY_reg_reg__0[3]),
        .I4(\PosY_reg[6]_i_2_n_0 ),
        .I5(PosY_reg_reg__0[2]),
        .O(p_0_in__0[6]));
  LUT2 #(
    .INIT(4'h8)) 
    \PosY_reg[6]_i_2 
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .O(\PosY_reg[6]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h6A)) 
    \PosY_reg[7]_i_1 
       (.I0(PosY_reg_reg__0[7]),
        .I1(PosY_reg_reg__0[6]),
        .I2(\PosY_reg[9]_i_4_n_0 ),
        .O(p_0_in__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \PosY_reg[8]_i_1 
       (.I0(PosY_reg_reg__0[8]),
        .I1(PosY_reg_reg__0[7]),
        .I2(\PosY_reg[9]_i_4_n_0 ),
        .I3(PosY_reg_reg__0[6]),
        .O(p_0_in__0[8]));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \PosY_reg[9]_i_1 
       (.I0(EndLine),
        .I1(\PosY_reg[9]_i_3_n_0 ),
        .I2(PosY_reg_reg__0[5]),
        .I3(PosY_reg_reg__0[4]),
        .I4(PosY_reg_reg__0[7]),
        .I5(PosY_reg_reg__0[6]),
        .O(PosY_reg));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \PosY_reg[9]_i_2 
       (.I0(PosY_reg_reg__0[9]),
        .I1(PosY_reg_reg__0[8]),
        .I2(PosY_reg_reg__0[6]),
        .I3(\PosY_reg[9]_i_4_n_0 ),
        .I4(PosY_reg_reg__0[7]),
        .O(p_0_in__0[9]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFF7FFFFF)) 
    \PosY_reg[9]_i_3 
       (.I0(PosY_reg_reg__0[0]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[3]),
        .I3(PosY_reg_reg__0[2]),
        .I4(PosY_reg_reg__0[9]),
        .I5(PosY_reg_reg__0[8]),
        .O(\PosY_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \PosY_reg[9]_i_4 
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[0]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[3]),
        .I4(PosY_reg_reg__0[4]),
        .I5(PosY_reg_reg__0[5]),
        .O(\PosY_reg[9]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[0] 
       (.C(CLK),
        .CE(EndLine),
        .D(\PosY_reg[0]_i_1_n_0 ),
        .Q(PosY_reg_reg__0[0]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[1] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[1]),
        .Q(PosY_reg_reg__0[1]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[2] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[2]),
        .Q(PosY_reg_reg__0[2]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[3] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[3]),
        .Q(PosY_reg_reg__0[3]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[4] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[4]),
        .Q(PosY_reg_reg__0[4]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[5] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[5]),
        .Q(PosY_reg_reg__0[5]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[6] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[6]),
        .Q(PosY_reg_reg__0[6]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[7] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[7]),
        .Q(PosY_reg_reg__0[7]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[8] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[8]),
        .Q(PosY_reg_reg__0[8]),
        .R(PosY_reg));
  FDRE #(
    .INIT(1'b0)) 
    \PosY_reg_reg[9] 
       (.C(CLK),
        .CE(EndLine),
        .D(p_0_in__0[9]),
        .Q(PosY_reg_reg__0[9]),
        .R(PosY_reg));
  LUT6 #(
    .INIT(64'hFDFDFFFDFFFFFDFF)) 
    TMDS_inst_i_1
       (.I0(TMDS_inst_i_5_n_0),
        .I1(\PosX_reg_reg[3]_0 ),
        .I2(PosX_reg_reg__0[9]),
        .I3(PosX_reg_reg__0[7]),
        .I4(TMDS_inst_i_7_n_0),
        .I5(PosX_reg_reg__0[8]),
        .O(green));
  LUT6 #(
    .INIT(64'hFFFFFFFB0000000D)) 
    TMDS_inst_i_10
       (.I0(PosY_reg_reg__0[5]),
        .I1(TMDS_inst_i_18_n_0),
        .I2(PosY_reg_reg__0[6]),
        .I3(PosY_reg_reg__0[7]),
        .I4(PosY_reg_reg__0[8]),
        .I5(PosY_reg_reg__0[9]),
        .O(TMDS_inst_i_10_n_0));
  LUT6 #(
    .INIT(64'hA955A815A815A955)) 
    TMDS_inst_i_11
       (.I0(PosY_reg_reg__0[8]),
        .I1(PosY_reg_reg__0[6]),
        .I2(char_tab_i_48_n_0),
        .I3(PosY_reg_reg__0[7]),
        .I4(PosX_reg_reg__0[5]),
        .I5(PosX_reg_reg__0[4]),
        .O(TMDS_inst_i_11_n_0));
  LUT4 #(
    .INIT(16'hAAA9)) 
    TMDS_inst_i_12
       (.I0(PosX_reg_reg__0[7]),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(PosX_reg_reg__0[6]),
        .O(TMDS_inst_i_12_n_0));
  LUT3 #(
    .INIT(8'h56)) 
    TMDS_inst_i_13
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .O(TMDS_inst_i_13_n_0));
  LUT4 #(
    .INIT(16'h4002)) 
    TMDS_inst_i_14
       (.I0(PosY_reg_reg__0[8]),
        .I1(char_tab_i_48_n_0),
        .I2(PosY_reg_reg__0[6]),
        .I3(PosY_reg_reg__0[7]),
        .O(TMDS_inst_i_14_n_0));
  LUT6 #(
    .INIT(64'h400055AA070A50A0)) 
    TMDS_inst_i_15
       (.I0(char_tab_i_38_n_0),
        .I1(char_tab_i_26_n_0),
        .I2(PosX_reg_reg__0[4]),
        .I3(char_tab_i_18_n_0),
        .I4(PosX_reg_reg__0[6]),
        .I5(PosX_reg_reg__0[5]),
        .O(TMDS_inst_i_15_n_0));
  LUT5 #(
    .INIT(32'h00000001)) 
    TMDS_inst_i_18
       (.I0(PosY_reg_reg__0[3]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[2]),
        .I4(PosY_reg_reg__0[4]),
        .O(TMDS_inst_i_18_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFF8)) 
    TMDS_inst_i_2
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[7]),
        .I3(PosX_reg_reg__0[9]),
        .I4(PosX_reg_reg__0[8]),
        .O(hSync));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    TMDS_inst_i_3
       (.I0(TMDS_inst_i_8_n_0),
        .I1(PosY_reg_reg__0[3]),
        .I2(PosY_reg_reg__0[8]),
        .I3(PosY_reg_reg__0[2]),
        .I4(PosY_reg_reg__0[1]),
        .I5(PosY_reg_reg__0[9]),
        .O(vSync));
  LUT6 #(
    .INIT(64'h0000000001FFFFA8)) 
    TMDS_inst_i_4
       (.I0(PosX_reg_reg__0[7]),
        .I1(TMDS_inst_i_9_n_0),
        .I2(PosX_reg_reg__0[6]),
        .I3(PosX_reg_reg__0[8]),
        .I4(PosX_reg_reg__0[9]),
        .I5(TMDS_inst_i_10_n_0),
        .O(ActiveArea));
  LUT6 #(
    .INIT(64'h3C003F373C003C04)) 
    TMDS_inst_i_5
       (.I0(TMDS_inst_i_11_n_0),
        .I1(TMDS_inst_i_12_n_0),
        .I2(TMDS_inst_i_13_n_0),
        .I3(TMDS_inst_i_14_n_0),
        .I4(char_tab_i_14_n_0),
        .I5(TMDS_inst_i_15_n_0),
        .O(TMDS_inst_i_5_n_0));
  LUT3 #(
    .INIT(8'h01)) 
    TMDS_inst_i_7
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(PosX_reg_reg__0[4]),
        .O(TMDS_inst_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    TMDS_inst_i_8
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[4]),
        .I2(PosY_reg_reg__0[7]),
        .I3(PosY_reg_reg__0[6]),
        .O(TMDS_inst_i_8_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    TMDS_inst_i_9
       (.I0(PosX_reg_reg__0[4]),
        .I1(PosX_reg_reg__0[5]),
        .O(TMDS_inst_i_9_n_0));
  LUT6 #(
    .INIT(64'hFFFF0000FF54FF54)) 
    char_tab_i_1
       (.I0(char_tab_i_9_n_0),
        .I1(char_tab_i_10_n_0),
        .I2(char_tab_i_11_n_0),
        .I3(char_tab_i_12_n_0),
        .I4(\PosX_reg_reg[6]_2 ),
        .I5(char_tab_i_14_n_0),
        .O(a[7]));
  LUT6 #(
    .INIT(64'h00000000FFD800D8)) 
    char_tab_i_10
       (.I0(\TMDSn[2]_6 ),
        .I1(D[2]),
        .I2(\q_reg[152]_1 ),
        .I3(\TMDSn[2]_1 ),
        .I4(D[6]),
        .I5(\TMDSn[2]_7 ),
        .O(char_tab_i_10_n_0));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    char_tab_i_101
       (.I0(\TMDSn[2]_2 ),
        .I1(\bbstub_spo[31] [4]),
        .I2(\bbstub_spo[31] [8]),
        .I3(\TMDSn[2]_5 ),
        .I4(char_tab_i_26_n_0),
        .O(char_tab_i_101_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_106
       (.I0(\TMDSn[2]_1 ),
        .I1(\q_reg[34] [0]),
        .O(char_tab_i_106_n_0));
  LUT3 #(
    .INIT(8'h4F)) 
    char_tab_i_108
       (.I0(\q_reg[27] [1]),
        .I1(\TMDSn[2] ),
        .I2(\TMDSn[2]_3 ),
        .O(char_tab_i_108_n_0));
  LUT3 #(
    .INIT(8'hBA)) 
    char_tab_i_109
       (.I0(\TMDSn[2]_4 ),
        .I1(\TMDSn[2]_3 ),
        .I2(\q_reg[27] [2]),
        .O(char_tab_i_109_n_0));
  LUT5 #(
    .INIT(32'h22F2FFFF)) 
    char_tab_i_11
       (.I0(D[12]),
        .I1(\TMDSn[2]_5 ),
        .I2(D[9]),
        .I3(\TMDSn[2]_2 ),
        .I4(char_tab_i_26_n_0),
        .O(char_tab_i_11_n_0));
  LUT6 #(
    .INIT(64'hFF00470000004700)) 
    char_tab_i_12
       (.I0(\PC_reg_reg[3] ),
        .I1(char_tab_i_38_n_0),
        .I2(char_tab_i_39_n_0),
        .I3(char_tab_i_18_n_0),
        .I4(char_tab_i_26_n_0),
        .I5(\q_reg[27]_0 ),
        .O(char_tab_i_12_n_0));
  LUT6 #(
    .INIT(64'h5555555555555556)) 
    char_tab_i_14
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[4]),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[1]),
        .I5(PosY_reg_reg__0[3]),
        .O(char_tab_i_14_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFC5C5F505)) 
    char_tab_i_17
       (.I0(char_tab_i_46_n_0),
        .I1(\PC_reg_reg[2] ),
        .I2(char_tab_i_38_n_0),
        .I3(\PC_reg_reg[6] [2]),
        .I4(\TMDSn[2]_5 ),
        .I5(char_tab_i_26_n_0),
        .O(char_tab_i_17_n_0));
  LUT4 #(
    .INIT(16'h5556)) 
    char_tab_i_18
       (.I0(PosY_reg_reg__0[8]),
        .I1(char_tab_i_48_n_0),
        .I2(PosY_reg_reg__0[6]),
        .I3(PosY_reg_reg__0[7]),
        .O(char_tab_i_18_n_0));
  LUT6 #(
    .INIT(64'hEEFEFFFFEEFE0000)) 
    char_tab_i_19
       (.I0(char_tab_i_49_n_0),
        .I1(\q_reg[152]_0 ),
        .I2(D[8]),
        .I3(\TMDSn[2]_2 ),
        .I4(char_tab_i_26_n_0),
        .I5(char_tab_i_51_n_0),
        .O(char_tab_i_19_n_0));
  LUT6 #(
    .INIT(64'h8B88BBBB8B888888)) 
    char_tab_i_2
       (.I0(\PosX_reg_reg[4]_1 ),
        .I1(char_tab_i_14_n_0),
        .I2(\q_reg[14] ),
        .I3(char_tab_i_17_n_0),
        .I4(char_tab_i_18_n_0),
        .I5(char_tab_i_19_n_0),
        .O(a[6]));
  LUT6 #(
    .INIT(64'h00000000AAAAEEAE)) 
    char_tab_i_21
       (.I0(char_tab_i_53_n_0),
        .I1(\q_reg[16] ),
        .I2(\TMDSn[2]_1 ),
        .I3(\q_reg[34] [1]),
        .I4(\TMDSn[2]_7 ),
        .I5(char_tab_i_55_n_0),
        .O(char_tab_i_21_n_0));
  LUT6 #(
    .INIT(64'hFF70FF70FF00FFFF)) 
    char_tab_i_22
       (.I0(\TMDSn[2]_1 ),
        .I1(\q_reg[27] [7]),
        .I2(char_tab_i_56_n_0),
        .I3(char_tab_i_57_n_0),
        .I4(\q_reg[27] [9]),
        .I5(\TMDSn[2]_2 ),
        .O(char_tab_i_22_n_0));
  LUT6 #(
    .INIT(64'hFFAEFFFFFFAE0000)) 
    char_tab_i_23
       (.I0(char_tab_i_58_n_0),
        .I1(D[11]),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[152] ),
        .I4(char_tab_i_26_n_0),
        .I5(char_tab_i_60_n_0),
        .O(char_tab_i_23_n_0));
  LUT6 #(
    .INIT(64'hBBBBBBBBABABABAA)) 
    char_tab_i_24
       (.I0(char_tab_i_14_n_0),
        .I1(char_tab_i_61_n_0),
        .I2(char_tab_i_62_n_0),
        .I3(\PosX_reg_reg[4]_0 ),
        .I4(\PosX_reg_reg[6]_1 ),
        .I5(char_tab_i_65_n_0),
        .O(char_tab_i_24_n_0));
  MUXF7 char_tab_i_25
       (.I0(char_tab_i_66_n_0),
        .I1(\PC_reg_reg[0] ),
        .O(char_tab_i_25_n_0),
        .S(char_tab_i_38_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    char_tab_i_26
       (.I0(PosY_reg_reg__0[6]),
        .I1(char_tab_i_48_n_0),
        .O(char_tab_i_26_n_0));
  LUT6 #(
    .INIT(64'hDD1D1111FFFFFFFF)) 
    char_tab_i_27
       (.I0(\q_reg[27] [8]),
        .I1(\TMDSn[2]_2 ),
        .I2(char_tab_i_68_n_0),
        .I3(char_tab_i_69_n_0),
        .I4(char_tab_i_70_n_0),
        .I5(\TMDSn[2]_5 ),
        .O(char_tab_i_27_n_0));
  LUT6 #(
    .INIT(64'h0808A808A8A8A808)) 
    char_tab_i_28
       (.I0(char_tab_i_14_n_0),
        .I1(\q_reg[121] ),
        .I2(\TMDSn[2]_5 ),
        .I3(\q_reg[137] ),
        .I4(\TMDSn[2]_2 ),
        .I5(\q_reg[147] ),
        .O(char_tab_i_28_n_0));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    char_tab_i_29
       (.I0(\TMDSn[2]_2 ),
        .I1(\bbstub_spo[31] [7]),
        .I2(\bbstub_spo[31] [11]),
        .I3(\TMDSn[2]_5 ),
        .I4(char_tab_i_26_n_0),
        .O(char_tab_i_29_n_0));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8BB8888)) 
    char_tab_i_3
       (.I0(\PosX_reg_reg[6]_0 ),
        .I1(char_tab_i_14_n_0),
        .I2(char_tab_i_21_n_0),
        .I3(char_tab_i_22_n_0),
        .I4(char_tab_i_18_n_0),
        .I5(char_tab_i_23_n_0),
        .O(a[5]));
  LUT3 #(
    .INIT(8'h08)) 
    char_tab_i_31
       (.I0(PosX_reg_reg__0[6]),
        .I1(PosX_reg_reg__0[5]),
        .I2(char_tab_i_73_n_0),
        .O(\TMDSn[2]_1 ));
  LUT2 #(
    .INIT(4'h7)) 
    char_tab_i_32
       (.I0(\TMDSn[2]_2 ),
        .I1(\TMDSn[2]_5 ),
        .O(\TMDSn[2]_7 ));
  LUT4 #(
    .INIT(16'h4004)) 
    char_tab_i_33
       (.I0(char_tab_i_74_n_0),
        .I1(char_tab_i_75_n_0),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosX_reg_reg__0[5]),
        .O(\TMDSn[2]_6 ));
  LUT3 #(
    .INIT(8'hFB)) 
    char_tab_i_35
       (.I0(char_tab_i_73_n_0),
        .I1(PosX_reg_reg__0[6]),
        .I2(PosX_reg_reg__0[5]),
        .O(\TMDSn[2]_5 ));
  LUT4 #(
    .INIT(16'hEFFB)) 
    char_tab_i_36
       (.I0(char_tab_i_74_n_0),
        .I1(PosX_reg_reg__0[4]),
        .I2(\PosX_reg[8]_i_2_n_0 ),
        .I3(PosX_reg_reg__0[5]),
        .O(\TMDSn[2]_2 ));
  LUT3 #(
    .INIT(8'h56)) 
    char_tab_i_38
       (.I0(PosY_reg_reg__0[7]),
        .I1(char_tab_i_48_n_0),
        .I2(PosY_reg_reg__0[6]),
        .O(char_tab_i_38_n_0));
  LUT6 #(
    .INIT(64'hEE0FEE0F0000FF0F)) 
    char_tab_i_39
       (.I0(char_tab_i_77_n_0),
        .I1(\q_reg[18] ),
        .I2(\q_reg[34] [7]),
        .I3(\TMDSn[2]_2 ),
        .I4(\q_reg[34] [11]),
        .I5(\TMDSn[2]_5 ),
        .O(char_tab_i_39_n_0));
  LUT6 #(
    .INIT(64'h00000000AAAEEEAE)) 
    char_tab_i_4
       (.I0(char_tab_i_24_n_0),
        .I1(char_tab_i_18_n_0),
        .I2(char_tab_i_25_n_0),
        .I3(char_tab_i_26_n_0),
        .I4(char_tab_i_27_n_0),
        .I5(char_tab_i_28_n_0),
        .O(a[4]));
  LUT5 #(
    .INIT(32'h00000009)) 
    char_tab_i_44
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(PosX_reg_reg__0[7]),
        .I4(char_tab_i_85_n_0),
        .O(\TMDSn[2]_4 ));
  LUT5 #(
    .INIT(32'h4F4FFF4F)) 
    char_tab_i_45
       (.I0(\TMDSn[2]_2 ),
        .I1(\q_reg[27] [8]),
        .I2(char_tab_i_26_n_0),
        .I3(\q_reg[27] [10]),
        .I4(\TMDSn[2]_5 ),
        .O(\TMDSn[2]_8 ));
  LUT6 #(
    .INIT(64'hEE0FEE0F0000FF0F)) 
    char_tab_i_46
       (.I0(char_tab_i_86_n_0),
        .I1(\q_reg[17] ),
        .I2(\q_reg[34] [6]),
        .I3(\TMDSn[2]_2 ),
        .I4(\q_reg[34] [10]),
        .I5(\TMDSn[2]_5 ),
        .O(char_tab_i_46_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    char_tab_i_48
       (.I0(PosY_reg_reg__0[5]),
        .I1(PosY_reg_reg__0[4]),
        .I2(PosY_reg_reg__0[2]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[1]),
        .I5(PosY_reg_reg__0[3]),
        .O(char_tab_i_48_n_0));
  LUT6 #(
    .INIT(64'h00000000FFD800D8)) 
    char_tab_i_49
       (.I0(\TMDSn[2]_6 ),
        .I1(D[1]),
        .I2(\PosX_reg_reg[4]_2 ),
        .I3(\TMDSn[2]_1 ),
        .I4(D[5]),
        .I5(\TMDSn[2]_7 ),
        .O(char_tab_i_49_n_0));
  LUT5 #(
    .INIT(32'hAAAAAAA9)) 
    char_tab_i_5
       (.I0(PosY_reg_reg__0[4]),
        .I1(PosY_reg_reg__0[3]),
        .I2(PosY_reg_reg__0[1]),
        .I3(PosY_reg_reg__0[0]),
        .I4(PosY_reg_reg__0[2]),
        .O(a[3]));
  LUT6 #(
    .INIT(64'h11F011F0FFFF00F0)) 
    char_tab_i_51
       (.I0(char_tab_i_91_n_0),
        .I1(\PosX_reg_reg[4]_4 ),
        .I2(\bbstub_spo[31] [10]),
        .I3(\TMDSn[2]_5 ),
        .I4(\bbstub_spo[31] [6]),
        .I5(\TMDSn[2]_2 ),
        .O(char_tab_i_51_n_0));
  LUT5 #(
    .INIT(32'hFFFF44F4)) 
    char_tab_i_53
       (.I0(\TMDSn[2]_2 ),
        .I1(\q_reg[34] [5]),
        .I2(\q_reg[34] [9]),
        .I3(\TMDSn[2]_5 ),
        .I4(char_tab_i_38_n_0),
        .O(char_tab_i_53_n_0));
  LUT6 #(
    .INIT(64'hEFAAAAAAEFAAEFAA)) 
    char_tab_i_55
       (.I0(char_tab_i_26_n_0),
        .I1(\TMDSn[2]_5 ),
        .I2(\PC_reg_reg[6] [1]),
        .I3(char_tab_i_38_n_0),
        .I4(\TMDSn[2]_2 ),
        .I5(\PC_reg_reg[6] [0]),
        .O(char_tab_i_55_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFF00B0FFB0)) 
    char_tab_i_56
       (.I0(\TMDSn[2]_3 ),
        .I1(\q_reg[27] [3]),
        .I2(\q_reg[0] ),
        .I3(\TMDSn[2]_4 ),
        .I4(\q_reg[27] [5]),
        .I5(char_tab_i_96_n_0),
        .O(char_tab_i_56_n_0));
  LUT2 #(
    .INIT(4'h7)) 
    char_tab_i_57
       (.I0(char_tab_i_26_n_0),
        .I1(\TMDSn[2]_5 ),
        .O(char_tab_i_57_n_0));
  LUT6 #(
    .INIT(64'h00000000FFD800D8)) 
    char_tab_i_58
       (.I0(\TMDSn[2]_6 ),
        .I1(D[0]),
        .I2(\q_reg[152]_2 ),
        .I3(\TMDSn[2]_1 ),
        .I4(D[4]),
        .I5(\TMDSn[2]_7 ),
        .O(char_tab_i_58_n_0));
  LUT4 #(
    .INIT(16'hAAA9)) 
    char_tab_i_6
       (.I0(PosY_reg_reg__0[3]),
        .I1(PosY_reg_reg__0[2]),
        .I2(PosY_reg_reg__0[0]),
        .I3(PosY_reg_reg__0[1]),
        .O(a[2]));
  LUT6 #(
    .INIT(64'h11F011F0FFFF00F0)) 
    char_tab_i_60
       (.I0(char_tab_i_99_n_0),
        .I1(\PosX_reg_reg[4]_5 ),
        .I2(\bbstub_spo[31] [9]),
        .I3(\TMDSn[2]_5 ),
        .I4(\bbstub_spo[31] [5]),
        .I5(\TMDSn[2]_2 ),
        .O(char_tab_i_60_n_0));
  LUT6 #(
    .INIT(64'hBBBBBBBBBABABBBA)) 
    char_tab_i_61
       (.I0(char_tab_i_18_n_0),
        .I1(char_tab_i_101_n_0),
        .I2(\PosX_reg_reg[4]_6 ),
        .I3(\TMDSn[2]_1 ),
        .I4(\bbstub_spo[31] [0]),
        .I5(\TMDSn[2]_7 ),
        .O(char_tab_i_61_n_0));
  LUT3 #(
    .INIT(8'hBA)) 
    char_tab_i_62
       (.I0(\TMDSn[2]_7 ),
        .I1(D[3]),
        .I2(\TMDSn[2]_1 ),
        .O(char_tab_i_62_n_0));
  LUT5 #(
    .INIT(32'h22F2FFFF)) 
    char_tab_i_65
       (.I0(D[10]),
        .I1(\TMDSn[2]_5 ),
        .I2(D[7]),
        .I3(\TMDSn[2]_2 ),
        .I4(char_tab_i_26_n_0),
        .O(char_tab_i_65_n_0));
  LUT6 #(
    .INIT(64'hEE0FEE0F0000FF0F)) 
    char_tab_i_66
       (.I0(char_tab_i_106_n_0),
        .I1(\q_reg[15] ),
        .I2(\q_reg[34] [8]),
        .I3(\TMDSn[2]_5 ),
        .I4(\q_reg[34] [4]),
        .I5(\TMDSn[2]_2 ),
        .O(char_tab_i_66_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFF55544454)) 
    char_tab_i_68
       (.I0(char_tab_i_108_n_0),
        .I1(\TMDSn[2] ),
        .I2(\q_reg[27] [0]),
        .I3(\TMDSn[2]_0 ),
        .I4(\q_reg[12] ),
        .I5(char_tab_i_109_n_0),
        .O(char_tab_i_68_n_0));
  LUT4 #(
    .INIT(16'hEFEE)) 
    char_tab_i_69
       (.I0(\TMDSn[2]_1 ),
        .I1(\TMDSn[2]_6 ),
        .I2(\q_reg[27] [4]),
        .I3(\TMDSn[2]_4 ),
        .O(char_tab_i_69_n_0));
  LUT3 #(
    .INIT(8'hA9)) 
    char_tab_i_7
       (.I0(PosY_reg_reg__0[2]),
        .I1(PosY_reg_reg__0[1]),
        .I2(PosY_reg_reg__0[0]),
        .O(a[1]));
  LUT4 #(
    .INIT(16'h0777)) 
    char_tab_i_70
       (.I0(\TMDSn[2]_1 ),
        .I1(\q_reg[27] [6]),
        .I2(\TMDSn[2]_6 ),
        .I3(\q_reg[27] [10]),
        .O(char_tab_i_70_n_0));
  LUT6 #(
    .INIT(64'hFFFFDFFFFFFFF7BB)) 
    char_tab_i_73
       (.I0(PosX_reg_reg__0[4]),
        .I1(PosX_reg_reg__0[7]),
        .I2(TMDS_inst_i_7_n_0),
        .I3(\PosX_reg[8]_i_2_n_0 ),
        .I4(PosX_reg_reg__0[9]),
        .I5(PosX_reg_reg__0[8]),
        .O(char_tab_i_73_n_0));
  LUT6 #(
    .INIT(64'hFFFFFEFFFFFF7F77)) 
    char_tab_i_74
       (.I0(PosX_reg_reg__0[7]),
        .I1(PosX_reg_reg__0[6]),
        .I2(TMDS_inst_i_9_n_0),
        .I3(\PosX_reg[8]_i_2_n_0 ),
        .I4(PosX_reg_reg__0[9]),
        .I5(PosX_reg_reg__0[8]),
        .O(char_tab_i_74_n_0));
  LUT5 #(
    .INIT(32'h95555555)) 
    char_tab_i_75
       (.I0(PosX_reg_reg__0[4]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(PosX_reg_reg__0[0]),
        .I4(Q[1]),
        .O(char_tab_i_75_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_77
       (.I0(\TMDSn[2]_1 ),
        .I1(\q_reg[34] [3]),
        .O(char_tab_i_77_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    char_tab_i_8
       (.I0(PosY_reg_reg__0[1]),
        .I1(PosY_reg_reg__0[0]),
        .O(a[0]));
  LUT5 #(
    .INIT(32'h00004100)) 
    char_tab_i_82
       (.I0(char_tab_i_85_n_0),
        .I1(\PosX_reg[8]_i_2_n_0 ),
        .I2(PosX_reg_reg__0[4]),
        .I3(PosX_reg_reg__0[5]),
        .I4(PosX_reg_reg__0[7]),
        .O(\TMDSn[2] ));
  LUT6 #(
    .INIT(64'hFFFFFBEFFFEFFBFF)) 
    char_tab_i_83
       (.I0(char_tab_i_85_n_0),
        .I1(PosX_reg_reg__0[5]),
        .I2(\PosX_reg[8]_i_2_n_0 ),
        .I3(PosX_reg_reg__0[4]),
        .I4(PosX_reg_reg__0[7]),
        .I5(PosX_reg_reg__0[6]),
        .O(\TMDSn[2]_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFDB)) 
    char_tab_i_84
       (.I0(\PosX_reg[8]_i_2_n_0 ),
        .I1(PosX_reg_reg__0[4]),
        .I2(PosX_reg_reg__0[5]),
        .I3(PosX_reg_reg__0[7]),
        .I4(char_tab_i_85_n_0),
        .O(\TMDSn[2]_3 ));
  LUT6 #(
    .INIT(64'hFFFFF9FFF9F9FFF9)) 
    char_tab_i_85
       (.I0(PosX_reg_reg__0[8]),
        .I1(PosX_reg_reg__0[7]),
        .I2(PosX_reg_reg__0[9]),
        .I3(\PosX_reg[8]_i_2_n_0 ),
        .I4(TMDS_inst_i_9_n_0),
        .I5(PosX_reg_reg__0[6]),
        .O(char_tab_i_85_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_86
       (.I0(\TMDSn[2]_1 ),
        .I1(\q_reg[34] [2]),
        .O(char_tab_i_86_n_0));
  LUT6 #(
    .INIT(64'hBBBBBBBBBABABBBA)) 
    char_tab_i_9
       (.I0(char_tab_i_18_n_0),
        .I1(char_tab_i_29_n_0),
        .I2(\PosX_reg_reg[4]_3 ),
        .I3(\TMDSn[2]_1 ),
        .I4(\bbstub_spo[31] [3]),
        .I5(\TMDSn[2]_7 ),
        .O(char_tab_i_9_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_91
       (.I0(\TMDSn[2]_1 ),
        .I1(\bbstub_spo[31] [2]),
        .O(char_tab_i_91_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    char_tab_i_96
       (.I0(\TMDSn[2]_6 ),
        .I1(\TMDSn[2]_1 ),
        .O(char_tab_i_96_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    char_tab_i_99
       (.I0(\TMDSn[2]_1 ),
        .I1(\bbstub_spo[31] [1]),
        .O(char_tab_i_99_n_0));
endmodule

module vga_data
   (\TMDSn[2] ,
    a,
    CLK,
    Q);
  output \TMDSn[2] ;
  input [7:0]a;
  input CLK;
  input [2:0]Q;

  wire CLK;
  wire [2:0]Q;
  wire TMDS_inst_i_16_n_0;
  wire TMDS_inst_i_17_n_0;
  wire \TMDSn[2] ;
  wire [7:0]a;
  wire [7:0]rom_dout;

  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    TMDS_inst_i_16
       (.I0(rom_dout[4]),
        .I1(rom_dout[5]),
        .I2(Q[1]),
        .I3(rom_dout[6]),
        .I4(Q[0]),
        .I5(rom_dout[7]),
        .O(TMDS_inst_i_16_n_0));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    TMDS_inst_i_17
       (.I0(rom_dout[0]),
        .I1(rom_dout[1]),
        .I2(Q[1]),
        .I3(rom_dout[2]),
        .I4(Q[0]),
        .I5(rom_dout[3]),
        .O(TMDS_inst_i_17_n_0));
  MUXF7 TMDS_inst_i_6
       (.I0(TMDS_inst_i_16_n_0),
        .I1(TMDS_inst_i_17_n_0),
        .O(\TMDSn[2] ),
        .S(Q[2]));
  (* x_core_info = "dist_mem_gen_v8_0_11,Vivado 2017.1" *) 
  DisplayROM char_tab
       (.a(a),
        .clk(CLK),
        .qspo(rom_dout));
endmodule

(* C_ADDR_WIDTH = "6" *) (* C_DEFAULT_DATA = "0" *) (* C_DEPTH = "64" *) 
(* C_ELABORATION_DIR = "./" *) (* C_FAMILY = "artix7" *) (* C_HAS_CLK = "1" *) 
(* C_HAS_D = "1" *) (* C_HAS_DPO = "0" *) (* C_HAS_DPRA = "0" *) 
(* C_HAS_I_CE = "0" *) (* C_HAS_QDPO = "0" *) (* C_HAS_QDPO_CE = "0" *) 
(* C_HAS_QDPO_CLK = "0" *) (* C_HAS_QDPO_RST = "0" *) (* C_HAS_QDPO_SRST = "0" *) 
(* C_HAS_QSPO = "0" *) (* C_HAS_QSPO_CE = "0" *) (* C_HAS_QSPO_RST = "0" *) 
(* C_HAS_QSPO_SRST = "0" *) (* C_HAS_SPO = "1" *) (* C_HAS_WE = "1" *) 
(* C_MEM_INIT_FILE = "no_coe_file_loaded" *) (* C_MEM_TYPE = "1" *) (* C_PARSER_TYPE = "1" *) 
(* C_PIPELINE_STAGES = "0" *) (* C_QCE_JOINED = "0" *) (* C_QUALIFY_WE = "0" *) 
(* C_READ_MIF = "0" *) (* C_REG_A_D_INPUTS = "0" *) (* C_REG_DPRA_INPUT = "0" *) 
(* C_SYNC_ENABLE = "1" *) (* C_WIDTH = "32" *) (* ORIG_REF_NAME = "dist_mem_gen_v8_0_12" *) 
module DataRAM_dist_mem_gen_v8_0_12
   (a,
    d,
    dpra,
    clk,
    we,
    i_ce,
    qspo_ce,
    qdpo_ce,
    qdpo_clk,
    qspo_rst,
    qdpo_rst,
    qspo_srst,
    qdpo_srst,
    spo,
    dpo,
    qspo,
    qdpo);
  input [5:0]a;
  input [31:0]d;
  input [5:0]dpra;
  input clk;
  input we;
  input i_ce;
  input qspo_ce;
  input qdpo_ce;
  input qdpo_clk;
  input qspo_rst;
  input qdpo_rst;
  input qspo_srst;
  input qdpo_srst;
  output [31:0]spo;
  output [31:0]dpo;
  output [31:0]qspo;
  output [31:0]qdpo;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  DataRAM_dist_mem_gen_v8_0_12_synth \synth_options.dist_mem_inst 
       (.a(a),
        .clk(clk),
        .d(d),
        .spo(spo),
        .we(we));
endmodule

(* ORIG_REF_NAME = "dist_mem_gen_v8_0_12_synth" *) 
module DataRAM_dist_mem_gen_v8_0_12_synth
   (spo,
    clk,
    d,
    we,
    a);
  output [31:0]spo;
  input clk;
  input [31:0]d;
  input we;
  input [5:0]a;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  DataRAM_spram \gen_sp_ram.spram_inst 
       (.a(a),
        .clk(clk),
        .d(d),
        .spo(spo),
        .we(we));
endmodule

(* ORIG_REF_NAME = "spram" *) 
module DataRAM_spram
   (spo,
    clk,
    d,
    we,
    a);
  output [31:0]spo;
  input clk;
  input [31:0]d;
  input we;
  input [5:0]a;

  wire [5:0]a;
  wire clk;
  wire [31:0]d;
  wire [31:0]spo;
  wire we;

  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_UNIQ_BASE_ ram_reg_0_63_0_0
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[0]),
        .O(spo[0]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD1 ram_reg_0_63_10_10
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[10]),
        .O(spo[10]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD2 ram_reg_0_63_11_11
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[11]),
        .O(spo[11]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD3 ram_reg_0_63_12_12
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[12]),
        .O(spo[12]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD4 ram_reg_0_63_13_13
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[13]),
        .O(spo[13]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD5 ram_reg_0_63_14_14
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[14]),
        .O(spo[14]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD6 ram_reg_0_63_15_15
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[15]),
        .O(spo[15]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD7 ram_reg_0_63_16_16
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[16]),
        .O(spo[16]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD8 ram_reg_0_63_17_17
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[17]),
        .O(spo[17]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD9 ram_reg_0_63_18_18
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[18]),
        .O(spo[18]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD10 ram_reg_0_63_19_19
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[19]),
        .O(spo[19]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD11 ram_reg_0_63_1_1
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[1]),
        .O(spo[1]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD12 ram_reg_0_63_20_20
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[20]),
        .O(spo[20]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD13 ram_reg_0_63_21_21
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[21]),
        .O(spo[21]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD14 ram_reg_0_63_22_22
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[22]),
        .O(spo[22]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD15 ram_reg_0_63_23_23
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[23]),
        .O(spo[23]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD16 ram_reg_0_63_24_24
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[24]),
        .O(spo[24]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD17 ram_reg_0_63_25_25
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[25]),
        .O(spo[25]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD18 ram_reg_0_63_26_26
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[26]),
        .O(spo[26]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD19 ram_reg_0_63_27_27
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[27]),
        .O(spo[27]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD20 ram_reg_0_63_28_28
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[28]),
        .O(spo[28]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD21 ram_reg_0_63_29_29
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[29]),
        .O(spo[29]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD22 ram_reg_0_63_2_2
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[2]),
        .O(spo[2]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD23 ram_reg_0_63_30_30
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[30]),
        .O(spo[30]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD24 ram_reg_0_63_31_31
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[31]),
        .O(spo[31]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD25 ram_reg_0_63_3_3
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[3]),
        .O(spo[3]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD26 ram_reg_0_63_4_4
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[4]),
        .O(spo[4]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD27 ram_reg_0_63_5_5
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[5]),
        .O(spo[5]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD28 ram_reg_0_63_6_6
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[6]),
        .O(spo[6]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD29 ram_reg_0_63_7_7
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[7]),
        .O(spo[7]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD30 ram_reg_0_63_8_8
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[8]),
        .O(spo[8]),
        .WCLK(clk),
        .WE(we));
  (* INIT = "64'h0000000000000000" *) 
  RAM64X1S_HD31 ram_reg_0_63_9_9
       (.A0(a[0]),
        .A1(a[1]),
        .A2(a[2]),
        .A3(a[3]),
        .A4(a[4]),
        .A5(a[5]),
        .D(d[9]),
        .O(spo[9]),
        .WCLK(clk),
        .WE(we));
endmodule

(* C_ADDR_WIDTH = "8" *) (* C_DEFAULT_DATA = "0" *) (* C_DEPTH = "256" *) 
(* C_ELABORATION_DIR = "./" *) (* C_FAMILY = "artix7" *) (* C_HAS_CLK = "1" *) 
(* C_HAS_D = "0" *) (* C_HAS_DPO = "0" *) (* C_HAS_DPRA = "0" *) 
(* C_HAS_I_CE = "0" *) (* C_HAS_QDPO = "0" *) (* C_HAS_QDPO_CE = "0" *) 
(* C_HAS_QDPO_CLK = "0" *) (* C_HAS_QDPO_RST = "0" *) (* C_HAS_QDPO_SRST = "0" *) 
(* C_HAS_QSPO = "1" *) (* C_HAS_QSPO_CE = "0" *) (* C_HAS_QSPO_RST = "0" *) 
(* C_HAS_QSPO_SRST = "0" *) (* C_HAS_SPO = "0" *) (* C_HAS_WE = "0" *) 
(* C_MEM_INIT_FILE = "DisplayROM.mif" *) (* C_MEM_TYPE = "0" *) (* C_PARSER_TYPE = "1" *) 
(* C_PIPELINE_STAGES = "0" *) (* C_QCE_JOINED = "0" *) (* C_QUALIFY_WE = "0" *) 
(* C_READ_MIF = "1" *) (* C_REG_A_D_INPUTS = "0" *) (* C_REG_DPRA_INPUT = "0" *) 
(* C_SYNC_ENABLE = "1" *) (* C_WIDTH = "8" *) (* ORIG_REF_NAME = "dist_mem_gen_v8_0_11" *) 
module DisplayROM__dist_mem_gen_v8_0_11
   (a,
    d,
    dpra,
    clk,
    we,
    i_ce,
    qspo_ce,
    qdpo_ce,
    qdpo_clk,
    qspo_rst,
    qdpo_rst,
    qspo_srst,
    qdpo_srst,
    spo,
    dpo,
    qspo,
    qdpo);
  input [7:0]a;
  input [7:0]d;
  input [7:0]dpra;
  input clk;
  input we;
  input i_ce;
  input qspo_ce;
  input qdpo_ce;
  input qdpo_clk;
  input qspo_rst;
  input qdpo_rst;
  input qspo_srst;
  input qdpo_srst;
  output [7:0]spo;
  output [7:0]dpo;
  output [7:0]qspo;
  output [7:0]qdpo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;

  DisplayROM__dist_mem_gen_v8_0_11_synth \synth_options.dist_mem_inst 
       (.a(a),
        .clk(clk),
        .qspo(qspo));
endmodule

(* ORIG_REF_NAME = "dist_mem_gen_v8_0_11_synth" *) 
module DisplayROM__dist_mem_gen_v8_0_11_synth
   (qspo,
    a,
    clk);
  output [7:0]qspo;
  input [7:0]a;
  input clk;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;

  DisplayROM__rom \gen_rom.rom_inst 
       (.a(a),
        .clk(clk),
        .qspo(qspo));
endmodule

(* ORIG_REF_NAME = "rom" *) 
module DisplayROM__rom
   (qspo,
    a,
    clk);
  output [7:0]qspo;
  input [7:0]a;
  input clk;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire \qspo_int[0]_i_1_n_0 ;
  wire \qspo_int[0]_i_2_n_0 ;
  wire \qspo_int[1]_i_4_n_0 ;
  wire \qspo_int[1]_i_5_n_0 ;
  wire \qspo_int[1]_i_6_n_0 ;
  wire \qspo_int[1]_i_7_n_0 ;
  wire \qspo_int[2]_i_4_n_0 ;
  wire \qspo_int[2]_i_5_n_0 ;
  wire \qspo_int[2]_i_6_n_0 ;
  wire \qspo_int[2]_i_7_n_0 ;
  wire \qspo_int[3]_i_1_n_0 ;
  wire \qspo_int[3]_i_2_n_0 ;
  wire \qspo_int[3]_i_3_n_0 ;
  wire \qspo_int[3]_i_4_n_0 ;
  wire \qspo_int[4]_i_1_n_0 ;
  wire \qspo_int[4]_i_2_n_0 ;
  wire \qspo_int[4]_i_3_n_0 ;
  wire \qspo_int[4]_i_4_n_0 ;
  wire \qspo_int[4]_i_5_n_0 ;
  wire \qspo_int[5]_i_4_n_0 ;
  wire \qspo_int[5]_i_5_n_0 ;
  wire \qspo_int[5]_i_6_n_0 ;
  wire \qspo_int[5]_i_7_n_0 ;
  wire \qspo_int[6]_i_4_n_0 ;
  wire \qspo_int[6]_i_5_n_0 ;
  wire \qspo_int[6]_i_6_n_0 ;
  wire \qspo_int[6]_i_7_n_0 ;
  wire \qspo_int[7]_i_1_n_0 ;
  wire \qspo_int[7]_i_2_n_0 ;
  wire \qspo_int[7]_i_3_n_0 ;
  wire \qspo_int_reg[1]_i_1_n_0 ;
  wire \qspo_int_reg[1]_i_2_n_0 ;
  wire \qspo_int_reg[1]_i_3_n_0 ;
  wire \qspo_int_reg[2]_i_1_n_0 ;
  wire \qspo_int_reg[2]_i_2_n_0 ;
  wire \qspo_int_reg[2]_i_3_n_0 ;
  wire \qspo_int_reg[5]_i_1_n_0 ;
  wire \qspo_int_reg[5]_i_2_n_0 ;
  wire \qspo_int_reg[5]_i_3_n_0 ;
  wire \qspo_int_reg[6]_i_1_n_0 ;
  wire \qspo_int_reg[6]_i_2_n_0 ;
  wire \qspo_int_reg[6]_i_3_n_0 ;

  LUT6 #(
    .INIT(64'h0000200000000000)) 
    \qspo_int[0]_i_1 
       (.I0(a[5]),
        .I1(a[4]),
        .I2(\qspo_int[0]_i_2_n_0 ),
        .I3(a[2]),
        .I4(a[6]),
        .I5(a[7]),
        .O(\qspo_int[0]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h40)) 
    \qspo_int[0]_i_2 
       (.I0(a[1]),
        .I1(a[3]),
        .I2(a[0]),
        .O(\qspo_int[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0A08080014941C04)) 
    \qspo_int[1]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[0]),
        .I5(a[4]),
        .O(\qspo_int[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0105011566806000)) 
    \qspo_int[1]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[1]),
        .I3(a[3]),
        .I4(a[0]),
        .I5(a[2]),
        .O(\qspo_int[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00FD01CCCD20F300)) 
    \qspo_int[1]_i_6 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h07001400040030A0)) 
    \qspo_int[1]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[1]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h02024A8F2A080888)) 
    \qspo_int[2]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[4]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00001F40106780A0)) 
    \qspo_int[2]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000705000000D8C0)) 
    \qspo_int[2]_i_6 
       (.I0(a[6]),
        .I1(a[2]),
        .I2(a[4]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h003101450A404040)) 
    \qspo_int[2]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[0]),
        .I5(a[3]),
        .O(\qspo_int[2]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \qspo_int[3]_i_1 
       (.I0(\qspo_int[3]_i_2_n_0 ),
        .I1(\qspo_int[4]_i_3_n_0 ),
        .I2(a[7]),
        .I3(\qspo_int[3]_i_3_n_0 ),
        .I4(a[5]),
        .I5(\qspo_int[3]_i_4_n_0 ),
        .O(\qspo_int[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h006BFEB0000AB000)) 
    \qspo_int[3]_i_2 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[1]),
        .I4(a[3]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00EF710000800000)) 
    \qspo_int[3]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0089F00002000020)) 
    \qspo_int[3]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \qspo_int[4]_i_1 
       (.I0(\qspo_int[4]_i_2_n_0 ),
        .I1(\qspo_int[4]_i_3_n_0 ),
        .I2(a[7]),
        .I3(\qspo_int[4]_i_4_n_0 ),
        .I4(a[5]),
        .I5(\qspo_int[4]_i_5_n_0 ),
        .O(\qspo_int[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00EF611000000010)) 
    \qspo_int[4]_i_2 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000F00F4010000)) 
    \qspo_int[4]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0809F8886F000000)) 
    \qspo_int[4]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h04CDF46006404440)) 
    \qspo_int[4]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[2]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0202C01520080080)) 
    \qspo_int[5]_i_4 
       (.I0(a[6]),
        .I1(a[3]),
        .I2(a[4]),
        .I3(a[0]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h001D500000002220)) 
    \qspo_int[5]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[3]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0027CD0000005040)) 
    \qspo_int[5]_i_6 
       (.I0(a[6]),
        .I1(a[2]),
        .I2(a[4]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[0]),
        .O(\qspo_int[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000F1E0F0110000)) 
    \qspo_int[5]_i_7 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[3]),
        .I5(a[1]),
        .O(\qspo_int[5]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0048933B999C8000)) 
    \qspo_int[6]_i_4 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[1]),
        .I4(a[2]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h012F053D62802200)) 
    \qspo_int[6]_i_5 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[1]),
        .I3(a[3]),
        .I4(a[0]),
        .I5(a[2]),
        .O(\qspo_int[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00B98B88CD80FB00)) 
    \qspo_int[6]_i_6 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00FFFFFAFAC8FA00)) 
    \qspo_int[6]_i_7 
       (.I0(a[6]),
        .I1(a[0]),
        .I2(a[4]),
        .I3(a[2]),
        .I4(a[1]),
        .I5(a[3]),
        .O(\qspo_int[6]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hE200)) 
    \qspo_int[7]_i_1 
       (.I0(\qspo_int[7]_i_2_n_0 ),
        .I1(a[5]),
        .I2(\qspo_int[7]_i_3_n_0 ),
        .I3(a[7]),
        .O(\qspo_int[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0840502A00000000)) 
    \qspo_int[7]_i_2 
       (.I0(a[3]),
        .I1(a[0]),
        .I2(a[1]),
        .I3(a[2]),
        .I4(a[4]),
        .I5(a[6]),
        .O(\qspo_int[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000F00000E00000)) 
    \qspo_int[7]_i_3 
       (.I0(a[6]),
        .I1(a[4]),
        .I2(a[0]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(a[2]),
        .O(\qspo_int[7]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[0]_i_1_n_0 ),
        .Q(qspo[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[1]_i_1_n_0 ),
        .Q(qspo[1]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[1]_i_1 
       (.I0(\qspo_int_reg[1]_i_2_n_0 ),
        .I1(\qspo_int_reg[1]_i_3_n_0 ),
        .O(\qspo_int_reg[1]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[1]_i_2 
       (.I0(\qspo_int[1]_i_4_n_0 ),
        .I1(\qspo_int[1]_i_5_n_0 ),
        .O(\qspo_int_reg[1]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[1]_i_3 
       (.I0(\qspo_int[1]_i_6_n_0 ),
        .I1(\qspo_int[1]_i_7_n_0 ),
        .O(\qspo_int_reg[1]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[2]_i_1_n_0 ),
        .Q(qspo[2]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[2]_i_1 
       (.I0(\qspo_int_reg[2]_i_2_n_0 ),
        .I1(\qspo_int_reg[2]_i_3_n_0 ),
        .O(\qspo_int_reg[2]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[2]_i_2 
       (.I0(\qspo_int[2]_i_4_n_0 ),
        .I1(\qspo_int[2]_i_5_n_0 ),
        .O(\qspo_int_reg[2]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[2]_i_3 
       (.I0(\qspo_int[2]_i_6_n_0 ),
        .I1(\qspo_int[2]_i_7_n_0 ),
        .O(\qspo_int_reg[2]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[3]_i_1_n_0 ),
        .Q(qspo[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[4]_i_1_n_0 ),
        .Q(qspo[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[5]_i_1_n_0 ),
        .Q(qspo[5]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[5]_i_1 
       (.I0(\qspo_int_reg[5]_i_2_n_0 ),
        .I1(\qspo_int_reg[5]_i_3_n_0 ),
        .O(\qspo_int_reg[5]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[5]_i_2 
       (.I0(\qspo_int[5]_i_4_n_0 ),
        .I1(\qspo_int[5]_i_5_n_0 ),
        .O(\qspo_int_reg[5]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[5]_i_3 
       (.I0(\qspo_int[5]_i_6_n_0 ),
        .I1(\qspo_int[5]_i_7_n_0 ),
        .O(\qspo_int_reg[5]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int_reg[6]_i_1_n_0 ),
        .Q(qspo[6]),
        .R(1'b0));
  MUXF8 \qspo_int_reg[6]_i_1 
       (.I0(\qspo_int_reg[6]_i_2_n_0 ),
        .I1(\qspo_int_reg[6]_i_3_n_0 ),
        .O(\qspo_int_reg[6]_i_1_n_0 ),
        .S(a[7]));
  MUXF7 \qspo_int_reg[6]_i_2 
       (.I0(\qspo_int[6]_i_4_n_0 ),
        .I1(\qspo_int[6]_i_5_n_0 ),
        .O(\qspo_int_reg[6]_i_2_n_0 ),
        .S(a[5]));
  MUXF7 \qspo_int_reg[6]_i_3 
       (.I0(\qspo_int[6]_i_6_n_0 ),
        .I1(\qspo_int[6]_i_7_n_0 ),
        .O(\qspo_int_reg[6]_i_3_n_0 ),
        .S(a[5]));
  FDRE #(
    .INIT(1'b0)) 
    \qspo_int_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qspo_int[7]_i_1_n_0 ),
        .Q(qspo[7]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
