module InstructionROM(addr,dout);
	input [5 : 0] addr;
	output [31 : 0] dout;
	reg [31 : 0] dout;
	always @(*)
		case (addr)
            // Setup Handler
			6'd0:  dout=32'h04000093; // addi x1, x0, 0x40   (Handler Addr = 0x40 = 16*4)
            // NOPs to resolve hazard (addi -> csrw)
            6'd1:  dout=32'h00000013; // nop
            6'd2:  dout=32'h00000013; // nop
            
			6'd3:  dout=32'h30509073; // csrw mtvec, x1      (Set MTVEC)
            
            // Test Illegal Instruction
			6'd4:  dout=32'hFFFFFFFF; // Illegal Instruction
            // Return point 1
			6'd5:  dout=32'h00100113; // addi x2, x0, 1      (x2 = 1, indicates return from illegal)
            
            // Test ECALL
			6'd6:  dout=32'h00000073; // ecall
            // Return point 2
			6'd7:  dout=32'h00100193; // addi x3, x0, 1      (x3 = 1, indicates return from ecall)
			
            // Halt
			6'd8:  dout=32'h00000063; // beq x0, x0, 0       (Loop)
			
            // Exception Handler (Addr 16 = 0x10)
            6'd16: dout=32'h34202F73; // csrr x30, mcause    (Read Cause)
            6'd17: dout=32'h34102FF3; // csrr x31, mepc      (Read EPC)
            
            // NOPs for x31 hazard (csrr -> addi)
            6'd18: dout=32'h00000013; // nop
            6'd19: dout=32'h00000013; // nop
            
            6'd20: dout=32'h004F8F93; // addi x31, x31, 4    (EPC += 4)
            
            // NOPs for x31 hazard (addi -> csrw)
            6'd21: dout=32'h00000013; // nop
            6'd22: dout=32'h00000013; // nop
            
            6'd23: dout=32'h341F9073; // csrw mepc, x31      (Write EPC)
            6'd24: dout=32'h30200073; // mret                (Return)
			
			default: dout=32'h00000000; // nop
		endcase	
endmodule
