`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/06/14 08:18:23
// Design Name: 
// Module Name: E_LOCK_new
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ELOCK_FSM(
   input clk,reset,b0_in,b1_in,
   output out, 
   output [7:0] display,
   output [3:0] Seg_control,
   input en
   );
//synchronizer
reg E_signal;
always@(*)begin
if(en)E_signal=1;
else E_signal=0;
end

reg b0_in_en,b1_in_en;
always @(posedge clk or posedge reset or posedge en)begin
        if(reset)begin
            b0_in_en <= 0;
            b1_in_en <= 0;
            end
        else if(en) begin
            b0_in_en <= b0_in;
            b1_in_en <= b1_in;
        end  
    end

    reg b0_sync,b0temp,b1_sync,b1temp;
    always @(posedge clk)
    {b0_sync,b0temp} <={b0temp,b0_in};
    always @(posedge clk)
    {b1_sync,b1temp} <={b1temp,b1_in};
//debounce  
    wire b0_de,b1_de;
debounceIndex de1(.reset(reset), .clk(clk), .noisy(b0_sync), .clean(b0_de)); 
debounceIndex de2(.reset(reset), .clk(clk), .noisy(b1_sync), .clean(b1_de)); 
//conversion
    reg b0,b1;
    reg Q0,Q1;
    always @(posedge clk) begin
        Q0 <= b0_de;
        b0 <= ~Q0&b0_de;
        end
    always @(posedge clk) begin
        Q1 <= b1_de;
        b1 <= ~Q1&b1_de;
        end

parameter S_RESET = 0; parameter S_1 = 1;
parameter S_11 = 2; parameter S_110 = 3;
parameter S_1101 = 4;

reg [2:0] state ,next_state;

   always@(*) begin
   if(reset) next_state = S_RESET;
   else case (state)
        S_RESET: next_state = b0 ? S_RESET  :b1 ? S_1:state;
        S_1:     next_state = b0 ? S_RESET  :b1 ? S_11   :state;
        S_11:    next_state = b0 ? S_110:b1 ? S_1:state;
        S_110:   next_state = b0 ? S_RESET  :b1 ? S_1101 :state;
        S_1101:  next_state = b0 ? S_RESET:b1 ? S_11:state;
        default: next_state = S_RESET;
        endcase
    end
    always@(posedge clk) state<= next_state;
    assign out = (state == S_1101);    
//clk_div
wire clk_2ms;
clk_div #(.N(10_0000)) c2(.clk(clk),.reset(reset),.clk_div(clk_2ms));
//slight
reg [2:0] O1,O2,O3,O4;
wire [2:0] O;
always@(*) begin
       if(reset) begin
            O1=7;
            O2=7;
            O3=7;
            O4=7;
       end
       else case (state)
            S_RESET: begin O1=7;O2=7;O3=7;O4=7;end
            S_1:     begin O1=7;O2=7;O3=7;O4=1;end
            S_11:    begin O1=7;O2=7;O3=1;O4=1;end
            S_110:   begin O1=7;O2=1;O3=1;O4=0;end
            S_1101:  begin O1=4;O2=5;O3=6;O4=6;end
            default: begin O1=7;O2=7;O3=7;O4=7;end
            endcase
        end
slight #(.N(3)) s2(.E_signal(E_signal),.O1(O1),.O2(O2),.O3(O3),.O4(O4),.clk(clk_2ms),.reset(reset),.seg_control(Seg_control),.O(O));
// LED
    wire [7:0]segs;
    LED L1(.I(O),.Segs(segs));
    assign display = segs;
endmodule 

module debounceIndex (reset, clk, noisy, clean); 
input reset, clk, noisy;
output clean; 

parameter NDELAY = 65000;
parameter NBITS = 20;

reg [NBITS-1:0] count; 
reg xnew, clean;

always @(posedge clk) 
    if (reset) 
    begin 
        xnew <= noisy; 
        clean <= 0;
        count <= 0 ;
    end 
    else if (noisy!=xnew) 
    begin 
        xnew <= noisy; 
        count <= 0;
        end 
    else if (count == NDELAY) 
        clean <= noisy;
    else 
        count <= count+1;
endmodule

module LED(
input [2:0]I,
output reg [7:0]Segs
);
always @(I)begin
    case (I)
    0: Segs = 8'b11111100;
    1: Segs = 8'b01100000;
    2: Segs = 8'b11011010;
    3: Segs = 8'b11110010;
    4: Segs = 8'b11001110;//P
    5: Segs = 8'b11101110;//A
    6: Segs = 8'b10110110;//S
    7: Segs = 8'b00000000;//blank
    default: Segs = 8'b00000000;
    endcase
end
endmodule

module clk_div
#(
    parameter N=1_0000_0000
)
(
    input clk,reset,
    output reg clk_div
);
//synthesis: 2s:1_0000_0000 2ms:10_0000
reg [28:0] count;
//2_6843_5456
always @(posedge clk or posedge reset) begin
    if(reset) begin clk_div<=0;count<=0; end
    else if(count<N) count<=count+1;
    else if(count==N) begin count=0;clk_div=~clk_div; end
end
endmodule

module slight
#(  parameter N=8
)
(
    input [N-1:0] O1,O2,O3,O4,
    input clk,reset,
    output reg [3:0] seg_control,
    output reg [N-1:0] O,
    input E_signal
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            seg_control=4'b0000;
        else
         case(seg_control)
            4'b0000:begin if(E_signal)seg_control=4'b0001;
                    else seg_control=4'b0000; end
            4'b0001:begin if(E_signal) begin seg_control=4'b1000; O=O1; end
                    else seg_control=4'b0000; end
            4'b1000:begin if(E_signal) begin seg_control=4'b0100; O=O2; end
                    else seg_control=4'b0000; end
            4'b0100:begin if(E_signal) begin seg_control=4'b0010; O=O3; end
                    else seg_control=4'b0000; end
            4'b0010:begin if(E_signal) begin seg_control=4'b0001; O=O4; end
                    else seg_control=4'b0000; end
        endcase
    end
endmodule
