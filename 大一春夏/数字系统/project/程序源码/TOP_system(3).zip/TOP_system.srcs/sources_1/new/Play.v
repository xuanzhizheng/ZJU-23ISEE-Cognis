`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/18 19:54:43
// Design Name: 
// Module Name: Play
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Play(
input[17:0] divnum,
input clk,rst,pause,playsignal,
output reg sound
    );
    reg[31:0]cnt;
    always@(posedge clk or posedge rst)begin
    if(rst) begin cnt<=0;sound<=0;end
    else  if(!playsignal)begin sound<=0;cnt<=cnt;end
    
    else if(pause)begin sound<=0;cnt<=0; end
    else if(cnt<divnum-1)cnt<=cnt+1;
    else if(cnt>=divnum-1)begin cnt<=0;sound=~sound; end
    end

    
endmodule