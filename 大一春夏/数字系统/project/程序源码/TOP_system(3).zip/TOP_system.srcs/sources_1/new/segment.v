module segment(
    input [3:0] hex_display,
    output reg [11:0] seg
    );
always@(hex_display)
    begin
    case(hex_display)
    0: seg = 12'b1111_1111_1100;
    1: seg = 12'b0001_0110_0000;
    2: seg = 12'b0010_1101_1010;
    3: seg = 12'b0100_1111_0010;
    4: seg = 12'b1000_0110_0110;
    5: seg = 12'b1111_1100_1110;
 
    default: seg = 12'b1111_1111_1111;
    endcase
    end
endmodule