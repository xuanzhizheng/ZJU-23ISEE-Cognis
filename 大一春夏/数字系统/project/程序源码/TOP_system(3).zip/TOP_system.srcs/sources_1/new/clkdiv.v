`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/18 13:36:26
// Design Name: 
// Module Name: clk_div
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clkdiv(
input clk,rst,
output  reg clk_div
    );
     
    reg[31:0]cnt=0;
    parameter N=10;
    always@(posedge clk or posedge rst)begin
    if(rst)begin cnt<=0;clk_div<=0; end
    else if(cnt<N-1)cnt<=cnt+1;
    else if(cnt==N-1)begin cnt<=0;clk_div=~clk_div; end
    end
    
endmodule
