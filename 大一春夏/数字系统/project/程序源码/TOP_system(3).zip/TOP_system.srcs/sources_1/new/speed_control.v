`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/18 13:32:51
// Design Name: 
// Module Name: speed_control
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module speed_control(
input clk,rst,
output clk_4hz
    );
    wire clk_6Mhz;
    clkdiv #(.N('d8)) inst1(.clk(clk),.rst(rst),.clk_div(clk_6Mhz));// F1 = 100Mhz /( 2 * N ) = 6.25Mhz;
    clkdiv #(.N('d12500000)) inst2(.clk(clk),.rst(rst),.clk_div(clk_4hz));// 4hz = 100Mhz /( 2 * 12500000 );


endmodule
