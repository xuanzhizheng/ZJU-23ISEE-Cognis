module button(
    input clk,
    input in,
    output out         //��ť����
    );
    reg r1,r2,r3;
    always @(posedge clk)
    begin
    r1<=in;
    r2<=r1;
    r3<=r2;
    end
    assign out = ~r3&r2;     //old_button==0 && button==1
endmodule