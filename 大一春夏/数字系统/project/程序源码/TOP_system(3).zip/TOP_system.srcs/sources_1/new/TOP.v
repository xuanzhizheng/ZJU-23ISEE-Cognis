`timescale 1ns / 1ps

module TOP(
input clk,rst,in_Begin,in_stop,en,//s_begin,s_stop,,//jiaoyan
input[1:0]in_num,//s_num,
output sound,ground//led_begin,led_stop,led_num1,led_num0,led_rst,led_sound,led_pause,led_playsignal
);
wire Begin,stop;
wire [1:0]num;
assign ground=0;
assign Begin=in_Begin,stop=in_stop,num=in_num;
//assign in_begin=0,in_stop=0,in_num=0;
wire clk_4hz,pause;
wire[5:0]note;
wire[17:0] divnum;
reg playsignal;
assign led_rst=rst,led_sound=sound,led_pause=pause,led_playsignal=playsignal,led_stop=stop,led_begin=Begin,led_num1=num[1],led_num0=num[0];



always@(posedge Begin or posedge rst or posedge stop or negedge en or posedge clk)begin
if(rst) playsignal<=0;
else if(!en)playsignal<=0;
else if(Begin)playsignal<=1;
else if(stop)playsignal<=0;
else playsignal<=playsignal;
end

speed_control inst0(.clk(clk),.rst(rst),.clk_4hz(clk_4hz));

ROM inst1(.clk_4hz(clk_4hz),.rst(rst),.note(note),.pause(pause),.playsignal(playsignal),.num(num));

Divnum inst2(.note(note),.divnum(divnum));

Play inst3(.clk(clk),.rst(rst),.divnum(divnum),.pause(pause),.playsignal(playsignal),.sound(sound));
endmodule