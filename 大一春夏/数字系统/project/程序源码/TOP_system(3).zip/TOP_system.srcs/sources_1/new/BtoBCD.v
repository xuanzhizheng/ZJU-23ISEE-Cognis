`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/06/17 09:54:03
// Design Name: 
// Module Name: BtoBCD
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module BtoBCD(

 input[19:0]temp_data,
output[15:0] temp_BCD
    );
    assign temp_BCD[3:0]=temp_data%10;
    assign temp_BCD[7:4]=(temp_data%100)/10;
    assign temp_BCD[11:8]=(temp_data%1000)/100;
    assign temp_BCD[15:12]=temp_data/1000;
endmodule
