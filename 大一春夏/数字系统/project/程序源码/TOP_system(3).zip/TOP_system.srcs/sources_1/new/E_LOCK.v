`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/06/08 16:54:46
// Design Name: 
// Module Name: E_LOCK
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module E_LOCK(
    input clk, reset_in, b0_in, b1_in,en,
    output out,
    output [11:0] seg
    );
    reg b0_in_en,b1_in_en;
    always @(posedge clk or posedge reset_in or posedge en)begin
        if(reset_in)begin
            b0_in_en <= 0;
            b1_in_en <= 0;
            end
        else if(en) begin
            b0_in_en <= b0_in;
            b1_in_en <= b1_in;
        end  
    end
    wire [3:0] hex_display;
    wire reset, b0, b1;
    
    button b_reset(clk,reset_in,reset);
    button b_0(clk,b0_in_en,b0);
    button b_1(clk,b1_in_en,b1);
    
    LOCK L1(clk,reset,b0,b1,out,hex_display);
    segment seg1(hex_display,seg);
endmodule

