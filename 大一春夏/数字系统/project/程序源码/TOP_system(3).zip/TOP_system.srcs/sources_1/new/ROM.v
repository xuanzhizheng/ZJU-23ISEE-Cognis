`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/18 19:44:35
// Design Name: 
// Module Name: ROM
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ROM(
input clk_4hz,rst,playsignal,
output  pause,
input[1:0]num,
output reg[5:0]note
    );
    reg[31:0]s;
    reg [1:0]num_reg;
    
    always@(posedge clk_4hz or posedge rst )begin
    if(rst)begin s<=0;end
    else if(playsignal)begin 
         if(num_reg==num)s<=s+1;
         else begin s<=0; num_reg<=num;end
         end
    else begin s<=s;num_reg<=num_reg; end
    end

    assign pause=!note; 
    always@(*)begin
   case(num_reg)
   'd0://qinghuaci
    case(s)
    'd0:note=0;
    'd1:note='d12;
    'd2:note='d11;
    'd3:note='d06;
    'd4:note='d11;
    'd5:note='d11;
    'd6:note='d11;
    'd7:note='d06;
    'd8:note='d11;
    'd9:note='d11;
    'd10:note='d11;
    'd11:note='d06;
    'd12:note='d11;
    'd13:note='d06;
    'd14:note='d05;
    'd15:note='d05;
    'd16:note=0;
    'd17:note='d12;
    'd18:note='d11;
    'd19:note='d06;
    
    'd20:note='d11;
    'd21:note='d11;
    'd22:note='d11;
    'd23:note='d06;
    'd24:note='d11; 
    'd25:note='d11;
    'd26:note='d11;
    'd27:note='d13;
    'd28:note='d12;
    'd29:note='d11;
    'd30:note='d11;
    'd31:note='d11;
    'd32:note=0;
    'd33:note='d05;
    'd34:note='d06;
    'd35:note='d13;
    
    'd36:note='d13;
    'd37:note='d13;
    'd38:note='d13;
    'd39:note='d12;
    'd40:note='d13;
    'd41:note='d13;
    'd42:note='d13;
    'd43:note='d12;
    'd44:note='d13;
    'd45:note='d15;
    'd46:note='d13;
    'd47:note='d13;
    'd48:note=0;
    'd49:note='d13;
    'd50:note='d13;
    'd51:note='d13;
    
    'd52:note='d13;
    'd53:note='d12;
    'd54:note='d12;
    'd55:note='d12;
    'd56:note='d12;
    'd57:note='d12; 
    'd58:note='d11;
    'd59:note='d12;
    'd60:note='d13;
    'd61:note='d12;
    'd62:note='d12;
    'd63:note='d12; 
    endcase
    
    'd1://qingtian
    case(s)
    'd0:note=0;
    'd1:note=0;
    'd2:note='d15;
    'd3:note='d15;
    'd4:note='d15;
    'd5:note='d15;
    'd6:note='d11;
    'd7:note='d11; 
    'd8:note='d11;
    'd9:note='d11;
    'd10:note='d11;
    'd11:note='d11;
    'd12:note='d12;
    'd13:note='d12;
    'd14:note='d13;
    'd15:note='d13;
    
    'd16:note=0;
    'd17:note=0;
    'd18:note='d15;
    'd19:note='d15;
    'd20:note='d15;
    'd21:note='d15;
    'd22:note='d11;
    'd23:note='d11;
    'd24:note='d11;  
    'd25:note='d11;
    'd26:note='d12;
    'd27:note='d13;
    'd28:note='d12;
    'd29:note='d11;
    'd30:note='d05;
    
    'd31:note=0;
    'd32:note=0;
    'd33:note='d15;
    'd34:note='d15;
    'd35:note='d15; 
    'd36:note='d15;
    'd37:note='d11;
    'd38:note='d11;
    'd39:note='d11;
    'd40:note='d12;
    'd41:note='d12;
    'd42:note='d13;
    'd43:note='d13;
    
    'd44:note=0;
    'd45:note=0;
    'd46:note='d13;
    'd47:note='d13;
    'd48:note='d13;
    'd49:note='d13;
    'd50:note='d12;
    'd51:note='d13;
    'd52:note='d14;
    'd53:note='d13;
    'd54:note='d12;
    'd55:note='d14;
    'd56:note='d13;
    'd57:note='d12; 
    'd58:note='d11;
    'd59:note='d11;
    
    'd60:note='d05;
    'd61:note='d05;
    'd62:note='d11;
    'd63:note='d11; 
    'd64:note='d11;
    'd65:note='d11;
    'd66:note='d13;
    'd67:note='d13;
    'd68:note='d14;
    'd69:note='d14;
    'd70:note='d13;
    'd71:note='d13;
    'd72:note='d12;
    'd73:note='d12;
    'd74:note='d11;
    'd75:note='d12;
     
    'd76:note='d13;
    'd77:note='d13;
    'd78:note='d13;
    'd79:note='d13;
    'd80:note='d13;
    'd81:note='d13; 
    'd82:note='d13;
    'd83:note='d13;
    'd84:note='d12;
    'd85:note='d13;
    'd86:note='d12;
    'd87:note='d11;
    'd88:note='d11;
    'd89:note='d11;
    //'d90:circle=1;
    endcase
   
   'd2:   case(s)
   //erquanyingyue
    'd0:note=0;
    'd1:note=0;
    'd2:note=0;
    'd3:note='d16;
    'd4:note='d15;
    'd5:note='d16;
    'd6:note='d14;
    'd7:note='d13;
     
    'd8:note='d12;
    'd9:note='d12;
    'd10:note='d12;
    'd11:note='d12;
    'd12:note='d12;
    'd13:note='d12;
    'd14:note='d12;
    'd15:note='d12; 
    'd16:note='d12;
    'd17:note='d12;
    'd18:note='d12;
    'd19:note='d13;
    'd20:note='d11;
    'd21:note='d11;
    'd22:note='d11;
    'd23:note='d12;
    
    'd24:note='d13;  
    'd25:note='d13;
    'd26:note='d13;
    'd27:note='d13;
    'd28:note='d13;
    'd29:note='d13;
    'd30:note='d15;
    'd31:note='d15;
    'd32:note='d16;
    'd33:note='d16;
    'd34:note='d15;
    'd35:note='d15; 
    'd36:note='d16;
    'd37:note='d15;
    'd38:note='d16;
    'd39:note='d21;
    
    'd40:note='d15;
    'd41:note='d15;
    'd42:note='d15;
    'd43:note='d13;
    'd44:note='d15;
    'd45:note='d15;
    'd46:note='d15;
    'd47:note='d13;
    'd48:note='d12;
    'd49:note='d12;
    'd50:note='d16;
    'd51:note='d16;
    'd52:note='d15;
    'd53:note='d16;
    'd54:note='d11;
    'd55:note='d12;
    'd56:note='d13;
    'd57:note='d13; 
    'd58:note='d13;
    'd59:note='d13;
    
    'd60:note='d13;
    'd61:note='d13;
    'd62:note='d15;
    'd63:note='d15; 
    'd64:note='d12;
    'd65:note='d13;
    'd66:note='d15;
    'd67:note='d21;
    'd68:note='d16;
    'd69:note='d12;
    'd70:note='d13;
    'd71:note='d15;
    
    'd72:note='d11;
    'd73:note='d11;
    'd74:note='d11;
    'd75:note='d11;
    'd76:note='d11;
    'd77:note='d11;
    'd78:note='d11;
    'd79:note='d11;
    'd80:note='d21;
    'd81:note='d21; 
    'd82:note='d16;
    'd83:note='d21;
    'd84:note='d23;
    'd85:note='d23;
    'd86:note='d23;
    'd87:note='d22;
   // 'd88:circle=1;
   endcase
     
'd3:  case(s)   
     //liangzhu
    'd0:note='d03;
    'd1:note='d03;
    'd2:note='d03;
    'd3:note='d03;
    'd4:note='d03;
    'd5:note='d03;
    'd6:note='d03;
    'd7:note='d03; 
    'd8:note='d05;
    'd9:note='d05;
    'd10:note='d05;
    'd11:note='d05;
    'd12:note='d05;
    'd13:note='d05;
    'd14:note='d06;
    'd15:note='d06;
    
    'd16:note='d11;
    'd17:note='d11;
    'd18:note='d11;
    'd19:note='d11;
    'd20:note='d11;
    'd21:note='d11;
    'd22:note='d12;
    'd23:note='d12;
    'd24:note='d06;  
    'd25:note='d06;
    'd26:note='d11;
    'd27:note='d11;
    'd28:note='d05;
    'd29:note='d05;
    'd30:note='d05;
    'd31:note='d05;
   
    'd32:note='d15;
    'd33:note='d15;
    'd34:note='d15;
    'd35:note='d15; 
    'd36:note='d15;
    'd37:note='d15;
    'd38:note='d21;
    'd39:note='d21;
    'd40:note='d16;
    'd41:note='d16;
    'd42:note='d15;
    'd43:note='d15; 
    'd44:note='d13;
    'd45:note='d13;
    'd46:note='d15;
    'd47:note='d15;
    
    'd48:note='d12;
    'd49:note='d12;
    'd50:note='d12;
    'd51:note='d12;
    'd52:note='d12;
    'd53:note='d12;
    'd54:note='d12;
    'd55:note='d12;
    'd56:note='d12;
    'd57:note='d12; 
    'd58:note='d12;
    'd59:note='d12;
    'd60:note='d12;
    'd61:note='d12;
    'd62:note='d12;
    'd63:note='d12;
     
    'd64:note=0;
    'd65:note='d12;
    'd66:note='d12;
    'd67:note='d12;
    'd68:note='d12;
    'd69:note='d12;
    'd70:note='d13;
    'd71:note='d13;
    'd72:note='d07;
    'd73:note='d07;
    'd74:note='d07;
    'd75:note='d07; 
    'd76:note='d06;
    'd77:note='d06;
    'd78:note='d06;
    'd79:note='d06;
    
    'd80:note='d05;
    'd81:note='d05; 
    'd82:note='d05;
    'd83:note='d05;
    'd84:note='d05;
    'd85:note='d05;
    'd86:note='d06;
    'd87:note='d06;
    'd88:note='d11;
    'd89:note='d11;
    'd90:note='d11;
    'd91:note='d11;
    'd92:note='d12;
    'd93:note='d12;
    'd94:note='d12;
    'd95:note='d12;
    //'d96:circle=1;
    endcase
    
  
   
   
   endcase
    end
endmodule
