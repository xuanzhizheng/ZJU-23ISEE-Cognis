`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/18 14:41:44
// Design Name: 
// Module Name: Divnum
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Divnum(
input[5:0]note, 
output reg [31:0] divnum
    );
   
    always@(*)begin
    case(note)
     'd01 :divnum='d190837; //freq =    'd262;
     'd02 :divnum='d170068; //freq =    'd294;
     'd03 :divnum='d151515; //freq =    'd330;
     'd04 :divnum='d143266; //freq =    'd349;
     'd05 :divnum='d127551; //freq =    'd392;
     'd06 : divnum='d113636;//freq =    'd440;
     'd07 :divnum='d101214; //freq =    'd494;
      
     'd11 : divnum='d095602;//freq =    'd523;
     'd12 :divnum='d085179; //freq =    'd587;
     'd13 :divnum='d075872; //freq =    'd659;
     'd14 :divnum='d071530; //freq =    'd699;
     'd15 :divnum='d063775; //freq =    'd784;
     'd16 :divnum='d056818; //freq =    'd880;
     'd17 :divnum='d050607; //freq =    'd988;
      
     'd21 :divnum='d047619;// freq =    'd1050;
     'd22 :divnum='d042553; //freq =    'd1175;
     'd23 :divnum='d037907; //freq =    'd1319;
     'd24: divnum='d035790; //freq =    'd1397;
     'd25 :divnum='d031888; //freq =    'd1568;
     'd26 :divnum='d028409; //freq =    'd1760;
     'd27 :divnum='d025304; //freq =    'd1976;
      default :divnum='d190837;
    endcase
    end


    
endmodule