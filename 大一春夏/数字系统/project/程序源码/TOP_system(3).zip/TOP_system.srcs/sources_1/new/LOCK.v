`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/06/05 19:12:59
// Design Name: 
// Module Name: FSM
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module LOCK(
   input clk,reset,b0,b1,
   output out, 
   output [3:0] hex_display
   );
//����״̬
parameter S_RESET = 0; parameter S_1 = 1;
parameter S_10 = 2; parameter S_101 = 3;
parameter S_1010 = 4; parameter S_10101 = 5;

reg [2:0] state, next_state;
//��̬�߼�
   always@(*) begin
   if(reset) next_state = S_RESET;
   else case (state)
        S_RESET: next_state = b1 ? S_1  :b0 ? S_RESET:state;
        S_1:     next_state = b1 ? S_1  :b0 ? S_10   :state;
        S_10:    next_state = b1 ? S_101:b0 ? S_RESET:state;
        S_101:   next_state = b1 ? S_1  :b0 ? S_1010 :state;
        S_1010:  next_state = b0 ? S_101:b1 ? S_10101:state;
        S_10101: next_state = b0 ? S_1  :b1 ? S_RESET:state;
        default: next_state = S_RESET;
        endcase
    end
//��̬��ֵ
    always@(posedge clk) state<= next_state;
//���
    assign out = (state == S_10101);
    assign hex_display = {1'b0,state};
endmodule