`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/05/14 21:16:24
// Design Name: 
// Module Name: ADXL345
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module ADXL345(
  input                    sys_clk,
  input                    rst,
  output                   scl,
  inout                    sda,
//  output [3:0]             seg_control,
//  output [7:0]             Segs,
  output                   LEDx,
  output                   LEDx_neg,
  output                   LEDy,
  output                   LEDy_neg,
  output                   LEDz,
  output                   LEDz_neg,
  output                   Start,
  output                   Stop,
  output [1:0]             display,
  output                   Start_IO,
  output                   Stop_IO,
  output [1:0]             display_IO,
//--------------------------------------//
  output                   check,
  input  [3:0]             output_mux,
  output [3:0]             output_en1,
  output [3:0]             output_en2,
  input up,down,right,left,
  output up_IO,down_IO,right_IO,left_IO,
  output down_LED
);
assign up_IO=up;
assign down_IO=down;
assign down_LED=down_IO;
assign right_IO=right;
assign left_IO=left;
assign check=1;
assign output_en1=output_mux;
assign output_en2=output_en1;
wire [3:0]             seg_control;
wire [7:0]             Segs;
assign Start_IO=Start;
assign Stop_IO=Stop;
assign display_IO=display;
reg [2:0]cnt;//cnt=0��scl�����أ�cnt=1��scl�ߵ�ƽ�м䣻cnt=2��scl�½��أ�cnt=3��scl�͵�ƽ�м�   
reg [8:0]cnt_sum;//����IIC����Ҫ��ʱ��   
reg scl_r;//������ʱ������   
wire sys_rst_n;
clk_div #(.N(1500_0000)) c1 (.clk(sys_clk),.reset(rst),.clk_div(sys_rst_n));//sys_rst_n 0.3s read
reg [19:0]cnt_10ms;   
  
always@(posedge sys_clk or negedge sys_rst_n)begin   
if(!sys_rst_n)    
    cnt_10ms <= 20'd0;   
else  
    cnt_10ms <= cnt_10ms+1'b1;  
end	 
/*****************************************************/ 
//����Ϊ50MHZ��499Ϊ10usʱ�䣬��ΪSCL��һ��ʱ�����ڡ�
always@(posedge sys_clk or negedge sys_rst_n)begin   
    if(!sys_rst_n)    
        cnt_sum <= 0;   
    else if(cnt_sum ==9'd499)   
        cnt_sum <= 0;   
    else  
        cnt_sum <= cnt_sum+1'b1;   
end   
 /****************************************************/  
/*****************************************************/ 
//10us��SCLʱ�����ڷ�Ϊ�ĸ����֣��ֱ�Ϊ���ߵ�ƽ�м䣨�����ݣ����½��أ��͵�ƽ�м䣨����д���ݣ�
always@(posedge sys_clk or negedge sys_rst_n) begin   
    if(!sys_rst_n)   
        cnt <= 3'd5;   
    else begin   
            case(cnt_sum)   
            9'd124: cnt<=3'd1;//�ߵ�ƽ�м�   
            9'd249: cnt<=3'd2;//�½���   
            9'd374: cnt<=3'd3;//�͵�ƽ�м�   
            9'd499: cnt<=3'd0;//������   
            default: cnt<=3'd5;   
            endcase   
    end   
end   
 
`define SCL_POS (cnt==3'd0)   
`define SCL_HIG (cnt==3'd1) //�ߵ�ƽ�м�  
`define SCL_NEG (cnt==3'd2)   
`define SCL_LOW (cnt==3'd3) //�͵�ƽ�м� 
/****************************************************/
// ���ݴ��䣺SCLΪ�ߵ�ƽʱ��SDA���������ȶ�����ôSDA�����ڴ�������bit��
//   ��SDA�������䣬��������ʾһ���Ự�Ŀ�ʼ����������潲��
 //  ���ݸı䣺SCLΪ�͵�ƽʱ��SDA�߲��ܸı䴫���bit
 
always@(posedge sys_clk or negedge sys_rst_n)begin   
    if(!sys_rst_n)   
        scl_r <= 1'b0;   
    else if(cnt==3'd0)   
        scl_r <= 1'b1;   
    else if(cnt==3'd2)   
        scl_r <= 1'b0;   
end   
  
assign scl = scl_r;//sclʱ���ź�   
  
`define DEVICE_READ 8'hA7//Ѱַ������������   
`define DEVICE_WRITE 8'hA6//Ѱַ������д���� 
`define devid_d 8'h00 //���Զ�ȡ�����Ƿ���ȷ����Ϊ0XE5����ȷ
`define ACC_XL 8'h32//���ٶ�x���λ��ַ   
`define ACC_XH 8'h33//���ٶ�x���λ��ַ   
`define ACC_YL 8'h34//���ٶ�y���λ��ַ   
`define ACC_YH 8'h35//���ٶ�y���λ��ַ   
`define ACC_ZL 8'h36//���ٶ�z���λ��ַ   
`define ACC_ZH 8'h37//���ٶ�z���λ��ַ   
//`define GYRO_XH 8'h43//������x���λ��ַ   
//`define GYRO_XL 8'h44//������x���λ��ַ   
//`define GYRO_YH 8'h45//������y���λ��ַ   
//`define GYRO_YL 8'h46//������y���λ��ַ   
//`define GYRO_ZH 8'h47//������z���λ��ַ   
//`define GYRO_ZL 8'h48//������z���λ��ַ       
  
//��ʼ���Ĵ�����ַ   
`define DATA_FORMAT 8'h31   
`define BW_RATE 8'h2C   
`define POWER_CTL 8'h2D   
`define INT_ENABLE 8'h2E  

//��ʼ���Ĵ���   
`define DATA_FORMAT_VAL 8'h0B   
`define BW_RATE_VAL 8'h08   
`define POWER_CTL_VAL 8'h08   
`define INT_ENABLE_VAL 8'h80  
  
parameter IDLE = 4'd0;   
parameter START1 = 4'd1;    
parameter ADD1 = 4'd2;   
parameter ACK1 = 4'd3;   
parameter ADD2 = 4'd4;   
parameter ACK2 = 4'd5;   
parameter START2 = 4'd6;   
parameter ADD3 =4'd7;   
parameter ACK3 = 4'd8;   
parameter DATA = 4'd9;   
parameter ACK4 = 4'd10;   
parameter STOP1 = 4'd11;   
parameter STOP2 = 4'd12;   
parameter ADD_EXT = 4'd13;   
parameter ACK_EXT = 4'd14;   
  
reg [3:0]state;//״̬�Ĵ���   
reg sda_r;//���   
reg sda_link;//sda_link=1,sda���;sda_link=0,sda����̬   
reg [3:0]num;   
reg [7:0]db_r; 
reg [7:0]devid; 
reg signed [7:0]ACC_XL_READ;//�洢���ٶ�X��߰�λ   
reg signed [7:0]ACC_XH_READ;//�洢���ٶ�X��Ͱ�λ   
reg signed [7:0]ACC_YL_READ;//�洢���ٶ�Y��߰�λ   
reg signed [7:0]ACC_YH_READ;//�洢���ٶ�Y��Ͱ�λ   
reg signed [7:0]ACC_ZL_READ;//�洢���ٶ�Z��߰�λ   
reg signed [7:0]ACC_ZH_READ;//�洢���ٶ�Z��Ͱ�λ   
 
reg [4:0]times;//��¼�ѳ�ʼ�����õļĴ�������   
  
always@(posedge sys_clk or negedge sys_rst_n)begin   
    if(!sys_rst_n) begin   
        state <= IDLE;   
        sda_r <= 1'b1;//����������   
        sda_link <= 1'b0;//����̬   
        num <= 4'd0;   
        //��ʼ���Ĵ���
	     devid<=8'h00;	  
        ACC_XL_READ <= 8'h00;   
        ACC_XH_READ <= 8'h00;   
        ACC_YL_READ <= 8'h00;   
        ACC_YH_READ <= 8'h00;   
        ACC_ZL_READ <= 8'h00;   
        ACC_ZH_READ <= 8'h00;   
         
        times <= 5'b0;   
    end   
    else  
        case(state)   
        IDLE: begin   
                    times <= times+1'b1;   
                    sda_link <= 1'b1;//sdaΪ���   
                    sda_r <= 1'b1;//����sda   
                    db_r <= `DEVICE_WRITE;//��ӻ�д��������ַ   
                    state = START1;   
                end   
       START1:begin//IIC start   
                    if(`SCL_HIG)//sclΪ�ߵ�ƽ   
                    begin   
                        sda_link <= 1'b1;//sda���   
                        sda_r <= 1'b0;//����sda������start�ź�   
                        state <= ADD1;   
                        num <= 4'd0;   
                    end   
                    else  
                        state <= START1;   
                end   
        ADD1: begin//����д��   
                    if(`SCL_LOW)//sclΪ�͵�ƽ   
                    begin   
                        if(num == 4'd8)//��8λȫ�����   
                        begin   
                            num <= 4'd0;//��������   
                            sda_r <= 1'b1;   
                            sda_link <= 1'b0;//sda����̬   
                            state <= ACK1;   
                        end   
                        else  
                        begin   
                            state <= ADD1;   
                            num <= num+1'b1;   
                            sda_r <= db_r[4'd7-num];//��λ���   
                        end   
                    end   
                    else  
                        state <= ADD1;   
                end   
        ACK1: begin//Ӧ��   
                    if(`SCL_NEG)   					//Ӧ���źţ���������ַ������Ϻ�����Ҫ��ӻ�Ҫһ��Ӧ���źţ�
													//������ʾ�ӻ��Ѿ����յ����������͵����ݣ�
													//���һ��ʱ��������û���յ��ӻ�������Ӧ���źţ�������Ĭ�ϴӻ��յ����������͵����ݡ�
													//��������������״̬���ȴ�һ��ʱ�����ڣ���ΪӦ��ȴ�ʱ�䣬
                    begin   
                        state <= ADD2;   
                        case(times)//ѡ����һ��д��Ĵ�����ַ   
                            5'd1: db_r <= `DATA_FORMAT;   
                            5'd2: db_r <= `BW_RATE;   
                            5'd3: db_r <= `POWER_CTL;   
                            5'd4: db_r <= `INT_ENABLE;
									 5'd5: db_r <= `devid_d;
                            5'd6: db_r <= `ACC_XL;   
                            5'd7: db_r <= `ACC_XH;   
                            5'd8: db_r <= `ACC_YL;   
                            5'd9: db_r <= `ACC_YH;   
                            5'd10: db_r <= `ACC_ZL;   
                            5'd11: db_r <= `ACC_ZH;   
                            default: begin   
                                db_r <= `DATA_FORMAT;   
                                times <= 5'd1;   
                            end   
                        endcase   
                    end   
                    else  
                        state <= ACK1;//�ȴ���Ӧ   
                end   
        ADD2: begin   
                    if(`SCL_LOW)//sclΪ��   
                    begin   
                        if(num == 4'd8)   
                        begin   
                            num <= 4'd0;   
                            sda_r <= 1'b1;   
                            sda_link <= 1'b0;   
                            state <= ACK2;   
                        end   
                        else  
                        begin   
                            sda_link <= 1'b1;   
                            state <= ADD2;   
                            num <= num+1'b1;   
                            sda_r <= db_r[4'd7-num];//��λ�ͼĴ�����ַ   
                        end   
                    end   
                    else  
                        state <= ADD2;   
                end   
        ACK2: begin//Ӧ��   
                    if(`SCL_NEG)   
                    begin   
                        case(times)//��Ӧ�Ĵ������趨ֵ   
                            3'd1: db_r <= `DATA_FORMAT_VAL;   
                            3'd2: db_r <= `BW_RATE_VAL;   
                            3'd3: db_r <= `POWER_CTL_VAL;   
                            3'd4: db_r <= `INT_ENABLE_VAL;   
                            3'd5: db_r <= `DEVICE_READ;   
                            default: db_r <= `DEVICE_READ;   
                        endcase   
                        if(times >= 5'd5)   
                            state <= START2;   
                        else  
                            state <= ADD_EXT;   
                    end   
                    else  
                        state <= ACK2;//�ȴ���Ӧ   
                end   
        ADD_EXT:begin//��ʼ��һЩ�趨�Ĵ���   
                    if(`SCL_LOW)   
                    begin   
                        if(num == 4'd8)   
                        begin   
                            num <= 4'd0;   
                            sda_r <= 1'b1;   
                            sda_link <= 1'b0;//sda����̬   
                            state <= ACK_EXT;   
                        end   
                        else  
                        begin   
                            sda_link <= 1'b1;   
                            state <= ADD_EXT;   
                            num <= num+1'b1;   
                            sda_r <= db_r[4'd7-num];//��λ�趨�Ĵ���������ʽ   
                        end   
                    end   
                    else  
                        state <= ADD_EXT;   
                end   
        ACK_EXT:begin   
                    if(`SCL_NEG)   
                    begin   
                        sda_r <= 1'b1;//����sda   
                        state <= STOP1;   
                    end   
                    else  
                        state <= ACK_EXT;//�ȴ���Ӧ   
                end   
        START2:begin   
                    if(`SCL_LOW)//sclΪ��   
                    begin   
                        sda_link <= 1'b1;//sdaΪ���   
                        sda_r <= 1'b1;//����sda   
                        state <= START2;   
                    end   
                    else if(`SCL_HIG)//sclΪ��   
                    begin   
                        sda_r <= 1'b0;//����sda������start�ź�   
                        state <= ADD3;   
                    end   
                    else    
                        state <= START2;   
                end   
        ADD3: begin   
                    if(`SCL_LOW)//sclλ��   
                    begin   
                        if(num == 4'd8)   
                        begin   
                            num <= 4'd0;   
                            sda_r <= 1'b1;//����sda   
                            sda_link <= 1'b0;//scl����̬   
                            state <= ACK3;   
                        end   
                        else  
                        begin   
                            num <= num+1'b1;   
                            sda_r <= db_r[4'd7-num];//��λд���ȡ�Ĵ�����ַ   
                            state <= ADD3;   
                        end   
                    end   
                    else state <= ADD3;   
                end   
        ACK3: begin   
                    if(`SCL_NEG)   
                    begin   
                        state <= DATA;   
                        sda_link <= 1'b0;//sda����̬   
                    end   
                    else  
                        state <= ACK3;//�ȴ���Ӧ   
                end   
        DATA: begin   
                    if(num <= 4'd7)   
                    begin   
                        state <= DATA;   
                        if(`SCL_HIG)   
                        begin   
                            num <= num+1'b1;   
                            case(times)
										            5'd5: devid[4'd7-num] <= sda;
                                5'd6: ACC_XL_READ[4'd7-num] <= sda;   
                                5'd7: ACC_XH_READ[4'd7-num] <= sda;   
                                5'd8: ACC_YL_READ[4'd7-num] <= sda;   
                                5'd9: ACC_YH_READ[4'd7-num] <= sda;   
                                5'd10: ACC_ZL_READ[4'd7-num] <= sda;   
                                5'd11: ACC_ZH_READ[4'd7-num] <= sda;   
                                default: ;//��ʱδ���ǣ������Ӵ������ϵͳ�ȶ���   
                            endcase   
                        end   
                    end   
                    else if((`SCL_LOW)&&(num == 4'd8))   
                    begin   
                        sda_link <= 1'b1;//sdaΪ���   
                        num <= 4'd0;//��������   
                        state <= ACK4;   
                    end   
                    else  
                        state <= DATA;   
                end   
        ACK4: begin   
                    if(times == 5'd11)   
                        times <= 5'd0;   
                    if(`SCL_NEG)   
                    begin   
                        sda_r <= 1'b1;//����sda   
                        state <= STOP1;   
                    end   
                    else  
                        state <= ACK4;//�ȴ���Ӧ   
                end   
        STOP1:begin   
                    if(`SCL_LOW)//sclΪ��   
                    begin   
                        sda_link <= 1'b1;//sda���   
                        sda_r <= 1'b0;//����sda   
                        state <= STOP1;   
                    end   
                    else if(`SCL_HIG)//sdaΪ��   
                    begin   
                        sda_r <= 1'b1;//����sda,����stop�ź�   
                        state <= STOP2;   
                    end   
                    else  
                        state <= STOP1;   
                end   
        STOP2:begin   
                    if(`SCL_LOW)   
                    sda_r <= 1'b1;   
                    else if(cnt_10ms == 20'hffff0)//Լ10ms��һ������   
                        state <= IDLE;   
                    else  
                        state <= STOP2;   
                end   
        default:state <= IDLE;   
        endcase   
end   
//�洢X,Y,Z��������ݣ�Ȼ��ת��Ϊ����
reg signed [15:0] ACC_X_DATA;
reg signed [15:0] ACC_Y_DATA;
reg signed [15:0] ACC_Z_DATA;
always @(posedge sys_clk or negedge sys_rst_n)begin
  if(!sys_rst_n)  begin
    ACC_X_DATA<=16'b0;
    ACC_Y_DATA<=16'b0;
    ACC_Z_DATA<=16'b0;
  end
  else begin
    ACC_X_DATA[15:8]<=ACC_XH_READ[7:0];
    ACC_X_DATA[7:0] <=ACC_XL_READ[7:0];
    ACC_Y_DATA[15:8]<=ACC_YH_READ[7:0];
    ACC_Y_DATA[7:0] <=ACC_YL_READ[7:0];
    ACC_Z_DATA[15:8]<=ACC_ZH_READ[7:0];
    ACC_Z_DATA[7:0] <=ACC_ZL_READ[7:0];
  end
end
//���ｫ����ת��Ϊ��������Ҫ��չ����λ??
reg [16:0] x_data;
reg [16:0] y_data;
reg [16:0] z_data;
always@(posedge sys_clk or negedge sys_rst_n)begin
  if(!sys_rst_n)begin
   x_data<=17'b0;
   y_data<=17'b0;
   z_data<=17'b0;
  end
  else begin
    if(ACC_X_DATA[15]==1'b1)begin x_data<={ACC_X_DATA[15],-ACC_X_DATA};end
    else begin x_data<={ACC_X_DATA[15],ACC_X_DATA};end
    if(ACC_Y_DATA[15]==1'b1)begin y_data<={ACC_Y_DATA[15],-ACC_Y_DATA};end
    else begin y_data<={ACC_Y_DATA[15],ACC_Y_DATA};end
    if(ACC_Z_DATA[15]==1'b1)begin z_data<={ACC_Z_DATA[15],-ACC_Z_DATA};end
    else begin z_data<={ACC_Z_DATA[15],ACC_Z_DATA};end
  end
end

assign sda = sda_link?sda_r:1'bz;
//assign data={ACC _XH_READ[7:0],ACC_XL_READ[7:0],ACC_YH_READ[7:0],ACC_YL_READ[7:0],ACC_ZH_READ[7:0],ACC_ZL_READ[7:0]}; 

//delay
reg [16:0] x_data_delay,y_data_delay,z_data_delay;
always @(negedge sys_rst_n) begin
    y_data_delay <= y_data;
    x_data_delay <= x_data;
    z_data_delay <= z_data;
end

//readdata and slight
readdata rx(.data_delay(x_data_delay),.LED(LEDx),.LED_neg(LEDx_neg));
readdata ry(.data_delay(y_data_delay),.LED(LEDy),.LED_neg(LEDy_neg));
readdata_slight rz(.data_delay(z_data_delay),.sys_clk(sys_clk),.rst(rst),
.LED(LEDz),.LED_neg(LEDz_neg),.seg_control(seg_control),.Segs(Segs));

//musicdisplay
wire next,last;
assign Start=LEDz;
assign Stop=LEDz_neg;
assign next=LEDy_neg;
assign last=LEDy;

music_display m1 (.next(next),.last(last),.clk(sys_clk),.reset(rst),.display(display));
endmodule

module music_display(
    input next,last,clk,reset,
    output [1:0] display
);
    reg [2:0] state,next_state;
    wire done;
    reg rst_count;
    
    reg mux,displayload;
    wire [1:0] de_display,in_display,display_in;
    always @(*) begin
            case(state)
                0:begin 
                  if(next) next_state=1;
                  else if(last) next_state=2;
                  else next_state=0;
                  end
                1:next_state=3;
                2:next_state=3;
                3:next_state=4;
                4:begin if(done)next_state=0;
                        else next_state=4;
                        end
                endcase
        end
    always @(posedge clk or posedge reset) begin
        if(reset) state=2'b00;
        else state=next_state;
    end
    always @(*)begin
        case(state)
            0:begin
                mux=0;
                displayload=0;
                rst_count=1;
                end
            1:begin
                mux=0;
                displayload=1;
                rst_count=1;
              end  
            2:begin
                mux=1;
                displayload=1;
                rst_count=1;
                end
            3:begin
                mux=1;
                displayload=0;
                rst_count=1;
                end
            4:begin
                mux=0;
                displayload=0;
                rst_count=0;
                end
            default:begin
                mux=0;
                displayload=0;
                rst_count=1;
            end
        endcase
    end
count #(.N(1_5000_0000)) c1 (.reset(rst_count),.clk(clk),.done(done));

mux2to1 #(.N(2)) m1(.mux(mux),.ina(de_display),.inb(in_display),.out(display_in));
Increment #(.N(2)) PCinc(.IncInput(display),.IncOutput(in_display));
Decrement #(.N(2)) Adec(.DecInput(display),.DecOutput(de_display));
Register #(.N(2)) Areg(.clk(clk),.load(displayload),.clear(reset),.loaddata(display_in),.outdata(display));
endmodule

module mux2to1
#( parameter N = 8 )
(
    input mux,
    input [N-1:0] ina,inb,
    output reg [N-1:0] out
);
always @(*) begin
    if(mux)
    out <= ina;
    else
    out <= inb;
end
endmodule

module Register
#( parameter N = 8 )
(
    input clk,load,clear,
    input [N-1:0] loaddata,
    output reg [N-1:0] outdata
);
always @(posedge clk or posedge clear) begin
    if(clear)
    outdata <= 0;
    else if(load)
    outdata <= loaddata;
end
endmodule

module Decrement
#( parameter N = 8 )
(
    input [N-1:0] DecInput,
    output [N-1:0] DecOutput
);
assign DecOutput=DecInput-1;
endmodule

module Increment
#( parameter N = 8 )
(
    input [N-1:0] IncInput,
    output [N-1:0] IncOutput
);
assign IncOutput=IncInput+1;
endmodule

module slight
#(  parameter N=8
)
(
    input [N-1:0] O1,O2,O3,O4,
    input clk,reset,
    output reg [3:0] seg_control,
    output reg [N-1:0] O
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            seg_control=4'b1110;
        else case(seg_control)
            4'b1110:begin seg_control=4'b0111; O=O1;end
            4'b0111:begin seg_control=4'b1011; O=O2;end
            4'b1011:begin seg_control=4'b1101; O=O3;end
            4'b1101:begin seg_control=4'b1110; O=O4;end
        endcase
    end
endmodule

module LED(
input [3:0]I,
output reg [7:0]Segs
);
always @(I)begin
    case (I)
    0:Segs= 8'b00000011;
    1:Segs= 8'b10011111;
    2:Segs= 8'b00100101;
    3:Segs= 8'b00001101;
    4:Segs= 8'b10011001;
    5:Segs= 8'b01001001;
    6:Segs= 8'b01000001;
    7:Segs= 8'b00011111;
    8:Segs= 8'b00000001;
    9:Segs= 8'b00011001;
    10:Segs=8'b00000010;//0.
    11:Segs= 8'b10011110;//1.
    12:Segs= 8'b00100100;//2.
    13:Segs= 8'b00001100;//3.
    14:Segs= 8'b11111101;//-
    15:Segs= 8'b00001001;//g
    default:Segs= 8'b11111111;
    endcase
end
endmodule

module clk_div
#(
    parameter N=1_0000_0000
)
(
    input clk,reset,
    output reg clk_div
);
//synthesis: 2s:1_0000_0000 2ms:10_0000
reg [28:0] count;
//2_6843_5456
always @(posedge clk or posedge reset) begin
    if(reset) begin clk_div<=0;count<=0; end
    else if(count<N) count<=count+1;
    else if(count==N) begin count=0;clk_div=~clk_div; end
end
endmodule

module readdata(
    input [16:0] data_delay,
    output LED,
    output LED_neg
);
wire [3:0] O1,O2,O3;
wire [3:0] Oint,Ofrac;
assign Oint=8*data_delay[11]+4*data_delay[10]+2*data_delay[9]+data_delay[8];
assign Ofrac=(50000*data_delay[7]+25000*data_delay[6]+12500*data_delay[5]+6250*data_delay[4]+3125*data_delay[4])/10000;
assign O1[3]=data_delay[16];
assign O1[2]=data_delay[16];
assign O1[1]=data_delay[16];
assign O2=Oint%10;
assign O3=Ofrac;
assign LED=~O1[3]&(O2[3]|O2[2]|O2[1]|O2[0]|O3[3]);
assign LED_neg=O1[3]&(O2[3]|O2[2]|O2[1]|O2[0]|O3[3]);
endmodule

module readdata_slight(
    input [16:0] data_delay,
    input sys_clk,rst,
    output LED,
    output LED_neg,
    output [3:0]  seg_control,
    output [7:0]  Segs
);
wire [3:0] O1,O2,O3,O4,O,O2_dot;
wire [3:0] Oint,Ofrac;
assign Oint=8*data_delay[11]+4*data_delay[10]+2*data_delay[9]+data_delay[8];
assign Ofrac=(50000*data_delay[7]+25000*data_delay[6]+12500*data_delay[5]+6250*data_delay[4]+3125*data_delay[4])/10000;
assign O1[3]=data_delay[16];
assign O1[2]=data_delay[16];
assign O1[1]=data_delay[16];
assign O2=Oint%10;
assign O2_dot=O2+10;
assign O3=Ofrac;
assign O4=15;
wire  clk_2ms;
assign LED=~O1[3]&(O2[3]|O2[2]|O2[1]|O2[0]|O3[3]);
assign LED_neg=O1[3]&(O2[3]|O2[2]|O2[1]|O2[0]|O3[3]);
clk_div #(.N(10_0000)) c2(.clk(sys_clk),.reset(rst),.clk_div(clk_2ms));
slight #(.N(4)) s2(.O1(O1),.O2(O2_dot),.O3(O3),.O4(O4),
.clk(clk_2ms),.reset(rst),.seg_control(seg_control),.O(O));
LED L1(.I(O),.Segs(Segs));
endmodule

module count
#(
    parameter N=100
)
(
    input reset,clk,
    output reg done
);
reg [30:0] count; //5_0000_0000
always @(posedge clk or posedge reset) begin
    if(reset)begin
        count=0;
        done=0;
        end
    else if(count==N) begin
        done=1;
        count=0;
        end
    else
        count=count+1;
    end
// clk=100MHz N=1_0000_0000 ?s
endmodule