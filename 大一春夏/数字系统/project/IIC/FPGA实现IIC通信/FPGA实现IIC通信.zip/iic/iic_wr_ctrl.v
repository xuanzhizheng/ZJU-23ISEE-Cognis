module iic_wr_ctrl
(
	input sys_clk,//系统时钟
	input rst_n,//系统夏位信号 
	input key_wr,//写按键信号
	input key_rd,//读按键信号
	inout sda,//EEPROM串行双向数据信号
	output reg scl,//EEPROM串行时钟信号
	output reg[7:0]data,//数据采集信号寄存器
	output reg[3:0]led//写入指示信号
);
	reg[6:0]cnt;//分频计数器
	reg[3:0]count;//数据移位寄存器
	reg clk;//协议触发时钟信号
	reg wr;//写标志信号
	reg rd;//读标志型号
	reg link_sda;//总线开关
	reg sda_buf;//总线数据寄存器
	reg[7:0]eeprom_data;//预发送数据
	reg[3:0]state;//状态寄存器
	

	//--------------------------------------------------------------------------
	//取得总线控制权时，总线信号就等于sda_buf，释放总线控制权后，将总线设置为高阻态
	assign sda=(link_sda)?sda_buf:1'bz;

	//--------------------------------------------------------------------------
	//分频计数，产生c1k状态跳转时钟
	always @(posedge sys_clk or posedge rst_n) begin
		if(!rst_n)
		begin 
			cnt<=0;
			clk<=0;
		end 
	else if(cnt<125)
		cnt <=cnt+1;
	else 
		begin
		cnt<=0;
		clk<=~clk;
		end
	end

	//--------------------------------------------------------------------------
	//用clk触发，产生EEPROM串行时钟信号
	always @(negedge clk or negedge rst_n)
	begin 
		if(!rst_n)
			scl<=0;
		else
			scl<=~scl;
	end

	//--------------------------------------------------------------------------
	//利用状态机控制写和读的状态转换
	always @(posedge clk or negedge rst_n) 		//用clk触发，可以保证在scl高电平或者
	begin
		if (!rst_n) 							//低电平中间的稳定期间进行数据的采集或变化
			begin
				state<=0;
				wr<=0;
				rd<=0;
				count<=0;
				link_sda<=0;
				sda_buf<=0;
				data<=0;
				eeprom_data<=0;
				led<=4'b0000;
			end


		else
			begin
				case(state)
					0:begin
						if (!key_rd)
							rd<=1;
						else if(!key_wr)
							wr<=1;
						if (!scl&&(rd||wr)) 
							begin
								link_sda<=1;
								sda_buf<=1;
								state<=1;
							end 
						else 
							state<=0;
					end
					1:begin//发送启动信号
						if (scl) 
							begin
								sda_buf<=0;
								state<=2;
								eeprom_data<=8'b1010_0000;
							end
						else 
							state<=1;
					end
					2:begin//发送器件地址
						if(!scl&&count<8)
							begin
								count<=count+1;
								eeprom_data<={eeprom_data[6:0],eeprom_data[7]};
								sda_buf<=eeprom_data[7];
							end
						else if(count==8&&!scl)
							begin
								count<=0;
								link_sda<=0;
								state<=3;
							end
						else
							state<=2;
					end
					3:begin//检测应答信号
						if(scl)
							/*begin*/
								/*if (sda)*/
									begin
									state<=4;
									eeprom_data<=8'b0000_0011;
									end
							/*end*/
					end
					4:begin//发送字地址
						link_sda<=1;
						if (count<8&&!scl)
							begin
							count<=count+1;
							eeprom_data<={eeprom_data[6:0],eeprom_data[7]};
							sda_buf<=eeprom_data[7];
							end
						else if (count==8&&!scl) 
							begin
							count<=0;
							state<=5;
							link_sda<=0;
							end
						else 
							state<=4;
					end
					5:begin//检测应答信号
						if (scl) begin
							begin
								if (wr==1) begin
									state<=6;
									eeprom_data<=~8'b0100_1111;
								end
							else if (rd==1) begin
								state<=9;
								end	
							end
						end
					end
					6:begin//写入数据
						link_sda<=1;
						if (!scl&&count<8) begin
							count<=count+1;
							eeprom_data<={eeprom_data[6:0],eeprom_data[7]};
							sda_buf<=eeprom_data[7];
						end
						else if (!scl&&count==8) begin
							count<=0;
							link_sda<=0;
							state<=7;
						end
						else  state<=6;
					end
					7:begin//检测应答信号
						/*if (scl) begin
							if (!sda) begin
								state<=8;
							end
						end*/
						state<=8;
					end
					8:begin//发送停止信号
						link_sda<=1;
						sda_buf<=0;
						if (scl) begin
							sda_buf<=1;
							led<=4'b0001;
							wr<=0;
							state<=0;
						end
						else state<=8;
					end
					9:begin//获得总线控制权
						if (!scl) begin
								link_sda<=1;
								sda_buf<=1;
								state<=10;
							end
						else state<=9;
					end
					10:begin//发送启动信号
						if (scl) begin
							sda_buf<=0;
							state<=11;
							eeprom_data<=8'b1010_0001;
						end
						else begin
							state<=10;
						end
					end
					11:begin//发送器件地址
						if (!scl&&count<8) begin
							count<=count+1;
							eeprom_data<={eeprom_data[6:0],eeprom_data[7]};
							sda_buf<=eeprom_data[7];
						end
						else if (count==8&&!scl) begin
							count<=0;
							link_sda<=0;
							state<=12;
						end
						else state<=11;
					end
					12:begin//检测应答信号
						if (scl) begin
							/*if(!sda)*/
								state<=13;
						end
					end
					13:begin//接受数据
						if (scl&&count<8) begin
							count<=count+1;
							data[7-count]<=sda;
						end
						else if (count==8) begin
							count<=0;
							state<=14;
							sda_buf<=1;
							link_sda<=1;
						end
						else state<=13;
					end
					14:begin//发送应答信号
						if (scl) begin
							sda_buf<=1;
							state<=15;
						end
						else begin
							state<=14;
						end
					end
					15:begin
						if (!scl) begin
							sda_buf<=0;
						end
						else if (scl) begin
							sda_buf<=1;
							state<=0;
							rd<=0;
							led<=4'b0000;
						end
						else begin
							state<=15;
						end
					end
					default:state<=0;
				endcase
			end
	end
endmodule