`timescale 1ns/1ns
module iic_wr_ctrl_tb;
	reg sys_clk;
	reg rst_n;
	reg key_wr;
	reg key_rd;

	wire scl;
	wire [7:0] data;
	wire [3:0]led;

	wire sda;
	always  #10 sys_clk=~sys_clk;
	iic_wr_ctrl uiic_wr_ctrl(
		.sys_clk(sys_clk),
		.rst_n(rst_n),
		.key_wr(key_wr),
		.key_rd(key_rd),
		.sda(sda),
		.scl(scl),
		.data(data),
		.led(led));
	initial begin
		sys_clk=0;
		rst_n=0;
		key_rd=0;
		key_wr=0;
		#100;
		rst_n=1;
		#120;
		key_wr=1;
		#5020;
		key_wr=0;
		#400020;
		key_rd=1;
		#5020;
		key_rd=0;
	end
endmodule